#-*- coding=utf-8 -*-
"""

A wrapper for CTP's Api library
author: Lvsoft@gmail.com
date: 2010-07-20

This file is part of python-ctp library

python-ctp is free software; you can redistribute it and/or modify it
under the terms of the GUL Lesser General Public License as published
by the Free Software Foundation; either version 2.1 of the License, or
(at your option) any later version.

python-ctp is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY of FITNESS FOR A PARTICULAR PURPOSE. See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along the python-ctp; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
02110-1301 USA
"""

#This file is auto generated! Please don't edit directly.
class CThostFtdcQryTradingAccountField:
    def __init__(self, InvestorID="", BrokerID=""):
        self.InvestorID=InvestorID
        self.BrokerID=BrokerID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['InvestorID', 'BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('InvestorID', u'投资者代码'),('BrokerID', u'经纪公司代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcMarketDataUpdateTimeField:
    def __init__(self, UpdateMillisec=0, ActionDay="", InstrumentID="", UpdateTime=""):
        self.UpdateMillisec=UpdateMillisec
        self.ActionDay=ActionDay
        self.InstrumentID=InstrumentID
        self.UpdateTime=UpdateTime
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['UpdateMillisec', 'ActionDay', 'InstrumentID', 'UpdateTime']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('UpdateMillisec', u'最后修改毫秒'),('ActionDay', u'业务日期'),('InstrumentID', u'合约代码'),('UpdateTime', u'最后修改时间')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryTraderOfferField:
    def __init__(self, ParticipantID="", TraderID="", ExchangeID=""):
        self.ParticipantID=ParticipantID
        self.TraderID=TraderID
        self.ExchangeID=ExchangeID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ParticipantID', 'TraderID', 'ExchangeID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ParticipantID', u'会员代码'),('TraderID', u'交易所交易员代码'),('ExchangeID', u'交易所代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcSyncingInstrumentTradingRightField:
    def __init__(self, TradingRight='0', InvestorRange='1', InvestorID="", InstrumentID="", BrokerID=""):
        self.TradingRight=TradingRight
        self.InvestorRange=InvestorRange
        self.InvestorID=InvestorID
        self.InstrumentID=InstrumentID
        self.BrokerID=BrokerID
        self.vcmap={'TradingRight': {"'2'": '不能交易', "'0'": '可以交易', "'1'": '只能平仓'}, 'InvestorRange': {"'2'": '投资者组', "'3'": '单一投资者', "'1'": '所有'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['TradingRight', 'InvestorRange', 'InvestorID', 'InstrumentID', 'BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('TradingRight', u'交易权限'),('InvestorRange', u'投资者范围'),('InvestorID', u'投资者代码'),('InstrumentID', u'合约代码'),('BrokerID', u'经纪公司代码')]])
    def getval(self, n):
        if n in ['TradingRight', 'InvestorRange']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcFensUserInfoField:
    def __init__(self, LoginMode='0', BrokerID="", UserID=""):
        self.LoginMode=LoginMode
        self.BrokerID=BrokerID
        self.UserID=UserID
        self.vcmap={'LoginMode': {"'0'": '交易', "'1'": '转账'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['LoginMode', 'BrokerID', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('LoginMode', u'登录模式'),('BrokerID', u'经纪公司代码'),('UserID', u'用户代码')]])
    def getval(self, n):
        if n in ['LoginMode']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryInstrumentStatusField:
    def __init__(self, ExchangeInstID="", ExchangeID=""):
        self.ExchangeInstID=ExchangeInstID
        self.ExchangeID=ExchangeID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ExchangeInstID', 'ExchangeID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ExchangeInstID', u'合约在交易所的代码'),('ExchangeID', u'交易所代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcBrokerWithdrawAlgorithmField:
    def __init__(self, IsBrokerUserEvent=0, WithdrawAlgorithm='1', IncludeCloseProfit='0', AvailIncludeCloseProfit='0', AllWithoutTrade='0', UsingRatio=0, BrokerID=""):
        self.IsBrokerUserEvent=IsBrokerUserEvent
        self.WithdrawAlgorithm=WithdrawAlgorithm
        self.IncludeCloseProfit=IncludeCloseProfit
        self.AvailIncludeCloseProfit=AvailIncludeCloseProfit
        self.AllWithoutTrade=AllWithoutTrade
        self.UsingRatio=UsingRatio
        self.BrokerID=BrokerID
        self.vcmap={'AllWithoutTrade': {"'2'": '受可提比例限制', "'0'": '无仓无成交不受可提比例限制', "'3'": '无仓不受可提比例限制'}, 'WithdrawAlgorithm': {"'2'": '浮盈不计，浮亏计', "'3'": '浮盈计，浮亏不计', "'1'": '浮盈浮亏都计算', "'4'": '浮盈浮亏都不计算'}, 'AvailIncludeCloseProfit': {"'2'": '不包含平仓盈利', "'0'": '包含平仓盈利'}, 'IncludeCloseProfit': {"'2'": '不包含平仓盈利', "'0'": '包含平仓盈利'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['IsBrokerUserEvent', 'WithdrawAlgorithm', 'IncludeCloseProfit', 'AvailIncludeCloseProfit', 'AllWithoutTrade', 'UsingRatio', 'BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('IsBrokerUserEvent', u'是否启用用户事件'),('WithdrawAlgorithm', u'可提资金算法'),('IncludeCloseProfit', u'可提是否包含平仓盈利'),('AvailIncludeCloseProfit', u'可用是否包含平仓盈利'),('AllWithoutTrade', u'本日无仓且无成交客户是否受可提比例限制'),('UsingRatio', u'资金使用率'),('BrokerID', u'经纪公司代码')]])
    def getval(self, n):
        if n in ['WithdrawAlgorithm', 'IncludeCloseProfit', 'AvailIncludeCloseProfit', 'AllWithoutTrade']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcInputOrderField:
    def __init__(self, ContingentCondition='1', OrderRef="", IsAutoSuspend=0, ForceCloseReason='0', CombOffsetFlag="", InvestorID="", VolumeTotalOriginal=0, IsSwapOrder=0, UserID="", RequestID=0, BrokerID="", LimitPrice=0, OrderPriceType='1', CombHedgeFlag="", StopPrice=0, GTDDate="", MinVolume=0, InstrumentID="", VolumeCondition='1', BusinessUnit="", UserForceClose=0, TimeCondition='1', Direction='0'):
        self.ContingentCondition=ContingentCondition
        self.OrderRef=OrderRef
        self.IsAutoSuspend=IsAutoSuspend
        self.ForceCloseReason=ForceCloseReason
        self.CombOffsetFlag=CombOffsetFlag
        self.InvestorID=InvestorID
        self.VolumeTotalOriginal=VolumeTotalOriginal
        self.IsSwapOrder=IsSwapOrder
        self.UserID=UserID
        self.RequestID=RequestID
        self.BrokerID=BrokerID
        self.LimitPrice=LimitPrice
        self.OrderPriceType=OrderPriceType
        self.CombHedgeFlag=CombHedgeFlag
        self.StopPrice=StopPrice
        self.GTDDate=GTDDate
        self.MinVolume=MinVolume
        self.InstrumentID=InstrumentID
        self.VolumeCondition=VolumeCondition
        self.BusinessUnit=BusinessUnit
        self.UserForceClose=UserForceClose
        self.TimeCondition=TimeCondition
        self.Direction=Direction
        self.vcmap={'ContingentCondition': {"'6'": '最新价大于等于条件价', "'7'": '最新价小于条件价', "'2'": '止损', "'E'": '买一价大于等于条件价', "'8'": '最新价小于等于条件价', "'3'": '止赢', "'1'": '立即', "'D'": '买一价大于条件价', "'F'": '买一价小于条件价', "'9'": '卖一价大于条件价', "'B'": '卖一价小于条件价', "'5'": '最新价大于条件价', "'H'": '买一价小于等于条件价', "'C'": '卖一价小于等于条件价', "'A'": '卖一价大于等于条件价', "'4'": '预埋单'}, 'ForceCloseReason': {"'0'": '非强平', "'6'": '其它', "'7'": '自然人临近交割', "'2'": '客户超仓', "'5'": '违规', "'3'": '会员超仓', "'1'": '资金不足', "'4'": '持仓非整数倍'}, 'Direction': {"'0'": '买', "'1'": '卖'}, 'OrderPriceType': {"'6'": '最新价浮动上浮2个ticks', "'7'": '最新价浮动上浮3个ticks', "'2'": '限价', "'E'": '买一价浮动上浮2个ticks', "'8'": '卖一价', "'3'": '最优价', "'1'": '任意价', "'D'": '买一价浮动上浮1个ticks', "'F'": '买一价浮动上浮3个ticks', "'9'": '卖一价浮动上浮1个ticks', "'B'": '卖一价浮动上浮3个ticks', "'5'": '最新价浮动上浮1个ticks', "'C'": '买一价', "'A'": '卖一价浮动上浮2个ticks', "'4'": '最新价'}, 'TimeCondition': {"'6'": '集合竞价有效', "'2'": '本节有效', "'5'": '撤销前有效', "'3'": '当日有效', "'1'": '立即完成，否则撤销', "'4'": '指定日期前有效'}, 'VolumeCondition': {"'2'": '最小数量', "'3'": '全部数量', "'1'": '任何数量'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ContingentCondition', 'OrderRef', 'IsAutoSuspend', 'ForceCloseReason', 'CombOffsetFlag', 'InvestorID', 'VolumeTotalOriginal', 'IsSwapOrder', 'UserID', 'RequestID', 'BrokerID', 'LimitPrice', 'OrderPriceType', 'CombHedgeFlag', 'StopPrice', 'GTDDate', 'MinVolume', 'InstrumentID', 'VolumeCondition', 'BusinessUnit', 'UserForceClose', 'TimeCondition', 'Direction']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ContingentCondition', u'触发条件'),('OrderRef', u'报单引用'),('IsAutoSuspend', u'自动挂起标志'),('ForceCloseReason', u'强平原因'),('CombOffsetFlag', u'组合开平标志'),('InvestorID', u'投资者代码'),('VolumeTotalOriginal', u'数量'),('IsSwapOrder', u'互换单标志'),('UserID', u'用户代码'),('RequestID', u'请求编号'),('BrokerID', u'经纪公司代码'),('LimitPrice', u'价格'),('OrderPriceType', u'报单价格条件'),('CombHedgeFlag', u'组合投机套保标志'),('StopPrice', u'止损价'),('GTDDate', u'GTD日期'),('MinVolume', u'最小成交量'),('InstrumentID', u'合约代码'),('VolumeCondition', u'成交量类型'),('BusinessUnit', u'业务单元'),('UserForceClose', u'用户强评标志'),('TimeCondition', u'有效期类型'),('Direction', u'买卖方向')]])
    def getval(self, n):
        if n in ['ContingentCondition', 'ForceCloseReason', 'OrderPriceType', 'VolumeCondition', 'TimeCondition', 'Direction']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcPositionProfitAlgorithmField:
    def __init__(self, AccountID="", Memo="", BrokerID="", Algorithm='1'):
        self.AccountID=AccountID
        self.Memo=Memo
        self.BrokerID=BrokerID
        self.Algorithm=Algorithm
        self.vcmap={'Algorithm': {"'2'": '浮盈不计，浮亏计', "'3'": '浮盈计，浮亏不计', "'1'": '浮盈浮亏都计算', "'4'": '浮盈浮亏都不计算'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['AccountID', 'Memo', 'BrokerID', 'Algorithm']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('AccountID', u'投资者帐号'),('Memo', u'备注'),('BrokerID', u'经纪公司代码'),('Algorithm', u'盈亏算法')]])
    def getval(self, n):
        if n in ['Algorithm']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcChangeAccountField:
    def __init__(self, TradeTime="", Digest="", AccountID="", TradeDate="", BankAccount="", ErrorMsg="", VerifyCertNoFlag='0', LastFragment='0', CurrencyID="", SecuPwdFlag='0', BankPwdFlag='0', Gender='0', BrokerID="", BankID="", BankSerial="", MobilePhone="", NewBankAccount="", BankAccType='1', CustType='0', ErrorID=0, NewBankPassWord="", TID=0, MoneyAccountStatus='0', Fax="", CustomerName="", BrokerIDByBank="", BrokerBranchID="", BankBranchID="", TradeCode="", Password="", CountryCode="", BankPassWord="", IdentifiedCardNo="", IdCardType='0', EMail="", ZipCode="", InstallID=0, PlateSerial=0, Address="", TradingDay="", SessionID=0, Telephone=""):
        self.TradeTime=TradeTime
        self.Digest=Digest
        self.AccountID=AccountID
        self.TradeDate=TradeDate
        self.BankAccount=BankAccount
        self.ErrorMsg=ErrorMsg
        self.VerifyCertNoFlag=VerifyCertNoFlag
        self.LastFragment=LastFragment
        self.CurrencyID=CurrencyID
        self.SecuPwdFlag=SecuPwdFlag
        self.BankPwdFlag=BankPwdFlag
        self.Gender=Gender
        self.BrokerID=BrokerID
        self.BankID=BankID
        self.BankSerial=BankSerial
        self.MobilePhone=MobilePhone
        self.NewBankAccount=NewBankAccount
        self.BankAccType=BankAccType
        self.CustType=CustType
        self.ErrorID=ErrorID
        self.NewBankPassWord=NewBankPassWord
        self.TID=TID
        self.MoneyAccountStatus=MoneyAccountStatus
        self.Fax=Fax
        self.CustomerName=CustomerName
        self.BrokerIDByBank=BrokerIDByBank
        self.BrokerBranchID=BrokerBranchID
        self.BankBranchID=BankBranchID
        self.TradeCode=TradeCode
        self.Password=Password
        self.CountryCode=CountryCode
        self.BankPassWord=BankPassWord
        self.IdentifiedCardNo=IdentifiedCardNo
        self.IdCardType=IdCardType
        self.EMail=EMail
        self.ZipCode=ZipCode
        self.InstallID=InstallID
        self.PlateSerial=PlateSerial
        self.Address=Address
        self.TradingDay=TradingDay
        self.SessionID=SessionID
        self.Telephone=Telephone
        self.vcmap={'IdCardType': {"'0'": '组织机构代码', "'6'": '护照', "'7'": '台胞证', "'2'": '军官证', "'8'": '回乡证', "'3'": '警官证', "'1'": '身份证', "'x'": '其他证件', "'9'": '营业执照号', "'5'": '户口簿', "'A'": '税务登记号', "'4'": '士兵证'}, 'BankPwdFlag': {"'2'": '密文核对', "'0'": '不核对', "'1'": '明文核对'}, 'Gender': {"'2'": '女', "'0'": '未知状态', "'1'": '男'}, 'MoneyAccountStatus': {"'0'": '正常', "'1'": '销户'}, 'VerifyCertNoFlag': {"'0'": '是', "'1'": '否'}, 'CustType': {"'0'": '自然人', "'1'": '机构户'}, 'LastFragment': {"'0'": '是最后分片', "'1'": '不是最后分片'}, 'BankAccType': {"'2'": '储蓄卡', "'3'": '信用卡', "'1'": '银行存折'}, 'SecuPwdFlag': {"'2'": '密文核对', "'0'": '不核对', "'1'": '明文核对'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['TradeTime', 'Digest', 'AccountID', 'TradeDate', 'BankAccount', 'ErrorMsg', 'VerifyCertNoFlag', 'LastFragment', 'CurrencyID', 'SecuPwdFlag', 'BankPwdFlag', 'Gender', 'BrokerID', 'BankID', 'BankSerial', 'MobilePhone', 'NewBankAccount', 'BankAccType', 'CustType', 'ErrorID', 'NewBankPassWord', 'TID', 'MoneyAccountStatus', 'Fax', 'CustomerName', 'BrokerIDByBank', 'BrokerBranchID', 'BankBranchID', 'TradeCode', 'Password', 'CountryCode', 'BankPassWord', 'IdentifiedCardNo', 'IdCardType', 'EMail', 'ZipCode', 'InstallID', 'PlateSerial', 'Address', 'TradingDay', 'SessionID', 'Telephone']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('TradeTime', u'交易时间'),('Digest', u'摘要'),('AccountID', u'投资者帐号'),('TradeDate', u'交易日期'),('BankAccount', u'银行帐号'),('ErrorMsg', u'错误信息'),('VerifyCertNoFlag', u'验证客户证件号码标志'),('LastFragment', u'最后分片标志'),('CurrencyID', u'币种代码'),('SecuPwdFlag', u'期货资金密码核对标志'),('BankPwdFlag', u'银行密码标志'),('Gender', u'性别'),('BrokerID', u'期商代码'),('BankID', u'银行代码'),('BankSerial', u'银行流水号'),('MobilePhone', u'手机'),('NewBankAccount', u'新银行帐号'),('BankAccType', u'银行帐号类型'),('CustType', u'客户类型'),('ErrorID', u'错误代码'),('NewBankPassWord', u'新银行密码'),('TID', u'交易ID'),('MoneyAccountStatus', u'资金账户状态'),('Fax', u'传真'),('CustomerName', u'客户姓名'),('BrokerIDByBank', u'期货公司银行编码'),('BrokerBranchID', u'期商分支机构代码'),('BankBranchID', u'银行分支机构代码'),('TradeCode', u'业务功能码'),('Password', u'期货密码'),('CountryCode', u'国家代码'),('BankPassWord', u'银行密码'),('IdentifiedCardNo', u'证件号码'),('IdCardType', u'证件类型'),('EMail', u'电子邮件'),('ZipCode', u'邮编'),('InstallID', u'安装编号'),('PlateSerial', u'银期平台消息流水号'),('Address', u'地址'),('TradingDay', u'交易系统日期'),('SessionID', u'会话号'),('Telephone', u'电话号码')]])
    def getval(self, n):
        if n in ['VerifyCertNoFlag', 'LastFragment', 'SecuPwdFlag', 'BankPwdFlag', 'Gender', 'BankAccType', 'CustType', 'MoneyAccountStatus', 'IdCardType']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQrySettlementInfoField:
    def __init__(self, TradingDay="", InvestorID="", BrokerID=""):
        self.TradingDay=TradingDay
        self.InvestorID=InvestorID
        self.BrokerID=BrokerID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['TradingDay', 'InvestorID', 'BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('TradingDay', u'交易日'),('InvestorID', u'投资者代码'),('BrokerID', u'经纪公司代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcRspQueryTradeResultBySerialField:
    def __init__(self, TradeTime="", AccountID="", OriginReturnCode="", BankAccount="", BankBranchID="", TradeAmount=0, LastFragment='0', CurrencyID="", Digest="", OriginDescrInfoForReturnCode="", BankID="", RefrenceIssure="", Password="", ErrorID=0, BrokerBranchID="", ErrorMsg="", TradeCode="", RefrenceIssureType='0', BankPassWord="", PlateSerial=0, TradingDay="", TradeDate="", Reference=0, BankSerial="", SessionID=0, BrokerID=""):
        self.TradeTime=TradeTime
        self.AccountID=AccountID
        self.OriginReturnCode=OriginReturnCode
        self.BankAccount=BankAccount
        self.BankBranchID=BankBranchID
        self.TradeAmount=TradeAmount
        self.LastFragment=LastFragment
        self.CurrencyID=CurrencyID
        self.Digest=Digest
        self.OriginDescrInfoForReturnCode=OriginDescrInfoForReturnCode
        self.BankID=BankID
        self.RefrenceIssure=RefrenceIssure
        self.Password=Password
        self.ErrorID=ErrorID
        self.BrokerBranchID=BrokerBranchID
        self.ErrorMsg=ErrorMsg
        self.TradeCode=TradeCode
        self.RefrenceIssureType=RefrenceIssureType
        self.BankPassWord=BankPassWord
        self.PlateSerial=PlateSerial
        self.TradingDay=TradingDay
        self.TradeDate=TradeDate
        self.Reference=Reference
        self.BankSerial=BankSerial
        self.SessionID=SessionID
        self.BrokerID=BrokerID
        self.vcmap={'LastFragment': {"'0'": '是最后分片', "'1'": '不是最后分片'}, 'RefrenceIssureType': {"'2'": '券商', "'0'": '银行', "'1'": '期商'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['TradeTime', 'AccountID', 'OriginReturnCode', 'BankAccount', 'BankBranchID', 'TradeAmount', 'LastFragment', 'CurrencyID', 'Digest', 'OriginDescrInfoForReturnCode', 'BankID', 'RefrenceIssure', 'Password', 'ErrorID', 'BrokerBranchID', 'ErrorMsg', 'TradeCode', 'RefrenceIssureType', 'BankPassWord', 'PlateSerial', 'TradingDay', 'TradeDate', 'Reference', 'BankSerial', 'SessionID', 'BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('TradeTime', u'交易时间'),('AccountID', u'投资者帐号'),('OriginReturnCode', u'原始返回代码'),('BankAccount', u'银行帐号'),('BankBranchID', u'银行分支机构代码'),('TradeAmount', u'转帐金额'),('LastFragment', u'最后分片标志'),('CurrencyID', u'币种代码'),('Digest', u'摘要'),('OriginDescrInfoForReturnCode', u'原始返回码描述'),('BankID', u'银行代码'),('RefrenceIssure', u'本流水号发布者机构编码'),('Password', u'期货密码'),('ErrorID', u'错误代码'),('BrokerBranchID', u'期商分支机构代码'),('ErrorMsg', u'错误信息'),('TradeCode', u'业务功能码'),('RefrenceIssureType', u'本流水号发布者的机构类型'),('BankPassWord', u'银行密码'),('PlateSerial', u'银期平台消息流水号'),('TradingDay', u'交易系统日期'),('TradeDate', u'交易日期'),('Reference', u'流水号'),('BankSerial', u'银行流水号'),('SessionID', u'会话号'),('BrokerID', u'期商代码')]])
    def getval(self, n):
        if n in ['LastFragment', 'RefrenceIssureType']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcCommPhaseField:
    def __init__(self, SystemID="", CommPhaseNo=0, TradingDay=""):
        self.SystemID=SystemID
        self.CommPhaseNo=CommPhaseNo
        self.TradingDay=TradingDay
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['SystemID', 'CommPhaseNo', 'TradingDay']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('SystemID', u'系统编号'),('CommPhaseNo', u'通讯时段编号'),('TradingDay', u'交易日')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcVerifyInvestorPasswordField:
    def __init__(self, InvestorID="", BrokerID="", Password=""):
        self.InvestorID=InvestorID
        self.BrokerID=BrokerID
        self.Password=Password
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['InvestorID', 'BrokerID', 'Password']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('InvestorID', u'投资者代码'),('BrokerID', u'经纪公司代码'),('Password', u'密码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryEWarrantOffsetField:
    def __init__(self, ExchangeID="", InvestorID="", BrokerID="", InstrumentID=""):
        self.ExchangeID=ExchangeID
        self.InvestorID=InvestorID
        self.BrokerID=BrokerID
        self.InstrumentID=InstrumentID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ExchangeID', 'InvestorID', 'BrokerID', 'InstrumentID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ExchangeID', u'交易所代码'),('InvestorID', u'投资者代码'),('BrokerID', u'经纪公司代码'),('InstrumentID', u'合约代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcMarketDataStaticField:
    def __init__(self, SettlementPrice=0, ClosePrice=0, HighestPrice=0, UpperLimitPrice=0, OpenPrice=0, LowerLimitPrice=0, CurrDelta=0, LowestPrice=0):
        self.SettlementPrice=SettlementPrice
        self.ClosePrice=ClosePrice
        self.HighestPrice=HighestPrice
        self.UpperLimitPrice=UpperLimitPrice
        self.OpenPrice=OpenPrice
        self.LowerLimitPrice=LowerLimitPrice
        self.CurrDelta=CurrDelta
        self.LowestPrice=LowestPrice
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['SettlementPrice', 'ClosePrice', 'HighestPrice', 'UpperLimitPrice', 'OpenPrice', 'LowerLimitPrice', 'CurrDelta', 'LowestPrice']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('SettlementPrice', u'本次结算价'),('ClosePrice', u'今收盘'),('HighestPrice', u'最高价'),('UpperLimitPrice', u'涨停板价'),('OpenPrice', u'今开盘'),('LowerLimitPrice', u'跌停板价'),('CurrDelta', u'今虚实度'),('LowestPrice', u'最低价')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQrySuperUserFunctionField:
    def __init__(self, UserID=""):
        self.UserID=UserID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('UserID', u'用户代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcOrderField:
    def __init__(self, OrderRef="", TimeCondition='1', InvestorID="", SuspendTime="", BrokerOrderSeq=0, RequestID=0, CancelTime="", OrderSysID="", LimitPrice=0, OrderPriceType='1', VolumeTraded=0, ExchangeInstID="", MinVolume=0, OrderType='0', InstrumentID="", IsSwapOrder=0, VolumeCondition='1', ClearingPartID="", ActiveTraderID="", TradingDay="", StatusMsg="", ActiveUserID="", OrderSubmitStatus='0', ContingentCondition='1', CombHedgeFlag="", IsAutoSuspend=0, SessionID=0, NotifySequence=0, ZCETotalTradedVolume=0, ForceCloseReason='0', CombOffsetFlag="", VolumeTotalOriginal=0, SequenceNo=0, TraderID="", OrderLocalID="", InsertDate="", BrokerID="", FrontID=0, RelativeOrderSysID="", UserProductInfo="", InstallID=0, UpdateTime="", ParticipantID="", StopPrice=0, GTDDate="", ActiveTime="", InsertTime="", SettlementID=0, VolumeTotal=0, BusinessUnit="", OrderSource='0', UserForceClose=0, ClientID="", OrderStatus='0', ExchangeID="", UserID="", Direction='0'):
        self.OrderRef=OrderRef
        self.TimeCondition=TimeCondition
        self.InvestorID=InvestorID
        self.SuspendTime=SuspendTime
        self.BrokerOrderSeq=BrokerOrderSeq
        self.RequestID=RequestID
        self.CancelTime=CancelTime
        self.OrderSysID=OrderSysID
        self.LimitPrice=LimitPrice
        self.OrderPriceType=OrderPriceType
        self.VolumeTraded=VolumeTraded
        self.ExchangeInstID=ExchangeInstID
        self.MinVolume=MinVolume
        self.OrderType=OrderType
        self.InstrumentID=InstrumentID
        self.IsSwapOrder=IsSwapOrder
        self.VolumeCondition=VolumeCondition
        self.ClearingPartID=ClearingPartID
        self.ActiveTraderID=ActiveTraderID
        self.TradingDay=TradingDay
        self.StatusMsg=StatusMsg
        self.ActiveUserID=ActiveUserID
        self.OrderSubmitStatus=OrderSubmitStatus
        self.ContingentCondition=ContingentCondition
        self.CombHedgeFlag=CombHedgeFlag
        self.IsAutoSuspend=IsAutoSuspend
        self.SessionID=SessionID
        self.NotifySequence=NotifySequence
        self.ZCETotalTradedVolume=ZCETotalTradedVolume
        self.ForceCloseReason=ForceCloseReason
        self.CombOffsetFlag=CombOffsetFlag
        self.VolumeTotalOriginal=VolumeTotalOriginal
        self.SequenceNo=SequenceNo
        self.TraderID=TraderID
        self.OrderLocalID=OrderLocalID
        self.InsertDate=InsertDate
        self.BrokerID=BrokerID
        self.FrontID=FrontID
        self.RelativeOrderSysID=RelativeOrderSysID
        self.UserProductInfo=UserProductInfo
        self.InstallID=InstallID
        self.UpdateTime=UpdateTime
        self.ParticipantID=ParticipantID
        self.StopPrice=StopPrice
        self.GTDDate=GTDDate
        self.ActiveTime=ActiveTime
        self.InsertTime=InsertTime
        self.SettlementID=SettlementID
        self.VolumeTotal=VolumeTotal
        self.BusinessUnit=BusinessUnit
        self.OrderSource=OrderSource
        self.UserForceClose=UserForceClose
        self.ClientID=ClientID
        self.OrderStatus=OrderStatus
        self.ExchangeID=ExchangeID
        self.UserID=UserID
        self.Direction=Direction
        self.vcmap={'ContingentCondition': {"'6'": '最新价大于等于条件价', "'7'": '最新价小于条件价', "'2'": '止损', "'E'": '买一价大于等于条件价', "'8'": '最新价小于等于条件价', "'3'": '止赢', "'1'": '立即', "'D'": '买一价大于条件价', "'F'": '买一价小于条件价', "'9'": '卖一价大于条件价', "'B'": '卖一价小于条件价', "'5'": '最新价大于条件价', "'H'": '买一价小于等于条件价', "'C'": '卖一价小于等于条件价', "'A'": '卖一价大于等于条件价', "'4'": '预埋单'}, 'OrderStatus': {"'b'": '尚未触发', "'0'": '全部成交', "'3'": '未成交还在队列中', "'2'": '部分成交不在队列中', "'5'": '撤单', "'c'": '已触发', "'a'": '未知', "'4'": '未成交不在队列中', "'1'": '部分成交还在队列中'}, 'OrderSource': {"'0'": '来自参与者', "'1'": '来自管理员'}, 'OrderPriceType': {"'6'": '最新价浮动上浮2个ticks', "'7'": '最新价浮动上浮3个ticks', "'2'": '限价', "'E'": '买一价浮动上浮2个ticks', "'8'": '卖一价', "'3'": '最优价', "'1'": '任意价', "'D'": '买一价浮动上浮1个ticks', "'F'": '买一价浮动上浮3个ticks', "'9'": '卖一价浮动上浮1个ticks', "'B'": '卖一价浮动上浮3个ticks', "'5'": '最新价浮动上浮1个ticks', "'C'": '买一价', "'A'": '卖一价浮动上浮2个ticks', "'4'": '最新价'}, 'TimeCondition': {"'6'": '集合竞价有效', "'2'": '本节有效', "'5'": '撤销前有效', "'3'": '当日有效', "'1'": '立即完成，否则撤销', "'4'": '指定日期前有效'}, 'Direction': {"'0'": '买', "'1'": '卖'}, 'OrderType': {"'0'": '正常', "'2'": '组合衍生', "'5'": '互换单', "'3'": '组合报单', "'1'": '报价衍生', "'4'": '条件单'}, 'ForceCloseReason': {"'0'": '非强平', "'6'": '其它', "'7'": '自然人临近交割', "'2'": '客户超仓', "'5'": '违规', "'3'": '会员超仓', "'1'": '资金不足', "'4'": '持仓非整数倍'}, 'OrderSubmitStatus': {"'0'": '已经提交', "'6'": '改单已经被拒绝', "'2'": '修改已经提交', "'5'": '撤单已经被拒绝', "'3'": '已经接受', "'1'": '撤单已经提交', "'4'": '报单已经被拒绝'}, 'VolumeCondition': {"'2'": '最小数量', "'3'": '全部数量', "'1'": '任何数量'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['OrderRef', 'TimeCondition', 'InvestorID', 'SuspendTime', 'BrokerOrderSeq', 'RequestID', 'CancelTime', 'OrderSysID', 'LimitPrice', 'OrderPriceType', 'VolumeTraded', 'ExchangeInstID', 'MinVolume', 'OrderType', 'InstrumentID', 'IsSwapOrder', 'VolumeCondition', 'ClearingPartID', 'ActiveTraderID', 'TradingDay', 'StatusMsg', 'ActiveUserID', 'OrderSubmitStatus', 'ContingentCondition', 'CombHedgeFlag', 'IsAutoSuspend', 'SessionID', 'NotifySequence', 'ZCETotalTradedVolume', 'ForceCloseReason', 'CombOffsetFlag', 'VolumeTotalOriginal', 'SequenceNo', 'TraderID', 'OrderLocalID', 'InsertDate', 'BrokerID', 'FrontID', 'RelativeOrderSysID', 'UserProductInfo', 'InstallID', 'UpdateTime', 'ParticipantID', 'StopPrice', 'GTDDate', 'ActiveTime', 'InsertTime', 'SettlementID', 'VolumeTotal', 'BusinessUnit', 'OrderSource', 'UserForceClose', 'ClientID', 'OrderStatus', 'ExchangeID', 'UserID', 'Direction']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('OrderRef', u'报单引用'),('TimeCondition', u'有效期类型'),('InvestorID', u'投资者代码'),('SuspendTime', u'挂起时间'),('BrokerOrderSeq', u'经纪公司报单编号'),('RequestID', u'请求编号'),('CancelTime', u'撤销时间'),('OrderSysID', u'报单编号'),('LimitPrice', u'价格'),('OrderPriceType', u'报单价格条件'),('VolumeTraded', u'今成交数量'),('ExchangeInstID', u'合约在交易所的代码'),('MinVolume', u'最小成交量'),('OrderType', u'报单类型'),('InstrumentID', u'合约代码'),('IsSwapOrder', u'互换单标志'),('VolumeCondition', u'成交量类型'),('ClearingPartID', u'结算会员编号'),('ActiveTraderID', u'最后修改交易所交易员代码'),('TradingDay', u'交易日'),('StatusMsg', u'状态信息'),('ActiveUserID', u'操作用户代码'),('OrderSubmitStatus', u'报单提交状态'),('ContingentCondition', u'触发条件'),('CombHedgeFlag', u'组合投机套保标志'),('IsAutoSuspend', u'自动挂起标志'),('SessionID', u'会话编号'),('NotifySequence', u'报单提示序号'),('ZCETotalTradedVolume', u'郑商所成交数量'),('ForceCloseReason', u'强平原因'),('CombOffsetFlag', u'组合开平标志'),('VolumeTotalOriginal', u'数量'),('SequenceNo', u'序号'),('TraderID', u'交易所交易员代码'),('OrderLocalID', u'本地报单编号'),('InsertDate', u'报单日期'),('BrokerID', u'经纪公司代码'),('FrontID', u'前置编号'),('RelativeOrderSysID', u'相关报单'),('UserProductInfo', u'用户端产品信息'),('InstallID', u'安装编号'),('UpdateTime', u'最后修改时间'),('ParticipantID', u'会员代码'),('StopPrice', u'止损价'),('GTDDate', u'GTD日期'),('ActiveTime', u'激活时间'),('InsertTime', u'委托时间'),('SettlementID', u'结算编号'),('VolumeTotal', u'剩余数量'),('BusinessUnit', u'业务单元'),('OrderSource', u'报单来源'),('UserForceClose', u'用户强评标志'),('ClientID', u'客户代码'),('OrderStatus', u'报单状态'),('ExchangeID', u'交易所代码'),('UserID', u'用户代码'),('Direction', u'买卖方向')]])
    def getval(self, n):
        if n in ['TimeCondition', 'OrderPriceType', 'OrderType', 'VolumeCondition', 'OrderSubmitStatus', 'ContingentCondition', 'ForceCloseReason', 'OrderSource', 'OrderStatus', 'Direction']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcLoginInfoField:
    def __init__(self, SHFETime="", IPAddress="", InterfaceProductInfo="", CZCETime="", DCETime="", MacAddress="", MaxOrderRef="", Password="", SessionID=0, FrontID=0, BrokerID="", ProtocolInfo="", LoginTime="", SystemName="", OneTimePassword="", LoginDate="", UserProductInfo="", UserID="", FFEXTime=""):
        self.SHFETime=SHFETime
        self.IPAddress=IPAddress
        self.InterfaceProductInfo=InterfaceProductInfo
        self.CZCETime=CZCETime
        self.DCETime=DCETime
        self.MacAddress=MacAddress
        self.MaxOrderRef=MaxOrderRef
        self.Password=Password
        self.SessionID=SessionID
        self.FrontID=FrontID
        self.BrokerID=BrokerID
        self.ProtocolInfo=ProtocolInfo
        self.LoginTime=LoginTime
        self.SystemName=SystemName
        self.OneTimePassword=OneTimePassword
        self.LoginDate=LoginDate
        self.UserProductInfo=UserProductInfo
        self.UserID=UserID
        self.FFEXTime=FFEXTime
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['SHFETime', 'IPAddress', 'InterfaceProductInfo', 'CZCETime', 'DCETime', 'MacAddress', 'MaxOrderRef', 'Password', 'SessionID', 'FrontID', 'BrokerID', 'ProtocolInfo', 'LoginTime', 'SystemName', 'OneTimePassword', 'LoginDate', 'UserProductInfo', 'UserID', 'FFEXTime']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('SHFETime', u'上期所时间'),('IPAddress', u'IP地址'),('InterfaceProductInfo', u'接口端产品信息'),('CZCETime', u'郑商所时间'),('DCETime', u'大商所时间'),('MacAddress', u'Mac地址'),('MaxOrderRef', u'最大报单引用'),('Password', u'密码'),('SessionID', u'会话编号'),('FrontID', u'前置编号'),('BrokerID', u'经纪公司代码'),('ProtocolInfo', u'协议信息'),('LoginTime', u'登录时间'),('SystemName', u'系统名称'),('OneTimePassword', u'动态密码'),('LoginDate', u'登录日期'),('UserProductInfo', u'用户端产品信息'),('UserID', u'用户代码'),('FFEXTime', u'中金所时间')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcSyncingInstrumentMarginRateField:
    def __init__(self, InvestorRange='1', BrokerID="", LongMarginRatioByMoney=0, ShortMarginRatioByMoney=0, HedgeFlag='1', LongMarginRatioByVolume=0, IsRelative=0, InvestorID="", InstrumentID="", ShortMarginRatioByVolume=0):
        self.InvestorRange=InvestorRange
        self.BrokerID=BrokerID
        self.LongMarginRatioByMoney=LongMarginRatioByMoney
        self.ShortMarginRatioByMoney=ShortMarginRatioByMoney
        self.HedgeFlag=HedgeFlag
        self.LongMarginRatioByVolume=LongMarginRatioByVolume
        self.IsRelative=IsRelative
        self.InvestorID=InvestorID
        self.InstrumentID=InstrumentID
        self.ShortMarginRatioByVolume=ShortMarginRatioByVolume
        self.vcmap={'HedgeFlag': {"'2'": '套利', "'3'": '套保', "'1'": '投机'}, 'InvestorRange': {"'2'": '投资者组', "'3'": '单一投资者', "'1'": '所有'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['InvestorRange', 'BrokerID', 'LongMarginRatioByMoney', 'ShortMarginRatioByMoney', 'HedgeFlag', 'LongMarginRatioByVolume', 'IsRelative', 'InvestorID', 'InstrumentID', 'ShortMarginRatioByVolume']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('InvestorRange', u'投资者范围'),('BrokerID', u'经纪公司代码'),('LongMarginRatioByMoney', u'多头保证金率'),('ShortMarginRatioByMoney', u'空头保证金率'),('HedgeFlag', u'投机套保标志'),('LongMarginRatioByVolume', u'多头保证金费'),('IsRelative', u'是否相对交易所收取'),('InvestorID', u'投资者代码'),('InstrumentID', u'合约代码'),('ShortMarginRatioByVolume', u'空头保证金费')]])
    def getval(self, n):
        if n in ['InvestorRange', 'HedgeFlag']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcUserSessionField:
    def __init__(self, IPAddress="", LoginDate="", FrontID=0, BrokerID="", InterfaceProductInfo="", LoginTime="", ProtocolInfo="", MacAddress="", SessionID=0, UserProductInfo="", UserID=""):
        self.IPAddress=IPAddress
        self.LoginDate=LoginDate
        self.FrontID=FrontID
        self.BrokerID=BrokerID
        self.InterfaceProductInfo=InterfaceProductInfo
        self.LoginTime=LoginTime
        self.ProtocolInfo=ProtocolInfo
        self.MacAddress=MacAddress
        self.SessionID=SessionID
        self.UserProductInfo=UserProductInfo
        self.UserID=UserID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['IPAddress', 'LoginDate', 'FrontID', 'BrokerID', 'InterfaceProductInfo', 'LoginTime', 'ProtocolInfo', 'MacAddress', 'SessionID', 'UserProductInfo', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('IPAddress', u'IP地址'),('LoginDate', u'登录日期'),('FrontID', u'前置编号'),('BrokerID', u'经纪公司代码'),('InterfaceProductInfo', u'接口端产品信息'),('LoginTime', u'登录时间'),('ProtocolInfo', u'协议信息'),('MacAddress', u'Mac地址'),('SessionID', u'会话编号'),('UserProductInfo', u'用户端产品信息'),('UserID', u'用户代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcBrokerUserEventField:
    def __init__(self, EventSequenceNo=0, EventDate="", BrokerID="", EventTime="", UserEventType='1', InvestorID="", UserID="", InstrumentID="", UserEventInfo=""):
        self.EventSequenceNo=EventSequenceNo
        self.EventDate=EventDate
        self.BrokerID=BrokerID
        self.EventTime=EventTime
        self.UserEventType=UserEventType
        self.InvestorID=InvestorID
        self.UserID=UserID
        self.InstrumentID=InstrumentID
        self.UserEventInfo=UserEventInfo
        self.vcmap={'UserEventType': {"'6'": '客户端认证', "'9'": '其他', "'2'": '登出', "'5'": '修改密码', "'3'": '交易成功', "'1'": '登录', "'4'": '交易失败'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['EventSequenceNo', 'EventDate', 'BrokerID', 'EventTime', 'UserEventType', 'InvestorID', 'UserID', 'InstrumentID', 'UserEventInfo']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('EventSequenceNo', u'用户事件序号'),('EventDate', u'事件发生日期'),('BrokerID', u'经纪公司代码'),('EventTime', u'事件发生时间'),('UserEventType', u'用户事件类型'),('InvestorID', u'投资者代码'),('UserID', u'用户代码'),('InstrumentID', u'合约代码'),('UserEventInfo', u'用户事件信息')]])
    def getval(self, n):
        if n in ['UserEventType']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcTradingNoticeField:
    def __init__(self, SequenceNo=0, InvestorRange='1', BrokerID="", SendTime="", FieldContent="", SequenceSeries=0, InvestorID="", UserID=""):
        self.SequenceNo=SequenceNo
        self.InvestorRange=InvestorRange
        self.BrokerID=BrokerID
        self.SendTime=SendTime
        self.FieldContent=FieldContent
        self.SequenceSeries=SequenceSeries
        self.InvestorID=InvestorID
        self.UserID=UserID
        self.vcmap={'InvestorRange': {"'2'": '投资者组', "'3'": '单一投资者', "'1'": '所有'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['SequenceNo', 'InvestorRange', 'BrokerID', 'SendTime', 'FieldContent', 'SequenceSeries', 'InvestorID', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('SequenceNo', u'序列号'),('InvestorRange', u'投资者范围'),('BrokerID', u'经纪公司代码'),('SendTime', u'发送时间'),('FieldContent', u'消息正文'),('SequenceSeries', u'序列系列号'),('InvestorID', u'投资者代码'),('UserID', u'用户代码')]])
    def getval(self, n):
        if n in ['InvestorRange']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryInstrumentTradingRightField:
    def __init__(self, InvestorID="", BrokerID="", InstrumentID=""):
        self.InvestorID=InvestorID
        self.BrokerID=BrokerID
        self.InstrumentID=InstrumentID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['InvestorID', 'BrokerID', 'InstrumentID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('InvestorID', u'投资者代码'),('BrokerID', u'经纪公司代码'),('InstrumentID', u'合约代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcDisseminationField:
    def __init__(self, SequenceNo=0, SequenceSeries=0):
        self.SequenceNo=SequenceNo
        self.SequenceSeries=SequenceSeries
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['SequenceNo', 'SequenceSeries']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('SequenceNo', u'序列号'),('SequenceSeries', u'序列系列号')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryInvestorProductGroupMarginField:
    def __init__(self, ProductGroupID="", InvestorID="", BrokerID=""):
        self.ProductGroupID=ProductGroupID
        self.InvestorID=InvestorID
        self.BrokerID=BrokerID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ProductGroupID', 'InvestorID', 'BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ProductGroupID', u'品种/跨品种标示'),('InvestorID', u'投资者代码'),('BrokerID', u'经纪公司代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryTraderField:
    def __init__(self, ParticipantID="", TraderID="", ExchangeID=""):
        self.ParticipantID=ParticipantID
        self.TraderID=TraderID
        self.ExchangeID=ExchangeID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ParticipantID', 'TraderID', 'ExchangeID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ParticipantID', u'会员代码'),('TraderID', u'交易所交易员代码'),('ExchangeID', u'交易所代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcInstrumentMarginRateAdjustField:
    def __init__(self, InvestorRange='1', BrokerID="", LongMarginRatioByMoney=0, ShortMarginRatioByMoney=0, HedgeFlag='1', LongMarginRatioByVolume=0, IsRelative=0, InvestorID="", InstrumentID="", ShortMarginRatioByVolume=0):
        self.InvestorRange=InvestorRange
        self.BrokerID=BrokerID
        self.LongMarginRatioByMoney=LongMarginRatioByMoney
        self.ShortMarginRatioByMoney=ShortMarginRatioByMoney
        self.HedgeFlag=HedgeFlag
        self.LongMarginRatioByVolume=LongMarginRatioByVolume
        self.IsRelative=IsRelative
        self.InvestorID=InvestorID
        self.InstrumentID=InstrumentID
        self.ShortMarginRatioByVolume=ShortMarginRatioByVolume
        self.vcmap={'HedgeFlag': {"'2'": '套利', "'3'": '套保', "'1'": '投机'}, 'InvestorRange': {"'2'": '投资者组', "'3'": '单一投资者', "'1'": '所有'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['InvestorRange', 'BrokerID', 'LongMarginRatioByMoney', 'ShortMarginRatioByMoney', 'HedgeFlag', 'LongMarginRatioByVolume', 'IsRelative', 'InvestorID', 'InstrumentID', 'ShortMarginRatioByVolume']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('InvestorRange', u'投资者范围'),('BrokerID', u'经纪公司代码'),('LongMarginRatioByMoney', u'多头保证金率'),('ShortMarginRatioByMoney', u'空头保证金率'),('HedgeFlag', u'投机套保标志'),('LongMarginRatioByVolume', u'多头保证金费'),('IsRelative', u'是否相对交易所收取'),('InvestorID', u'投资者代码'),('InstrumentID', u'合约代码'),('ShortMarginRatioByVolume', u'空头保证金费')]])
    def getval(self, n):
        if n in ['InvestorRange', 'HedgeFlag']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcBrokerDepositField:
    def __init__(self, ParticipantID="", Reserve=0, Balance=0, FrozenMargin=0, Deposit=0, Withdraw=0, TradingDay="", BrokerID="", CurrMargin=0, Available=0, PreBalance=0, ExchangeID="", CloseProfit=0):
        self.ParticipantID=ParticipantID
        self.Reserve=Reserve
        self.Balance=Balance
        self.FrozenMargin=FrozenMargin
        self.Deposit=Deposit
        self.Withdraw=Withdraw
        self.TradingDay=TradingDay
        self.BrokerID=BrokerID
        self.CurrMargin=CurrMargin
        self.Available=Available
        self.PreBalance=PreBalance
        self.ExchangeID=ExchangeID
        self.CloseProfit=CloseProfit
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ParticipantID', 'Reserve', 'Balance', 'FrozenMargin', 'Deposit', 'Withdraw', 'TradingDay', 'BrokerID', 'CurrMargin', 'Available', 'PreBalance', 'ExchangeID', 'CloseProfit']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ParticipantID', u'会员代码'),('Reserve', u'基本准备金'),('Balance', u'期货结算准备金'),('FrozenMargin', u'冻结的保证金'),('Deposit', u'入金金额'),('Withdraw', u'出金金额'),('TradingDay', u'交易日期'),('BrokerID', u'经纪公司代码'),('CurrMargin', u'当前保证金总额'),('Available', u'可提资金'),('PreBalance', u'上次结算准备金'),('ExchangeID', u'交易所代码'),('CloseProfit', u'平仓盈亏')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcBrokerTradingParamsField:
    def __init__(self, Algorithm='1', InvestorID="", BrokerID="", AvailIncludeCloseProfit='0', MarginPriceType='1'):
        self.Algorithm=Algorithm
        self.InvestorID=InvestorID
        self.BrokerID=BrokerID
        self.AvailIncludeCloseProfit=AvailIncludeCloseProfit
        self.MarginPriceType=MarginPriceType
        self.vcmap={'MarginPriceType': {"'2'": '最新价', "'3'": '成交均价', "'1'": '昨结算价', "'4'": '开仓价'}, 'AvailIncludeCloseProfit': {"'2'": '不包含平仓盈利', "'0'": '包含平仓盈利'}, 'Algorithm': {"'2'": '浮盈不计，浮亏计', "'3'": '浮盈计，浮亏不计', "'1'": '浮盈浮亏都计算', "'4'": '浮盈浮亏都不计算'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['Algorithm', 'InvestorID', 'BrokerID', 'AvailIncludeCloseProfit', 'MarginPriceType']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('Algorithm', u'盈亏算法'),('InvestorID', u'投资者代码'),('BrokerID', u'经纪公司代码'),('AvailIncludeCloseProfit', u'可用是否包含平仓盈利'),('MarginPriceType', u'保证金价格类型')]])
    def getval(self, n):
        if n in ['Algorithm', 'AvailIncludeCloseProfit', 'MarginPriceType']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcSyncingTradingAccountField:
    def __init__(self, Balance=0, FrozenMargin=0, PreMortgage=0, FrozenCash=0, DeliveryMargin=0, ExchangeDeliveryMargin=0, BrokerID="", CashIn=0, Commission=0, CurrMargin=0, ExchangeMargin=0, Interest=0, PreCredit=0, FrozenCommission=0, Mortgage=0, Deposit=0, Credit=0, ReserveBalance=0, Reserve=0, InterestBase=0, PreDeposit=0, SettlementID=0, PositionProfit=0, AccountID="", Withdraw=0, TradingDay="", WithdrawQuota=0, Available=0, PreBalance=0, CloseProfit=0, PreMargin=0):
        self.Balance=Balance
        self.FrozenMargin=FrozenMargin
        self.PreMortgage=PreMortgage
        self.FrozenCash=FrozenCash
        self.DeliveryMargin=DeliveryMargin
        self.ExchangeDeliveryMargin=ExchangeDeliveryMargin
        self.BrokerID=BrokerID
        self.CashIn=CashIn
        self.Commission=Commission
        self.CurrMargin=CurrMargin
        self.ExchangeMargin=ExchangeMargin
        self.Interest=Interest
        self.PreCredit=PreCredit
        self.FrozenCommission=FrozenCommission
        self.Mortgage=Mortgage
        self.Deposit=Deposit
        self.Credit=Credit
        self.ReserveBalance=ReserveBalance
        self.Reserve=Reserve
        self.InterestBase=InterestBase
        self.PreDeposit=PreDeposit
        self.SettlementID=SettlementID
        self.PositionProfit=PositionProfit
        self.AccountID=AccountID
        self.Withdraw=Withdraw
        self.TradingDay=TradingDay
        self.WithdrawQuota=WithdrawQuota
        self.Available=Available
        self.PreBalance=PreBalance
        self.CloseProfit=CloseProfit
        self.PreMargin=PreMargin
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['Balance', 'FrozenMargin', 'PreMortgage', 'FrozenCash', 'DeliveryMargin', 'ExchangeDeliveryMargin', 'BrokerID', 'CashIn', 'Commission', 'CurrMargin', 'ExchangeMargin', 'Interest', 'PreCredit', 'FrozenCommission', 'Mortgage', 'Deposit', 'Credit', 'ReserveBalance', 'Reserve', 'InterestBase', 'PreDeposit', 'SettlementID', 'PositionProfit', 'AccountID', 'Withdraw', 'TradingDay', 'WithdrawQuota', 'Available', 'PreBalance', 'CloseProfit', 'PreMargin']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('Balance', u'期货结算准备金'),('FrozenMargin', u'冻结的保证金'),('PreMortgage', u'上次质押金额'),('FrozenCash', u'冻结的资金'),('DeliveryMargin', u'投资者交割保证金'),('ExchangeDeliveryMargin', u'交易所交割保证金'),('BrokerID', u'经纪公司代码'),('CashIn', u'资金差额'),('Commission', u'手续费'),('CurrMargin', u'当前保证金总额'),('ExchangeMargin', u'交易所保证金'),('Interest', u'利息收入'),('PreCredit', u'上次信用额度'),('FrozenCommission', u'冻结的手续费'),('Mortgage', u'质押金额'),('Deposit', u'入金金额'),('Credit', u'信用额度'),('ReserveBalance', u'保底期货结算准备金'),('Reserve', u'基本准备金'),('InterestBase', u'利息基数'),('PreDeposit', u'上次存款额'),('SettlementID', u'结算编号'),('PositionProfit', u'持仓盈亏'),('AccountID', u'投资者帐号'),('Withdraw', u'出金金额'),('TradingDay', u'交易日'),('WithdrawQuota', u'可取资金'),('Available', u'可用资金'),('PreBalance', u'上次结算准备金'),('CloseProfit', u'平仓盈亏'),('PreMargin', u'上次占用的保证金')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcNotifySyncKeyField:
    def __init__(self, TradeTime="", TID=0, ErrorMsg="", LastFragment='0', Message="", RequestID=0, BrokerID="", BankID="", BrokerIDByBank="", ErrorID=0, OperNo="", BrokerBranchID="", BankBranchID="", TradeCode="", DeviceID="", PlateSerial=0, TradingDay="", InstallID=0, TradeDate="", BankSerial="", SessionID=0, UserID=""):
        self.TradeTime=TradeTime
        self.TID=TID
        self.ErrorMsg=ErrorMsg
        self.LastFragment=LastFragment
        self.Message=Message
        self.RequestID=RequestID
        self.BrokerID=BrokerID
        self.BankID=BankID
        self.BrokerIDByBank=BrokerIDByBank
        self.ErrorID=ErrorID
        self.OperNo=OperNo
        self.BrokerBranchID=BrokerBranchID
        self.BankBranchID=BankBranchID
        self.TradeCode=TradeCode
        self.DeviceID=DeviceID
        self.PlateSerial=PlateSerial
        self.TradingDay=TradingDay
        self.InstallID=InstallID
        self.TradeDate=TradeDate
        self.BankSerial=BankSerial
        self.SessionID=SessionID
        self.UserID=UserID
        self.vcmap={'LastFragment': {"'0'": '是最后分片', "'1'": '不是最后分片'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['TradeTime', 'TID', 'ErrorMsg', 'LastFragment', 'Message', 'RequestID', 'BrokerID', 'BankID', 'BrokerIDByBank', 'ErrorID', 'OperNo', 'BrokerBranchID', 'BankBranchID', 'TradeCode', 'DeviceID', 'PlateSerial', 'TradingDay', 'InstallID', 'TradeDate', 'BankSerial', 'SessionID', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('TradeTime', u'交易时间'),('TID', u'交易ID'),('ErrorMsg', u'错误信息'),('LastFragment', u'最后分片标志'),('Message', u'交易核心给银期报盘的消息'),('RequestID', u'请求编号'),('BrokerID', u'期商代码'),('BankID', u'银行代码'),('BrokerIDByBank', u'期货公司银行编码'),('ErrorID', u'错误代码'),('OperNo', u'交易柜员'),('BrokerBranchID', u'期商分支机构代码'),('BankBranchID', u'银行分支机构代码'),('TradeCode', u'业务功能码'),('DeviceID', u'渠道标志'),('PlateSerial', u'银期平台消息流水号'),('TradingDay', u'交易系统日期'),('InstallID', u'安装编号'),('TradeDate', u'交易日期'),('BankSerial', u'银行流水号'),('SessionID', u'会话号'),('UserID', u'用户标识')]])
    def getval(self, n):
        if n in ['LastFragment']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryInstrumentCommissionRateField:
    def __init__(self, InvestorID="", BrokerID="", InstrumentID=""):
        self.InvestorID=InvestorID
        self.BrokerID=BrokerID
        self.InstrumentID=InstrumentID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['InvestorID', 'BrokerID', 'InstrumentID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('InvestorID', u'投资者代码'),('BrokerID', u'经纪公司代码'),('InstrumentID', u'合约代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcAccountregisterField:
    def __init__(self, BankAccount="", CurrencyID="", OpenOrDestroy='1', TID=0, OutDate="", CustType='0', BrokerBranchID="", BankBranchID="", IdCardType='0', TradeDay="", IdentifiedCardNo="", AccountID="", BrokerID="", BankID="", RegDate="", BankAccType='1', CustomerName=""):
        self.BankAccount=BankAccount
        self.CurrencyID=CurrencyID
        self.OpenOrDestroy=OpenOrDestroy
        self.TID=TID
        self.OutDate=OutDate
        self.CustType=CustType
        self.BrokerBranchID=BrokerBranchID
        self.BankBranchID=BankBranchID
        self.IdCardType=IdCardType
        self.TradeDay=TradeDay
        self.IdentifiedCardNo=IdentifiedCardNo
        self.AccountID=AccountID
        self.BrokerID=BrokerID
        self.BankID=BankID
        self.RegDate=RegDate
        self.BankAccType=BankAccType
        self.CustomerName=CustomerName
        self.vcmap={'IdCardType': {"'0'": '组织机构代码', "'6'": '护照', "'7'": '台胞证', "'2'": '军官证', "'8'": '回乡证', "'3'": '警官证', "'1'": '身份证', "'x'": '其他证件', "'9'": '营业执照号', "'5'": '户口簿', "'A'": '税务登记号', "'4'": '士兵证'}, 'OpenOrDestroy': {"'0'": '销户', "'1'": '开户'}, 'CustType': {"'0'": '自然人', "'1'": '机构户'}, 'BankAccType': {"'2'": '储蓄卡', "'3'": '信用卡', "'1'": '银行存折'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['BankAccount', 'CurrencyID', 'OpenOrDestroy', 'TID', 'OutDate', 'CustType', 'BrokerBranchID', 'BankBranchID', 'IdCardType', 'TradeDay', 'IdentifiedCardNo', 'AccountID', 'BrokerID', 'BankID', 'RegDate', 'BankAccType', 'CustomerName']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('BankAccount', u'银行帐号'),('CurrencyID', u'币种代码'),('OpenOrDestroy', u'开销户类别'),('TID', u'交易ID'),('OutDate', u'解约日期'),('CustType', u'客户类型'),('BrokerBranchID', u'期货公司分支机构编码'),('BankBranchID', u'银行分支机构编码'),('IdCardType', u'证件类型'),('TradeDay', u'交易日期'),('IdentifiedCardNo', u'证件号码'),('AccountID', u'投资者帐号'),('BrokerID', u'期货公司编码'),('BankID', u'银行编码'),('RegDate', u'签约日期'),('BankAccType', u'银行帐号类型'),('CustomerName', u'客户姓名')]])
    def getval(self, n):
        if n in ['OpenOrDestroy', 'CustType', 'IdCardType', 'BankAccType']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcSyncingInvestorPositionField:
    def __init__(self, SettlementPrice=0, LongFrozen=0, CombLongFrozen=0, PosiDirection='1', InvestorID="", FrozenMargin=0, TodayPosition=0, OpenVolume=0, FrozenCash=0, Commission=0, CombShortFrozen=0, MarginRateByVolume=0, BrokerID="", CashIn=0, CloseVolume=0, ExchangeMargin=0, ShortFrozenAmount=0, LongFrozenAmount=0, CloseAmount=0, PositionCost=0, CloseProfitByDate=0, FrozenCommission=0, UseMargin=0, MarginRateByMoney=0, CombPosition=0, PositionProfit=0, Position=0, ShortFrozen=0, OpenAmount=0, PositionDate='1', InstrumentID="", CloseProfitByTrade=0, SettlementID=0, TradingDay="", PreSettlementPrice=0, HedgeFlag='1', OpenCost=0, CloseProfit=0, YdPosition=0, PreMargin=0):
        self.SettlementPrice=SettlementPrice
        self.LongFrozen=LongFrozen
        self.CombLongFrozen=CombLongFrozen
        self.PosiDirection=PosiDirection
        self.InvestorID=InvestorID
        self.FrozenMargin=FrozenMargin
        self.TodayPosition=TodayPosition
        self.OpenVolume=OpenVolume
        self.FrozenCash=FrozenCash
        self.Commission=Commission
        self.CombShortFrozen=CombShortFrozen
        self.MarginRateByVolume=MarginRateByVolume
        self.BrokerID=BrokerID
        self.CashIn=CashIn
        self.CloseVolume=CloseVolume
        self.ExchangeMargin=ExchangeMargin
        self.ShortFrozenAmount=ShortFrozenAmount
        self.LongFrozenAmount=LongFrozenAmount
        self.CloseAmount=CloseAmount
        self.PositionCost=PositionCost
        self.CloseProfitByDate=CloseProfitByDate
        self.FrozenCommission=FrozenCommission
        self.UseMargin=UseMargin
        self.MarginRateByMoney=MarginRateByMoney
        self.CombPosition=CombPosition
        self.PositionProfit=PositionProfit
        self.Position=Position
        self.ShortFrozen=ShortFrozen
        self.OpenAmount=OpenAmount
        self.PositionDate=PositionDate
        self.InstrumentID=InstrumentID
        self.CloseProfitByTrade=CloseProfitByTrade
        self.SettlementID=SettlementID
        self.TradingDay=TradingDay
        self.PreSettlementPrice=PreSettlementPrice
        self.HedgeFlag=HedgeFlag
        self.OpenCost=OpenCost
        self.CloseProfit=CloseProfit
        self.YdPosition=YdPosition
        self.PreMargin=PreMargin
        self.vcmap={'HedgeFlag': {"'2'": '套利', "'3'": '套保', "'1'": '投机'}, 'PosiDirection': {"'2'": '多头', "'3'": '空头', "'1'": '净'}, 'PositionDate': {"'2'": '历史持仓', "'1'": '今日持仓'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['SettlementPrice', 'LongFrozen', 'CombLongFrozen', 'PosiDirection', 'InvestorID', 'FrozenMargin', 'TodayPosition', 'OpenVolume', 'FrozenCash', 'Commission', 'CombShortFrozen', 'MarginRateByVolume', 'BrokerID', 'CashIn', 'CloseVolume', 'ExchangeMargin', 'ShortFrozenAmount', 'LongFrozenAmount', 'CloseAmount', 'PositionCost', 'CloseProfitByDate', 'FrozenCommission', 'UseMargin', 'MarginRateByMoney', 'CombPosition', 'PositionProfit', 'Position', 'ShortFrozen', 'OpenAmount', 'PositionDate', 'InstrumentID', 'CloseProfitByTrade', 'SettlementID', 'TradingDay', 'PreSettlementPrice', 'HedgeFlag', 'OpenCost', 'CloseProfit', 'YdPosition', 'PreMargin']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('SettlementPrice', u'本次结算价'),('LongFrozen', u'多头冻结'),('CombLongFrozen', u'组合多头冻结'),('PosiDirection', u'持仓多空方向'),('InvestorID', u'投资者代码'),('FrozenMargin', u'冻结的保证金'),('TodayPosition', u'今日持仓'),('OpenVolume', u'开仓量'),('FrozenCash', u'冻结的资金'),('Commission', u'手续费'),('CombShortFrozen', u'组合空头冻结'),('MarginRateByVolume', u'保证金率(按手数)'),('BrokerID', u'经纪公司代码'),('CashIn', u'资金差额'),('CloseVolume', u'平仓量'),('ExchangeMargin', u'交易所保证金'),('ShortFrozenAmount', u'开仓冻结金额'),('LongFrozenAmount', u'开仓冻结金额'),('CloseAmount', u'平仓金额'),('PositionCost', u'持仓成本'),('CloseProfitByDate', u'逐日盯市平仓盈亏'),('FrozenCommission', u'冻结的手续费'),('UseMargin', u'占用的保证金'),('MarginRateByMoney', u'保证金率'),('CombPosition', u'组合成交形成的持仓'),('PositionProfit', u'持仓盈亏'),('Position', u'今日持仓'),('ShortFrozen', u'空头冻结'),('OpenAmount', u'开仓金额'),('PositionDate', u'持仓日期'),('InstrumentID', u'合约代码'),('CloseProfitByTrade', u'逐笔对冲平仓盈亏'),('SettlementID', u'结算编号'),('TradingDay', u'交易日'),('PreSettlementPrice', u'上次结算价'),('HedgeFlag', u'投机套保标志'),('OpenCost', u'开仓成本'),('CloseProfit', u'平仓盈亏'),('YdPosition', u'上日持仓'),('PreMargin', u'上次占用的保证金')]])
    def getval(self, n):
        if n in ['PosiDirection', 'PositionDate', 'HedgeFlag']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcRspRepealField:
    def __init__(self, RepealedTimes=0, PlateSerial=0, BankPwdFlag='0', TID=0, BankAccount="", ErrorMsg="", FutureFetchAmount=0, TradeAmount=0, Message="", SecuPwdFlag='0', RequestID=0, BankID="", BankSecuAcc="", BankSecuAccType='1', BrokerIDByBank="", BankPassWord="", CustFee=0, ErrorID=0, CustType='0', OperNo="", BrokerBranchID="", TradeCode="", AccountID="", TradingDay="", BrokerRepealFlag='0', IdCardType='0', BankSerial="", TransferStatus='0', TradeTime="", FeePayFlag='0', VerifyCertNoFlag='0', LastFragment='0', CurrencyID="", PlateRepealSerial=0, BrokerID="", BankRepealSerial="", FutureRepealSerial=0, FutureSerial=0, CustomerName="", InstallID=0, RepealTimeInterval=0, Digest="", BankBranchID="", Password="", BankAccType='1', DeviceID="", IdentifiedCardNo="", BankRepealFlag='0', BrokerFee=0, TradeDate="", SessionID=0, UserID=""):
        self.RepealedTimes=RepealedTimes
        self.PlateSerial=PlateSerial
        self.BankPwdFlag=BankPwdFlag
        self.TID=TID
        self.BankAccount=BankAccount
        self.ErrorMsg=ErrorMsg
        self.FutureFetchAmount=FutureFetchAmount
        self.TradeAmount=TradeAmount
        self.Message=Message
        self.SecuPwdFlag=SecuPwdFlag
        self.RequestID=RequestID
        self.BankID=BankID
        self.BankSecuAcc=BankSecuAcc
        self.BankSecuAccType=BankSecuAccType
        self.BrokerIDByBank=BrokerIDByBank
        self.BankPassWord=BankPassWord
        self.CustFee=CustFee
        self.ErrorID=ErrorID
        self.CustType=CustType
        self.OperNo=OperNo
        self.BrokerBranchID=BrokerBranchID
        self.TradeCode=TradeCode
        self.AccountID=AccountID
        self.TradingDay=TradingDay
        self.BrokerRepealFlag=BrokerRepealFlag
        self.IdCardType=IdCardType
        self.BankSerial=BankSerial
        self.TransferStatus=TransferStatus
        self.TradeTime=TradeTime
        self.FeePayFlag=FeePayFlag
        self.VerifyCertNoFlag=VerifyCertNoFlag
        self.LastFragment=LastFragment
        self.CurrencyID=CurrencyID
        self.PlateRepealSerial=PlateRepealSerial
        self.BrokerID=BrokerID
        self.BankRepealSerial=BankRepealSerial
        self.FutureRepealSerial=FutureRepealSerial
        self.FutureSerial=FutureSerial
        self.CustomerName=CustomerName
        self.InstallID=InstallID
        self.RepealTimeInterval=RepealTimeInterval
        self.Digest=Digest
        self.BankBranchID=BankBranchID
        self.Password=Password
        self.BankAccType=BankAccType
        self.DeviceID=DeviceID
        self.IdentifiedCardNo=IdentifiedCardNo
        self.BankRepealFlag=BankRepealFlag
        self.BrokerFee=BrokerFee
        self.TradeDate=TradeDate
        self.SessionID=SessionID
        self.UserID=UserID
        self.vcmap={'VerifyCertNoFlag': {"'0'": '是', "'1'": '否'}, 'BankRepealFlag': {"'2'": '银行已自动冲正', "'0'": '银行无需自动冲正', "'1'": '银行待自动冲正'}, 'LastFragment': {"'0'": '是最后分片', "'1'": '不是最后分片'}, 'CustType': {"'0'": '自然人', "'1'": '机构户'}, 'BankPwdFlag': {"'2'": '密文核对', "'0'": '不核对', "'1'": '明文核对'}, 'SecuPwdFlag': {"'2'": '密文核对', "'0'": '不核对', "'1'": '明文核对'}, 'BankAccType': {"'2'": '储蓄卡', "'3'": '信用卡', "'1'": '银行存折'}, 'IdCardType': {"'0'": '组织机构代码', "'6'": '护照', "'7'": '台胞证', "'2'": '军官证', "'8'": '回乡证', "'3'": '警官证', "'1'": '身份证', "'x'": '其他证件', "'9'": '营业执照号', "'5'": '户口簿', "'A'": '税务登记号', "'4'": '士兵证'}, 'BrokerRepealFlag': {"'2'": '期商已自动冲正', "'0'": '期商无需自动冲正', "'1'": '期商待自动冲正'}, 'BankSecuAccType': {"'2'": '储蓄卡', "'3'": '信用卡', "'1'": '银行存折'}, 'TransferStatus': {"'0'": '正常', "'1'": '被冲正'}, 'FeePayFlag': {"'2'": '由发送方支付发起的费用，受益方支付接受的费用', "'0'": '由受益方支付费用', "'1'": '由发送方支付费用'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['RepealedTimes', 'PlateSerial', 'BankPwdFlag', 'TID', 'BankAccount', 'ErrorMsg', 'FutureFetchAmount', 'TradeAmount', 'Message', 'SecuPwdFlag', 'RequestID', 'BankID', 'BankSecuAcc', 'BankSecuAccType', 'BrokerIDByBank', 'BankPassWord', 'CustFee', 'ErrorID', 'CustType', 'OperNo', 'BrokerBranchID', 'TradeCode', 'AccountID', 'TradingDay', 'BrokerRepealFlag', 'IdCardType', 'BankSerial', 'TransferStatus', 'TradeTime', 'FeePayFlag', 'VerifyCertNoFlag', 'LastFragment', 'CurrencyID', 'PlateRepealSerial', 'BrokerID', 'BankRepealSerial', 'FutureRepealSerial', 'FutureSerial', 'CustomerName', 'InstallID', 'RepealTimeInterval', 'Digest', 'BankBranchID', 'Password', 'BankAccType', 'DeviceID', 'IdentifiedCardNo', 'BankRepealFlag', 'BrokerFee', 'TradeDate', 'SessionID', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('RepealedTimes', u'已经冲正次数'),('PlateSerial', u'银期平台消息流水号'),('BankPwdFlag', u'银行密码标志'),('TID', u'交易ID'),('BankAccount', u'银行帐号'),('ErrorMsg', u'错误信息'),('FutureFetchAmount', u'期货可取金额'),('TradeAmount', u'转帐金额'),('Message', u'发送方给接收方的消息'),('SecuPwdFlag', u'期货资金密码核对标志'),('RequestID', u'请求编号'),('BankID', u'银行代码'),('BankSecuAcc', u'期货单位帐号'),('BankSecuAccType', u'期货单位帐号类型'),('BrokerIDByBank', u'期货公司银行编码'),('BankPassWord', u'银行密码'),('CustFee', u'应收客户费用'),('ErrorID', u'错误代码'),('CustType', u'客户类型'),('OperNo', u'交易柜员'),('BrokerBranchID', u'期商分支机构代码'),('TradeCode', u'业务功能码'),('AccountID', u'投资者帐号'),('TradingDay', u'交易系统日期'),('BrokerRepealFlag', u'期商冲正标志'),('IdCardType', u'证件类型'),('BankSerial', u'银行流水号'),('TransferStatus', u'转账交易状态'),('TradeTime', u'交易时间'),('FeePayFlag', u'费用支付标志'),('VerifyCertNoFlag', u'验证客户证件号码标志'),('LastFragment', u'最后分片标志'),('CurrencyID', u'币种代码'),('PlateRepealSerial', u'被冲正平台流水号'),('BrokerID', u'期商代码'),('BankRepealSerial', u'被冲正银行流水号'),('FutureRepealSerial', u'被冲正期货流水号'),('FutureSerial', u'期货公司流水号'),('CustomerName', u'客户姓名'),('InstallID', u'安装编号'),('RepealTimeInterval', u'冲正时间间隔'),('Digest', u'摘要'),('BankBranchID', u'银行分支机构代码'),('Password', u'期货密码'),('BankAccType', u'银行帐号类型'),('DeviceID', u'渠道标志'),('IdentifiedCardNo', u'证件号码'),('BankRepealFlag', u'银行冲正标志'),('BrokerFee', u'应收期货公司费用'),('TradeDate', u'交易日期'),('SessionID', u'会话号'),('UserID', u'用户标识')]])
    def getval(self, n):
        if n in ['BankPwdFlag', 'SecuPwdFlag', 'BankSecuAccType', 'CustType', 'BrokerRepealFlag', 'IdCardType', 'TransferStatus', 'FeePayFlag', 'VerifyCertNoFlag', 'LastFragment', 'BankAccType', 'BankRepealFlag']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryAccountregisterField:
    def __init__(self, AccountID="", BrokerID="", BankID=""):
        self.AccountID=AccountID
        self.BrokerID=BrokerID
        self.BankID=BankID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['AccountID', 'BrokerID', 'BankID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('AccountID', u'投资者帐号'),('BrokerID', u'经纪公司代码'),('BankID', u'银行编码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcTradingAccountField:
    def __init__(self, Balance=0, FrozenMargin=0, PreMortgage=0, FrozenCash=0, DeliveryMargin=0, ExchangeDeliveryMargin=0, BrokerID="", CashIn=0, Commission=0, CurrMargin=0, ExchangeMargin=0, Interest=0, PreCredit=0, FrozenCommission=0, Mortgage=0, Deposit=0, Credit=0, ReserveBalance=0, Reserve=0, InterestBase=0, PreDeposit=0, SettlementID=0, PositionProfit=0, AccountID="", Withdraw=0, TradingDay="", WithdrawQuota=0, Available=0, PreBalance=0, CloseProfit=0, PreMargin=0):
        self.Balance=Balance
        self.FrozenMargin=FrozenMargin
        self.PreMortgage=PreMortgage
        self.FrozenCash=FrozenCash
        self.DeliveryMargin=DeliveryMargin
        self.ExchangeDeliveryMargin=ExchangeDeliveryMargin
        self.BrokerID=BrokerID
        self.CashIn=CashIn
        self.Commission=Commission
        self.CurrMargin=CurrMargin
        self.ExchangeMargin=ExchangeMargin
        self.Interest=Interest
        self.PreCredit=PreCredit
        self.FrozenCommission=FrozenCommission
        self.Mortgage=Mortgage
        self.Deposit=Deposit
        self.Credit=Credit
        self.ReserveBalance=ReserveBalance
        self.Reserve=Reserve
        self.InterestBase=InterestBase
        self.PreDeposit=PreDeposit
        self.SettlementID=SettlementID
        self.PositionProfit=PositionProfit
        self.AccountID=AccountID
        self.Withdraw=Withdraw
        self.TradingDay=TradingDay
        self.WithdrawQuota=WithdrawQuota
        self.Available=Available
        self.PreBalance=PreBalance
        self.CloseProfit=CloseProfit
        self.PreMargin=PreMargin
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['Balance', 'FrozenMargin', 'PreMortgage', 'FrozenCash', 'DeliveryMargin', 'ExchangeDeliveryMargin', 'BrokerID', 'CashIn', 'Commission', 'CurrMargin', 'ExchangeMargin', 'Interest', 'PreCredit', 'FrozenCommission', 'Mortgage', 'Deposit', 'Credit', 'ReserveBalance', 'Reserve', 'InterestBase', 'PreDeposit', 'SettlementID', 'PositionProfit', 'AccountID', 'Withdraw', 'TradingDay', 'WithdrawQuota', 'Available', 'PreBalance', 'CloseProfit', 'PreMargin']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('Balance', u'期货结算准备金'),('FrozenMargin', u'冻结的保证金'),('PreMortgage', u'上次质押金额'),('FrozenCash', u'冻结的资金'),('DeliveryMargin', u'投资者交割保证金'),('ExchangeDeliveryMargin', u'交易所交割保证金'),('BrokerID', u'经纪公司代码'),('CashIn', u'资金差额'),('Commission', u'手续费'),('CurrMargin', u'当前保证金总额'),('ExchangeMargin', u'交易所保证金'),('Interest', u'利息收入'),('PreCredit', u'上次信用额度'),('FrozenCommission', u'冻结的手续费'),('Mortgage', u'质押金额'),('Deposit', u'入金金额'),('Credit', u'信用额度'),('ReserveBalance', u'保底期货结算准备金'),('Reserve', u'基本准备金'),('InterestBase', u'利息基数'),('PreDeposit', u'上次存款额'),('SettlementID', u'结算编号'),('PositionProfit', u'持仓盈亏'),('AccountID', u'投资者帐号'),('Withdraw', u'出金金额'),('TradingDay', u'交易日'),('WithdrawQuota', u'可取资金'),('Available', u'可用资金'),('PreBalance', u'上次结算准备金'),('CloseProfit', u'平仓盈亏'),('PreMargin', u'上次占用的保证金')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryMarginModelField:
    def __init__(self, MarginModelID="", BrokerID=""):
        self.MarginModelID=MarginModelID
        self.BrokerID=BrokerID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['MarginModelID', 'BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('MarginModelID', u'保证金率模板代码'),('BrokerID', u'经纪公司代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryDepthMarketDataField:
    def __init__(self, InstrumentID=""):
        self.InstrumentID=InstrumentID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['InstrumentID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('InstrumentID', u'合约代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcTradingNoticeInfoField:
    def __init__(self, SequenceNo=0, BrokerID="", SendTime="", FieldContent="", SequenceSeries=0, InvestorID=""):
        self.SequenceNo=SequenceNo
        self.BrokerID=BrokerID
        self.SendTime=SendTime
        self.FieldContent=FieldContent
        self.SequenceSeries=SequenceSeries
        self.InvestorID=InvestorID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['SequenceNo', 'BrokerID', 'SendTime', 'FieldContent', 'SequenceSeries', 'InvestorID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('SequenceNo', u'序列号'),('BrokerID', u'经纪公司代码'),('SendTime', u'发送时间'),('FieldContent', u'消息正文'),('SequenceSeries', u'序列系列号'),('InvestorID', u'投资者代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcMarketDataAsk45Field:
    def __init__(self, AskVolume4=0, AskVolume5=0, AskPrice4=0, AskPrice5=0):
        self.AskVolume4=AskVolume4
        self.AskVolume5=AskVolume5
        self.AskPrice4=AskPrice4
        self.AskPrice5=AskPrice5
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['AskVolume4', 'AskVolume5', 'AskPrice4', 'AskPrice5']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('AskVolume4', u'申卖量四'),('AskVolume5', u'申卖量五'),('AskPrice4', u'申卖价四'),('AskPrice5', u'申卖价五')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcExchangeOrderActionField:
    def __init__(self, ParticipantID="", VolumeChange=0, OrderActionStatus='a', ExchangeID="", OrderSysID="", ActionDate="", UserID="", TraderID="", OrderLocalID="", ActionFlag='0', ActionTime="", LimitPrice=0, ActionLocalID="", BusinessUnit="", InstallID=0, ClientID=""):
        self.ParticipantID=ParticipantID
        self.VolumeChange=VolumeChange
        self.OrderActionStatus=OrderActionStatus
        self.ExchangeID=ExchangeID
        self.OrderSysID=OrderSysID
        self.ActionDate=ActionDate
        self.UserID=UserID
        self.TraderID=TraderID
        self.OrderLocalID=OrderLocalID
        self.ActionFlag=ActionFlag
        self.ActionTime=ActionTime
        self.LimitPrice=LimitPrice
        self.ActionLocalID=ActionLocalID
        self.BusinessUnit=BusinessUnit
        self.InstallID=InstallID
        self.ClientID=ClientID
        self.vcmap={'OrderActionStatus': {"'b'": '已经接受', "'c'": '已经被拒绝', "'a'": '已经提交'}, 'ActionFlag': {"'0'": '删除', "'3'": '修改'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ParticipantID', 'VolumeChange', 'OrderActionStatus', 'ExchangeID', 'OrderSysID', 'ActionDate', 'UserID', 'TraderID', 'OrderLocalID', 'ActionFlag', 'ActionTime', 'LimitPrice', 'ActionLocalID', 'BusinessUnit', 'InstallID', 'ClientID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ParticipantID', u'会员代码'),('VolumeChange', u'数量变化'),('OrderActionStatus', u'报单操作状态'),('ExchangeID', u'交易所代码'),('OrderSysID', u'报单编号'),('ActionDate', u'操作日期'),('UserID', u'用户代码'),('TraderID', u'交易所交易员代码'),('OrderLocalID', u'本地报单编号'),('ActionFlag', u'操作标志'),('ActionTime', u'操作时间'),('LimitPrice', u'价格'),('ActionLocalID', u'操作本地编号'),('BusinessUnit', u'业务单元'),('InstallID', u'安装编号'),('ClientID', u'客户代码')]])
    def getval(self, n):
        if n in ['OrderActionStatus', 'ActionFlag']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcPartBrokerField:
    def __init__(self, ParticipantID="", ExchangeID="", IsActive=0, BrokerID=""):
        self.ParticipantID=ParticipantID
        self.ExchangeID=ExchangeID
        self.IsActive=IsActive
        self.BrokerID=BrokerID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ParticipantID', 'ExchangeID', 'IsActive', 'BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ParticipantID', u'会员代码'),('ExchangeID', u'交易所代码'),('IsActive', u'是否活跃'),('BrokerID', u'经纪公司代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcRspTransferField:
    def __init__(self, PlateSerial=0, Digest="", TID=0, BankAccount="", ErrorMsg="", FutureFetchAmount=0, TradeAmount=0, SecuPwdFlag='0', RequestID=0, BankID="", BankSecuAcc="", BankSecuAccType='1', BrokerIDByBank="", BankPassWord="", CustFee=0, ErrorID=0, CustomerName="", OperNo="", BrokerBranchID="", TradeCode="", AccountID="", TradingDay="", BankSerial="", TransferStatus='0', TradeTime="", FeePayFlag='0', VerifyCertNoFlag='0', LastFragment='0', CurrencyID="", BrokerID="", FutureSerial=0, Message="", CustType='0', InstallID=0, BankPwdFlag='0', BankBranchID="", Password="", BankAccType='1', DeviceID="", IdentifiedCardNo="", IdCardType='0', BrokerFee=0, TradeDate="", SessionID=0, UserID=""):
        self.PlateSerial=PlateSerial
        self.Digest=Digest
        self.TID=TID
        self.BankAccount=BankAccount
        self.ErrorMsg=ErrorMsg
        self.FutureFetchAmount=FutureFetchAmount
        self.TradeAmount=TradeAmount
        self.SecuPwdFlag=SecuPwdFlag
        self.RequestID=RequestID
        self.BankID=BankID
        self.BankSecuAcc=BankSecuAcc
        self.BankSecuAccType=BankSecuAccType
        self.BrokerIDByBank=BrokerIDByBank
        self.BankPassWord=BankPassWord
        self.CustFee=CustFee
        self.ErrorID=ErrorID
        self.CustomerName=CustomerName
        self.OperNo=OperNo
        self.BrokerBranchID=BrokerBranchID
        self.TradeCode=TradeCode
        self.AccountID=AccountID
        self.TradingDay=TradingDay
        self.BankSerial=BankSerial
        self.TransferStatus=TransferStatus
        self.TradeTime=TradeTime
        self.FeePayFlag=FeePayFlag
        self.VerifyCertNoFlag=VerifyCertNoFlag
        self.LastFragment=LastFragment
        self.CurrencyID=CurrencyID
        self.BrokerID=BrokerID
        self.FutureSerial=FutureSerial
        self.Message=Message
        self.CustType=CustType
        self.InstallID=InstallID
        self.BankPwdFlag=BankPwdFlag
        self.BankBranchID=BankBranchID
        self.Password=Password
        self.BankAccType=BankAccType
        self.DeviceID=DeviceID
        self.IdentifiedCardNo=IdentifiedCardNo
        self.IdCardType=IdCardType
        self.BrokerFee=BrokerFee
        self.TradeDate=TradeDate
        self.SessionID=SessionID
        self.UserID=UserID
        self.vcmap={'IdCardType': {"'0'": '组织机构代码', "'6'": '护照', "'7'": '台胞证', "'2'": '军官证', "'8'": '回乡证', "'3'": '警官证', "'1'": '身份证', "'x'": '其他证件', "'9'": '营业执照号', "'5'": '户口簿', "'A'": '税务登记号', "'4'": '士兵证'}, 'BankSecuAccType': {"'2'": '储蓄卡', "'3'": '信用卡', "'1'": '银行存折'}, 'BankPwdFlag': {"'2'": '密文核对', "'0'": '不核对', "'1'": '明文核对'}, 'BankAccType': {"'2'": '储蓄卡', "'3'": '信用卡', "'1'": '银行存折'}, 'CustType': {"'0'": '自然人', "'1'": '机构户'}, 'VerifyCertNoFlag': {"'0'": '是', "'1'": '否'}, 'TransferStatus': {"'0'": '正常', "'1'": '被冲正'}, 'SecuPwdFlag': {"'2'": '密文核对', "'0'": '不核对', "'1'": '明文核对'}, 'FeePayFlag': {"'2'": '由发送方支付发起的费用，受益方支付接受的费用', "'0'": '由受益方支付费用', "'1'": '由发送方支付费用'}, 'LastFragment': {"'0'": '是最后分片', "'1'": '不是最后分片'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['PlateSerial', 'Digest', 'TID', 'BankAccount', 'ErrorMsg', 'FutureFetchAmount', 'TradeAmount', 'SecuPwdFlag', 'RequestID', 'BankID', 'BankSecuAcc', 'BankSecuAccType', 'BrokerIDByBank', 'BankPassWord', 'CustFee', 'ErrorID', 'CustomerName', 'OperNo', 'BrokerBranchID', 'TradeCode', 'AccountID', 'TradingDay', 'BankSerial', 'TransferStatus', 'TradeTime', 'FeePayFlag', 'VerifyCertNoFlag', 'LastFragment', 'CurrencyID', 'BrokerID', 'FutureSerial', 'Message', 'CustType', 'InstallID', 'BankPwdFlag', 'BankBranchID', 'Password', 'BankAccType', 'DeviceID', 'IdentifiedCardNo', 'IdCardType', 'BrokerFee', 'TradeDate', 'SessionID', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('PlateSerial', u'银期平台消息流水号'),('Digest', u'摘要'),('TID', u'交易ID'),('BankAccount', u'银行帐号'),('ErrorMsg', u'错误信息'),('FutureFetchAmount', u'期货可取金额'),('TradeAmount', u'转帐金额'),('SecuPwdFlag', u'期货资金密码核对标志'),('RequestID', u'请求编号'),('BankID', u'银行代码'),('BankSecuAcc', u'期货单位帐号'),('BankSecuAccType', u'期货单位帐号类型'),('BrokerIDByBank', u'期货公司银行编码'),('BankPassWord', u'银行密码'),('CustFee', u'应收客户费用'),('ErrorID', u'错误代码'),('CustomerName', u'客户姓名'),('OperNo', u'交易柜员'),('BrokerBranchID', u'期商分支机构代码'),('TradeCode', u'业务功能码'),('AccountID', u'投资者帐号'),('TradingDay', u'交易系统日期'),('BankSerial', u'银行流水号'),('TransferStatus', u'转账交易状态'),('TradeTime', u'交易时间'),('FeePayFlag', u'费用支付标志'),('VerifyCertNoFlag', u'验证客户证件号码标志'),('LastFragment', u'最后分片标志'),('CurrencyID', u'币种代码'),('BrokerID', u'期商代码'),('FutureSerial', u'期货公司流水号'),('Message', u'发送方给接收方的消息'),('CustType', u'客户类型'),('InstallID', u'安装编号'),('BankPwdFlag', u'银行密码标志'),('BankBranchID', u'银行分支机构代码'),('Password', u'期货密码'),('BankAccType', u'银行帐号类型'),('DeviceID', u'渠道标志'),('IdentifiedCardNo', u'证件号码'),('IdCardType', u'证件类型'),('BrokerFee', u'应收期货公司费用'),('TradeDate', u'交易日期'),('SessionID', u'会话号'),('UserID', u'用户标识')]])
    def getval(self, n):
        if n in ['SecuPwdFlag', 'BankSecuAccType', 'TransferStatus', 'FeePayFlag', 'VerifyCertNoFlag', 'LastFragment', 'CustType', 'BankPwdFlag', 'BankAccType', 'IdCardType']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcDRTransferField:
    def __init__(self, DestBrokerID="", OrigBrokerID="", OrigDRIdentityID=0, DestDRIdentityID=0):
        self.DestBrokerID=DestBrokerID
        self.OrigBrokerID=OrigBrokerID
        self.OrigDRIdentityID=OrigDRIdentityID
        self.DestDRIdentityID=DestDRIdentityID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['DestBrokerID', 'OrigBrokerID', 'OrigDRIdentityID', 'DestDRIdentityID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('DestBrokerID', u'目标易用单元代码'),('OrigBrokerID', u'原应用单元代码'),('OrigDRIdentityID', u'原交易中心代码'),('DestDRIdentityID', u'目标交易中心代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryParkedOrderField:
    def __init__(self, ExchangeID="", InvestorID="", BrokerID="", InstrumentID=""):
        self.ExchangeID=ExchangeID
        self.InvestorID=InvestorID
        self.BrokerID=BrokerID
        self.InstrumentID=InstrumentID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ExchangeID', 'InvestorID', 'BrokerID', 'InstrumentID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ExchangeID', u'交易所代码'),('InvestorID', u'投资者代码'),('BrokerID', u'经纪公司代码'),('InstrumentID', u'合约代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcReqQueryAccountField:
    def __init__(self, TradeTime="", Digest="", TradeDate="", BankAccount="", VerifyCertNoFlag='0', LastFragment='0', TradeCode="", SecuPwdFlag='0', BankPwdFlag='0', RequestID=0, BrokerID="", BankID="", BankSecuAcc="", FutureSerial=0, BankSecuAccType='1', CustType='0', InstallID=0, TID=0, DeviceID="", CurrencyID="", CustomerName="", OperNo="", BrokerBranchID="", BankBranchID="", IdCardType='0', Password="", BankAccType='1', BankPassWord="", IdentifiedCardNo="", AccountID="", TradingDay="", BrokerIDByBank="", PlateSerial=0, BankSerial="", SessionID=0, UserID=""):
        self.TradeTime=TradeTime
        self.Digest=Digest
        self.TradeDate=TradeDate
        self.BankAccount=BankAccount
        self.VerifyCertNoFlag=VerifyCertNoFlag
        self.LastFragment=LastFragment
        self.TradeCode=TradeCode
        self.SecuPwdFlag=SecuPwdFlag
        self.BankPwdFlag=BankPwdFlag
        self.RequestID=RequestID
        self.BrokerID=BrokerID
        self.BankID=BankID
        self.BankSecuAcc=BankSecuAcc
        self.FutureSerial=FutureSerial
        self.BankSecuAccType=BankSecuAccType
        self.CustType=CustType
        self.InstallID=InstallID
        self.TID=TID
        self.DeviceID=DeviceID
        self.CurrencyID=CurrencyID
        self.CustomerName=CustomerName
        self.OperNo=OperNo
        self.BrokerBranchID=BrokerBranchID
        self.BankBranchID=BankBranchID
        self.IdCardType=IdCardType
        self.Password=Password
        self.BankAccType=BankAccType
        self.BankPassWord=BankPassWord
        self.IdentifiedCardNo=IdentifiedCardNo
        self.AccountID=AccountID
        self.TradingDay=TradingDay
        self.BrokerIDByBank=BrokerIDByBank
        self.PlateSerial=PlateSerial
        self.BankSerial=BankSerial
        self.SessionID=SessionID
        self.UserID=UserID
        self.vcmap={'IdCardType': {"'0'": '组织机构代码', "'6'": '护照', "'7'": '台胞证', "'2'": '军官证', "'8'": '回乡证', "'3'": '警官证', "'1'": '身份证', "'x'": '其他证件', "'9'": '营业执照号', "'5'": '户口簿', "'A'": '税务登记号', "'4'": '士兵证'}, 'VerifyCertNoFlag': {"'0'": '是', "'1'": '否'}, 'CustType': {"'0'": '自然人', "'1'": '机构户'}, 'BankSecuAccType': {"'2'": '储蓄卡', "'3'": '信用卡', "'1'": '银行存折'}, 'BankPwdFlag': {"'2'": '密文核对', "'0'": '不核对', "'1'": '明文核对'}, 'LastFragment': {"'0'": '是最后分片', "'1'": '不是最后分片'}, 'BankAccType': {"'2'": '储蓄卡', "'3'": '信用卡', "'1'": '银行存折'}, 'SecuPwdFlag': {"'2'": '密文核对', "'0'": '不核对', "'1'": '明文核对'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['TradeTime', 'Digest', 'TradeDate', 'BankAccount', 'VerifyCertNoFlag', 'LastFragment', 'TradeCode', 'SecuPwdFlag', 'BankPwdFlag', 'RequestID', 'BrokerID', 'BankID', 'BankSecuAcc', 'FutureSerial', 'BankSecuAccType', 'CustType', 'InstallID', 'TID', 'DeviceID', 'CurrencyID', 'CustomerName', 'OperNo', 'BrokerBranchID', 'BankBranchID', 'IdCardType', 'Password', 'BankAccType', 'BankPassWord', 'IdentifiedCardNo', 'AccountID', 'TradingDay', 'BrokerIDByBank', 'PlateSerial', 'BankSerial', 'SessionID', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('TradeTime', u'交易时间'),('Digest', u'摘要'),('TradeDate', u'交易日期'),('BankAccount', u'银行帐号'),('VerifyCertNoFlag', u'验证客户证件号码标志'),('LastFragment', u'最后分片标志'),('TradeCode', u'业务功能码'),('SecuPwdFlag', u'期货资金密码核对标志'),('BankPwdFlag', u'银行密码标志'),('RequestID', u'请求编号'),('BrokerID', u'期商代码'),('BankID', u'银行代码'),('BankSecuAcc', u'期货单位帐号'),('FutureSerial', u'期货公司流水号'),('BankSecuAccType', u'期货单位帐号类型'),('CustType', u'客户类型'),('InstallID', u'安装编号'),('TID', u'交易ID'),('DeviceID', u'渠道标志'),('CurrencyID', u'币种代码'),('CustomerName', u'客户姓名'),('OperNo', u'交易柜员'),('BrokerBranchID', u'期商分支机构代码'),('BankBranchID', u'银行分支机构代码'),('IdCardType', u'证件类型'),('Password', u'期货密码'),('BankAccType', u'银行帐号类型'),('BankPassWord', u'银行密码'),('IdentifiedCardNo', u'证件号码'),('AccountID', u'投资者帐号'),('TradingDay', u'交易系统日期'),('BrokerIDByBank', u'期货公司银行编码'),('PlateSerial', u'银期平台消息流水号'),('BankSerial', u'银行流水号'),('SessionID', u'会话号'),('UserID', u'用户标识')]])
    def getval(self, n):
        if n in ['VerifyCertNoFlag', 'LastFragment', 'SecuPwdFlag', 'BankPwdFlag', 'BankSecuAccType', 'CustType', 'IdCardType', 'BankAccType']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcExchangeOrderActionErrorField:
    def __init__(self, TraderID="", OrderLocalID="", OrderSysID="", ErrorMsg="", ExchangeID="", ActionLocalID="", ErrorID=0, InstallID=0):
        self.TraderID=TraderID
        self.OrderLocalID=OrderLocalID
        self.OrderSysID=OrderSysID
        self.ErrorMsg=ErrorMsg
        self.ExchangeID=ExchangeID
        self.ActionLocalID=ActionLocalID
        self.ErrorID=ErrorID
        self.InstallID=InstallID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['TraderID', 'OrderLocalID', 'OrderSysID', 'ErrorMsg', 'ExchangeID', 'ActionLocalID', 'ErrorID', 'InstallID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('TraderID', u'交易所交易员代码'),('OrderLocalID', u'本地报单编号'),('OrderSysID', u'报单编号'),('ErrorMsg', u'错误信息'),('ExchangeID', u'交易所代码'),('ActionLocalID', u'操作本地编号'),('ErrorID', u'错误代码'),('InstallID', u'安装编号')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcExchangeMarginRateAdjustField:
    def __init__(self, NoShortMarginRatioByMoney=0, ShortMarginRatioByVolume=0, InstrumentID="", ExchShortMarginRatioByVolume=0, ExchLongMarginRatioByVolume=0, BrokerID="", NoLongMarginRatioByMoney=0, HedgeFlag='1', ShortMarginRatioByMoney=0, LongMarginRatioByMoney=0, ExchShortMarginRatioByMoney=0, NoLongMarginRatioByVolume=0, LongMarginRatioByVolume=0, NoShortMarginRatioByVolume=0, ExchLongMarginRatioByMoney=0):
        self.NoShortMarginRatioByMoney=NoShortMarginRatioByMoney
        self.ShortMarginRatioByVolume=ShortMarginRatioByVolume
        self.InstrumentID=InstrumentID
        self.ExchShortMarginRatioByVolume=ExchShortMarginRatioByVolume
        self.ExchLongMarginRatioByVolume=ExchLongMarginRatioByVolume
        self.BrokerID=BrokerID
        self.NoLongMarginRatioByMoney=NoLongMarginRatioByMoney
        self.HedgeFlag=HedgeFlag
        self.ShortMarginRatioByMoney=ShortMarginRatioByMoney
        self.LongMarginRatioByMoney=LongMarginRatioByMoney
        self.ExchShortMarginRatioByMoney=ExchShortMarginRatioByMoney
        self.NoLongMarginRatioByVolume=NoLongMarginRatioByVolume
        self.LongMarginRatioByVolume=LongMarginRatioByVolume
        self.NoShortMarginRatioByVolume=NoShortMarginRatioByVolume
        self.ExchLongMarginRatioByMoney=ExchLongMarginRatioByMoney
        self.vcmap={'HedgeFlag': {"'2'": '套利', "'3'": '套保', "'1'": '投机'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['NoShortMarginRatioByMoney', 'ShortMarginRatioByVolume', 'InstrumentID', 'ExchShortMarginRatioByVolume', 'ExchLongMarginRatioByVolume', 'BrokerID', 'NoLongMarginRatioByMoney', 'HedgeFlag', 'ShortMarginRatioByMoney', 'LongMarginRatioByMoney', 'ExchShortMarginRatioByMoney', 'NoLongMarginRatioByVolume', 'LongMarginRatioByVolume', 'NoShortMarginRatioByVolume', 'ExchLongMarginRatioByMoney']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('NoShortMarginRatioByMoney', u'不跟随交易所投资者空头保证金率'),('ShortMarginRatioByVolume', u'跟随交易所投资者空头保证金费'),('InstrumentID', u'合约代码'),('ExchShortMarginRatioByVolume', u'交易所空头保证金费'),('ExchLongMarginRatioByVolume', u'交易所多头保证金费'),('BrokerID', u'经纪公司代码'),('NoLongMarginRatioByMoney', u'不跟随交易所投资者多头保证金率'),('HedgeFlag', u'投机套保标志'),('ShortMarginRatioByMoney', u'跟随交易所投资者空头保证金率'),('LongMarginRatioByMoney', u'跟随交易所投资者多头保证金率'),('ExchShortMarginRatioByMoney', u'交易所空头保证金率'),('NoLongMarginRatioByVolume', u'不跟随交易所投资者多头保证金费'),('LongMarginRatioByVolume', u'跟随交易所投资者多头保证金费'),('NoShortMarginRatioByVolume', u'不跟随交易所投资者空头保证金费'),('ExchLongMarginRatioByMoney', u'交易所多头保证金率')]])
    def getval(self, n):
        if n in ['HedgeFlag']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryParkedOrderActionField:
    def __init__(self, ExchangeID="", InvestorID="", BrokerID="", InstrumentID=""):
        self.ExchangeID=ExchangeID
        self.InvestorID=InvestorID
        self.BrokerID=BrokerID
        self.InstrumentID=InstrumentID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ExchangeID', 'InvestorID', 'BrokerID', 'InstrumentID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ExchangeID', u'交易所代码'),('InvestorID', u'投资者代码'),('BrokerID', u'经纪公司代码'),('InstrumentID', u'合约代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcTransferFutureToBankReqField:
    def __init__(self, FuturePwdFlag='0', FutureAccPwd="", TradeAmt=0, CurrencyCode="", FutureAccount="", CustFee=0):
        self.FuturePwdFlag=FuturePwdFlag
        self.FutureAccPwd=FutureAccPwd
        self.TradeAmt=TradeAmt
        self.CurrencyCode=CurrencyCode
        self.FutureAccount=FutureAccount
        self.CustFee=CustFee
        self.vcmap={'FuturePwdFlag': {"'0'": '不核对', "'1'": '核对'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['FuturePwdFlag', 'FutureAccPwd', 'TradeAmt', 'CurrencyCode', 'FutureAccount', 'CustFee']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('FuturePwdFlag', u'密码标志'),('FutureAccPwd', u'密码'),('TradeAmt', u'转账金额'),('CurrencyCode', u'币种：RMB-人民币 USD-美圆 HKD-港元'),('FutureAccount', u'期货资金账户'),('CustFee', u'客户手续费')]])
    def getval(self, n):
        if n in ['FuturePwdFlag']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcErrorConditionalOrderField:
    def __init__(self, OrderRef="", TimeCondition='1', InvestorID="", SuspendTime="", BrokerOrderSeq=0, RequestID=0, CancelTime="", OrderSysID="", LimitPrice=0, OrderPriceType='1', VolumeTraded=0, ExchangeInstID="", ErrorID=0, MinVolume=0, OrderType='0', InstrumentID="", IsSwapOrder=0, VolumeCondition='1', ClearingPartID="", ActiveTraderID="", TradingDay="", StatusMsg="", ActiveUserID="", OrderSubmitStatus='0', ContingentCondition='1', CombHedgeFlag="", IsAutoSuspend=0, SessionID=0, NotifySequence=0, ZCETotalTradedVolume=0, ForceCloseReason='0', CombOffsetFlag="", VolumeTotalOriginal=0, SequenceNo=0, TraderID="", OrderLocalID="", InsertDate="", BrokerID="", FrontID=0, RelativeOrderSysID="", UserProductInfo="", InstallID=0, UpdateTime="", ParticipantID="", StopPrice=0, GTDDate="", ActiveTime="", InsertTime="", ErrorMsg="", SettlementID=0, VolumeTotal=0, BusinessUnit="", OrderSource='0', UserForceClose=0, ClientID="", OrderStatus='0', ExchangeID="", UserID="", Direction='0'):
        self.OrderRef=OrderRef
        self.TimeCondition=TimeCondition
        self.InvestorID=InvestorID
        self.SuspendTime=SuspendTime
        self.BrokerOrderSeq=BrokerOrderSeq
        self.RequestID=RequestID
        self.CancelTime=CancelTime
        self.OrderSysID=OrderSysID
        self.LimitPrice=LimitPrice
        self.OrderPriceType=OrderPriceType
        self.VolumeTraded=VolumeTraded
        self.ExchangeInstID=ExchangeInstID
        self.ErrorID=ErrorID
        self.MinVolume=MinVolume
        self.OrderType=OrderType
        self.InstrumentID=InstrumentID
        self.IsSwapOrder=IsSwapOrder
        self.VolumeCondition=VolumeCondition
        self.ClearingPartID=ClearingPartID
        self.ActiveTraderID=ActiveTraderID
        self.TradingDay=TradingDay
        self.StatusMsg=StatusMsg
        self.ActiveUserID=ActiveUserID
        self.OrderSubmitStatus=OrderSubmitStatus
        self.ContingentCondition=ContingentCondition
        self.CombHedgeFlag=CombHedgeFlag
        self.IsAutoSuspend=IsAutoSuspend
        self.SessionID=SessionID
        self.NotifySequence=NotifySequence
        self.ZCETotalTradedVolume=ZCETotalTradedVolume
        self.ForceCloseReason=ForceCloseReason
        self.CombOffsetFlag=CombOffsetFlag
        self.VolumeTotalOriginal=VolumeTotalOriginal
        self.SequenceNo=SequenceNo
        self.TraderID=TraderID
        self.OrderLocalID=OrderLocalID
        self.InsertDate=InsertDate
        self.BrokerID=BrokerID
        self.FrontID=FrontID
        self.RelativeOrderSysID=RelativeOrderSysID
        self.UserProductInfo=UserProductInfo
        self.InstallID=InstallID
        self.UpdateTime=UpdateTime
        self.ParticipantID=ParticipantID
        self.StopPrice=StopPrice
        self.GTDDate=GTDDate
        self.ActiveTime=ActiveTime
        self.InsertTime=InsertTime
        self.ErrorMsg=ErrorMsg
        self.SettlementID=SettlementID
        self.VolumeTotal=VolumeTotal
        self.BusinessUnit=BusinessUnit
        self.OrderSource=OrderSource
        self.UserForceClose=UserForceClose
        self.ClientID=ClientID
        self.OrderStatus=OrderStatus
        self.ExchangeID=ExchangeID
        self.UserID=UserID
        self.Direction=Direction
        self.vcmap={'ContingentCondition': {"'6'": '最新价大于等于条件价', "'7'": '最新价小于条件价', "'2'": '止损', "'E'": '买一价大于等于条件价', "'8'": '最新价小于等于条件价', "'3'": '止赢', "'1'": '立即', "'D'": '买一价大于条件价', "'F'": '买一价小于条件价', "'9'": '卖一价大于条件价', "'B'": '卖一价小于条件价', "'5'": '最新价大于条件价', "'H'": '买一价小于等于条件价', "'C'": '卖一价小于等于条件价', "'A'": '卖一价大于等于条件价', "'4'": '预埋单'}, 'OrderStatus': {"'b'": '尚未触发', "'0'": '全部成交', "'3'": '未成交还在队列中', "'2'": '部分成交不在队列中', "'5'": '撤单', "'c'": '已触发', "'a'": '未知', "'4'": '未成交不在队列中', "'1'": '部分成交还在队列中'}, 'OrderSource': {"'0'": '来自参与者', "'1'": '来自管理员'}, 'OrderPriceType': {"'6'": '最新价浮动上浮2个ticks', "'7'": '最新价浮动上浮3个ticks', "'2'": '限价', "'E'": '买一价浮动上浮2个ticks', "'8'": '卖一价', "'3'": '最优价', "'1'": '任意价', "'D'": '买一价浮动上浮1个ticks', "'F'": '买一价浮动上浮3个ticks', "'9'": '卖一价浮动上浮1个ticks', "'B'": '卖一价浮动上浮3个ticks', "'5'": '最新价浮动上浮1个ticks', "'C'": '买一价', "'A'": '卖一价浮动上浮2个ticks', "'4'": '最新价'}, 'TimeCondition': {"'6'": '集合竞价有效', "'2'": '本节有效', "'5'": '撤销前有效', "'3'": '当日有效', "'1'": '立即完成，否则撤销', "'4'": '指定日期前有效'}, 'Direction': {"'0'": '买', "'1'": '卖'}, 'OrderType': {"'0'": '正常', "'2'": '组合衍生', "'5'": '互换单', "'3'": '组合报单', "'1'": '报价衍生', "'4'": '条件单'}, 'ForceCloseReason': {"'0'": '非强平', "'6'": '其它', "'7'": '自然人临近交割', "'2'": '客户超仓', "'5'": '违规', "'3'": '会员超仓', "'1'": '资金不足', "'4'": '持仓非整数倍'}, 'OrderSubmitStatus': {"'0'": '已经提交', "'6'": '改单已经被拒绝', "'2'": '修改已经提交', "'5'": '撤单已经被拒绝', "'3'": '已经接受', "'1'": '撤单已经提交', "'4'": '报单已经被拒绝'}, 'VolumeCondition': {"'2'": '最小数量', "'3'": '全部数量', "'1'": '任何数量'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['OrderRef', 'TimeCondition', 'InvestorID', 'SuspendTime', 'BrokerOrderSeq', 'RequestID', 'CancelTime', 'OrderSysID', 'LimitPrice', 'OrderPriceType', 'VolumeTraded', 'ExchangeInstID', 'ErrorID', 'MinVolume', 'OrderType', 'InstrumentID', 'IsSwapOrder', 'VolumeCondition', 'ClearingPartID', 'ActiveTraderID', 'TradingDay', 'StatusMsg', 'ActiveUserID', 'OrderSubmitStatus', 'ContingentCondition', 'CombHedgeFlag', 'IsAutoSuspend', 'SessionID', 'NotifySequence', 'ZCETotalTradedVolume', 'ForceCloseReason', 'CombOffsetFlag', 'VolumeTotalOriginal', 'SequenceNo', 'TraderID', 'OrderLocalID', 'InsertDate', 'BrokerID', 'FrontID', 'RelativeOrderSysID', 'UserProductInfo', 'InstallID', 'UpdateTime', 'ParticipantID', 'StopPrice', 'GTDDate', 'ActiveTime', 'InsertTime', 'ErrorMsg', 'SettlementID', 'VolumeTotal', 'BusinessUnit', 'OrderSource', 'UserForceClose', 'ClientID', 'OrderStatus', 'ExchangeID', 'UserID', 'Direction']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('OrderRef', u'报单引用'),('TimeCondition', u'有效期类型'),('InvestorID', u'投资者代码'),('SuspendTime', u'挂起时间'),('BrokerOrderSeq', u'经纪公司报单编号'),('RequestID', u'请求编号'),('CancelTime', u'撤销时间'),('OrderSysID', u'报单编号'),('LimitPrice', u'价格'),('OrderPriceType', u'报单价格条件'),('VolumeTraded', u'今成交数量'),('ExchangeInstID', u'合约在交易所的代码'),('ErrorID', u'错误代码'),('MinVolume', u'最小成交量'),('OrderType', u'报单类型'),('InstrumentID', u'合约代码'),('IsSwapOrder', u'互换单标志'),('VolumeCondition', u'成交量类型'),('ClearingPartID', u'结算会员编号'),('ActiveTraderID', u'最后修改交易所交易员代码'),('TradingDay', u'交易日'),('StatusMsg', u'状态信息'),('ActiveUserID', u'操作用户代码'),('OrderSubmitStatus', u'报单提交状态'),('ContingentCondition', u'触发条件'),('CombHedgeFlag', u'组合投机套保标志'),('IsAutoSuspend', u'自动挂起标志'),('SessionID', u'会话编号'),('NotifySequence', u'报单提示序号'),('ZCETotalTradedVolume', u'郑商所成交数量'),('ForceCloseReason', u'强平原因'),('CombOffsetFlag', u'组合开平标志'),('VolumeTotalOriginal', u'数量'),('SequenceNo', u'序号'),('TraderID', u'交易所交易员代码'),('OrderLocalID', u'本地报单编号'),('InsertDate', u'报单日期'),('BrokerID', u'经纪公司代码'),('FrontID', u'前置编号'),('RelativeOrderSysID', u'相关报单'),('UserProductInfo', u'用户端产品信息'),('InstallID', u'安装编号'),('UpdateTime', u'最后修改时间'),('ParticipantID', u'会员代码'),('StopPrice', u'止损价'),('GTDDate', u'GTD日期'),('ActiveTime', u'激活时间'),('InsertTime', u'委托时间'),('ErrorMsg', u'错误信息'),('SettlementID', u'结算编号'),('VolumeTotal', u'剩余数量'),('BusinessUnit', u'业务单元'),('OrderSource', u'报单来源'),('UserForceClose', u'用户强评标志'),('ClientID', u'客户代码'),('OrderStatus', u'报单状态'),('ExchangeID', u'交易所代码'),('UserID', u'用户代码'),('Direction', u'买卖方向')]])
    def getval(self, n):
        if n in ['TimeCondition', 'OrderPriceType', 'OrderType', 'VolumeCondition', 'OrderSubmitStatus', 'ContingentCondition', 'ForceCloseReason', 'OrderSource', 'OrderStatus', 'Direction']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcRemoveParkedOrderActionField:
    def __init__(self, InvestorID="", BrokerID="", ParkedOrderActionID=""):
        self.InvestorID=InvestorID
        self.BrokerID=BrokerID
        self.ParkedOrderActionID=ParkedOrderActionID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['InvestorID', 'BrokerID', 'ParkedOrderActionID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('InvestorID', u'投资者代码'),('BrokerID', u'经纪公司代码'),('ParkedOrderActionID', u'预埋撤单编号')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcTradingAccountPasswordField:
    def __init__(self, AccountID="", BrokerID="", Password=""):
        self.AccountID=AccountID
        self.BrokerID=BrokerID
        self.Password=Password
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['AccountID', 'BrokerID', 'Password']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('AccountID', u'投资者帐号'),('BrokerID', u'经纪公司代码'),('Password', u'密码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryErrOrderActionField:
    def __init__(self, InvestorID="", BrokerID=""):
        self.InvestorID=InvestorID
        self.BrokerID=BrokerID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['InvestorID', 'BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('InvestorID', u'投资者代码'),('BrokerID', u'经纪公司代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryTradeField:
    def __init__(self, ExchangeID="", TradeTimeStart="", BrokerID="", TradeID="", InvestorID="", InstrumentID="", TradeTimeEnd=""):
        self.ExchangeID=ExchangeID
        self.TradeTimeStart=TradeTimeStart
        self.BrokerID=BrokerID
        self.TradeID=TradeID
        self.InvestorID=InvestorID
        self.InstrumentID=InstrumentID
        self.TradeTimeEnd=TradeTimeEnd
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ExchangeID', 'TradeTimeStart', 'BrokerID', 'TradeID', 'InvestorID', 'InstrumentID', 'TradeTimeEnd']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ExchangeID', u'交易所代码'),('TradeTimeStart', u'开始时间'),('BrokerID', u'经纪公司代码'),('TradeID', u'成交编号'),('InvestorID', u'投资者代码'),('InstrumentID', u'合约代码'),('TradeTimeEnd', u'结束时间')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryLoginForbiddenUserField:
    def __init__(self, BrokerID="", UserID=""):
        self.BrokerID=BrokerID
        self.UserID=UserID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['BrokerID', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('BrokerID', u'经纪公司代码'),('UserID', u'用户代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcTransferFutureToBankRspField:
    def __init__(self, CustFee=0, RetInfo="", CurrencyCode="", RetCode="", FutureAccount="", TradeAmt=0):
        self.CustFee=CustFee
        self.RetInfo=RetInfo
        self.CurrencyCode=CurrencyCode
        self.RetCode=RetCode
        self.FutureAccount=FutureAccount
        self.TradeAmt=TradeAmt
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['CustFee', 'RetInfo', 'CurrencyCode', 'RetCode', 'FutureAccount', 'TradeAmt']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('CustFee', u'应收客户手续费'),('RetInfo', u'响应信息'),('CurrencyCode', u'币种'),('RetCode', u'响应代码'),('FutureAccount', u'资金账户'),('TradeAmt', u'转帐金额')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryInvestorPositionCombineDetailField:
    def __init__(self, CombInstrumentID="", InvestorID="", BrokerID=""):
        self.CombInstrumentID=CombInstrumentID
        self.InvestorID=InvestorID
        self.BrokerID=BrokerID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['CombInstrumentID', 'InvestorID', 'BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('CombInstrumentID', u'组合持仓合约编码'),('InvestorID', u'投资者代码'),('BrokerID', u'经纪公司代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcExchangeOrderInsertErrorField:
    def __init__(self, ParticipantID="", TraderID="", OrderLocalID="", ErrorID=0, ExchangeID="", ErrorMsg="", InstallID=0):
        self.ParticipantID=ParticipantID
        self.TraderID=TraderID
        self.OrderLocalID=OrderLocalID
        self.ErrorID=ErrorID
        self.ExchangeID=ExchangeID
        self.ErrorMsg=ErrorMsg
        self.InstallID=InstallID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ParticipantID', 'TraderID', 'OrderLocalID', 'ErrorID', 'ExchangeID', 'ErrorMsg', 'InstallID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ParticipantID', u'会员代码'),('TraderID', u'交易所交易员代码'),('OrderLocalID', u'本地报单编号'),('ErrorID', u'错误代码'),('ExchangeID', u'交易所代码'),('ErrorMsg', u'错误信息'),('InstallID', u'安装编号')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryCommRateModelField:
    def __init__(self, BrokerID="", CommModelID=""):
        self.BrokerID=BrokerID
        self.CommModelID=CommModelID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['BrokerID', 'CommModelID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('BrokerID', u'经纪公司代码'),('CommModelID', u'手续费率模板代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryExchangeField:
    def __init__(self, ExchangeID=""):
        self.ExchangeID=ExchangeID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ExchangeID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ExchangeID', u'交易所代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcSpecificInstrumentField:
    def __init__(self, InstrumentID=""):
        self.InstrumentID=InstrumentID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['InstrumentID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('InstrumentID', u'合约代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcRemoveParkedOrderField:
    def __init__(self, InvestorID="", BrokerID="", ParkedOrderID=""):
        self.InvestorID=InvestorID
        self.BrokerID=BrokerID
        self.ParkedOrderID=ParkedOrderID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['InvestorID', 'BrokerID', 'ParkedOrderID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('InvestorID', u'投资者代码'),('BrokerID', u'经纪公司代码'),('ParkedOrderID', u'预埋报单编号')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryCFMMCBrokerKeyField:
    def __init__(self, BrokerID=""):
        self.BrokerID=BrokerID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('BrokerID', u'经纪公司代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcOpenAccountField:
    def __init__(self, PlateSerial=0, Digest="", CashExchangeCode='1', TID=0, BankAccount="", ErrorMsg="", TradeCode="", Gender='0', BankID="", BankSecuAcc="", BankSecuAccType='1', BrokerIDByBank="", BankPassWord="", MoneyAccountStatus='0', ErrorID=0, CustomerName="", OperNo="", BrokerBranchID="", SecuPwdFlag='0', CountryCode="", AccountID="", EMail="", ZipCode="", BankSerial="", Telephone="", TradeTime="", VerifyCertNoFlag='0', LastFragment='0', CurrencyID="", BrokerID="", MobilePhone="", CustType='0', InstallID=0, TradingDay="", Fax="", BankPwdFlag='0', BankBranchID="", Password="", BankAccType='1', DeviceID="", IdentifiedCardNo="", IdCardType='0', TradeDate="", Address="", SessionID=0, UserID=""):
        self.PlateSerial=PlateSerial
        self.Digest=Digest
        self.CashExchangeCode=CashExchangeCode
        self.TID=TID
        self.BankAccount=BankAccount
        self.ErrorMsg=ErrorMsg
        self.TradeCode=TradeCode
        self.Gender=Gender
        self.BankID=BankID
        self.BankSecuAcc=BankSecuAcc
        self.BankSecuAccType=BankSecuAccType
        self.BrokerIDByBank=BrokerIDByBank
        self.BankPassWord=BankPassWord
        self.MoneyAccountStatus=MoneyAccountStatus
        self.ErrorID=ErrorID
        self.CustomerName=CustomerName
        self.OperNo=OperNo
        self.BrokerBranchID=BrokerBranchID
        self.SecuPwdFlag=SecuPwdFlag
        self.CountryCode=CountryCode
        self.AccountID=AccountID
        self.EMail=EMail
        self.ZipCode=ZipCode
        self.BankSerial=BankSerial
        self.Telephone=Telephone
        self.TradeTime=TradeTime
        self.VerifyCertNoFlag=VerifyCertNoFlag
        self.LastFragment=LastFragment
        self.CurrencyID=CurrencyID
        self.BrokerID=BrokerID
        self.MobilePhone=MobilePhone
        self.CustType=CustType
        self.InstallID=InstallID
        self.TradingDay=TradingDay
        self.Fax=Fax
        self.BankPwdFlag=BankPwdFlag
        self.BankBranchID=BankBranchID
        self.Password=Password
        self.BankAccType=BankAccType
        self.DeviceID=DeviceID
        self.IdentifiedCardNo=IdentifiedCardNo
        self.IdCardType=IdCardType
        self.TradeDate=TradeDate
        self.Address=Address
        self.SessionID=SessionID
        self.UserID=UserID
        self.vcmap={'IdCardType': {"'0'": '组织机构代码', "'6'": '护照', "'7'": '台胞证', "'2'": '军官证', "'8'": '回乡证', "'3'": '警官证', "'1'": '身份证', "'x'": '其他证件', "'9'": '营业执照号', "'5'": '户口簿', "'A'": '税务登记号', "'4'": '士兵证'}, 'VerifyCertNoFlag': {"'0'": '是', "'1'": '否'}, 'Gender': {"'2'": '女', "'0'": '未知状态', "'1'": '男'}, 'BankPwdFlag': {"'2'": '密文核对', "'0'": '不核对', "'1'": '明文核对'}, 'MoneyAccountStatus': {"'0'": '正常', "'1'": '销户'}, 'CashExchangeCode': {"'2'": '钞', "'1'": '汇'}, 'BankSecuAccType': {"'2'": '储蓄卡', "'3'": '信用卡', "'1'": '银行存折'}, 'CustType': {"'0'": '自然人', "'1'": '机构户'}, 'SecuPwdFlag': {"'2'": '密文核对', "'0'": '不核对', "'1'": '明文核对'}, 'BankAccType': {"'2'": '储蓄卡', "'3'": '信用卡', "'1'": '银行存折'}, 'LastFragment': {"'0'": '是最后分片', "'1'": '不是最后分片'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['PlateSerial', 'Digest', 'CashExchangeCode', 'TID', 'BankAccount', 'ErrorMsg', 'TradeCode', 'Gender', 'BankID', 'BankSecuAcc', 'BankSecuAccType', 'BrokerIDByBank', 'BankPassWord', 'MoneyAccountStatus', 'ErrorID', 'CustomerName', 'OperNo', 'BrokerBranchID', 'SecuPwdFlag', 'CountryCode', 'AccountID', 'EMail', 'ZipCode', 'BankSerial', 'Telephone', 'TradeTime', 'VerifyCertNoFlag', 'LastFragment', 'CurrencyID', 'BrokerID', 'MobilePhone', 'CustType', 'InstallID', 'TradingDay', 'Fax', 'BankPwdFlag', 'BankBranchID', 'Password', 'BankAccType', 'DeviceID', 'IdentifiedCardNo', 'IdCardType', 'TradeDate', 'Address', 'SessionID', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('PlateSerial', u'银期平台消息流水号'),('Digest', u'摘要'),('CashExchangeCode', u'汇钞标志'),('TID', u'交易ID'),('BankAccount', u'银行帐号'),('ErrorMsg', u'错误信息'),('TradeCode', u'业务功能码'),('Gender', u'性别'),('BankID', u'银行代码'),('BankSecuAcc', u'期货单位帐号'),('BankSecuAccType', u'期货单位帐号类型'),('BrokerIDByBank', u'期货公司银行编码'),('BankPassWord', u'银行密码'),('MoneyAccountStatus', u'资金账户状态'),('ErrorID', u'错误代码'),('CustomerName', u'客户姓名'),('OperNo', u'交易柜员'),('BrokerBranchID', u'期商分支机构代码'),('SecuPwdFlag', u'期货资金密码核对标志'),('CountryCode', u'国家代码'),('AccountID', u'投资者帐号'),('EMail', u'电子邮件'),('ZipCode', u'邮编'),('BankSerial', u'银行流水号'),('Telephone', u'电话号码'),('TradeTime', u'交易时间'),('VerifyCertNoFlag', u'验证客户证件号码标志'),('LastFragment', u'最后分片标志'),('CurrencyID', u'币种代码'),('BrokerID', u'期商代码'),('MobilePhone', u'手机'),('CustType', u'客户类型'),('InstallID', u'安装编号'),('TradingDay', u'交易系统日期'),('Fax', u'传真'),('BankPwdFlag', u'银行密码标志'),('BankBranchID', u'银行分支机构代码'),('Password', u'期货密码'),('BankAccType', u'银行帐号类型'),('DeviceID', u'渠道标志'),('IdentifiedCardNo', u'证件号码'),('IdCardType', u'证件类型'),('TradeDate', u'交易日期'),('Address', u'地址'),('SessionID', u'会话号'),('UserID', u'用户标识')]])
    def getval(self, n):
        if n in ['CashExchangeCode', 'Gender', 'BankSecuAccType', 'MoneyAccountStatus', 'SecuPwdFlag', 'VerifyCertNoFlag', 'LastFragment', 'CustType', 'BankPwdFlag', 'BankAccType', 'IdCardType']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcMarginModelField:
    def __init__(self, MarginModelID="", MarginModelName="", BrokerID=""):
        self.MarginModelID=MarginModelID
        self.MarginModelName=MarginModelName
        self.BrokerID=BrokerID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['MarginModelID', 'MarginModelName', 'BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('MarginModelID', u'保证金率模板代码'),('MarginModelName', u'模板名称'),('BrokerID', u'经纪公司代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryCFMMCTradingAccountKeyField:
    def __init__(self, InvestorID="", BrokerID=""):
        self.InvestorID=InvestorID
        self.BrokerID=BrokerID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['InvestorID', 'BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('InvestorID', u'投资者代码'),('BrokerID', u'经纪公司代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcFutureSignIOField:
    def __init__(self, TradeTime="", CurrencyID="", Digest="", BankID="", OperNo="", BrokerIDByBank="", BrokerBranchID="", BankBranchID="", TradeCode="", LastFragment='0', DeviceID="", PlateSerial=0, TradingDay="", BrokerID="", TradeDate="", BankSerial="", SessionID=0, RequestID=0, UserID="", InstallID=0, TID=0):
        self.TradeTime=TradeTime
        self.CurrencyID=CurrencyID
        self.Digest=Digest
        self.BankID=BankID
        self.OperNo=OperNo
        self.BrokerIDByBank=BrokerIDByBank
        self.BrokerBranchID=BrokerBranchID
        self.BankBranchID=BankBranchID
        self.TradeCode=TradeCode
        self.LastFragment=LastFragment
        self.DeviceID=DeviceID
        self.PlateSerial=PlateSerial
        self.TradingDay=TradingDay
        self.BrokerID=BrokerID
        self.TradeDate=TradeDate
        self.BankSerial=BankSerial
        self.SessionID=SessionID
        self.RequestID=RequestID
        self.UserID=UserID
        self.InstallID=InstallID
        self.TID=TID
        self.vcmap={'LastFragment': {"'0'": '是最后分片', "'1'": '不是最后分片'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['TradeTime', 'CurrencyID', 'Digest', 'BankID', 'OperNo', 'BrokerIDByBank', 'BrokerBranchID', 'BankBranchID', 'TradeCode', 'LastFragment', 'DeviceID', 'PlateSerial', 'TradingDay', 'BrokerID', 'TradeDate', 'BankSerial', 'SessionID', 'RequestID', 'UserID', 'InstallID', 'TID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('TradeTime', u'交易时间'),('CurrencyID', u'币种代码'),('Digest', u'摘要'),('BankID', u'银行代码'),('OperNo', u'交易柜员'),('BrokerIDByBank', u'期货公司银行编码'),('BrokerBranchID', u'期商分支机构代码'),('BankBranchID', u'银行分支机构代码'),('TradeCode', u'业务功能码'),('LastFragment', u'最后分片标志'),('DeviceID', u'渠道标志'),('PlateSerial', u'银期平台消息流水号'),('TradingDay', u'交易系统日期'),('BrokerID', u'期商代码'),('TradeDate', u'交易日期'),('BankSerial', u'银行流水号'),('SessionID', u'会话号'),('RequestID', u'请求编号'),('UserID', u'用户标识'),('InstallID', u'安装编号'),('TID', u'交易ID')]])
    def getval(self, n):
        if n in ['LastFragment']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryCombinationLegField:
    def __init__(self, CombInstrumentID="", LegInstrumentID="", LegID=0):
        self.CombInstrumentID=CombInstrumentID
        self.LegInstrumentID=LegInstrumentID
        self.LegID=LegID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['CombInstrumentID', 'LegInstrumentID', 'LegID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('CombInstrumentID', u'组合合约代码'),('LegInstrumentID', u'单腿合约代码'),('LegID', u'单腿编号')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcEWarrantOffsetField:
    def __init__(self, Volume=0, TradingDay="", BrokerID="", HedgeFlag='1', ExchangeID="", InvestorID="", InstrumentID="", Direction='0'):
        self.Volume=Volume
        self.TradingDay=TradingDay
        self.BrokerID=BrokerID
        self.HedgeFlag=HedgeFlag
        self.ExchangeID=ExchangeID
        self.InvestorID=InvestorID
        self.InstrumentID=InstrumentID
        self.Direction=Direction
        self.vcmap={'HedgeFlag': {"'2'": '套利', "'3'": '套保', "'1'": '投机'}, 'Direction': {"'0'": '买', "'1'": '卖'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['Volume', 'TradingDay', 'BrokerID', 'HedgeFlag', 'ExchangeID', 'InvestorID', 'InstrumentID', 'Direction']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('Volume', u'数量'),('TradingDay', u'交易日期'),('BrokerID', u'经纪公司代码'),('HedgeFlag', u'投机套保标志'),('ExchangeID', u'交易所代码'),('InvestorID', u'投资者代码'),('InstrumentID', u'合约代码'),('Direction', u'买卖方向')]])
    def getval(self, n):
        if n in ['HedgeFlag', 'Direction']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcForceUserLogoutField:
    def __init__(self, BrokerID="", UserID=""):
        self.BrokerID=BrokerID
        self.UserID=UserID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['BrokerID', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('BrokerID', u'经纪公司代码'),('UserID', u'用户代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcTradingAccountPasswordUpdateField:
    def __init__(self, OldPassword="", AccountID="", BrokerID="", NewPassword=""):
        self.OldPassword=OldPassword
        self.AccountID=AccountID
        self.BrokerID=BrokerID
        self.NewPassword=NewPassword
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['OldPassword', 'AccountID', 'BrokerID', 'NewPassword']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('OldPassword', u'原来的口令'),('AccountID', u'投资者帐号'),('BrokerID', u'经纪公司代码'),('NewPassword', u'新的口令')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryBrokerTradingAlgosField:
    def __init__(self, ExchangeID="", BrokerID="", InstrumentID=""):
        self.ExchangeID=ExchangeID
        self.BrokerID=BrokerID
        self.InstrumentID=InstrumentID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ExchangeID', 'BrokerID', 'InstrumentID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ExchangeID', u'交易所代码'),('BrokerID', u'经纪公司代码'),('InstrumentID', u'合约代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcSyncingInvestorGroupField:
    def __init__(self, InvestorGroupName="", InvestorGroupID="", BrokerID=""):
        self.InvestorGroupName=InvestorGroupName
        self.InvestorGroupID=InvestorGroupID
        self.BrokerID=BrokerID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['InvestorGroupName', 'InvestorGroupID', 'BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('InvestorGroupName', u'投资者分组名称'),('InvestorGroupID', u'投资者分组代码'),('BrokerID', u'经纪公司代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcInputOrderActionField:
    def __init__(self, OrderActionRef=0, LimitPrice=0, ActionFlag='0', InvestorID="", OrderRef="", SessionID=0, VolumeChange=0, RequestID=0, BrokerID="", OrderSysID="", FrontID=0, ExchangeID="", UserID="", InstrumentID=""):
        self.OrderActionRef=OrderActionRef
        self.LimitPrice=LimitPrice
        self.ActionFlag=ActionFlag
        self.InvestorID=InvestorID
        self.OrderRef=OrderRef
        self.SessionID=SessionID
        self.VolumeChange=VolumeChange
        self.RequestID=RequestID
        self.BrokerID=BrokerID
        self.OrderSysID=OrderSysID
        self.FrontID=FrontID
        self.ExchangeID=ExchangeID
        self.UserID=UserID
        self.InstrumentID=InstrumentID
        self.vcmap={'ActionFlag': {"'0'": '删除', "'3'": '修改'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['OrderActionRef', 'LimitPrice', 'ActionFlag', 'InvestorID', 'OrderRef', 'SessionID', 'VolumeChange', 'RequestID', 'BrokerID', 'OrderSysID', 'FrontID', 'ExchangeID', 'UserID', 'InstrumentID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('OrderActionRef', u'报单操作引用'),('LimitPrice', u'价格'),('ActionFlag', u'操作标志'),('InvestorID', u'投资者代码'),('OrderRef', u'报单引用'),('SessionID', u'会话编号'),('VolumeChange', u'数量变化'),('RequestID', u'请求编号'),('BrokerID', u'经纪公司代码'),('OrderSysID', u'报单编号'),('FrontID', u'前置编号'),('ExchangeID', u'交易所代码'),('UserID', u'用户代码'),('InstrumentID', u'合约代码')]])
    def getval(self, n):
        if n in ['ActionFlag']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcInvestorPositionDetailField:
    def __init__(self, Volume=0, SettlementPrice=0, PositionProfitByTrade=0, OpenPrice=0, InvestorID="", InstrumentID="", OpenDate="", LastSettlementPrice=0, BrokerID="", HedgeFlag='1', CloseVolume=0, MarginRateByVolume=0, MarginRateByMoney=0, CloseAmount=0, CloseProfitByDate=0, TradeID="", PositionProfitByDate=0, CloseProfitByTrade=0, SettlementID=0, TradeType='0', TradingDay="", ExchMargin=0, Margin=0, CombInstrumentID="", ExchangeID="", Direction='0'):
        self.Volume=Volume
        self.SettlementPrice=SettlementPrice
        self.PositionProfitByTrade=PositionProfitByTrade
        self.OpenPrice=OpenPrice
        self.InvestorID=InvestorID
        self.InstrumentID=InstrumentID
        self.OpenDate=OpenDate
        self.LastSettlementPrice=LastSettlementPrice
        self.BrokerID=BrokerID
        self.HedgeFlag=HedgeFlag
        self.CloseVolume=CloseVolume
        self.MarginRateByVolume=MarginRateByVolume
        self.MarginRateByMoney=MarginRateByMoney
        self.CloseAmount=CloseAmount
        self.CloseProfitByDate=CloseProfitByDate
        self.TradeID=TradeID
        self.PositionProfitByDate=PositionProfitByDate
        self.CloseProfitByTrade=CloseProfitByTrade
        self.SettlementID=SettlementID
        self.TradeType=TradeType
        self.TradingDay=TradingDay
        self.ExchMargin=ExchMargin
        self.Margin=Margin
        self.CombInstrumentID=CombInstrumentID
        self.ExchangeID=ExchangeID
        self.Direction=Direction
        self.vcmap={'HedgeFlag': {"'2'": '套利', "'3'": '套保', "'1'": '投机'}, 'TradeType': {"'2'": 'OTC成交', "'0'": '普通成交', "'3'": '期转现衍生成交', "'1'": '期权执行', "'4'": '组合衍生成交'}, 'Direction': {"'0'": '买', "'1'": '卖'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['Volume', 'SettlementPrice', 'PositionProfitByTrade', 'OpenPrice', 'InvestorID', 'InstrumentID', 'OpenDate', 'LastSettlementPrice', 'BrokerID', 'HedgeFlag', 'CloseVolume', 'MarginRateByVolume', 'MarginRateByMoney', 'CloseAmount', 'CloseProfitByDate', 'TradeID', 'PositionProfitByDate', 'CloseProfitByTrade', 'SettlementID', 'TradeType', 'TradingDay', 'ExchMargin', 'Margin', 'CombInstrumentID', 'ExchangeID', 'Direction']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('Volume', u'数量'),('SettlementPrice', u'结算价'),('PositionProfitByTrade', u'逐笔对冲持仓盈亏'),('OpenPrice', u'开仓价'),('InvestorID', u'投资者代码'),('InstrumentID', u'合约代码'),('OpenDate', u'开仓日期'),('LastSettlementPrice', u'昨结算价'),('BrokerID', u'经纪公司代码'),('HedgeFlag', u'投机套保标志'),('CloseVolume', u'平仓量'),('MarginRateByVolume', u'保证金率(按手数)'),('MarginRateByMoney', u'保证金率'),('CloseAmount', u'平仓金额'),('CloseProfitByDate', u'逐日盯市平仓盈亏'),('TradeID', u'成交编号'),('PositionProfitByDate', u'逐日盯市持仓盈亏'),('CloseProfitByTrade', u'逐笔对冲平仓盈亏'),('SettlementID', u'结算编号'),('TradeType', u'成交类型'),('TradingDay', u'交易日'),('ExchMargin', u'交易所保证金'),('Margin', u'投资者保证金'),('CombInstrumentID', u'组合合约代码'),('ExchangeID', u'交易所代码'),('Direction', u'买卖')]])
    def getval(self, n):
        if n in ['HedgeFlag', 'TradeType', 'Direction']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcReqOpenAccountField:
    def __init__(self, PlateSerial=0, Digest="", CashExchangeCode='1', TID=0, BankAccount="", TradeCode="", Gender='0', BankID="", BankSecuAcc="", BankSecuAccType='1', BrokerIDByBank="", BankPassWord="", MoneyAccountStatus='0', CustomerName="", OperNo="", BrokerBranchID="", SecuPwdFlag='0', CountryCode="", AccountID="", EMail="", ZipCode="", BankSerial="", Telephone="", TradeTime="", VerifyCertNoFlag='0', LastFragment='0', CurrencyID="", BrokerID="", MobilePhone="", CustType='0', InstallID=0, TradingDay="", Fax="", BankPwdFlag='0', BankBranchID="", Password="", BankAccType='1', DeviceID="", IdentifiedCardNo="", IdCardType='0', TradeDate="", Address="", SessionID=0, UserID=""):
        self.PlateSerial=PlateSerial
        self.Digest=Digest
        self.CashExchangeCode=CashExchangeCode
        self.TID=TID
        self.BankAccount=BankAccount
        self.TradeCode=TradeCode
        self.Gender=Gender
        self.BankID=BankID
        self.BankSecuAcc=BankSecuAcc
        self.BankSecuAccType=BankSecuAccType
        self.BrokerIDByBank=BrokerIDByBank
        self.BankPassWord=BankPassWord
        self.MoneyAccountStatus=MoneyAccountStatus
        self.CustomerName=CustomerName
        self.OperNo=OperNo
        self.BrokerBranchID=BrokerBranchID
        self.SecuPwdFlag=SecuPwdFlag
        self.CountryCode=CountryCode
        self.AccountID=AccountID
        self.EMail=EMail
        self.ZipCode=ZipCode
        self.BankSerial=BankSerial
        self.Telephone=Telephone
        self.TradeTime=TradeTime
        self.VerifyCertNoFlag=VerifyCertNoFlag
        self.LastFragment=LastFragment
        self.CurrencyID=CurrencyID
        self.BrokerID=BrokerID
        self.MobilePhone=MobilePhone
        self.CustType=CustType
        self.InstallID=InstallID
        self.TradingDay=TradingDay
        self.Fax=Fax
        self.BankPwdFlag=BankPwdFlag
        self.BankBranchID=BankBranchID
        self.Password=Password
        self.BankAccType=BankAccType
        self.DeviceID=DeviceID
        self.IdentifiedCardNo=IdentifiedCardNo
        self.IdCardType=IdCardType
        self.TradeDate=TradeDate
        self.Address=Address
        self.SessionID=SessionID
        self.UserID=UserID
        self.vcmap={'IdCardType': {"'0'": '组织机构代码', "'6'": '护照', "'7'": '台胞证', "'2'": '军官证', "'8'": '回乡证', "'3'": '警官证', "'1'": '身份证', "'x'": '其他证件', "'9'": '营业执照号', "'5'": '户口簿', "'A'": '税务登记号', "'4'": '士兵证'}, 'VerifyCertNoFlag': {"'0'": '是', "'1'": '否'}, 'Gender': {"'2'": '女', "'0'": '未知状态', "'1'": '男'}, 'BankPwdFlag': {"'2'": '密文核对', "'0'": '不核对', "'1'": '明文核对'}, 'MoneyAccountStatus': {"'0'": '正常', "'1'": '销户'}, 'CashExchangeCode': {"'2'": '钞', "'1'": '汇'}, 'BankSecuAccType': {"'2'": '储蓄卡', "'3'": '信用卡', "'1'": '银行存折'}, 'CustType': {"'0'": '自然人', "'1'": '机构户'}, 'SecuPwdFlag': {"'2'": '密文核对', "'0'": '不核对', "'1'": '明文核对'}, 'BankAccType': {"'2'": '储蓄卡', "'3'": '信用卡', "'1'": '银行存折'}, 'LastFragment': {"'0'": '是最后分片', "'1'": '不是最后分片'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['PlateSerial', 'Digest', 'CashExchangeCode', 'TID', 'BankAccount', 'TradeCode', 'Gender', 'BankID', 'BankSecuAcc', 'BankSecuAccType', 'BrokerIDByBank', 'BankPassWord', 'MoneyAccountStatus', 'CustomerName', 'OperNo', 'BrokerBranchID', 'SecuPwdFlag', 'CountryCode', 'AccountID', 'EMail', 'ZipCode', 'BankSerial', 'Telephone', 'TradeTime', 'VerifyCertNoFlag', 'LastFragment', 'CurrencyID', 'BrokerID', 'MobilePhone', 'CustType', 'InstallID', 'TradingDay', 'Fax', 'BankPwdFlag', 'BankBranchID', 'Password', 'BankAccType', 'DeviceID', 'IdentifiedCardNo', 'IdCardType', 'TradeDate', 'Address', 'SessionID', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('PlateSerial', u'银期平台消息流水号'),('Digest', u'摘要'),('CashExchangeCode', u'汇钞标志'),('TID', u'交易ID'),('BankAccount', u'银行帐号'),('TradeCode', u'业务功能码'),('Gender', u'性别'),('BankID', u'银行代码'),('BankSecuAcc', u'期货单位帐号'),('BankSecuAccType', u'期货单位帐号类型'),('BrokerIDByBank', u'期货公司银行编码'),('BankPassWord', u'银行密码'),('MoneyAccountStatus', u'资金账户状态'),('CustomerName', u'客户姓名'),('OperNo', u'交易柜员'),('BrokerBranchID', u'期商分支机构代码'),('SecuPwdFlag', u'期货资金密码核对标志'),('CountryCode', u'国家代码'),('AccountID', u'投资者帐号'),('EMail', u'电子邮件'),('ZipCode', u'邮编'),('BankSerial', u'银行流水号'),('Telephone', u'电话号码'),('TradeTime', u'交易时间'),('VerifyCertNoFlag', u'验证客户证件号码标志'),('LastFragment', u'最后分片标志'),('CurrencyID', u'币种代码'),('BrokerID', u'期商代码'),('MobilePhone', u'手机'),('CustType', u'客户类型'),('InstallID', u'安装编号'),('TradingDay', u'交易系统日期'),('Fax', u'传真'),('BankPwdFlag', u'银行密码标志'),('BankBranchID', u'银行分支机构代码'),('Password', u'期货密码'),('BankAccType', u'银行帐号类型'),('DeviceID', u'渠道标志'),('IdentifiedCardNo', u'证件号码'),('IdCardType', u'证件类型'),('TradeDate', u'交易日期'),('Address', u'地址'),('SessionID', u'会话号'),('UserID', u'用户标识')]])
    def getval(self, n):
        if n in ['CashExchangeCode', 'Gender', 'BankSecuAccType', 'MoneyAccountStatus', 'SecuPwdFlag', 'VerifyCertNoFlag', 'LastFragment', 'CustType', 'BankPwdFlag', 'BankAccType', 'IdCardType']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryUserSessionField:
    def __init__(self, SessionID=0, FrontID=0, BrokerID="", UserID=""):
        self.SessionID=SessionID
        self.FrontID=FrontID
        self.BrokerID=BrokerID
        self.UserID=UserID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['SessionID', 'FrontID', 'BrokerID', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('SessionID', u'会话编号'),('FrontID', u'前置编号'),('BrokerID', u'经纪公司代码'),('UserID', u'用户代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcReqTransferField:
    def __init__(self, TradeTime="", FutureFetchAmount=0, TradeDate="", BankPwdFlag='0', BankAccount="", VerifyCertNoFlag='0', TradeAmount=0, LastFragment='0', TradeCode="", SecuPwdFlag='0', Digest="", RequestID=0, BrokerID="", BankID="", BankSecuAcc="", FutureSerial=0, Message="", CustType='0', InstallID=0, TID=0, DeviceID="", CurrencyID="", BankSecuAccType='1', CustFee=0, OperNo="", CustomerName="", BrokerIDByBank="", BrokerBranchID="", BankBranchID="", IdCardType='0', Password="", BankAccType='1', BankPassWord="", IdentifiedCardNo="", AccountID="", TradingDay="", BrokerFee=0, PlateSerial=0, BankSerial="", SessionID=0, TransferStatus='0', UserID="", FeePayFlag='0'):
        self.TradeTime=TradeTime
        self.FutureFetchAmount=FutureFetchAmount
        self.TradeDate=TradeDate
        self.BankPwdFlag=BankPwdFlag
        self.BankAccount=BankAccount
        self.VerifyCertNoFlag=VerifyCertNoFlag
        self.TradeAmount=TradeAmount
        self.LastFragment=LastFragment
        self.TradeCode=TradeCode
        self.SecuPwdFlag=SecuPwdFlag
        self.Digest=Digest
        self.RequestID=RequestID
        self.BrokerID=BrokerID
        self.BankID=BankID
        self.BankSecuAcc=BankSecuAcc
        self.FutureSerial=FutureSerial
        self.Message=Message
        self.CustType=CustType
        self.InstallID=InstallID
        self.TID=TID
        self.DeviceID=DeviceID
        self.CurrencyID=CurrencyID
        self.BankSecuAccType=BankSecuAccType
        self.CustFee=CustFee
        self.OperNo=OperNo
        self.CustomerName=CustomerName
        self.BrokerIDByBank=BrokerIDByBank
        self.BrokerBranchID=BrokerBranchID
        self.BankBranchID=BankBranchID
        self.IdCardType=IdCardType
        self.Password=Password
        self.BankAccType=BankAccType
        self.BankPassWord=BankPassWord
        self.IdentifiedCardNo=IdentifiedCardNo
        self.AccountID=AccountID
        self.TradingDay=TradingDay
        self.BrokerFee=BrokerFee
        self.PlateSerial=PlateSerial
        self.BankSerial=BankSerial
        self.SessionID=SessionID
        self.TransferStatus=TransferStatus
        self.UserID=UserID
        self.FeePayFlag=FeePayFlag
        self.vcmap={'IdCardType': {"'0'": '组织机构代码', "'6'": '护照', "'7'": '台胞证', "'2'": '军官证', "'8'": '回乡证', "'3'": '警官证', "'1'": '身份证', "'x'": '其他证件', "'9'": '营业执照号', "'5'": '户口簿', "'A'": '税务登记号', "'4'": '士兵证'}, 'BankPwdFlag': {"'2'": '密文核对', "'0'": '不核对', "'1'": '明文核对'}, 'FeePayFlag': {"'2'": '由发送方支付发起的费用，受益方支付接受的费用', "'0'": '由受益方支付费用', "'1'": '由发送方支付费用'}, 'BankSecuAccType': {"'2'": '储蓄卡', "'3'": '信用卡', "'1'": '银行存折'}, 'TransferStatus': {"'0'": '正常', "'1'": '被冲正'}, 'VerifyCertNoFlag': {"'0'": '是', "'1'": '否'}, 'CustType': {"'0'": '自然人', "'1'": '机构户'}, 'LastFragment': {"'0'": '是最后分片', "'1'": '不是最后分片'}, 'BankAccType': {"'2'": '储蓄卡', "'3'": '信用卡', "'1'": '银行存折'}, 'SecuPwdFlag': {"'2'": '密文核对', "'0'": '不核对', "'1'": '明文核对'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['TradeTime', 'FutureFetchAmount', 'TradeDate', 'BankPwdFlag', 'BankAccount', 'VerifyCertNoFlag', 'TradeAmount', 'LastFragment', 'TradeCode', 'SecuPwdFlag', 'Digest', 'RequestID', 'BrokerID', 'BankID', 'BankSecuAcc', 'FutureSerial', 'Message', 'CustType', 'InstallID', 'TID', 'DeviceID', 'CurrencyID', 'BankSecuAccType', 'CustFee', 'OperNo', 'CustomerName', 'BrokerIDByBank', 'BrokerBranchID', 'BankBranchID', 'IdCardType', 'Password', 'BankAccType', 'BankPassWord', 'IdentifiedCardNo', 'AccountID', 'TradingDay', 'BrokerFee', 'PlateSerial', 'BankSerial', 'SessionID', 'TransferStatus', 'UserID', 'FeePayFlag']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('TradeTime', u'交易时间'),('FutureFetchAmount', u'期货可取金额'),('TradeDate', u'交易日期'),('BankPwdFlag', u'银行密码标志'),('BankAccount', u'银行帐号'),('VerifyCertNoFlag', u'验证客户证件号码标志'),('TradeAmount', u'转帐金额'),('LastFragment', u'最后分片标志'),('TradeCode', u'业务功能码'),('SecuPwdFlag', u'期货资金密码核对标志'),('Digest', u'摘要'),('RequestID', u'请求编号'),('BrokerID', u'期商代码'),('BankID', u'银行代码'),('BankSecuAcc', u'期货单位帐号'),('FutureSerial', u'期货公司流水号'),('Message', u'发送方给接收方的消息'),('CustType', u'客户类型'),('InstallID', u'安装编号'),('TID', u'交易ID'),('DeviceID', u'渠道标志'),('CurrencyID', u'币种代码'),('BankSecuAccType', u'期货单位帐号类型'),('CustFee', u'应收客户费用'),('OperNo', u'交易柜员'),('CustomerName', u'客户姓名'),('BrokerIDByBank', u'期货公司银行编码'),('BrokerBranchID', u'期商分支机构代码'),('BankBranchID', u'银行分支机构代码'),('IdCardType', u'证件类型'),('Password', u'期货密码'),('BankAccType', u'银行帐号类型'),('BankPassWord', u'银行密码'),('IdentifiedCardNo', u'证件号码'),('AccountID', u'投资者帐号'),('TradingDay', u'交易系统日期'),('BrokerFee', u'应收期货公司费用'),('PlateSerial', u'银期平台消息流水号'),('BankSerial', u'银行流水号'),('SessionID', u'会话号'),('TransferStatus', u'转账交易状态'),('UserID', u'用户标识'),('FeePayFlag', u'费用支付标志')]])
    def getval(self, n):
        if n in ['BankPwdFlag', 'VerifyCertNoFlag', 'LastFragment', 'SecuPwdFlag', 'CustType', 'BankSecuAccType', 'IdCardType', 'BankAccType', 'TransferStatus', 'FeePayFlag']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryHisOrderField:
    def __init__(self, InsertTimeStart="", InsertTimeEnd="", TradingDay="", BrokerID="", OrderSysID="", ExchangeID="", InvestorID="", InstrumentID="", SettlementID=0):
        self.InsertTimeStart=InsertTimeStart
        self.InsertTimeEnd=InsertTimeEnd
        self.TradingDay=TradingDay
        self.BrokerID=BrokerID
        self.OrderSysID=OrderSysID
        self.ExchangeID=ExchangeID
        self.InvestorID=InvestorID
        self.InstrumentID=InstrumentID
        self.SettlementID=SettlementID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['InsertTimeStart', 'InsertTimeEnd', 'TradingDay', 'BrokerID', 'OrderSysID', 'ExchangeID', 'InvestorID', 'InstrumentID', 'SettlementID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('InsertTimeStart', u'开始时间'),('InsertTimeEnd', u'结束时间'),('TradingDay', u'交易日'),('BrokerID', u'经纪公司代码'),('OrderSysID', u'报单编号'),('ExchangeID', u'交易所代码'),('InvestorID', u'投资者代码'),('InstrumentID', u'合约代码'),('SettlementID', u'结算编号')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcInstrumentField:
    def __init__(self, ShortMarginRatio=0, MinLimitOrderVolume=0, MinMarketOrderVolume=0, PositionDateType='1', ProductClass='1', InstrumentName="", OpenDate="", ExpireDate="", InstLifePhase='0', ProductID="", LongMarginRatio=0, EndDelivDate="", ExchangeInstID="", MaxMarketOrderVolume=0, MaxMarginSideAlgorithm='0', StartDelivDate="", IsTrading=0, InstrumentID="", DeliveryMonth=0, PositionType='1', MaxLimitOrderVolume=0, PriceTick=0, CreateDate="", DeliveryYear=0, ExchangeID="", VolumeMultiple=0):
        self.ShortMarginRatio=ShortMarginRatio
        self.MinLimitOrderVolume=MinLimitOrderVolume
        self.MinMarketOrderVolume=MinMarketOrderVolume
        self.PositionDateType=PositionDateType
        self.ProductClass=ProductClass
        self.InstrumentName=InstrumentName
        self.OpenDate=OpenDate
        self.ExpireDate=ExpireDate
        self.InstLifePhase=InstLifePhase
        self.ProductID=ProductID
        self.LongMarginRatio=LongMarginRatio
        self.EndDelivDate=EndDelivDate
        self.ExchangeInstID=ExchangeInstID
        self.MaxMarketOrderVolume=MaxMarketOrderVolume
        self.MaxMarginSideAlgorithm=MaxMarginSideAlgorithm
        self.StartDelivDate=StartDelivDate
        self.IsTrading=IsTrading
        self.InstrumentID=InstrumentID
        self.DeliveryMonth=DeliveryMonth
        self.PositionType=PositionType
        self.MaxLimitOrderVolume=MaxLimitOrderVolume
        self.PriceTick=PriceTick
        self.CreateDate=CreateDate
        self.DeliveryYear=DeliveryYear
        self.ExchangeID=ExchangeID
        self.VolumeMultiple=VolumeMultiple
        self.vcmap={'PositionDateType': {"'2'": '不使用历史持仓', "'1'": '使用历史持仓'}, 'PositionType': {"'2'": '综合持仓', "'1'": '净持仓'}, 'InstLifePhase': {"'2'": '停牌', "'0'": '未上市', "'3'": '到期', "'1'": '上市'}, 'ProductClass': {"'2'": '期权', "'5'": '期转现', "'3'": '组合', "'1'": '期货', "'4'": '即期'}, 'MaxMarginSideAlgorithm': {"'0'": '不使用大额单边保证金算法', "'1'": '使用大额单边保证金算法'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ShortMarginRatio', 'MinLimitOrderVolume', 'MinMarketOrderVolume', 'PositionDateType', 'ProductClass', 'InstrumentName', 'OpenDate', 'ExpireDate', 'InstLifePhase', 'ProductID', 'LongMarginRatio', 'EndDelivDate', 'ExchangeInstID', 'MaxMarketOrderVolume', 'MaxMarginSideAlgorithm', 'StartDelivDate', 'IsTrading', 'InstrumentID', 'DeliveryMonth', 'PositionType', 'MaxLimitOrderVolume', 'PriceTick', 'CreateDate', 'DeliveryYear', 'ExchangeID', 'VolumeMultiple']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ShortMarginRatio', u'空头保证金率'),('MinLimitOrderVolume', u'限价单最小下单量'),('MinMarketOrderVolume', u'市价单最小下单量'),('PositionDateType', u'持仓日期类型'),('ProductClass', u'产品类型'),('InstrumentName', u'合约名称'),('OpenDate', u'上市日'),('ExpireDate', u'到期日'),('InstLifePhase', u'合约生命周期状态'),('ProductID', u'产品代码'),('LongMarginRatio', u'多头保证金率'),('EndDelivDate', u'结束交割日'),('ExchangeInstID', u'合约在交易所的代码'),('MaxMarketOrderVolume', u'市价单最大下单量'),('MaxMarginSideAlgorithm', u'是否使用大额单边保证金算法'),('StartDelivDate', u'开始交割日'),('IsTrading', u'当前是否交易'),('InstrumentID', u'合约代码'),('DeliveryMonth', u'交割月'),('PositionType', u'持仓类型'),('MaxLimitOrderVolume', u'限价单最大下单量'),('PriceTick', u'最小变动价位'),('CreateDate', u'创建日'),('DeliveryYear', u'交割年份'),('ExchangeID', u'交易所代码'),('VolumeMultiple', u'合约数量乘数')]])
    def getval(self, n):
        if n in ['PositionDateType', 'ProductClass', 'InstLifePhase', 'MaxMarginSideAlgorithm', 'PositionType']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryBrokerField:
    def __init__(self, BrokerID=""):
        self.BrokerID=BrokerID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('BrokerID', u'经纪公司代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcTradingCodeField:
    def __init__(self, IsActive=0, ClientIDType='1', BrokerID="", ClientID="", ExchangeID="", InvestorID=""):
        self.IsActive=IsActive
        self.ClientIDType=ClientIDType
        self.BrokerID=BrokerID
        self.ClientID=ClientID
        self.ExchangeID=ExchangeID
        self.InvestorID=InvestorID
        self.vcmap={'ClientIDType': {"'2'": '套利', "'3'": '套保', "'1'": '投机'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['IsActive', 'ClientIDType', 'BrokerID', 'ClientID', 'ExchangeID', 'InvestorID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('IsActive', u'是否活跃'),('ClientIDType', u'交易编码类型'),('BrokerID', u'经纪公司代码'),('ClientID', u'客户代码'),('ExchangeID', u'交易所代码'),('InvestorID', u'投资者代码')]])
    def getval(self, n):
        if n in ['ClientIDType']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcInstrumentTradingRightField:
    def __init__(self, TradingRight='0', InvestorRange='1', InvestorID="", InstrumentID="", BrokerID=""):
        self.TradingRight=TradingRight
        self.InvestorRange=InvestorRange
        self.InvestorID=InvestorID
        self.InstrumentID=InstrumentID
        self.BrokerID=BrokerID
        self.vcmap={'TradingRight': {"'2'": '不能交易', "'0'": '可以交易', "'1'": '只能平仓'}, 'InvestorRange': {"'2'": '投资者组', "'3'": '单一投资者', "'1'": '所有'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['TradingRight', 'InvestorRange', 'InvestorID', 'InstrumentID', 'BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('TradingRight', u'交易权限'),('InvestorRange', u'投资者范围'),('InvestorID', u'投资者代码'),('InstrumentID', u'合约代码'),('BrokerID', u'经纪公司代码')]])
    def getval(self, n):
        if n in ['TradingRight', 'InvestorRange']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcSuperUserField:
    def __init__(self, UserName="", IsActive=0, UserID="", Password=""):
        self.UserName=UserName
        self.IsActive=IsActive
        self.UserID=UserID
        self.Password=Password
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['UserName', 'IsActive', 'UserID', 'Password']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('UserName', u'用户名称'),('IsActive', u'是否活跃'),('UserID', u'用户代码'),('Password', u'密码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcVerifyFuturePasswordAndCustInfoField:
    def __init__(self, IdentifiedCardNo="", IdCardType='0', CustomerName="", CustType='0', AccountID="", Password=""):
        self.IdentifiedCardNo=IdentifiedCardNo
        self.IdCardType=IdCardType
        self.CustomerName=CustomerName
        self.CustType=CustType
        self.AccountID=AccountID
        self.Password=Password
        self.vcmap={'IdCardType': {"'0'": '组织机构代码', "'6'": '护照', "'7'": '台胞证', "'2'": '军官证', "'8'": '回乡证', "'3'": '警官证', "'1'": '身份证', "'x'": '其他证件', "'9'": '营业执照号', "'5'": '户口簿', "'A'": '税务登记号', "'4'": '士兵证'}, 'CustType': {"'0'": '自然人', "'1'": '机构户'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['IdentifiedCardNo', 'IdCardType', 'CustomerName', 'CustType', 'AccountID', 'Password']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('IdentifiedCardNo', u'证件号码'),('IdCardType', u'证件类型'),('CustomerName', u'客户姓名'),('CustType', u'客户类型'),('AccountID', u'投资者帐号'),('Password', u'期货密码')]])
    def getval(self, n):
        if n in ['IdCardType', 'CustType']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQueryMaxOrderVolumeField:
    def __init__(self, BrokerID="", HedgeFlag='1', MaxVolume=0, InvestorID="", OffsetFlag='0', InstrumentID="", Direction='0'):
        self.BrokerID=BrokerID
        self.HedgeFlag=HedgeFlag
        self.MaxVolume=MaxVolume
        self.InvestorID=InvestorID
        self.OffsetFlag=OffsetFlag
        self.InstrumentID=InstrumentID
        self.Direction=Direction
        self.vcmap={'HedgeFlag': {"'2'": '套利', "'3'": '套保', "'1'": '投机'}, 'OffsetFlag': {"'0'": '开仓', "'6'": '本地强平', "'2'": '强平', "'5'": '强减', "'3'": '平今', "'1'": '平仓', "'4'": '平昨'}, 'Direction': {"'0'": '买', "'1'": '卖'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['BrokerID', 'HedgeFlag', 'MaxVolume', 'InvestorID', 'OffsetFlag', 'InstrumentID', 'Direction']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('BrokerID', u'经纪公司代码'),('HedgeFlag', u'投机套保标志'),('MaxVolume', u'最大允许报单数量'),('InvestorID', u'投资者代码'),('OffsetFlag', u'开平标志'),('InstrumentID', u'合约代码'),('Direction', u'买卖方向')]])
    def getval(self, n):
        if n in ['HedgeFlag', 'OffsetFlag', 'Direction']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcReqAuthenticateField:
    def __init__(self, AuthCode="", UserProductInfo="", BrokerID="", UserID=""):
        self.AuthCode=AuthCode
        self.UserProductInfo=UserProductInfo
        self.BrokerID=BrokerID
        self.UserID=UserID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['AuthCode', 'UserProductInfo', 'BrokerID', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('AuthCode', u'认证码'),('UserProductInfo', u'用户端产品信息'),('BrokerID', u'经纪公司代码'),('UserID', u'用户代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcContractBankField:
    def __init__(self, BankName="", BankBrchID="", BrokerID="", BankID=""):
        self.BankName=BankName
        self.BankBrchID=BankBrchID
        self.BrokerID=BrokerID
        self.BankID=BankID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['BankName', 'BankBrchID', 'BrokerID', 'BankID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('BankName', u'银行名称'),('BankBrchID', u'银行分中心代码'),('BrokerID', u'经纪公司代码'),('BankID', u'银行代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQrySettlementInfoConfirmField:
    def __init__(self, InvestorID="", BrokerID=""):
        self.InvestorID=InvestorID
        self.BrokerID=BrokerID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['InvestorID', 'BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('InvestorID', u'投资者代码'),('BrokerID', u'经纪公司代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcLinkManField:
    def __init__(self, IdentifiedCardNo="", IdentifiedCardType='0', ZipCode="", PersonType='1', BrokerID="", Priority=0, Telephone="", InvestorID="", Address="", PersonName=""):
        self.IdentifiedCardNo=IdentifiedCardNo
        self.IdentifiedCardType=IdentifiedCardType
        self.ZipCode=ZipCode
        self.PersonType=PersonType
        self.BrokerID=BrokerID
        self.Priority=Priority
        self.Telephone=Telephone
        self.InvestorID=InvestorID
        self.Address=Address
        self.PersonName=PersonName
        self.vcmap={'IdentifiedCardType': {"'0'": '组织机构代码', "'6'": '护照', "'7'": '台胞证', "'2'": '军官证', "'8'": '回乡证', "'3'": '警官证', "'1'": '身份证', "'x'": '其他证件', "'9'": '营业执照号', "'5'": '户口簿', "'A'": '税务登记号', "'4'": '士兵证'}, 'PersonType': {"'6'": '法人代表', "'7'": '投资者联系人', "'2'": '开户授权人', "'8'": '分户管理资产负责人', "'3'": '资金调拨人', "'1'": '指定下单人', "'9'": '托（保）管人', "'B'": '托（保）管机构开户授权人', "'5'": '法人', "'C'": '托（保）管机构联系人', "'A'": '托（保）管机构法人代表', "'4'": '结算单确认人'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['IdentifiedCardNo', 'IdentifiedCardType', 'ZipCode', 'PersonType', 'BrokerID', 'Priority', 'Telephone', 'InvestorID', 'Address', 'PersonName']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('IdentifiedCardNo', u'证件号码'),('IdentifiedCardType', u'证件类型'),('ZipCode', u'邮政编码'),('PersonType', u'联系人类型'),('BrokerID', u'经纪公司代码'),('Priority', u'优先级'),('Telephone', u'联系电话'),('InvestorID', u'投资者代码'),('Address', u'通讯地址'),('PersonName', u'名称')]])
    def getval(self, n):
        if n in ['IdentifiedCardType', 'PersonType']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQueryBrokerDepositField:
    def __init__(self, ExchangeID="", BrokerID=""):
        self.ExchangeID=ExchangeID
        self.BrokerID=BrokerID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ExchangeID', 'BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ExchangeID', u'交易所代码'),('BrokerID', u'经纪公司代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcMarketDataAveragePriceField:
    def __init__(self, AveragePrice=0):
        self.AveragePrice=AveragePrice
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['AveragePrice']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('AveragePrice', u'当日均价')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcTransferQryBankRspField:
    def __init__(self, TradeAmt=0, RetInfo="", UseAmt=0, FetchAmt=0, RetCode="", CurrencyCode="", FutureAccount=""):
        self.TradeAmt=TradeAmt
        self.RetInfo=RetInfo
        self.UseAmt=UseAmt
        self.FetchAmt=FetchAmt
        self.RetCode=RetCode
        self.CurrencyCode=CurrencyCode
        self.FutureAccount=FutureAccount
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['TradeAmt', 'RetInfo', 'UseAmt', 'FetchAmt', 'RetCode', 'CurrencyCode', 'FutureAccount']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('TradeAmt', u'银行余额'),('RetInfo', u'响应信息'),('UseAmt', u'银行可用余额'),('FetchAmt', u'银行可取余额'),('RetCode', u'响应代码'),('CurrencyCode', u'币种'),('FutureAccount', u'资金账户')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcReqFutureSignOutField:
    def __init__(self, TradeTime="", CurrencyID="", Digest="", BankID="", OperNo="", BrokerIDByBank="", BrokerBranchID="", BankBranchID="", TradeCode="", LastFragment='0', DeviceID="", PlateSerial=0, TradingDay="", BrokerID="", TradeDate="", BankSerial="", SessionID=0, RequestID=0, UserID="", InstallID=0, TID=0):
        self.TradeTime=TradeTime
        self.CurrencyID=CurrencyID
        self.Digest=Digest
        self.BankID=BankID
        self.OperNo=OperNo
        self.BrokerIDByBank=BrokerIDByBank
        self.BrokerBranchID=BrokerBranchID
        self.BankBranchID=BankBranchID
        self.TradeCode=TradeCode
        self.LastFragment=LastFragment
        self.DeviceID=DeviceID
        self.PlateSerial=PlateSerial
        self.TradingDay=TradingDay
        self.BrokerID=BrokerID
        self.TradeDate=TradeDate
        self.BankSerial=BankSerial
        self.SessionID=SessionID
        self.RequestID=RequestID
        self.UserID=UserID
        self.InstallID=InstallID
        self.TID=TID
        self.vcmap={'LastFragment': {"'0'": '是最后分片', "'1'": '不是最后分片'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['TradeTime', 'CurrencyID', 'Digest', 'BankID', 'OperNo', 'BrokerIDByBank', 'BrokerBranchID', 'BankBranchID', 'TradeCode', 'LastFragment', 'DeviceID', 'PlateSerial', 'TradingDay', 'BrokerID', 'TradeDate', 'BankSerial', 'SessionID', 'RequestID', 'UserID', 'InstallID', 'TID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('TradeTime', u'交易时间'),('CurrencyID', u'币种代码'),('Digest', u'摘要'),('BankID', u'银行代码'),('OperNo', u'交易柜员'),('BrokerIDByBank', u'期货公司银行编码'),('BrokerBranchID', u'期商分支机构代码'),('BankBranchID', u'银行分支机构代码'),('TradeCode', u'业务功能码'),('LastFragment', u'最后分片标志'),('DeviceID', u'渠道标志'),('PlateSerial', u'银期平台消息流水号'),('TradingDay', u'交易系统日期'),('BrokerID', u'期商代码'),('TradeDate', u'交易日期'),('BankSerial', u'银行流水号'),('SessionID', u'会话号'),('RequestID', u'请求编号'),('UserID', u'用户标识'),('InstallID', u'安装编号'),('TID', u'交易ID')]])
    def getval(self, n):
        if n in ['LastFragment']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryNoticeField:
    def __init__(self, BrokerID=""):
        self.BrokerID=BrokerID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('BrokerID', u'经纪公司代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcUserRightField:
    def __init__(self, IsForbidden=0, UserRightType='1', BrokerID="", UserID=""):
        self.IsForbidden=IsForbidden
        self.UserRightType=UserRightType
        self.BrokerID=BrokerID
        self.UserID=UserID
        self.vcmap={'UserRightType': {"'2'": '银期转帐', "'5'": '条件单', "'3'": '邮寄结算单', "'1'": '登录', "'4'": '传真结算单'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['IsForbidden', 'UserRightType', 'BrokerID', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('IsForbidden', u'是否禁止'),('UserRightType', u'客户权限类型'),('BrokerID', u'经纪公司代码'),('UserID', u'用户代码')]])
    def getval(self, n):
        if n in ['UserRightType']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcReqCancelAccountField:
    def __init__(self, PlateSerial=0, Digest="", CashExchangeCode='1', TID=0, BankAccount="", TradeCode="", Gender='0', BankID="", BankSecuAcc="", BankSecuAccType='1', BrokerIDByBank="", BankPassWord="", MoneyAccountStatus='0', CustomerName="", OperNo="", BrokerBranchID="", SecuPwdFlag='0', CountryCode="", AccountID="", EMail="", ZipCode="", BankSerial="", Telephone="", TradeTime="", VerifyCertNoFlag='0', LastFragment='0', CurrencyID="", BrokerID="", MobilePhone="", CustType='0', InstallID=0, TradingDay="", Fax="", BankPwdFlag='0', BankBranchID="", Password="", BankAccType='1', DeviceID="", IdentifiedCardNo="", IdCardType='0', TradeDate="", Address="", SessionID=0, UserID=""):
        self.PlateSerial=PlateSerial
        self.Digest=Digest
        self.CashExchangeCode=CashExchangeCode
        self.TID=TID
        self.BankAccount=BankAccount
        self.TradeCode=TradeCode
        self.Gender=Gender
        self.BankID=BankID
        self.BankSecuAcc=BankSecuAcc
        self.BankSecuAccType=BankSecuAccType
        self.BrokerIDByBank=BrokerIDByBank
        self.BankPassWord=BankPassWord
        self.MoneyAccountStatus=MoneyAccountStatus
        self.CustomerName=CustomerName
        self.OperNo=OperNo
        self.BrokerBranchID=BrokerBranchID
        self.SecuPwdFlag=SecuPwdFlag
        self.CountryCode=CountryCode
        self.AccountID=AccountID
        self.EMail=EMail
        self.ZipCode=ZipCode
        self.BankSerial=BankSerial
        self.Telephone=Telephone
        self.TradeTime=TradeTime
        self.VerifyCertNoFlag=VerifyCertNoFlag
        self.LastFragment=LastFragment
        self.CurrencyID=CurrencyID
        self.BrokerID=BrokerID
        self.MobilePhone=MobilePhone
        self.CustType=CustType
        self.InstallID=InstallID
        self.TradingDay=TradingDay
        self.Fax=Fax
        self.BankPwdFlag=BankPwdFlag
        self.BankBranchID=BankBranchID
        self.Password=Password
        self.BankAccType=BankAccType
        self.DeviceID=DeviceID
        self.IdentifiedCardNo=IdentifiedCardNo
        self.IdCardType=IdCardType
        self.TradeDate=TradeDate
        self.Address=Address
        self.SessionID=SessionID
        self.UserID=UserID
        self.vcmap={'IdCardType': {"'0'": '组织机构代码', "'6'": '护照', "'7'": '台胞证', "'2'": '军官证', "'8'": '回乡证', "'3'": '警官证', "'1'": '身份证', "'x'": '其他证件', "'9'": '营业执照号', "'5'": '户口簿', "'A'": '税务登记号', "'4'": '士兵证'}, 'VerifyCertNoFlag': {"'0'": '是', "'1'": '否'}, 'Gender': {"'2'": '女', "'0'": '未知状态', "'1'": '男'}, 'BankPwdFlag': {"'2'": '密文核对', "'0'": '不核对', "'1'": '明文核对'}, 'MoneyAccountStatus': {"'0'": '正常', "'1'": '销户'}, 'CashExchangeCode': {"'2'": '钞', "'1'": '汇'}, 'BankSecuAccType': {"'2'": '储蓄卡', "'3'": '信用卡', "'1'": '银行存折'}, 'CustType': {"'0'": '自然人', "'1'": '机构户'}, 'SecuPwdFlag': {"'2'": '密文核对', "'0'": '不核对', "'1'": '明文核对'}, 'BankAccType': {"'2'": '储蓄卡', "'3'": '信用卡', "'1'": '银行存折'}, 'LastFragment': {"'0'": '是最后分片', "'1'": '不是最后分片'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['PlateSerial', 'Digest', 'CashExchangeCode', 'TID', 'BankAccount', 'TradeCode', 'Gender', 'BankID', 'BankSecuAcc', 'BankSecuAccType', 'BrokerIDByBank', 'BankPassWord', 'MoneyAccountStatus', 'CustomerName', 'OperNo', 'BrokerBranchID', 'SecuPwdFlag', 'CountryCode', 'AccountID', 'EMail', 'ZipCode', 'BankSerial', 'Telephone', 'TradeTime', 'VerifyCertNoFlag', 'LastFragment', 'CurrencyID', 'BrokerID', 'MobilePhone', 'CustType', 'InstallID', 'TradingDay', 'Fax', 'BankPwdFlag', 'BankBranchID', 'Password', 'BankAccType', 'DeviceID', 'IdentifiedCardNo', 'IdCardType', 'TradeDate', 'Address', 'SessionID', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('PlateSerial', u'银期平台消息流水号'),('Digest', u'摘要'),('CashExchangeCode', u'汇钞标志'),('TID', u'交易ID'),('BankAccount', u'银行帐号'),('TradeCode', u'业务功能码'),('Gender', u'性别'),('BankID', u'银行代码'),('BankSecuAcc', u'期货单位帐号'),('BankSecuAccType', u'期货单位帐号类型'),('BrokerIDByBank', u'期货公司银行编码'),('BankPassWord', u'银行密码'),('MoneyAccountStatus', u'资金账户状态'),('CustomerName', u'客户姓名'),('OperNo', u'交易柜员'),('BrokerBranchID', u'期商分支机构代码'),('SecuPwdFlag', u'期货资金密码核对标志'),('CountryCode', u'国家代码'),('AccountID', u'投资者帐号'),('EMail', u'电子邮件'),('ZipCode', u'邮编'),('BankSerial', u'银行流水号'),('Telephone', u'电话号码'),('TradeTime', u'交易时间'),('VerifyCertNoFlag', u'验证客户证件号码标志'),('LastFragment', u'最后分片标志'),('CurrencyID', u'币种代码'),('BrokerID', u'期商代码'),('MobilePhone', u'手机'),('CustType', u'客户类型'),('InstallID', u'安装编号'),('TradingDay', u'交易系统日期'),('Fax', u'传真'),('BankPwdFlag', u'银行密码标志'),('BankBranchID', u'银行分支机构代码'),('Password', u'期货密码'),('BankAccType', u'银行帐号类型'),('DeviceID', u'渠道标志'),('IdentifiedCardNo', u'证件号码'),('IdCardType', u'证件类型'),('TradeDate', u'交易日期'),('Address', u'地址'),('SessionID', u'会话号'),('UserID', u'用户标识')]])
    def getval(self, n):
        if n in ['CashExchangeCode', 'Gender', 'BankSecuAccType', 'MoneyAccountStatus', 'SecuPwdFlag', 'VerifyCertNoFlag', 'LastFragment', 'CustType', 'BankPwdFlag', 'BankAccType', 'IdCardType']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcTradingAccountReserveField:
    def __init__(self, InvestorID="", BrokerID="", Reserve=0):
        self.InvestorID=InvestorID
        self.BrokerID=BrokerID
        self.Reserve=Reserve
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['InvestorID', 'BrokerID', 'Reserve']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('InvestorID', u'投资者代码'),('BrokerID', u'经纪公司代码'),('Reserve', u'基本准备金')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcInstrumentMarginRateField:
    def __init__(self, InvestorRange='1', BrokerID="", LongMarginRatioByMoney=0, ShortMarginRatioByMoney=0, HedgeFlag='1', LongMarginRatioByVolume=0, IsRelative=0, InvestorID="", InstrumentID="", ShortMarginRatioByVolume=0):
        self.InvestorRange=InvestorRange
        self.BrokerID=BrokerID
        self.LongMarginRatioByMoney=LongMarginRatioByMoney
        self.ShortMarginRatioByMoney=ShortMarginRatioByMoney
        self.HedgeFlag=HedgeFlag
        self.LongMarginRatioByVolume=LongMarginRatioByVolume
        self.IsRelative=IsRelative
        self.InvestorID=InvestorID
        self.InstrumentID=InstrumentID
        self.ShortMarginRatioByVolume=ShortMarginRatioByVolume
        self.vcmap={'HedgeFlag': {"'2'": '套利', "'3'": '套保', "'1'": '投机'}, 'InvestorRange': {"'2'": '投资者组', "'3'": '单一投资者', "'1'": '所有'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['InvestorRange', 'BrokerID', 'LongMarginRatioByMoney', 'ShortMarginRatioByMoney', 'HedgeFlag', 'LongMarginRatioByVolume', 'IsRelative', 'InvestorID', 'InstrumentID', 'ShortMarginRatioByVolume']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('InvestorRange', u'投资者范围'),('BrokerID', u'经纪公司代码'),('LongMarginRatioByMoney', u'多头保证金率'),('ShortMarginRatioByMoney', u'空头保证金率'),('HedgeFlag', u'投机套保标志'),('LongMarginRatioByVolume', u'多头保证金费'),('IsRelative', u'是否相对交易所收取'),('InvestorID', u'投资者代码'),('InstrumentID', u'合约代码'),('ShortMarginRatioByVolume', u'空头保证金费')]])
    def getval(self, n):
        if n in ['InvestorRange', 'HedgeFlag']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcNoticeField:
    def __init__(self, SequenceLabel="", BrokerID="", Content=""):
        self.SequenceLabel=SequenceLabel
        self.BrokerID=BrokerID
        self.Content=Content
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['SequenceLabel', 'BrokerID', 'Content']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('SequenceLabel', u'经纪公司通知内容序列号'),('BrokerID', u'经纪公司代码'),('Content', u'消息正文')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcCurrentTimeField:
    def __init__(self, CurrMillisec=0, ActionDay="", CurrDate="", CurrTime=""):
        self.CurrMillisec=CurrMillisec
        self.ActionDay=ActionDay
        self.CurrDate=CurrDate
        self.CurrTime=CurrTime
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['CurrMillisec', 'ActionDay', 'CurrDate', 'CurrTime']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('CurrMillisec', u'当前时间（毫秒）'),('ActionDay', u'业务日期'),('CurrDate', u'当前日期'),('CurrTime', u'当前时间')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcReqRepealField:
    def __init__(self, RepealedTimes=0, PlateSerial=0, BankPwdFlag='0', TID=0, BankAccount="", FutureFetchAmount=0, TradeAmount=0, Message="", SecuPwdFlag='0', RequestID=0, BankID="", BankSecuAcc="", BankSecuAccType='1', BrokerIDByBank="", BankPassWord="", CustFee=0, CustType='0', OperNo="", BrokerBranchID="", TradeCode="", AccountID="", TradingDay="", BrokerRepealFlag='0', IdCardType='0', BankSerial="", TransferStatus='0', TradeTime="", FeePayFlag='0', VerifyCertNoFlag='0', LastFragment='0', CurrencyID="", PlateRepealSerial=0, BrokerID="", BankRepealSerial="", FutureRepealSerial=0, FutureSerial=0, CustomerName="", InstallID=0, RepealTimeInterval=0, Digest="", BankBranchID="", Password="", BankAccType='1', DeviceID="", IdentifiedCardNo="", BankRepealFlag='0', BrokerFee=0, TradeDate="", SessionID=0, UserID=""):
        self.RepealedTimes=RepealedTimes
        self.PlateSerial=PlateSerial
        self.BankPwdFlag=BankPwdFlag
        self.TID=TID
        self.BankAccount=BankAccount
        self.FutureFetchAmount=FutureFetchAmount
        self.TradeAmount=TradeAmount
        self.Message=Message
        self.SecuPwdFlag=SecuPwdFlag
        self.RequestID=RequestID
        self.BankID=BankID
        self.BankSecuAcc=BankSecuAcc
        self.BankSecuAccType=BankSecuAccType
        self.BrokerIDByBank=BrokerIDByBank
        self.BankPassWord=BankPassWord
        self.CustFee=CustFee
        self.CustType=CustType
        self.OperNo=OperNo
        self.BrokerBranchID=BrokerBranchID
        self.TradeCode=TradeCode
        self.AccountID=AccountID
        self.TradingDay=TradingDay
        self.BrokerRepealFlag=BrokerRepealFlag
        self.IdCardType=IdCardType
        self.BankSerial=BankSerial
        self.TransferStatus=TransferStatus
        self.TradeTime=TradeTime
        self.FeePayFlag=FeePayFlag
        self.VerifyCertNoFlag=VerifyCertNoFlag
        self.LastFragment=LastFragment
        self.CurrencyID=CurrencyID
        self.PlateRepealSerial=PlateRepealSerial
        self.BrokerID=BrokerID
        self.BankRepealSerial=BankRepealSerial
        self.FutureRepealSerial=FutureRepealSerial
        self.FutureSerial=FutureSerial
        self.CustomerName=CustomerName
        self.InstallID=InstallID
        self.RepealTimeInterval=RepealTimeInterval
        self.Digest=Digest
        self.BankBranchID=BankBranchID
        self.Password=Password
        self.BankAccType=BankAccType
        self.DeviceID=DeviceID
        self.IdentifiedCardNo=IdentifiedCardNo
        self.BankRepealFlag=BankRepealFlag
        self.BrokerFee=BrokerFee
        self.TradeDate=TradeDate
        self.SessionID=SessionID
        self.UserID=UserID
        self.vcmap={'VerifyCertNoFlag': {"'0'": '是', "'1'": '否'}, 'BankRepealFlag': {"'2'": '银行已自动冲正', "'0'": '银行无需自动冲正', "'1'": '银行待自动冲正'}, 'LastFragment': {"'0'": '是最后分片', "'1'": '不是最后分片'}, 'CustType': {"'0'": '自然人', "'1'": '机构户'}, 'BankPwdFlag': {"'2'": '密文核对', "'0'": '不核对', "'1'": '明文核对'}, 'SecuPwdFlag': {"'2'": '密文核对', "'0'": '不核对', "'1'": '明文核对'}, 'BankAccType': {"'2'": '储蓄卡', "'3'": '信用卡', "'1'": '银行存折'}, 'IdCardType': {"'0'": '组织机构代码', "'6'": '护照', "'7'": '台胞证', "'2'": '军官证', "'8'": '回乡证', "'3'": '警官证', "'1'": '身份证', "'x'": '其他证件', "'9'": '营业执照号', "'5'": '户口簿', "'A'": '税务登记号', "'4'": '士兵证'}, 'BrokerRepealFlag': {"'2'": '期商已自动冲正', "'0'": '期商无需自动冲正', "'1'": '期商待自动冲正'}, 'BankSecuAccType': {"'2'": '储蓄卡', "'3'": '信用卡', "'1'": '银行存折'}, 'TransferStatus': {"'0'": '正常', "'1'": '被冲正'}, 'FeePayFlag': {"'2'": '由发送方支付发起的费用，受益方支付接受的费用', "'0'": '由受益方支付费用', "'1'": '由发送方支付费用'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['RepealedTimes', 'PlateSerial', 'BankPwdFlag', 'TID', 'BankAccount', 'FutureFetchAmount', 'TradeAmount', 'Message', 'SecuPwdFlag', 'RequestID', 'BankID', 'BankSecuAcc', 'BankSecuAccType', 'BrokerIDByBank', 'BankPassWord', 'CustFee', 'CustType', 'OperNo', 'BrokerBranchID', 'TradeCode', 'AccountID', 'TradingDay', 'BrokerRepealFlag', 'IdCardType', 'BankSerial', 'TransferStatus', 'TradeTime', 'FeePayFlag', 'VerifyCertNoFlag', 'LastFragment', 'CurrencyID', 'PlateRepealSerial', 'BrokerID', 'BankRepealSerial', 'FutureRepealSerial', 'FutureSerial', 'CustomerName', 'InstallID', 'RepealTimeInterval', 'Digest', 'BankBranchID', 'Password', 'BankAccType', 'DeviceID', 'IdentifiedCardNo', 'BankRepealFlag', 'BrokerFee', 'TradeDate', 'SessionID', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('RepealedTimes', u'已经冲正次数'),('PlateSerial', u'银期平台消息流水号'),('BankPwdFlag', u'银行密码标志'),('TID', u'交易ID'),('BankAccount', u'银行帐号'),('FutureFetchAmount', u'期货可取金额'),('TradeAmount', u'转帐金额'),('Message', u'发送方给接收方的消息'),('SecuPwdFlag', u'期货资金密码核对标志'),('RequestID', u'请求编号'),('BankID', u'银行代码'),('BankSecuAcc', u'期货单位帐号'),('BankSecuAccType', u'期货单位帐号类型'),('BrokerIDByBank', u'期货公司银行编码'),('BankPassWord', u'银行密码'),('CustFee', u'应收客户费用'),('CustType', u'客户类型'),('OperNo', u'交易柜员'),('BrokerBranchID', u'期商分支机构代码'),('TradeCode', u'业务功能码'),('AccountID', u'投资者帐号'),('TradingDay', u'交易系统日期'),('BrokerRepealFlag', u'期商冲正标志'),('IdCardType', u'证件类型'),('BankSerial', u'银行流水号'),('TransferStatus', u'转账交易状态'),('TradeTime', u'交易时间'),('FeePayFlag', u'费用支付标志'),('VerifyCertNoFlag', u'验证客户证件号码标志'),('LastFragment', u'最后分片标志'),('CurrencyID', u'币种代码'),('PlateRepealSerial', u'被冲正平台流水号'),('BrokerID', u'期商代码'),('BankRepealSerial', u'被冲正银行流水号'),('FutureRepealSerial', u'被冲正期货流水号'),('FutureSerial', u'期货公司流水号'),('CustomerName', u'客户姓名'),('InstallID', u'安装编号'),('RepealTimeInterval', u'冲正时间间隔'),('Digest', u'摘要'),('BankBranchID', u'银行分支机构代码'),('Password', u'期货密码'),('BankAccType', u'银行帐号类型'),('DeviceID', u'渠道标志'),('IdentifiedCardNo', u'证件号码'),('BankRepealFlag', u'银行冲正标志'),('BrokerFee', u'应收期货公司费用'),('TradeDate', u'交易日期'),('SessionID', u'会话号'),('UserID', u'用户标识')]])
    def getval(self, n):
        if n in ['BankPwdFlag', 'SecuPwdFlag', 'BankSecuAccType', 'CustType', 'BrokerRepealFlag', 'IdCardType', 'TransferStatus', 'FeePayFlag', 'VerifyCertNoFlag', 'LastFragment', 'BankAccType', 'BankRepealFlag']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcTransferSerialField:
    def __init__(self, TradeTime="", BankAccount="", InvestorID="", OperatorCode="", ErrorMsg="", TradeAmount=0, CurrencyID="", AvailabilityFlag='0', BrokerID="", BankID="", BankSerial="", FutureSerial=0, PlateSerial=0, CustFee=0, ErrorID=0, IdCardType='0', BrokerBranchID="", BankBranchID="", TradeCode="", BankAccType='1', IdentifiedCardNo="", AccountID="", FutureAccType='1', BrokerFee=0, TradeDate="", TradingDay="", SessionID=0, BankNewAccount=""):
        self.TradeTime=TradeTime
        self.BankAccount=BankAccount
        self.InvestorID=InvestorID
        self.OperatorCode=OperatorCode
        self.ErrorMsg=ErrorMsg
        self.TradeAmount=TradeAmount
        self.CurrencyID=CurrencyID
        self.AvailabilityFlag=AvailabilityFlag
        self.BrokerID=BrokerID
        self.BankID=BankID
        self.BankSerial=BankSerial
        self.FutureSerial=FutureSerial
        self.PlateSerial=PlateSerial
        self.CustFee=CustFee
        self.ErrorID=ErrorID
        self.IdCardType=IdCardType
        self.BrokerBranchID=BrokerBranchID
        self.BankBranchID=BankBranchID
        self.TradeCode=TradeCode
        self.BankAccType=BankAccType
        self.IdentifiedCardNo=IdentifiedCardNo
        self.AccountID=AccountID
        self.FutureAccType=FutureAccType
        self.BrokerFee=BrokerFee
        self.TradeDate=TradeDate
        self.TradingDay=TradingDay
        self.SessionID=SessionID
        self.BankNewAccount=BankNewAccount
        self.vcmap={'IdCardType': {"'0'": '组织机构代码', "'6'": '护照', "'7'": '台胞证', "'2'": '军官证', "'8'": '回乡证', "'3'": '警官证', "'1'": '身份证', "'x'": '其他证件', "'9'": '营业执照号', "'5'": '户口簿', "'A'": '税务登记号', "'4'": '士兵证'}, 'FutureAccType': {"'2'": '储蓄卡', "'3'": '信用卡', "'1'": '银行存折'}, 'AvailabilityFlag': {"'2'": '冲正', "'0'": '未确认', "'1'": '有效'}, 'BankAccType': {"'2'": '储蓄卡', "'3'": '信用卡', "'1'": '银行存折'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['TradeTime', 'BankAccount', 'InvestorID', 'OperatorCode', 'ErrorMsg', 'TradeAmount', 'CurrencyID', 'AvailabilityFlag', 'BrokerID', 'BankID', 'BankSerial', 'FutureSerial', 'PlateSerial', 'CustFee', 'ErrorID', 'IdCardType', 'BrokerBranchID', 'BankBranchID', 'TradeCode', 'BankAccType', 'IdentifiedCardNo', 'AccountID', 'FutureAccType', 'BrokerFee', 'TradeDate', 'TradingDay', 'SessionID', 'BankNewAccount']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('TradeTime', u'交易时间'),('BankAccount', u'银行帐号'),('InvestorID', u'投资者代码'),('OperatorCode', u'操作员'),('ErrorMsg', u'错误信息'),('TradeAmount', u'交易金额'),('CurrencyID', u'币种代码'),('AvailabilityFlag', u'有效标志'),('BrokerID', u'期货公司编码'),('BankID', u'银行编码'),('BankSerial', u'银行流水号'),('FutureSerial', u'期货公司流水号'),('PlateSerial', u'平台流水号'),('CustFee', u'应收客户费用'),('ErrorID', u'错误代码'),('IdCardType', u'证件类型'),('BrokerBranchID', u'期商分支机构代码'),('BankBranchID', u'银行分支机构编码'),('TradeCode', u'交易代码'),('BankAccType', u'银行帐号类型'),('IdentifiedCardNo', u'证件号码'),('AccountID', u'投资者帐号'),('FutureAccType', u'期货公司帐号类型'),('BrokerFee', u'应收期货公司费用'),('TradeDate', u'交易发起方日期'),('TradingDay', u'交易日期'),('SessionID', u'会话编号'),('BankNewAccount', u'新银行帐号')]])
    def getval(self, n):
        if n in ['AvailabilityFlag', 'IdCardType', 'BankAccType', 'FutureAccType']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcInvestorPositionField:
    def __init__(self, SettlementPrice=0, LongFrozen=0, CombLongFrozen=0, PosiDirection='1', InvestorID="", FrozenMargin=0, TodayPosition=0, OpenVolume=0, FrozenCash=0, Commission=0, CombShortFrozen=0, MarginRateByVolume=0, BrokerID="", CashIn=0, CloseVolume=0, ExchangeMargin=0, ShortFrozenAmount=0, LongFrozenAmount=0, CloseAmount=0, PositionCost=0, CloseProfitByDate=0, FrozenCommission=0, UseMargin=0, MarginRateByMoney=0, CombPosition=0, PositionProfit=0, Position=0, ShortFrozen=0, OpenAmount=0, PositionDate='1', InstrumentID="", CloseProfitByTrade=0, SettlementID=0, TradingDay="", PreSettlementPrice=0, HedgeFlag='1', OpenCost=0, CloseProfit=0, YdPosition=0, PreMargin=0):
        self.SettlementPrice=SettlementPrice
        self.LongFrozen=LongFrozen
        self.CombLongFrozen=CombLongFrozen
        self.PosiDirection=PosiDirection
        self.InvestorID=InvestorID
        self.FrozenMargin=FrozenMargin
        self.TodayPosition=TodayPosition
        self.OpenVolume=OpenVolume
        self.FrozenCash=FrozenCash
        self.Commission=Commission
        self.CombShortFrozen=CombShortFrozen
        self.MarginRateByVolume=MarginRateByVolume
        self.BrokerID=BrokerID
        self.CashIn=CashIn
        self.CloseVolume=CloseVolume
        self.ExchangeMargin=ExchangeMargin
        self.ShortFrozenAmount=ShortFrozenAmount
        self.LongFrozenAmount=LongFrozenAmount
        self.CloseAmount=CloseAmount
        self.PositionCost=PositionCost
        self.CloseProfitByDate=CloseProfitByDate
        self.FrozenCommission=FrozenCommission
        self.UseMargin=UseMargin
        self.MarginRateByMoney=MarginRateByMoney
        self.CombPosition=CombPosition
        self.PositionProfit=PositionProfit
        self.Position=Position
        self.ShortFrozen=ShortFrozen
        self.OpenAmount=OpenAmount
        self.PositionDate=PositionDate
        self.InstrumentID=InstrumentID
        self.CloseProfitByTrade=CloseProfitByTrade
        self.SettlementID=SettlementID
        self.TradingDay=TradingDay
        self.PreSettlementPrice=PreSettlementPrice
        self.HedgeFlag=HedgeFlag
        self.OpenCost=OpenCost
        self.CloseProfit=CloseProfit
        self.YdPosition=YdPosition
        self.PreMargin=PreMargin
        self.vcmap={'HedgeFlag': {"'2'": '套利', "'3'": '套保', "'1'": '投机'}, 'PosiDirection': {"'2'": '多头', "'3'": '空头', "'1'": '净'}, 'PositionDate': {"'2'": '历史持仓', "'1'": '今日持仓'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['SettlementPrice', 'LongFrozen', 'CombLongFrozen', 'PosiDirection', 'InvestorID', 'FrozenMargin', 'TodayPosition', 'OpenVolume', 'FrozenCash', 'Commission', 'CombShortFrozen', 'MarginRateByVolume', 'BrokerID', 'CashIn', 'CloseVolume', 'ExchangeMargin', 'ShortFrozenAmount', 'LongFrozenAmount', 'CloseAmount', 'PositionCost', 'CloseProfitByDate', 'FrozenCommission', 'UseMargin', 'MarginRateByMoney', 'CombPosition', 'PositionProfit', 'Position', 'ShortFrozen', 'OpenAmount', 'PositionDate', 'InstrumentID', 'CloseProfitByTrade', 'SettlementID', 'TradingDay', 'PreSettlementPrice', 'HedgeFlag', 'OpenCost', 'CloseProfit', 'YdPosition', 'PreMargin']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('SettlementPrice', u'本次结算价'),('LongFrozen', u'多头冻结'),('CombLongFrozen', u'组合多头冻结'),('PosiDirection', u'持仓多空方向'),('InvestorID', u'投资者代码'),('FrozenMargin', u'冻结的保证金'),('TodayPosition', u'今日持仓'),('OpenVolume', u'开仓量'),('FrozenCash', u'冻结的资金'),('Commission', u'手续费'),('CombShortFrozen', u'组合空头冻结'),('MarginRateByVolume', u'保证金率(按手数)'),('BrokerID', u'经纪公司代码'),('CashIn', u'资金差额'),('CloseVolume', u'平仓量'),('ExchangeMargin', u'交易所保证金'),('ShortFrozenAmount', u'开仓冻结金额'),('LongFrozenAmount', u'开仓冻结金额'),('CloseAmount', u'平仓金额'),('PositionCost', u'持仓成本'),('CloseProfitByDate', u'逐日盯市平仓盈亏'),('FrozenCommission', u'冻结的手续费'),('UseMargin', u'占用的保证金'),('MarginRateByMoney', u'保证金率'),('CombPosition', u'组合成交形成的持仓'),('PositionProfit', u'持仓盈亏'),('Position', u'今日持仓'),('ShortFrozen', u'空头冻结'),('OpenAmount', u'开仓金额'),('PositionDate', u'持仓日期'),('InstrumentID', u'合约代码'),('CloseProfitByTrade', u'逐笔对冲平仓盈亏'),('SettlementID', u'结算编号'),('TradingDay', u'交易日'),('PreSettlementPrice', u'上次结算价'),('HedgeFlag', u'投机套保标志'),('OpenCost', u'开仓成本'),('CloseProfit', u'平仓盈亏'),('YdPosition', u'上日持仓'),('PreMargin', u'上次占用的保证金')]])
    def getval(self, n):
        if n in ['PosiDirection', 'PositionDate', 'HedgeFlag']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcBrokerUserFunctionField:
    def __init__(self, BrokerFunctionCode='1', BrokerID="", UserID=""):
        self.BrokerFunctionCode=BrokerFunctionCode
        self.BrokerID=BrokerID
        self.UserID=UserID
        self.vcmap={'BrokerFunctionCode': {"'j'": '察看经纪公司资金权限', "'u'": '强平', "'s'": '投资者信息查询', "'i'": '风控通知发送', "'r'": '出入金查询', "'e'": '银期转账', "'x'": '净持仓保证金指标', "'d'": '交易功能：报单，撤单', "'q'": '风险通知查询', "'z'": '数据导出', "'k'": '资金查询', "'f'": '风险监控', "'y'": '风险预算', "'g'": '查询/管理：查询会话，踢人等', "'b'": '基本查询：查询基础数据，如合约，交易所等常量', "'3'": '同步经纪公司数据', "'H'": '交易终端应急功能', "'c'": '交易查询：如查成交，委托', "'a'": '系统功能：登入/登出/修改密码等', "'4'": '批量同步经纪公司数据', "'6'": '报单操作', "'p'": '用户事件查询', "'v'": '压力测试', "'7'": '全部查询', "'2'": '变更用户口令', "'E'": '同步动态令牌', "'w'": '权益反算', "'1'": '强制用户登出', "'D'": '业务通知模板设置', "'m'": '成交查询', "'5'": '报单插入', "'F'": '发送业务通知', "'t'": '交易编码查询', "'l'": '报单查询', "'G'": '风险级别标准设置', "'B'": '行情预警', "'h'": '风控通知控制', "'C'": '业务通知查询', "'n'": '持仓查询', "'A'": '风控指标设置', "'o'": '行情查询'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['BrokerFunctionCode', 'BrokerID', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('BrokerFunctionCode', u'经纪公司功能代码'),('BrokerID', u'经纪公司代码'),('UserID', u'用户代码')]])
    def getval(self, n):
        if n in ['BrokerFunctionCode']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcOrderActionField:
    def __init__(self, OrderActionRef=0, VolumeChange=0, OrderActionStatus='a', OrderSysID="", InvestorID="", OrderRef="", InstrumentID="", TraderID="", OrderLocalID="", RequestID=0, BrokerID="", ActionFlag='0', ActionTime="", LimitPrice=0, InstallID=0, ParticipantID="", ExchangeID="", ActionDate="", UserID="", StatusMsg="", ClientID="", FrontID=0, SessionID=0, ActionLocalID="", BusinessUnit=""):
        self.OrderActionRef=OrderActionRef
        self.VolumeChange=VolumeChange
        self.OrderActionStatus=OrderActionStatus
        self.OrderSysID=OrderSysID
        self.InvestorID=InvestorID
        self.OrderRef=OrderRef
        self.InstrumentID=InstrumentID
        self.TraderID=TraderID
        self.OrderLocalID=OrderLocalID
        self.RequestID=RequestID
        self.BrokerID=BrokerID
        self.ActionFlag=ActionFlag
        self.ActionTime=ActionTime
        self.LimitPrice=LimitPrice
        self.InstallID=InstallID
        self.ParticipantID=ParticipantID
        self.ExchangeID=ExchangeID
        self.ActionDate=ActionDate
        self.UserID=UserID
        self.StatusMsg=StatusMsg
        self.ClientID=ClientID
        self.FrontID=FrontID
        self.SessionID=SessionID
        self.ActionLocalID=ActionLocalID
        self.BusinessUnit=BusinessUnit
        self.vcmap={'OrderActionStatus': {"'b'": '已经接受', "'c'": '已经被拒绝', "'a'": '已经提交'}, 'ActionFlag': {"'0'": '删除', "'3'": '修改'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['OrderActionRef', 'VolumeChange', 'OrderActionStatus', 'OrderSysID', 'InvestorID', 'OrderRef', 'InstrumentID', 'TraderID', 'OrderLocalID', 'RequestID', 'BrokerID', 'ActionFlag', 'ActionTime', 'LimitPrice', 'InstallID', 'ParticipantID', 'ExchangeID', 'ActionDate', 'UserID', 'StatusMsg', 'ClientID', 'FrontID', 'SessionID', 'ActionLocalID', 'BusinessUnit']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('OrderActionRef', u'报单操作引用'),('VolumeChange', u'数量变化'),('OrderActionStatus', u'报单操作状态'),('OrderSysID', u'报单编号'),('InvestorID', u'投资者代码'),('OrderRef', u'报单引用'),('InstrumentID', u'合约代码'),('TraderID', u'交易所交易员代码'),('OrderLocalID', u'本地报单编号'),('RequestID', u'请求编号'),('BrokerID', u'经纪公司代码'),('ActionFlag', u'操作标志'),('ActionTime', u'操作时间'),('LimitPrice', u'价格'),('InstallID', u'安装编号'),('ParticipantID', u'会员代码'),('ExchangeID', u'交易所代码'),('ActionDate', u'操作日期'),('UserID', u'用户代码'),('StatusMsg', u'状态信息'),('ClientID', u'客户代码'),('FrontID', u'前置编号'),('SessionID', u'会话编号'),('ActionLocalID', u'操作本地编号'),('BusinessUnit', u'业务单元')]])
    def getval(self, n):
        if n in ['OrderActionStatus', 'ActionFlag']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryInvestorGroupField:
    def __init__(self, BrokerID=""):
        self.BrokerID=BrokerID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('BrokerID', u'经纪公司代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcTransferQryDetailReqField:
    def __init__(self, FutureAccount=""):
        self.FutureAccount=FutureAccount
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['FutureAccount']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('FutureAccount', u'期货资金账户')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcExchangeSequenceField:
    def __init__(self, SequenceNo=0, ExchangeID="", MarketStatus='0'):
        self.SequenceNo=SequenceNo
        self.ExchangeID=ExchangeID
        self.MarketStatus=MarketStatus
        self.vcmap={'MarketStatus': {"'0'": '开盘前', "'6'": '收盘', "'2'": '连续交易', "'5'": '集合竞价撮合', "'3'": '集合竞价报单', "'1'": '非交易', "'4'": '集合竞价价格平衡'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['SequenceNo', 'ExchangeID', 'MarketStatus']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('SequenceNo', u'序号'),('ExchangeID', u'交易所代码'),('MarketStatus', u'合约交易状态')]])
    def getval(self, n):
        if n in ['MarketStatus']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryProductField:
    def __init__(self, ProductID=""):
        self.ProductID=ProductID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ProductID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ProductID', u'产品代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcUserIPField:
    def __init__(self, IPMask="", IPAddress="", MacAddress="", BrokerID="", UserID=""):
        self.IPMask=IPMask
        self.IPAddress=IPAddress
        self.MacAddress=MacAddress
        self.BrokerID=BrokerID
        self.UserID=UserID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['IPMask', 'IPAddress', 'MacAddress', 'BrokerID', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('IPMask', u'IP地址掩码'),('IPAddress', u'IP地址'),('MacAddress', u'Mac地址'),('BrokerID', u'经纪公司代码'),('UserID', u'用户代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcMDTraderOfferField:
    def __init__(self, ParticipantID="", LastReportTime="", StartTime="", ConnectDate="", ConnectTime="", ConnectRequestDate="", ConnectRequestTime="", TraderConnectStatus='1', MaxTradeID="", LastReportDate="", Password="", StartDate="", TraderID="", OrderLocalID="", TradingDay="", BrokerID="", MaxOrderMessageReference="", ExchangeID="", InstallID=0):
        self.ParticipantID=ParticipantID
        self.LastReportTime=LastReportTime
        self.StartTime=StartTime
        self.ConnectDate=ConnectDate
        self.ConnectTime=ConnectTime
        self.ConnectRequestDate=ConnectRequestDate
        self.ConnectRequestTime=ConnectRequestTime
        self.TraderConnectStatus=TraderConnectStatus
        self.MaxTradeID=MaxTradeID
        self.LastReportDate=LastReportDate
        self.Password=Password
        self.StartDate=StartDate
        self.TraderID=TraderID
        self.OrderLocalID=OrderLocalID
        self.TradingDay=TradingDay
        self.BrokerID=BrokerID
        self.MaxOrderMessageReference=MaxOrderMessageReference
        self.ExchangeID=ExchangeID
        self.InstallID=InstallID
        self.vcmap={'TraderConnectStatus': {"'2'": '已经连接', "'3'": '已经发出合约查询请求', "'1'": '没有任何连接', "'4'": '订阅私有流'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ParticipantID', 'LastReportTime', 'StartTime', 'ConnectDate', 'ConnectTime', 'ConnectRequestDate', 'ConnectRequestTime', 'TraderConnectStatus', 'MaxTradeID', 'LastReportDate', 'Password', 'StartDate', 'TraderID', 'OrderLocalID', 'TradingDay', 'BrokerID', 'MaxOrderMessageReference', 'ExchangeID', 'InstallID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ParticipantID', u'会员代码'),('LastReportTime', u'上次报告时间'),('StartTime', u'启动时间'),('ConnectDate', u'完成连接日期'),('ConnectTime', u'完成连接时间'),('ConnectRequestDate', u'发出连接请求的日期'),('ConnectRequestTime', u'发出连接请求的时间'),('TraderConnectStatus', u'交易所交易员连接状态'),('MaxTradeID', u'本席位最大成交编号'),('LastReportDate', u'上次报告日期'),('Password', u'密码'),('StartDate', u'启动日期'),('TraderID', u'交易所交易员代码'),('OrderLocalID', u'本地报单编号'),('TradingDay', u'交易日'),('BrokerID', u'经纪公司代码'),('MaxOrderMessageReference', u'本席位最大报单备拷'),('ExchangeID', u'交易所代码'),('InstallID', u'安装编号')]])
    def getval(self, n):
        if n in ['TraderConnectStatus']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcMarketDataField:
    def __init__(self, Volume=0, SettlementPrice=0, PreOpenInterest=0, ActionDay="", Turnover=0, OpenPrice=0, PreClosePrice=0, LowestPrice=0, UpdateMillisec=0, PreSettlementPrice=0, OpenInterest=0, ExchangeInstID="", ClosePrice=0, HighestPrice=0, ExchangeID="", UpperLimitPrice=0, InstrumentID="", LowerLimitPrice=0, TradingDay="", PreDelta=0, UpdateTime="", CurrDelta=0, LastPrice=0):
        self.Volume=Volume
        self.SettlementPrice=SettlementPrice
        self.PreOpenInterest=PreOpenInterest
        self.ActionDay=ActionDay
        self.Turnover=Turnover
        self.OpenPrice=OpenPrice
        self.PreClosePrice=PreClosePrice
        self.LowestPrice=LowestPrice
        self.UpdateMillisec=UpdateMillisec
        self.PreSettlementPrice=PreSettlementPrice
        self.OpenInterest=OpenInterest
        self.ExchangeInstID=ExchangeInstID
        self.ClosePrice=ClosePrice
        self.HighestPrice=HighestPrice
        self.ExchangeID=ExchangeID
        self.UpperLimitPrice=UpperLimitPrice
        self.InstrumentID=InstrumentID
        self.LowerLimitPrice=LowerLimitPrice
        self.TradingDay=TradingDay
        self.PreDelta=PreDelta
        self.UpdateTime=UpdateTime
        self.CurrDelta=CurrDelta
        self.LastPrice=LastPrice
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['Volume', 'SettlementPrice', 'PreOpenInterest', 'ActionDay', 'Turnover', 'OpenPrice', 'PreClosePrice', 'LowestPrice', 'UpdateMillisec', 'PreSettlementPrice', 'OpenInterest', 'ExchangeInstID', 'ClosePrice', 'HighestPrice', 'ExchangeID', 'UpperLimitPrice', 'InstrumentID', 'LowerLimitPrice', 'TradingDay', 'PreDelta', 'UpdateTime', 'CurrDelta', 'LastPrice']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('Volume', u'数量'),('SettlementPrice', u'本次结算价'),('PreOpenInterest', u'昨持仓量'),('ActionDay', u'业务日期'),('Turnover', u'成交金额'),('OpenPrice', u'今开盘'),('PreClosePrice', u'昨收盘'),('LowestPrice', u'最低价'),('UpdateMillisec', u'最后修改毫秒'),('PreSettlementPrice', u'上次结算价'),('OpenInterest', u'持仓量'),('ExchangeInstID', u'合约在交易所的代码'),('ClosePrice', u'今收盘'),('HighestPrice', u'最高价'),('ExchangeID', u'交易所代码'),('UpperLimitPrice', u'涨停板价'),('InstrumentID', u'合约代码'),('LowerLimitPrice', u'跌停板价'),('TradingDay', u'交易日'),('PreDelta', u'昨虚实度'),('UpdateTime', u'最后修改时间'),('CurrDelta', u'今虚实度'),('LastPrice', u'最新价')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcCombinationLegField:
    def __init__(self, LegInstrumentID="", ImplyLevel=0, CombInstrumentID="", LegID=0, LegMultiple=0, Direction='0'):
        self.LegInstrumentID=LegInstrumentID
        self.ImplyLevel=ImplyLevel
        self.CombInstrumentID=CombInstrumentID
        self.LegID=LegID
        self.LegMultiple=LegMultiple
        self.Direction=Direction
        self.vcmap={'Direction': {"'0'": '买', "'1'": '卖'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['LegInstrumentID', 'ImplyLevel', 'CombInstrumentID', 'LegID', 'LegMultiple', 'Direction']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('LegInstrumentID', u'单腿合约代码'),('ImplyLevel', u'派生层数'),('CombInstrumentID', u'组合合约代码'),('LegID', u'单腿编号'),('LegMultiple', u'单腿乘数'),('Direction', u'买卖方向')]])
    def getval(self, n):
        if n in ['Direction']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcRspFutureSignOutField:
    def __init__(self, TradeTime="", BrokerBranchID="", TID=0, ErrorMsg="", CurrencyID="", LastFragment='0', RequestID=0, BrokerID="", BankID="", BrokerIDByBank="", ErrorID=0, OperNo="", Digest="", BankBranchID="", TradeCode="", DeviceID="", PlateSerial=0, TradingDay="", InstallID=0, TradeDate="", BankSerial="", SessionID=0, UserID=""):
        self.TradeTime=TradeTime
        self.BrokerBranchID=BrokerBranchID
        self.TID=TID
        self.ErrorMsg=ErrorMsg
        self.CurrencyID=CurrencyID
        self.LastFragment=LastFragment
        self.RequestID=RequestID
        self.BrokerID=BrokerID
        self.BankID=BankID
        self.BrokerIDByBank=BrokerIDByBank
        self.ErrorID=ErrorID
        self.OperNo=OperNo
        self.Digest=Digest
        self.BankBranchID=BankBranchID
        self.TradeCode=TradeCode
        self.DeviceID=DeviceID
        self.PlateSerial=PlateSerial
        self.TradingDay=TradingDay
        self.InstallID=InstallID
        self.TradeDate=TradeDate
        self.BankSerial=BankSerial
        self.SessionID=SessionID
        self.UserID=UserID
        self.vcmap={'LastFragment': {"'0'": '是最后分片', "'1'": '不是最后分片'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['TradeTime', 'BrokerBranchID', 'TID', 'ErrorMsg', 'CurrencyID', 'LastFragment', 'RequestID', 'BrokerID', 'BankID', 'BrokerIDByBank', 'ErrorID', 'OperNo', 'Digest', 'BankBranchID', 'TradeCode', 'DeviceID', 'PlateSerial', 'TradingDay', 'InstallID', 'TradeDate', 'BankSerial', 'SessionID', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('TradeTime', u'交易时间'),('BrokerBranchID', u'期商分支机构代码'),('TID', u'交易ID'),('ErrorMsg', u'错误信息'),('CurrencyID', u'币种代码'),('LastFragment', u'最后分片标志'),('RequestID', u'请求编号'),('BrokerID', u'期商代码'),('BankID', u'银行代码'),('BrokerIDByBank', u'期货公司银行编码'),('ErrorID', u'错误代码'),('OperNo', u'交易柜员'),('Digest', u'摘要'),('BankBranchID', u'银行分支机构代码'),('TradeCode', u'业务功能码'),('DeviceID', u'渠道标志'),('PlateSerial', u'银期平台消息流水号'),('TradingDay', u'交易系统日期'),('InstallID', u'安装编号'),('TradeDate', u'交易日期'),('BankSerial', u'银行流水号'),('SessionID', u'会话号'),('UserID', u'用户标识')]])
    def getval(self, n):
        if n in ['LastFragment']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcSyncingInstrumentCommissionRateField:
    def __init__(self, CloseRatioByMoney=0, InvestorRange='1', OpenRatioByVolume=0, BrokerID="", OpenRatioByMoney=0, CloseTodayRatioByVolume=0, CloseRatioByVolume=0, InvestorID="", InstrumentID="", CloseTodayRatioByMoney=0):
        self.CloseRatioByMoney=CloseRatioByMoney
        self.InvestorRange=InvestorRange
        self.OpenRatioByVolume=OpenRatioByVolume
        self.BrokerID=BrokerID
        self.OpenRatioByMoney=OpenRatioByMoney
        self.CloseTodayRatioByVolume=CloseTodayRatioByVolume
        self.CloseRatioByVolume=CloseRatioByVolume
        self.InvestorID=InvestorID
        self.InstrumentID=InstrumentID
        self.CloseTodayRatioByMoney=CloseTodayRatioByMoney
        self.vcmap={'InvestorRange': {"'2'": '投资者组', "'3'": '单一投资者', "'1'": '所有'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['CloseRatioByMoney', 'InvestorRange', 'OpenRatioByVolume', 'BrokerID', 'OpenRatioByMoney', 'CloseTodayRatioByVolume', 'CloseRatioByVolume', 'InvestorID', 'InstrumentID', 'CloseTodayRatioByMoney']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('CloseRatioByMoney', u'平仓手续费率'),('InvestorRange', u'投资者范围'),('OpenRatioByVolume', u'开仓手续费'),('BrokerID', u'经纪公司代码'),('OpenRatioByMoney', u'开仓手续费率'),('CloseTodayRatioByVolume', u'平今手续费'),('CloseRatioByVolume', u'平仓手续费'),('InvestorID', u'投资者代码'),('InstrumentID', u'合约代码'),('CloseTodayRatioByMoney', u'平今手续费率')]])
    def getval(self, n):
        if n in ['InvestorRange']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcSuperUserFunctionField:
    def __init__(self, UserID="", FunctionCode='1'):
        self.UserID=UserID
        self.FunctionCode=FunctionCode
        self.vcmap={'FunctionCode': {"'6'": '报单插入', "'7'": '报单操作', "'2'": '强制用户登出', "'E'": '同步动态令牌', "'8'": '同步系统数据', "'3'": '变更管理用户口令', "'1'": '数据异步化', "'D'": '报单操作', "'9'": '同步经纪公司数据', "'B'": '超级查询', "'5'": '变更投资者口令', "'C'": '报单插入', "'A'": '批量同步经纪公司数据', "'4'": '变更经纪公司口令'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['UserID', 'FunctionCode']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('UserID', u'用户代码'),('FunctionCode', u'功能代码')]])
    def getval(self, n):
        if n in ['FunctionCode']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQrySyncDepositField:
    def __init__(self, BrokerID="", DepositSeqNo=""):
        self.BrokerID=BrokerID
        self.DepositSeqNo=DepositSeqNo
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['BrokerID', 'DepositSeqNo']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('BrokerID', u'经纪公司代码'),('DepositSeqNo', u'出入金流水号')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcBrokerTradingAlgosField:
    def __init__(self, HandlePositionAlgoID='1', BrokerID="", HandleTradingAccountAlgoID='1', FindMarginRateAlgoID='1', ExchangeID="", InstrumentID=""):
        self.HandlePositionAlgoID=HandlePositionAlgoID
        self.BrokerID=BrokerID
        self.HandleTradingAccountAlgoID=HandleTradingAccountAlgoID
        self.FindMarginRateAlgoID=FindMarginRateAlgoID
        self.ExchangeID=ExchangeID
        self.InstrumentID=InstrumentID
        self.vcmap={'HandlePositionAlgoID': {"'2'": '大连商品交易所', "'3'": '郑州商品交易所', "'1'": '基本'}, 'FindMarginRateAlgoID': {"'2'": '大连商品交易所', "'3'": '郑州商品交易所', "'1'": '基本'}, 'HandleTradingAccountAlgoID': {"'2'": '大连商品交易所', "'3'": '郑州商品交易所', "'1'": '基本'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['HandlePositionAlgoID', 'BrokerID', 'HandleTradingAccountAlgoID', 'FindMarginRateAlgoID', 'ExchangeID', 'InstrumentID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('HandlePositionAlgoID', u'持仓处理算法编号'),('BrokerID', u'经纪公司代码'),('HandleTradingAccountAlgoID', u'资金处理算法编号'),('FindMarginRateAlgoID', u'寻找保证金率算法编号'),('ExchangeID', u'交易所代码'),('InstrumentID', u'合约代码')]])
    def getval(self, n):
        if n in ['HandlePositionAlgoID', 'HandleTradingAccountAlgoID', 'FindMarginRateAlgoID']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcCurrTransferIdentityField:
    def __init__(self, IdentityID=0):
        self.IdentityID=IdentityID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['IdentityID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('IdentityID', u'交易中心代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcTransferBankToFutureRspField:
    def __init__(self, CustFee=0, RetInfo="", CurrencyCode="", RetCode="", FutureAccount="", TradeAmt=0):
        self.CustFee=CustFee
        self.RetInfo=RetInfo
        self.CurrencyCode=CurrencyCode
        self.RetCode=RetCode
        self.FutureAccount=FutureAccount
        self.TradeAmt=TradeAmt
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['CustFee', 'RetInfo', 'CurrencyCode', 'RetCode', 'FutureAccount', 'TradeAmt']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('CustFee', u'应收客户手续费'),('RetInfo', u'响应信息'),('CurrencyCode', u'币种'),('RetCode', u'响应代码'),('FutureAccount', u'资金账户'),('TradeAmt', u'转帐金额')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcDiscountField:
    def __init__(self, Discount=0, InvestorRange='1', InvestorID="", BrokerID=""):
        self.Discount=Discount
        self.InvestorRange=InvestorRange
        self.InvestorID=InvestorID
        self.BrokerID=BrokerID
        self.vcmap={'InvestorRange': {"'2'": '投资者组', "'3'": '单一投资者', "'1'": '所有'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['Discount', 'InvestorRange', 'InvestorID', 'BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('Discount', u'资金折扣比例'),('InvestorRange', u'投资者范围'),('InvestorID', u'投资者代码'),('BrokerID', u'经纪公司代码')]])
    def getval(self, n):
        if n in ['InvestorRange']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcReqUserLoginField:
    def __init__(self, InterfaceProductInfo="", TradingDay="", BrokerID="", ClientIPAddress="", MacAddress="", ProtocolInfo="", OneTimePassword="", UserProductInfo="", UserID="", Password=""):
        self.InterfaceProductInfo=InterfaceProductInfo
        self.TradingDay=TradingDay
        self.BrokerID=BrokerID
        self.ClientIPAddress=ClientIPAddress
        self.MacAddress=MacAddress
        self.ProtocolInfo=ProtocolInfo
        self.OneTimePassword=OneTimePassword
        self.UserProductInfo=UserProductInfo
        self.UserID=UserID
        self.Password=Password
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['InterfaceProductInfo', 'TradingDay', 'BrokerID', 'ClientIPAddress', 'MacAddress', 'ProtocolInfo', 'OneTimePassword', 'UserProductInfo', 'UserID', 'Password']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('InterfaceProductInfo', u'接口端产品信息'),('TradingDay', u'交易日'),('BrokerID', u'经纪公司代码'),('ClientIPAddress', u'终端IP地址'),('MacAddress', u'Mac地址'),('ProtocolInfo', u'协议信息'),('OneTimePassword', u'动态密码'),('UserProductInfo', u'用户端产品信息'),('UserID', u'用户代码'),('Password', u'密码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryErrOrderField:
    def __init__(self, InvestorID="", BrokerID=""):
        self.InvestorID=InvestorID
        self.BrokerID=BrokerID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['InvestorID', 'BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('InvestorID', u'投资者代码'),('BrokerID', u'经纪公司代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQrySyncStatusField:
    def __init__(self, TradingDay=""):
        self.TradingDay=TradingDay
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['TradingDay']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('TradingDay', u'交易日')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryInvestorField:
    def __init__(self, InvestorID="", BrokerID=""):
        self.InvestorID=InvestorID
        self.BrokerID=BrokerID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['InvestorID', 'BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('InvestorID', u'投资者代码'),('BrokerID', u'经纪公司代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcDepthMarketDataField:
    def __init__(self, Volume=0, LastPrice=0, ActionDay="", Turnover=0, OpenPrice=0, LowerLimitPrice=0, UpdateMillisec=0, OpenInterest=0, AskPrice2=0, AskPrice3=0, AskPrice1=0, ClosePrice=0, AskPrice4=0, AskPrice5=0, UpperLimitPrice=0, InstrumentID="", BidVolume1=0, TradingDay="", BidVolume5=0, CurrDelta=0, SettlementPrice=0, UpdateTime="", PreClosePrice=0, LowestPrice=0, ExchangeInstID="", PreDelta=0, PreSettlementPrice=0, AskVolume5=0, AskVolume1=0, AskVolume2=0, AskVolume3=0, AskVolume4=0, AveragePrice=0, HighestPrice=0, BidPrice1=0, BidPrice2=0, BidPrice3=0, BidPrice4=0, BidPrice5=0, BidVolume4=0, ExchangeID="", BidVolume2=0, BidVolume3=0, PreOpenInterest=0):
        self.Volume=Volume
        self.LastPrice=LastPrice
        self.ActionDay=ActionDay
        self.Turnover=Turnover
        self.OpenPrice=OpenPrice
        self.LowerLimitPrice=LowerLimitPrice
        self.UpdateMillisec=UpdateMillisec
        self.OpenInterest=OpenInterest
        self.AskPrice2=AskPrice2
        self.AskPrice3=AskPrice3
        self.AskPrice1=AskPrice1
        self.ClosePrice=ClosePrice
        self.AskPrice4=AskPrice4
        self.AskPrice5=AskPrice5
        self.UpperLimitPrice=UpperLimitPrice
        self.InstrumentID=InstrumentID
        self.BidVolume1=BidVolume1
        self.TradingDay=TradingDay
        self.BidVolume5=BidVolume5
        self.CurrDelta=CurrDelta
        self.SettlementPrice=SettlementPrice
        self.UpdateTime=UpdateTime
        self.PreClosePrice=PreClosePrice
        self.LowestPrice=LowestPrice
        self.ExchangeInstID=ExchangeInstID
        self.PreDelta=PreDelta
        self.PreSettlementPrice=PreSettlementPrice
        self.AskVolume5=AskVolume5
        self.AskVolume1=AskVolume1
        self.AskVolume2=AskVolume2
        self.AskVolume3=AskVolume3
        self.AskVolume4=AskVolume4
        self.AveragePrice=AveragePrice
        self.HighestPrice=HighestPrice
        self.BidPrice1=BidPrice1
        self.BidPrice2=BidPrice2
        self.BidPrice3=BidPrice3
        self.BidPrice4=BidPrice4
        self.BidPrice5=BidPrice5
        self.BidVolume4=BidVolume4
        self.ExchangeID=ExchangeID
        self.BidVolume2=BidVolume2
        self.BidVolume3=BidVolume3
        self.PreOpenInterest=PreOpenInterest
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['Volume', 'LastPrice', 'ActionDay', 'Turnover', 'OpenPrice', 'LowerLimitPrice', 'UpdateMillisec', 'OpenInterest', 'AskPrice2', 'AskPrice3', 'AskPrice1', 'ClosePrice', 'AskPrice4', 'AskPrice5', 'UpperLimitPrice', 'InstrumentID', 'BidVolume1', 'TradingDay', 'BidVolume5', 'CurrDelta', 'SettlementPrice', 'UpdateTime', 'PreClosePrice', 'LowestPrice', 'ExchangeInstID', 'PreDelta', 'PreSettlementPrice', 'AskVolume5', 'AskVolume1', 'AskVolume2', 'AskVolume3', 'AskVolume4', 'AveragePrice', 'HighestPrice', 'BidPrice1', 'BidPrice2', 'BidPrice3', 'BidPrice4', 'BidPrice5', 'BidVolume4', 'ExchangeID', 'BidVolume2', 'BidVolume3', 'PreOpenInterest']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('Volume', u'数量'),('LastPrice', u'最新价'),('ActionDay', u'业务日期'),('Turnover', u'成交金额'),('OpenPrice', u'今开盘'),('LowerLimitPrice', u'跌停板价'),('UpdateMillisec', u'最后修改毫秒'),('OpenInterest', u'持仓量'),('AskPrice2', u'申卖价二'),('AskPrice3', u'申卖价三'),('AskPrice1', u'申卖价一'),('ClosePrice', u'今收盘'),('AskPrice4', u'申卖价四'),('AskPrice5', u'申卖价五'),('UpperLimitPrice', u'涨停板价'),('InstrumentID', u'合约代码'),('BidVolume1', u'申买量一'),('TradingDay', u'交易日'),('BidVolume5', u'申买量五'),('CurrDelta', u'今虚实度'),('SettlementPrice', u'本次结算价'),('UpdateTime', u'最后修改时间'),('PreClosePrice', u'昨收盘'),('LowestPrice', u'最低价'),('ExchangeInstID', u'合约在交易所的代码'),('PreDelta', u'昨虚实度'),('PreSettlementPrice', u'上次结算价'),('AskVolume5', u'申卖量五'),('AskVolume1', u'申卖量一'),('AskVolume2', u'申卖量二'),('AskVolume3', u'申卖量三'),('AskVolume4', u'申卖量四'),('AveragePrice', u'当日均价'),('HighestPrice', u'最高价'),('BidPrice1', u'申买价一'),('BidPrice2', u'申买价二'),('BidPrice3', u'申买价三'),('BidPrice4', u'申买价四'),('BidPrice5', u'申买价五'),('BidVolume4', u'申买量四'),('ExchangeID', u'交易所代码'),('BidVolume2', u'申买量二'),('BidVolume3', u'申买量三'),('PreOpenInterest', u'昨持仓量')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcTransferQryBankReqField:
    def __init__(self, FuturePwdFlag='0', FutureAccPwd="", FutureAccount="", CurrencyCode=""):
        self.FuturePwdFlag=FuturePwdFlag
        self.FutureAccPwd=FutureAccPwd
        self.FutureAccount=FutureAccount
        self.CurrencyCode=CurrencyCode
        self.vcmap={'FuturePwdFlag': {"'0'": '不核对', "'1'": '核对'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['FuturePwdFlag', 'FutureAccPwd', 'FutureAccount', 'CurrencyCode']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('FuturePwdFlag', u'密码标志'),('FutureAccPwd', u'密码'),('FutureAccount', u'期货资金账户'),('CurrencyCode', u'币种：RMB-人民币 USD-美圆 HKD-港元')]])
    def getval(self, n):
        if n in ['FuturePwdFlag']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcTradingAccountPasswordUpdateV1Field:
    def __init__(self, OldPassword="", InvestorID="", BrokerID="", NewPassword=""):
        self.OldPassword=OldPassword
        self.InvestorID=InvestorID
        self.BrokerID=BrokerID
        self.NewPassword=NewPassword
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['OldPassword', 'InvestorID', 'BrokerID', 'NewPassword']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('OldPassword', u'原来的口令'),('InvestorID', u'投资者代码'),('BrokerID', u'经纪公司代码'),('NewPassword', u'新的口令')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcTradeField:
    def __init__(self, Volume=0, OrderRef="", TradingRole='1', Price=0, InvestorID="", PriceSource='0', SequenceNo=0, TraderID="", OrderLocalID="", BrokerID="", TradeSource='0', OrderSysID="", SettlementID=0, OffsetFlag='0', ParticipantID="", ExchangeInstID="", ClearingPartID="", TradeID="", InstrumentID="", BusinessUnit="", TradeType='0', BrokerOrderSeq=0, TradingDay="", TradeDate="", ClientID="", HedgeFlag='1', ExchangeID="", UserID="", TradeTime="", Direction='0'):
        self.Volume=Volume
        self.OrderRef=OrderRef
        self.TradingRole=TradingRole
        self.Price=Price
        self.InvestorID=InvestorID
        self.PriceSource=PriceSource
        self.SequenceNo=SequenceNo
        self.TraderID=TraderID
        self.OrderLocalID=OrderLocalID
        self.BrokerID=BrokerID
        self.TradeSource=TradeSource
        self.OrderSysID=OrderSysID
        self.SettlementID=SettlementID
        self.OffsetFlag=OffsetFlag
        self.ParticipantID=ParticipantID
        self.ExchangeInstID=ExchangeInstID
        self.ClearingPartID=ClearingPartID
        self.TradeID=TradeID
        self.InstrumentID=InstrumentID
        self.BusinessUnit=BusinessUnit
        self.TradeType=TradeType
        self.BrokerOrderSeq=BrokerOrderSeq
        self.TradingDay=TradingDay
        self.TradeDate=TradeDate
        self.ClientID=ClientID
        self.HedgeFlag=HedgeFlag
        self.ExchangeID=ExchangeID
        self.UserID=UserID
        self.TradeTime=TradeTime
        self.Direction=Direction
        self.vcmap={'PriceSource': {"'2'": '卖委托价', "'0'": '前成交价', "'1'": '买委托价'}, 'TradingRole': {"'2'": '自营', "'3'": '做市商', "'1'": '代理'}, 'HedgeFlag': {"'2'": '套利', "'3'": '套保', "'1'": '投机'}, 'Direction': {"'0'": '买', "'1'": '卖'}, 'OffsetFlag': {"'0'": '开仓', "'6'": '本地强平', "'2'": '强平', "'5'": '强减', "'3'": '平今', "'1'": '平仓', "'4'": '平昨'}, 'TradeType': {"'2'": 'OTC成交', "'0'": '普通成交', "'3'": '期转现衍生成交', "'1'": '期权执行', "'4'": '组合衍生成交'}, 'TradeSource': {"'0'": '来自交易所普通回报', "'1'": '来自查询'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['Volume', 'OrderRef', 'TradingRole', 'Price', 'InvestorID', 'PriceSource', 'SequenceNo', 'TraderID', 'OrderLocalID', 'BrokerID', 'TradeSource', 'OrderSysID', 'SettlementID', 'OffsetFlag', 'ParticipantID', 'ExchangeInstID', 'ClearingPartID', 'TradeID', 'InstrumentID', 'BusinessUnit', 'TradeType', 'BrokerOrderSeq', 'TradingDay', 'TradeDate', 'ClientID', 'HedgeFlag', 'ExchangeID', 'UserID', 'TradeTime', 'Direction']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('Volume', u'数量'),('OrderRef', u'报单引用'),('TradingRole', u'交易角色'),('Price', u'价格'),('InvestorID', u'投资者代码'),('PriceSource', u'成交价来源'),('SequenceNo', u'序号'),('TraderID', u'交易所交易员代码'),('OrderLocalID', u'本地报单编号'),('BrokerID', u'经纪公司代码'),('TradeSource', u'成交来源'),('OrderSysID', u'报单编号'),('SettlementID', u'结算编号'),('OffsetFlag', u'开平标志'),('ParticipantID', u'会员代码'),('ExchangeInstID', u'合约在交易所的代码'),('ClearingPartID', u'结算会员编号'),('TradeID', u'成交编号'),('InstrumentID', u'合约代码'),('BusinessUnit', u'业务单元'),('TradeType', u'成交类型'),('BrokerOrderSeq', u'经纪公司报单编号'),('TradingDay', u'交易日'),('TradeDate', u'成交时期'),('ClientID', u'客户代码'),('HedgeFlag', u'投机套保标志'),('ExchangeID', u'交易所代码'),('UserID', u'用户代码'),('TradeTime', u'成交时间'),('Direction', u'买卖方向')]])
    def getval(self, n):
        if n in ['TradingRole', 'PriceSource', 'TradeSource', 'OffsetFlag', 'TradeType', 'HedgeFlag', 'Direction']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcTraderField:
    def __init__(self, ParticipantID="", TraderID="", BrokerID="", InstallCount=0, ExchangeID="", Password=""):
        self.ParticipantID=ParticipantID
        self.TraderID=TraderID
        self.BrokerID=BrokerID
        self.InstallCount=InstallCount
        self.ExchangeID=ExchangeID
        self.Password=Password
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ParticipantID', 'TraderID', 'BrokerID', 'InstallCount', 'ExchangeID', 'Password']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ParticipantID', u'会员代码'),('TraderID', u'交易所交易员代码'),('BrokerID', u'经纪公司代码'),('InstallCount', u'安装数量'),('ExchangeID', u'交易所代码'),('Password', u'密码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcMarketDataBid23Field:
    def __init__(self, BidPrice2=0, BidPrice3=0, BidVolume2=0, BidVolume3=0):
        self.BidPrice2=BidPrice2
        self.BidPrice3=BidPrice3
        self.BidVolume2=BidVolume2
        self.BidVolume3=BidVolume3
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['BidPrice2', 'BidPrice3', 'BidVolume2', 'BidVolume3']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('BidPrice2', u'申买价二'),('BidPrice3', u'申买价三'),('BidVolume2', u'申买量二'),('BidVolume3', u'申买量三')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryTransferSerialField:
    def __init__(self, AccountID="", BrokerID="", BankID=""):
        self.AccountID=AccountID
        self.BrokerID=BrokerID
        self.BankID=BankID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['AccountID', 'BrokerID', 'BankID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('AccountID', u'投资者帐号'),('BrokerID', u'经纪公司代码'),('BankID', u'银行编码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQrySuperUserField:
    def __init__(self, UserID=""):
        self.UserID=UserID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('UserID', u'用户代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcMarketDataAsk23Field:
    def __init__(self, AskPrice2=0, AskPrice3=0, AskVolume2=0, AskVolume3=0):
        self.AskPrice2=AskPrice2
        self.AskPrice3=AskPrice3
        self.AskVolume2=AskVolume2
        self.AskVolume3=AskVolume3
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['AskPrice2', 'AskPrice3', 'AskVolume2', 'AskVolume3']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('AskPrice2', u'申卖价二'),('AskPrice3', u'申卖价三'),('AskVolume2', u'申卖量二'),('AskVolume3', u'申卖量三')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryTradingNoticeField:
    def __init__(self, InvestorID="", BrokerID=""):
        self.InvestorID=InvestorID
        self.BrokerID=BrokerID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['InvestorID', 'BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('InvestorID', u'投资者代码'),('BrokerID', u'经纪公司代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcRspInfoField:
    def __init__(self, ErrorMsg="", ErrorID=0):
        self.ErrorMsg=ErrorMsg
        self.ErrorID=ErrorID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ErrorMsg', 'ErrorID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ErrorMsg', u'错误信息'),('ErrorID', u'错误代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcBrokerUserOTPParamField:
    def __init__(self, AuthKey="", BrokerID="", OTPType='0', OTPVendorsID="", LastSuccess=0, UserID="", SerialNumber="", LastDrift=0):
        self.AuthKey=AuthKey
        self.BrokerID=BrokerID
        self.OTPType=OTPType
        self.OTPVendorsID=OTPVendorsID
        self.LastSuccess=LastSuccess
        self.UserID=UserID
        self.SerialNumber=SerialNumber
        self.LastDrift=LastDrift
        self.vcmap={'OTPType': {"'0'": '无动态令牌', "'1'": '时间令牌'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['AuthKey', 'BrokerID', 'OTPType', 'OTPVendorsID', 'LastSuccess', 'UserID', 'SerialNumber', 'LastDrift']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('AuthKey', u'令牌密钥'),('BrokerID', u'经纪公司代码'),('OTPType', u'动态令牌类型'),('OTPVendorsID', u'动态令牌提供商'),('LastSuccess', u'成功值'),('UserID', u'用户代码'),('SerialNumber', u'动态令牌序列号'),('LastDrift', u'漂移值')]])
    def getval(self, n):
        if n in ['OTPType']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcReqChangeAccountField:
    def __init__(self, TradeTime="", Digest="", AccountID="", TradeDate="", BankAccount="", VerifyCertNoFlag='0', LastFragment='0', CurrencyID="", SecuPwdFlag='0', BankPwdFlag='0', Gender='0', BrokerID="", BankID="", BankSerial="", MobilePhone="", NewBankAccount="", BankAccType='1', CustType='0', NewBankPassWord="", TID=0, MoneyAccountStatus='0', Fax="", CustomerName="", BrokerIDByBank="", BrokerBranchID="", BankBranchID="", TradeCode="", Password="", CountryCode="", BankPassWord="", IdentifiedCardNo="", IdCardType='0', EMail="", ZipCode="", InstallID=0, PlateSerial=0, Address="", TradingDay="", SessionID=0, Telephone=""):
        self.TradeTime=TradeTime
        self.Digest=Digest
        self.AccountID=AccountID
        self.TradeDate=TradeDate
        self.BankAccount=BankAccount
        self.VerifyCertNoFlag=VerifyCertNoFlag
        self.LastFragment=LastFragment
        self.CurrencyID=CurrencyID
        self.SecuPwdFlag=SecuPwdFlag
        self.BankPwdFlag=BankPwdFlag
        self.Gender=Gender
        self.BrokerID=BrokerID
        self.BankID=BankID
        self.BankSerial=BankSerial
        self.MobilePhone=MobilePhone
        self.NewBankAccount=NewBankAccount
        self.BankAccType=BankAccType
        self.CustType=CustType
        self.NewBankPassWord=NewBankPassWord
        self.TID=TID
        self.MoneyAccountStatus=MoneyAccountStatus
        self.Fax=Fax
        self.CustomerName=CustomerName
        self.BrokerIDByBank=BrokerIDByBank
        self.BrokerBranchID=BrokerBranchID
        self.BankBranchID=BankBranchID
        self.TradeCode=TradeCode
        self.Password=Password
        self.CountryCode=CountryCode
        self.BankPassWord=BankPassWord
        self.IdentifiedCardNo=IdentifiedCardNo
        self.IdCardType=IdCardType
        self.EMail=EMail
        self.ZipCode=ZipCode
        self.InstallID=InstallID
        self.PlateSerial=PlateSerial
        self.Address=Address
        self.TradingDay=TradingDay
        self.SessionID=SessionID
        self.Telephone=Telephone
        self.vcmap={'IdCardType': {"'0'": '组织机构代码', "'6'": '护照', "'7'": '台胞证', "'2'": '军官证', "'8'": '回乡证', "'3'": '警官证', "'1'": '身份证', "'x'": '其他证件', "'9'": '营业执照号', "'5'": '户口簿', "'A'": '税务登记号', "'4'": '士兵证'}, 'BankPwdFlag': {"'2'": '密文核对', "'0'": '不核对', "'1'": '明文核对'}, 'Gender': {"'2'": '女', "'0'": '未知状态', "'1'": '男'}, 'MoneyAccountStatus': {"'0'": '正常', "'1'": '销户'}, 'VerifyCertNoFlag': {"'0'": '是', "'1'": '否'}, 'CustType': {"'0'": '自然人', "'1'": '机构户'}, 'LastFragment': {"'0'": '是最后分片', "'1'": '不是最后分片'}, 'BankAccType': {"'2'": '储蓄卡', "'3'": '信用卡', "'1'": '银行存折'}, 'SecuPwdFlag': {"'2'": '密文核对', "'0'": '不核对', "'1'": '明文核对'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['TradeTime', 'Digest', 'AccountID', 'TradeDate', 'BankAccount', 'VerifyCertNoFlag', 'LastFragment', 'CurrencyID', 'SecuPwdFlag', 'BankPwdFlag', 'Gender', 'BrokerID', 'BankID', 'BankSerial', 'MobilePhone', 'NewBankAccount', 'BankAccType', 'CustType', 'NewBankPassWord', 'TID', 'MoneyAccountStatus', 'Fax', 'CustomerName', 'BrokerIDByBank', 'BrokerBranchID', 'BankBranchID', 'TradeCode', 'Password', 'CountryCode', 'BankPassWord', 'IdentifiedCardNo', 'IdCardType', 'EMail', 'ZipCode', 'InstallID', 'PlateSerial', 'Address', 'TradingDay', 'SessionID', 'Telephone']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('TradeTime', u'交易时间'),('Digest', u'摘要'),('AccountID', u'投资者帐号'),('TradeDate', u'交易日期'),('BankAccount', u'银行帐号'),('VerifyCertNoFlag', u'验证客户证件号码标志'),('LastFragment', u'最后分片标志'),('CurrencyID', u'币种代码'),('SecuPwdFlag', u'期货资金密码核对标志'),('BankPwdFlag', u'银行密码标志'),('Gender', u'性别'),('BrokerID', u'期商代码'),('BankID', u'银行代码'),('BankSerial', u'银行流水号'),('MobilePhone', u'手机'),('NewBankAccount', u'新银行帐号'),('BankAccType', u'银行帐号类型'),('CustType', u'客户类型'),('NewBankPassWord', u'新银行密码'),('TID', u'交易ID'),('MoneyAccountStatus', u'资金账户状态'),('Fax', u'传真'),('CustomerName', u'客户姓名'),('BrokerIDByBank', u'期货公司银行编码'),('BrokerBranchID', u'期商分支机构代码'),('BankBranchID', u'银行分支机构代码'),('TradeCode', u'业务功能码'),('Password', u'期货密码'),('CountryCode', u'国家代码'),('BankPassWord', u'银行密码'),('IdentifiedCardNo', u'证件号码'),('IdCardType', u'证件类型'),('EMail', u'电子邮件'),('ZipCode', u'邮编'),('InstallID', u'安装编号'),('PlateSerial', u'银期平台消息流水号'),('Address', u'地址'),('TradingDay', u'交易系统日期'),('SessionID', u'会话号'),('Telephone', u'电话号码')]])
    def getval(self, n):
        if n in ['VerifyCertNoFlag', 'LastFragment', 'SecuPwdFlag', 'BankPwdFlag', 'Gender', 'BankAccType', 'CustType', 'MoneyAccountStatus', 'IdCardType']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryExchangeMarginRateField:
    def __init__(self, HedgeFlag='1', BrokerID="", InstrumentID=""):
        self.HedgeFlag=HedgeFlag
        self.BrokerID=BrokerID
        self.InstrumentID=InstrumentID
        self.vcmap={'HedgeFlag': {"'2'": '套利', "'3'": '套保', "'1'": '投机'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['HedgeFlag', 'BrokerID', 'InstrumentID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('HedgeFlag', u'投机套保标志'),('BrokerID', u'经纪公司代码'),('InstrumentID', u'合约代码')]])
    def getval(self, n):
        if n in ['HedgeFlag']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcParkedOrderActionField:
    def __init__(self, OrderActionRef=0, LimitPrice=0, ParkedOrderActionID="", ErrorID=0, ErrorMsg="", ActionFlag='0', InvestorID="", OrderRef="", SessionID=0, Status='1', VolumeChange=0, RequestID=0, BrokerID="", OrderSysID="", FrontID=0, ExchangeID="", UserType='0', UserID="", InstrumentID=""):
        self.OrderActionRef=OrderActionRef
        self.LimitPrice=LimitPrice
        self.ParkedOrderActionID=ParkedOrderActionID
        self.ErrorID=ErrorID
        self.ErrorMsg=ErrorMsg
        self.ActionFlag=ActionFlag
        self.InvestorID=InvestorID
        self.OrderRef=OrderRef
        self.SessionID=SessionID
        self.Status=Status
        self.VolumeChange=VolumeChange
        self.RequestID=RequestID
        self.BrokerID=BrokerID
        self.OrderSysID=OrderSysID
        self.FrontID=FrontID
        self.ExchangeID=ExchangeID
        self.UserType=UserType
        self.UserID=UserID
        self.InstrumentID=InstrumentID
        self.vcmap={'Status': {"'2'": '已发送', "'3'": '已删除', "'1'": '未发送'}, 'UserType': {"'2'": '管理员', "'0'": '投资者', "'1'": '操作员'}, 'ActionFlag': {"'0'": '删除', "'3'": '修改'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['OrderActionRef', 'LimitPrice', 'ParkedOrderActionID', 'ErrorID', 'ErrorMsg', 'ActionFlag', 'InvestorID', 'OrderRef', 'SessionID', 'Status', 'VolumeChange', 'RequestID', 'BrokerID', 'OrderSysID', 'FrontID', 'ExchangeID', 'UserType', 'UserID', 'InstrumentID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('OrderActionRef', u'报单操作引用'),('LimitPrice', u'价格'),('ParkedOrderActionID', u'预埋撤单单编号'),('ErrorID', u'错误代码'),('ErrorMsg', u'错误信息'),('ActionFlag', u'操作标志'),('InvestorID', u'投资者代码'),('OrderRef', u'报单引用'),('SessionID', u'会话编号'),('Status', u'预埋撤单状态'),('VolumeChange', u'数量变化'),('RequestID', u'请求编号'),('BrokerID', u'经纪公司代码'),('OrderSysID', u'报单编号'),('FrontID', u'前置编号'),('ExchangeID', u'交易所代码'),('UserType', u'用户类型'),('UserID', u'用户代码'),('InstrumentID', u'合约代码')]])
    def getval(self, n):
        if n in ['ActionFlag', 'Status', 'UserType']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryExchangeOrderField:
    def __init__(self, ParticipantID="", ExchangeID="", TraderID="", ExchangeInstID="", ClientID=""):
        self.ParticipantID=ParticipantID
        self.ExchangeID=ExchangeID
        self.TraderID=TraderID
        self.ExchangeInstID=ExchangeInstID
        self.ClientID=ClientID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ParticipantID', 'ExchangeID', 'TraderID', 'ExchangeInstID', 'ClientID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ParticipantID', u'会员代码'),('ExchangeID', u'交易所代码'),('TraderID', u'交易所交易员代码'),('ExchangeInstID', u'合约在交易所的代码'),('ClientID', u'客户代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryBrokerUserEventField:
    def __init__(self, UserEventType='1', BrokerID="", UserID=""):
        self.UserEventType=UserEventType
        self.BrokerID=BrokerID
        self.UserID=UserID
        self.vcmap={'UserEventType': {"'6'": '客户端认证', "'9'": '其他', "'2'": '登出', "'5'": '修改密码', "'3'": '交易成功', "'1'": '登录', "'4'": '交易失败'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['UserEventType', 'BrokerID', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('UserEventType', u'用户事件类型'),('BrokerID', u'经纪公司代码'),('UserID', u'用户代码')]])
    def getval(self, n):
        if n in ['UserEventType']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcSettlementRefField:
    def __init__(self, TradingDay="", SettlementID=0):
        self.TradingDay=TradingDay
        self.SettlementID=SettlementID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['TradingDay', 'SettlementID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('TradingDay', u'交易日'),('SettlementID', u'结算编号')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryInvestorPositionField:
    def __init__(self, InvestorID="", BrokerID="", InstrumentID=""):
        self.InvestorID=InvestorID
        self.BrokerID=BrokerID
        self.InstrumentID=InstrumentID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['InvestorID', 'BrokerID', 'InstrumentID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('InvestorID', u'投资者代码'),('BrokerID', u'经纪公司代码'),('InstrumentID', u'合约代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryExchangeOrderActionField:
    def __init__(self, ParticipantID="", TraderID="", ExchangeID="", ClientID=""):
        self.ParticipantID=ParticipantID
        self.TraderID=TraderID
        self.ExchangeID=ExchangeID
        self.ClientID=ClientID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ParticipantID', 'TraderID', 'ExchangeID', 'ClientID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ParticipantID', u'会员代码'),('TraderID', u'交易所交易员代码'),('ExchangeID', u'交易所代码'),('ClientID', u'客户代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcTransferQryDetailRspField:
    def __init__(self, CertCode="", TradeTime="", BankBrchID="", TradeDate="", BankAccount="", CurrencyCode="", TradeCode="", FutureAccount="", Flag='0', TxAmount=0, BankID="", FutureSerial=0, BankSerial=0, FutureID=""):
        self.CertCode=CertCode
        self.TradeTime=TradeTime
        self.BankBrchID=BankBrchID
        self.TradeDate=TradeDate
        self.BankAccount=BankAccount
        self.CurrencyCode=CurrencyCode
        self.TradeCode=TradeCode
        self.FutureAccount=FutureAccount
        self.Flag=Flag
        self.TxAmount=TxAmount
        self.BankID=BankID
        self.FutureSerial=FutureSerial
        self.BankSerial=BankSerial
        self.FutureID=FutureID
        self.vcmap={'Flag': {"'2'": '冲正', "'0'": '无效或失败', "'1'": '有效'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['CertCode', 'TradeTime', 'BankBrchID', 'TradeDate', 'BankAccount', 'CurrencyCode', 'TradeCode', 'FutureAccount', 'Flag', 'TxAmount', 'BankID', 'FutureSerial', 'BankSerial', 'FutureID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('CertCode', u'证件号码'),('TradeTime', u'交易时间'),('BankBrchID', u'银行分中心代码'),('TradeDate', u'交易日期'),('BankAccount', u'银行账号'),('CurrencyCode', u'货币代码'),('TradeCode', u'交易代码'),('FutureAccount', u'资金帐号'),('Flag', u'有效标志'),('TxAmount', u'发生金额'),('BankID', u'银行代码'),('FutureSerial', u'期货流水号'),('BankSerial', u'银行流水号'),('FutureID', u'期货公司代码')]])
    def getval(self, n):
        if n in ['Flag']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcSyncingTradingCodeField:
    def __init__(self, IsActive=0, ClientIDType='1', BrokerID="", ClientID="", ExchangeID="", InvestorID=""):
        self.IsActive=IsActive
        self.ClientIDType=ClientIDType
        self.BrokerID=BrokerID
        self.ClientID=ClientID
        self.ExchangeID=ExchangeID
        self.InvestorID=InvestorID
        self.vcmap={'ClientIDType': {"'2'": '套利', "'3'": '套保', "'1'": '投机'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['IsActive', 'ClientIDType', 'BrokerID', 'ClientID', 'ExchangeID', 'InvestorID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('IsActive', u'是否活跃'),('ClientIDType', u'交易编码类型'),('BrokerID', u'经纪公司代码'),('ClientID', u'客户代码'),('ExchangeID', u'交易所代码'),('InvestorID', u'投资者代码')]])
    def getval(self, n):
        if n in ['ClientIDType']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryBrokerUserField:
    def __init__(self, BrokerID="", UserID=""):
        self.BrokerID=BrokerID
        self.UserID=UserID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['BrokerID', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('BrokerID', u'经纪公司代码'),('UserID', u'用户代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryInstrumentMarginRateField:
    def __init__(self, HedgeFlag='1', InvestorID="", BrokerID="", InstrumentID=""):
        self.HedgeFlag=HedgeFlag
        self.InvestorID=InvestorID
        self.BrokerID=BrokerID
        self.InstrumentID=InstrumentID
        self.vcmap={'HedgeFlag': {"'2'": '套利', "'3'": '套保', "'1'": '投机'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['HedgeFlag', 'InvestorID', 'BrokerID', 'InstrumentID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('HedgeFlag', u'投机套保标志'),('InvestorID', u'投资者代码'),('BrokerID', u'经纪公司代码'),('InstrumentID', u'合约代码')]])
    def getval(self, n):
        if n in ['HedgeFlag']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcLoginForbiddenUserField:
    def __init__(self, BrokerID="", UserID=""):
        self.BrokerID=BrokerID
        self.UserID=UserID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['BrokerID', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('BrokerID', u'经纪公司代码'),('UserID', u'用户代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryFrontStatusField:
    def __init__(self, FrontID=0):
        self.FrontID=FrontID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['FrontID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('FrontID', u'前置编号')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcInvestorAccountField:
    def __init__(self, AccountID="", InvestorID="", BrokerID=""):
        self.AccountID=AccountID
        self.InvestorID=InvestorID
        self.BrokerID=BrokerID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['AccountID', 'InvestorID', 'BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('AccountID', u'投资者帐号'),('InvestorID', u'投资者代码'),('BrokerID', u'经纪公司代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcDepositResultInformField:
    def __init__(self, Deposit=0, ReturnCode="", RequestID=0, BrokerID="", DescrInfoForReturnCode="", DepositSeqNo="", InvestorID=""):
        self.Deposit=Deposit
        self.ReturnCode=ReturnCode
        self.RequestID=RequestID
        self.BrokerID=BrokerID
        self.DescrInfoForReturnCode=DescrInfoForReturnCode
        self.DepositSeqNo=DepositSeqNo
        self.InvestorID=InvestorID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['Deposit', 'ReturnCode', 'RequestID', 'BrokerID', 'DescrInfoForReturnCode', 'DepositSeqNo', 'InvestorID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('Deposit', u'入金金额'),('ReturnCode', u'返回代码'),('RequestID', u'请求编号'),('BrokerID', u'经纪公司代码'),('DescrInfoForReturnCode', u'返回码描述'),('DepositSeqNo', u'出入金流水号，该流水号为银期报盘返回的流水号'),('InvestorID', u'投资者代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcBrokerUserPasswordField:
    def __init__(self, BrokerID="", Password="", UserID=""):
        self.BrokerID=BrokerID
        self.Password=Password
        self.UserID=UserID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['BrokerID', 'Password', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('BrokerID', u'经纪公司代码'),('Password', u'密码'),('UserID', u'用户代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryMDTraderOfferField:
    def __init__(self, ParticipantID="", TraderID="", ExchangeID=""):
        self.ParticipantID=ParticipantID
        self.TraderID=TraderID
        self.ExchangeID=ExchangeID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ParticipantID', 'TraderID', 'ExchangeID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ParticipantID', u'会员代码'),('TraderID', u'交易所交易员代码'),('ExchangeID', u'交易所代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryTradingCodeField:
    def __init__(self, ClientIDType='1', ExchangeID="", InvestorID="", BrokerID="", ClientID=""):
        self.ClientIDType=ClientIDType
        self.ExchangeID=ExchangeID
        self.InvestorID=InvestorID
        self.BrokerID=BrokerID
        self.ClientID=ClientID
        self.vcmap={'ClientIDType': {"'2'": '套利', "'3'": '套保', "'1'": '投机'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ClientIDType', 'ExchangeID', 'InvestorID', 'BrokerID', 'ClientID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ClientIDType', u'交易编码类型'),('ExchangeID', u'交易所代码'),('InvestorID', u'投资者代码'),('BrokerID', u'经纪公司代码'),('ClientID', u'客户代码')]])
    def getval(self, n):
        if n in ['ClientIDType']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcCFMMCTradingAccountKeyField:
    def __init__(self, ParticipantID="", KeyID=0, AccountID="", BrokerID="", CurrentKey=""):
        self.ParticipantID=ParticipantID
        self.KeyID=KeyID
        self.AccountID=AccountID
        self.BrokerID=BrokerID
        self.CurrentKey=CurrentKey
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ParticipantID', 'KeyID', 'AccountID', 'BrokerID', 'CurrentKey']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ParticipantID', u'经纪公司统一编码'),('KeyID', u'密钥编号'),('AccountID', u'投资者帐号'),('BrokerID', u'经纪公司代码'),('CurrentKey', u'动态密钥')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcRspAuthenticateField:
    def __init__(self, UserProductInfo="", BrokerID="", UserID=""):
        self.UserProductInfo=UserProductInfo
        self.BrokerID=BrokerID
        self.UserID=UserID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['UserProductInfo', 'BrokerID', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('UserProductInfo', u'用户端产品信息'),('BrokerID', u'经纪公司代码'),('UserID', u'用户代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcNotifyQueryAccountField:
    def __init__(self, TradeTime="", Digest="", BankUseAmount=0, TradeDate="", BankAccount="", ErrorMsg="", VerifyCertNoFlag='0', LastFragment='0', TradeCode="", SecuPwdFlag='0', BankPwdFlag='0', RequestID=0, BrokerID="", BankID="", BankSecuAcc="", FutureSerial=0, BankSecuAccType='1', CustType='0', InstallID=0, TID=0, DeviceID="", CurrencyID="", ErrorID=0, CustomerName="", OperNo="", BrokerBranchID="", BankBranchID="", IdCardType='0', Password="", BankAccType='1', BankPassWord="", IdentifiedCardNo="", AccountID="", TradingDay="", BrokerIDByBank="", PlateSerial=0, BankSerial="", SessionID=0, BankFetchAmount=0, UserID=""):
        self.TradeTime=TradeTime
        self.Digest=Digest
        self.BankUseAmount=BankUseAmount
        self.TradeDate=TradeDate
        self.BankAccount=BankAccount
        self.ErrorMsg=ErrorMsg
        self.VerifyCertNoFlag=VerifyCertNoFlag
        self.LastFragment=LastFragment
        self.TradeCode=TradeCode
        self.SecuPwdFlag=SecuPwdFlag
        self.BankPwdFlag=BankPwdFlag
        self.RequestID=RequestID
        self.BrokerID=BrokerID
        self.BankID=BankID
        self.BankSecuAcc=BankSecuAcc
        self.FutureSerial=FutureSerial
        self.BankSecuAccType=BankSecuAccType
        self.CustType=CustType
        self.InstallID=InstallID
        self.TID=TID
        self.DeviceID=DeviceID
        self.CurrencyID=CurrencyID
        self.ErrorID=ErrorID
        self.CustomerName=CustomerName
        self.OperNo=OperNo
        self.BrokerBranchID=BrokerBranchID
        self.BankBranchID=BankBranchID
        self.IdCardType=IdCardType
        self.Password=Password
        self.BankAccType=BankAccType
        self.BankPassWord=BankPassWord
        self.IdentifiedCardNo=IdentifiedCardNo
        self.AccountID=AccountID
        self.TradingDay=TradingDay
        self.BrokerIDByBank=BrokerIDByBank
        self.PlateSerial=PlateSerial
        self.BankSerial=BankSerial
        self.SessionID=SessionID
        self.BankFetchAmount=BankFetchAmount
        self.UserID=UserID
        self.vcmap={'IdCardType': {"'0'": '组织机构代码', "'6'": '护照', "'7'": '台胞证', "'2'": '军官证', "'8'": '回乡证', "'3'": '警官证', "'1'": '身份证', "'x'": '其他证件', "'9'": '营业执照号', "'5'": '户口簿', "'A'": '税务登记号', "'4'": '士兵证'}, 'VerifyCertNoFlag': {"'0'": '是', "'1'": '否'}, 'CustType': {"'0'": '自然人', "'1'": '机构户'}, 'BankSecuAccType': {"'2'": '储蓄卡', "'3'": '信用卡', "'1'": '银行存折'}, 'BankPwdFlag': {"'2'": '密文核对', "'0'": '不核对', "'1'": '明文核对'}, 'LastFragment': {"'0'": '是最后分片', "'1'": '不是最后分片'}, 'BankAccType': {"'2'": '储蓄卡', "'3'": '信用卡', "'1'": '银行存折'}, 'SecuPwdFlag': {"'2'": '密文核对', "'0'": '不核对', "'1'": '明文核对'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['TradeTime', 'Digest', 'BankUseAmount', 'TradeDate', 'BankAccount', 'ErrorMsg', 'VerifyCertNoFlag', 'LastFragment', 'TradeCode', 'SecuPwdFlag', 'BankPwdFlag', 'RequestID', 'BrokerID', 'BankID', 'BankSecuAcc', 'FutureSerial', 'BankSecuAccType', 'CustType', 'InstallID', 'TID', 'DeviceID', 'CurrencyID', 'ErrorID', 'CustomerName', 'OperNo', 'BrokerBranchID', 'BankBranchID', 'IdCardType', 'Password', 'BankAccType', 'BankPassWord', 'IdentifiedCardNo', 'AccountID', 'TradingDay', 'BrokerIDByBank', 'PlateSerial', 'BankSerial', 'SessionID', 'BankFetchAmount', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('TradeTime', u'交易时间'),('Digest', u'摘要'),('BankUseAmount', u'银行可用金额'),('TradeDate', u'交易日期'),('BankAccount', u'银行帐号'),('ErrorMsg', u'错误信息'),('VerifyCertNoFlag', u'验证客户证件号码标志'),('LastFragment', u'最后分片标志'),('TradeCode', u'业务功能码'),('SecuPwdFlag', u'期货资金密码核对标志'),('BankPwdFlag', u'银行密码标志'),('RequestID', u'请求编号'),('BrokerID', u'期商代码'),('BankID', u'银行代码'),('BankSecuAcc', u'期货单位帐号'),('FutureSerial', u'期货公司流水号'),('BankSecuAccType', u'期货单位帐号类型'),('CustType', u'客户类型'),('InstallID', u'安装编号'),('TID', u'交易ID'),('DeviceID', u'渠道标志'),('CurrencyID', u'币种代码'),('ErrorID', u'错误代码'),('CustomerName', u'客户姓名'),('OperNo', u'交易柜员'),('BrokerBranchID', u'期商分支机构代码'),('BankBranchID', u'银行分支机构代码'),('IdCardType', u'证件类型'),('Password', u'期货密码'),('BankAccType', u'银行帐号类型'),('BankPassWord', u'银行密码'),('IdentifiedCardNo', u'证件号码'),('AccountID', u'投资者帐号'),('TradingDay', u'交易系统日期'),('BrokerIDByBank', u'期货公司银行编码'),('PlateSerial', u'银期平台消息流水号'),('BankSerial', u'银行流水号'),('SessionID', u'会话号'),('BankFetchAmount', u'银行可取金额'),('UserID', u'用户标识')]])
    def getval(self, n):
        if n in ['VerifyCertNoFlag', 'LastFragment', 'SecuPwdFlag', 'BankPwdFlag', 'BankSecuAccType', 'CustType', 'IdCardType', 'BankAccType']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcManualSyncBrokerUserOTPField:
    def __init__(self, OTPType='0', FirstOTP="", SecondOTP="", BrokerID="", UserID=""):
        self.OTPType=OTPType
        self.FirstOTP=FirstOTP
        self.SecondOTP=SecondOTP
        self.BrokerID=BrokerID
        self.UserID=UserID
        self.vcmap={'OTPType': {"'0'": '无动态令牌', "'1'": '时间令牌'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['OTPType', 'FirstOTP', 'SecondOTP', 'BrokerID', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('OTPType', u'动态令牌类型'),('FirstOTP', u'第一个动态密码'),('SecondOTP', u'第二个动态密码'),('BrokerID', u'经纪公司代码'),('UserID', u'用户代码')]])
    def getval(self, n):
        if n in ['OTPType']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcLoadSettlementInfoField:
    def __init__(self, BrokerID=""):
        self.BrokerID=BrokerID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('BrokerID', u'经纪公司代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryBrokerTradingParamsField:
    def __init__(self, InvestorID="", BrokerID=""):
        self.InvestorID=InvestorID
        self.BrokerID=BrokerID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['InvestorID', 'BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('InvestorID', u'投资者代码'),('BrokerID', u'经纪公司代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcTransferHeaderField:
    def __init__(self, TradeTime="", BankBrchID="", BankID="", Version="", OperNo="", TradeSerial="", RecordNum="", TradeCode="", DeviceID="", RequestID=0, TradeDate="", SessionID=0, FutureID=""):
        self.TradeTime=TradeTime
        self.BankBrchID=BankBrchID
        self.BankID=BankID
        self.Version=Version
        self.OperNo=OperNo
        self.TradeSerial=TradeSerial
        self.RecordNum=RecordNum
        self.TradeCode=TradeCode
        self.DeviceID=DeviceID
        self.RequestID=RequestID
        self.TradeDate=TradeDate
        self.SessionID=SessionID
        self.FutureID=FutureID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['TradeTime', 'BankBrchID', 'BankID', 'Version', 'OperNo', 'TradeSerial', 'RecordNum', 'TradeCode', 'DeviceID', 'RequestID', 'TradeDate', 'SessionID', 'FutureID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('TradeTime', u'交易时间，必填，格式：hhmmss'),('BankBrchID', u'银行分中心代码，根据查询银行得到，必填'),('BankID', u'银行代码，根据查询银行得到，必填'),('Version', u'版本号，常量，1.0'),('OperNo', u'操作员，N/A'),('TradeSerial', u'发起方流水号，N/A'),('RecordNum', u'记录数，N/A'),('TradeCode', u'交易代码，必填'),('DeviceID', u'交易设备类型，N/A'),('RequestID', u'请求编号，N/A'),('TradeDate', u'交易日期，必填，格式：yyyymmdd'),('SessionID', u'会话编号，N/A'),('FutureID', u'期货公司代码，必填')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcReqDayEndFileReadyField:
    def __init__(self, TradeTime="", FileBusinessCode='0', Digest="", BankID="", BrokerBranchID="", BankBranchID="", TradeCode="", LastFragment='0', PlateSerial=0, TradingDay="", BrokerID="", TradeDate="", BankSerial="", SessionID=0):
        self.TradeTime=TradeTime
        self.FileBusinessCode=FileBusinessCode
        self.Digest=Digest
        self.BankID=BankID
        self.BrokerBranchID=BrokerBranchID
        self.BankBranchID=BankBranchID
        self.TradeCode=TradeCode
        self.LastFragment=LastFragment
        self.PlateSerial=PlateSerial
        self.TradingDay=TradingDay
        self.BrokerID=BrokerID
        self.TradeDate=TradeDate
        self.BankSerial=BankSerial
        self.SessionID=SessionID
        self.vcmap={'FileBusinessCode': {"'0'": '其他', "'6'": '客户销户结息明细对账', "'7'": '客户资金余额对账结果', "'2'": '客户账户状态对账', "'e'": '存管银行备付金余额', "'8'": '其它对账异常结果文件', "'3'": '账户类交易明细对账', "'1'": '转账交易明细对账', "'d'": '总分平衡监管数据', "'f'": '协办存管银行资金监管数据', "'9'": '客户结息净额明细', "'b'": '法人存管银行资金交收汇总', "'5'": '客户资金台账余额明细对账', "'c'": '主体间资金交收汇总', "'a'": '客户资金交收明细', "'4'": '期货账户信息变更明细对账'}, 'LastFragment': {"'0'": '是最后分片', "'1'": '不是最后分片'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['TradeTime', 'FileBusinessCode', 'Digest', 'BankID', 'BrokerBranchID', 'BankBranchID', 'TradeCode', 'LastFragment', 'PlateSerial', 'TradingDay', 'BrokerID', 'TradeDate', 'BankSerial', 'SessionID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('TradeTime', u'交易时间'),('FileBusinessCode', u'文件业务功能'),('Digest', u'摘要'),('BankID', u'银行代码'),('BrokerBranchID', u'期商分支机构代码'),('BankBranchID', u'银行分支机构代码'),('TradeCode', u'业务功能码'),('LastFragment', u'最后分片标志'),('PlateSerial', u'银期平台消息流水号'),('TradingDay', u'交易系统日期'),('BrokerID', u'期商代码'),('TradeDate', u'交易日期'),('BankSerial', u'银行流水号'),('SessionID', u'会话号')]])
    def getval(self, n):
        if n in ['FileBusinessCode', 'LastFragment']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcMarketDataLastMatchField:
    def __init__(self, Volume=0, Turnover=0, OpenInterest=0, LastPrice=0):
        self.Volume=Volume
        self.Turnover=Turnover
        self.OpenInterest=OpenInterest
        self.LastPrice=LastPrice
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['Volume', 'Turnover', 'OpenInterest', 'LastPrice']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('Volume', u'数量'),('Turnover', u'成交金额'),('OpenInterest', u'持仓量'),('LastPrice', u'最新价')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcCancelAccountField:
    def __init__(self, PlateSerial=0, Digest="", CashExchangeCode='1', TID=0, BankAccount="", ErrorMsg="", TradeCode="", Gender='0', BankID="", BankSecuAcc="", BankSecuAccType='1', BrokerIDByBank="", BankPassWord="", MoneyAccountStatus='0', ErrorID=0, CustomerName="", OperNo="", BrokerBranchID="", SecuPwdFlag='0', CountryCode="", AccountID="", EMail="", ZipCode="", BankSerial="", Telephone="", TradeTime="", VerifyCertNoFlag='0', LastFragment='0', CurrencyID="", BrokerID="", MobilePhone="", CustType='0', InstallID=0, TradingDay="", Fax="", BankPwdFlag='0', BankBranchID="", Password="", BankAccType='1', DeviceID="", IdentifiedCardNo="", IdCardType='0', TradeDate="", Address="", SessionID=0, UserID=""):
        self.PlateSerial=PlateSerial
        self.Digest=Digest
        self.CashExchangeCode=CashExchangeCode
        self.TID=TID
        self.BankAccount=BankAccount
        self.ErrorMsg=ErrorMsg
        self.TradeCode=TradeCode
        self.Gender=Gender
        self.BankID=BankID
        self.BankSecuAcc=BankSecuAcc
        self.BankSecuAccType=BankSecuAccType
        self.BrokerIDByBank=BrokerIDByBank
        self.BankPassWord=BankPassWord
        self.MoneyAccountStatus=MoneyAccountStatus
        self.ErrorID=ErrorID
        self.CustomerName=CustomerName
        self.OperNo=OperNo
        self.BrokerBranchID=BrokerBranchID
        self.SecuPwdFlag=SecuPwdFlag
        self.CountryCode=CountryCode
        self.AccountID=AccountID
        self.EMail=EMail
        self.ZipCode=ZipCode
        self.BankSerial=BankSerial
        self.Telephone=Telephone
        self.TradeTime=TradeTime
        self.VerifyCertNoFlag=VerifyCertNoFlag
        self.LastFragment=LastFragment
        self.CurrencyID=CurrencyID
        self.BrokerID=BrokerID
        self.MobilePhone=MobilePhone
        self.CustType=CustType
        self.InstallID=InstallID
        self.TradingDay=TradingDay
        self.Fax=Fax
        self.BankPwdFlag=BankPwdFlag
        self.BankBranchID=BankBranchID
        self.Password=Password
        self.BankAccType=BankAccType
        self.DeviceID=DeviceID
        self.IdentifiedCardNo=IdentifiedCardNo
        self.IdCardType=IdCardType
        self.TradeDate=TradeDate
        self.Address=Address
        self.SessionID=SessionID
        self.UserID=UserID
        self.vcmap={'IdCardType': {"'0'": '组织机构代码', "'6'": '护照', "'7'": '台胞证', "'2'": '军官证', "'8'": '回乡证', "'3'": '警官证', "'1'": '身份证', "'x'": '其他证件', "'9'": '营业执照号', "'5'": '户口簿', "'A'": '税务登记号', "'4'": '士兵证'}, 'VerifyCertNoFlag': {"'0'": '是', "'1'": '否'}, 'Gender': {"'2'": '女', "'0'": '未知状态', "'1'": '男'}, 'BankPwdFlag': {"'2'": '密文核对', "'0'": '不核对', "'1'": '明文核对'}, 'MoneyAccountStatus': {"'0'": '正常', "'1'": '销户'}, 'CashExchangeCode': {"'2'": '钞', "'1'": '汇'}, 'BankSecuAccType': {"'2'": '储蓄卡', "'3'": '信用卡', "'1'": '银行存折'}, 'CustType': {"'0'": '自然人', "'1'": '机构户'}, 'SecuPwdFlag': {"'2'": '密文核对', "'0'": '不核对', "'1'": '明文核对'}, 'BankAccType': {"'2'": '储蓄卡', "'3'": '信用卡', "'1'": '银行存折'}, 'LastFragment': {"'0'": '是最后分片', "'1'": '不是最后分片'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['PlateSerial', 'Digest', 'CashExchangeCode', 'TID', 'BankAccount', 'ErrorMsg', 'TradeCode', 'Gender', 'BankID', 'BankSecuAcc', 'BankSecuAccType', 'BrokerIDByBank', 'BankPassWord', 'MoneyAccountStatus', 'ErrorID', 'CustomerName', 'OperNo', 'BrokerBranchID', 'SecuPwdFlag', 'CountryCode', 'AccountID', 'EMail', 'ZipCode', 'BankSerial', 'Telephone', 'TradeTime', 'VerifyCertNoFlag', 'LastFragment', 'CurrencyID', 'BrokerID', 'MobilePhone', 'CustType', 'InstallID', 'TradingDay', 'Fax', 'BankPwdFlag', 'BankBranchID', 'Password', 'BankAccType', 'DeviceID', 'IdentifiedCardNo', 'IdCardType', 'TradeDate', 'Address', 'SessionID', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('PlateSerial', u'银期平台消息流水号'),('Digest', u'摘要'),('CashExchangeCode', u'汇钞标志'),('TID', u'交易ID'),('BankAccount', u'银行帐号'),('ErrorMsg', u'错误信息'),('TradeCode', u'业务功能码'),('Gender', u'性别'),('BankID', u'银行代码'),('BankSecuAcc', u'期货单位帐号'),('BankSecuAccType', u'期货单位帐号类型'),('BrokerIDByBank', u'期货公司银行编码'),('BankPassWord', u'银行密码'),('MoneyAccountStatus', u'资金账户状态'),('ErrorID', u'错误代码'),('CustomerName', u'客户姓名'),('OperNo', u'交易柜员'),('BrokerBranchID', u'期商分支机构代码'),('SecuPwdFlag', u'期货资金密码核对标志'),('CountryCode', u'国家代码'),('AccountID', u'投资者帐号'),('EMail', u'电子邮件'),('ZipCode', u'邮编'),('BankSerial', u'银行流水号'),('Telephone', u'电话号码'),('TradeTime', u'交易时间'),('VerifyCertNoFlag', u'验证客户证件号码标志'),('LastFragment', u'最后分片标志'),('CurrencyID', u'币种代码'),('BrokerID', u'期商代码'),('MobilePhone', u'手机'),('CustType', u'客户类型'),('InstallID', u'安装编号'),('TradingDay', u'交易系统日期'),('Fax', u'传真'),('BankPwdFlag', u'银行密码标志'),('BankBranchID', u'银行分支机构代码'),('Password', u'期货密码'),('BankAccType', u'银行帐号类型'),('DeviceID', u'渠道标志'),('IdentifiedCardNo', u'证件号码'),('IdCardType', u'证件类型'),('TradeDate', u'交易日期'),('Address', u'地址'),('SessionID', u'会话号'),('UserID', u'用户标识')]])
    def getval(self, n):
        if n in ['CashExchangeCode', 'Gender', 'BankSecuAccType', 'MoneyAccountStatus', 'SecuPwdFlag', 'VerifyCertNoFlag', 'LastFragment', 'CustType', 'BankPwdFlag', 'BankAccType', 'IdCardType']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcUserLogoutField:
    def __init__(self, BrokerID="", UserID=""):
        self.BrokerID=BrokerID
        self.UserID=UserID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['BrokerID', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('BrokerID', u'经纪公司代码'),('UserID', u'用户代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcInvestorField:
    def __init__(self, Mobile="", IsActive=0, CommModelID="", OpenDate="", MarginModelID="", InvestorID="", Address="", IdentifiedCardNo="", IdentifiedCardType='0', InvestorGroupID="", BrokerID="", InvestorName="", Telephone=""):
        self.Mobile=Mobile
        self.IsActive=IsActive
        self.CommModelID=CommModelID
        self.OpenDate=OpenDate
        self.MarginModelID=MarginModelID
        self.InvestorID=InvestorID
        self.Address=Address
        self.IdentifiedCardNo=IdentifiedCardNo
        self.IdentifiedCardType=IdentifiedCardType
        self.InvestorGroupID=InvestorGroupID
        self.BrokerID=BrokerID
        self.InvestorName=InvestorName
        self.Telephone=Telephone
        self.vcmap={'IdentifiedCardType': {"'0'": '组织机构代码', "'6'": '护照', "'7'": '台胞证', "'2'": '军官证', "'8'": '回乡证', "'3'": '警官证', "'1'": '身份证', "'x'": '其他证件', "'9'": '营业执照号', "'5'": '户口簿', "'A'": '税务登记号', "'4'": '士兵证'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['Mobile', 'IsActive', 'CommModelID', 'OpenDate', 'MarginModelID', 'InvestorID', 'Address', 'IdentifiedCardNo', 'IdentifiedCardType', 'InvestorGroupID', 'BrokerID', 'InvestorName', 'Telephone']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('Mobile', u'手机'),('IsActive', u'是否活跃'),('CommModelID', u'手续费率模板代码'),('OpenDate', u'开户日期'),('MarginModelID', u'保证金率模板代码'),('InvestorID', u'投资者代码'),('Address', u'通讯地址'),('IdentifiedCardNo', u'证件号码'),('IdentifiedCardType', u'证件类型'),('InvestorGroupID', u'投资者分组代码'),('BrokerID', u'经纪公司代码'),('InvestorName', u'投资者名称'),('Telephone', u'联系电话')]])
    def getval(self, n):
        if n in ['IdentifiedCardType']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryContractBankField:
    def __init__(self, BankBrchID="", BrokerID="", BankID=""):
        self.BankBrchID=BankBrchID
        self.BrokerID=BrokerID
        self.BankID=BankID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['BankBrchID', 'BrokerID', 'BankID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('BankBrchID', u'银行分中心代码'),('BrokerID', u'经纪公司代码'),('BankID', u'银行代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcReturnResultField:
    def __init__(self, ReturnCode="", DescrInfoForReturnCode=""):
        self.ReturnCode=ReturnCode
        self.DescrInfoForReturnCode=DescrInfoForReturnCode
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ReturnCode', 'DescrInfoForReturnCode']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ReturnCode', u'返回代码'),('DescrInfoForReturnCode', u'返回码描述')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryInstrumentField:
    def __init__(self, ExchangeInstID="", ExchangeID="", InstrumentID="", ProductID=""):
        self.ExchangeInstID=ExchangeInstID
        self.ExchangeID=ExchangeID
        self.InstrumentID=InstrumentID
        self.ProductID=ProductID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ExchangeInstID', 'ExchangeID', 'InstrumentID', 'ProductID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ExchangeInstID', u'合约在交易所的代码'),('ExchangeID', u'交易所代码'),('InstrumentID', u'合约代码'),('ProductID', u'产品代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcSettlementInfoConfirmField:
    def __init__(self, ConfirmTime="", ConfirmDate="", InvestorID="", BrokerID=""):
        self.ConfirmTime=ConfirmTime
        self.ConfirmDate=ConfirmDate
        self.InvestorID=InvestorID
        self.BrokerID=BrokerID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ConfirmTime', 'ConfirmDate', 'InvestorID', 'BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ConfirmTime', u'确认时间'),('ConfirmDate', u'确认日期'),('InvestorID', u'投资者代码'),('BrokerID', u'经纪公司代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcExchangeTradeField:
    def __init__(self, Volume=0, PriceSource='0', TradingRole='1', Price=0, SequenceNo=0, TraderID="", OrderLocalID="", TradeSource='0', OrderSysID="", OffsetFlag='0', ParticipantID="", ExchangeInstID="", ClearingPartID="", TradeID="", TradeType='0', TradeDate="", ClientID="", HedgeFlag='1', ExchangeID="", BusinessUnit="", TradeTime="", Direction='0'):
        self.Volume=Volume
        self.PriceSource=PriceSource
        self.TradingRole=TradingRole
        self.Price=Price
        self.SequenceNo=SequenceNo
        self.TraderID=TraderID
        self.OrderLocalID=OrderLocalID
        self.TradeSource=TradeSource
        self.OrderSysID=OrderSysID
        self.OffsetFlag=OffsetFlag
        self.ParticipantID=ParticipantID
        self.ExchangeInstID=ExchangeInstID
        self.ClearingPartID=ClearingPartID
        self.TradeID=TradeID
        self.TradeType=TradeType
        self.TradeDate=TradeDate
        self.ClientID=ClientID
        self.HedgeFlag=HedgeFlag
        self.ExchangeID=ExchangeID
        self.BusinessUnit=BusinessUnit
        self.TradeTime=TradeTime
        self.Direction=Direction
        self.vcmap={'PriceSource': {"'2'": '卖委托价', "'0'": '前成交价', "'1'": '买委托价'}, 'TradingRole': {"'2'": '自营', "'3'": '做市商', "'1'": '代理'}, 'HedgeFlag': {"'2'": '套利', "'3'": '套保', "'1'": '投机'}, 'Direction': {"'0'": '买', "'1'": '卖'}, 'OffsetFlag': {"'0'": '开仓', "'6'": '本地强平', "'2'": '强平', "'5'": '强减', "'3'": '平今', "'1'": '平仓', "'4'": '平昨'}, 'TradeType': {"'2'": 'OTC成交', "'0'": '普通成交', "'3'": '期转现衍生成交', "'1'": '期权执行', "'4'": '组合衍生成交'}, 'TradeSource': {"'0'": '来自交易所普通回报', "'1'": '来自查询'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['Volume', 'PriceSource', 'TradingRole', 'Price', 'SequenceNo', 'TraderID', 'OrderLocalID', 'TradeSource', 'OrderSysID', 'OffsetFlag', 'ParticipantID', 'ExchangeInstID', 'ClearingPartID', 'TradeID', 'TradeType', 'TradeDate', 'ClientID', 'HedgeFlag', 'ExchangeID', 'BusinessUnit', 'TradeTime', 'Direction']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('Volume', u'数量'),('PriceSource', u'成交价来源'),('TradingRole', u'交易角色'),('Price', u'价格'),('SequenceNo', u'序号'),('TraderID', u'交易所交易员代码'),('OrderLocalID', u'本地报单编号'),('TradeSource', u'成交来源'),('OrderSysID', u'报单编号'),('OffsetFlag', u'开平标志'),('ParticipantID', u'会员代码'),('ExchangeInstID', u'合约在交易所的代码'),('ClearingPartID', u'结算会员编号'),('TradeID', u'成交编号'),('TradeType', u'成交类型'),('TradeDate', u'成交时期'),('ClientID', u'客户代码'),('HedgeFlag', u'投机套保标志'),('ExchangeID', u'交易所代码'),('BusinessUnit', u'业务单元'),('TradeTime', u'成交时间'),('Direction', u'买卖方向')]])
    def getval(self, n):
        if n in ['PriceSource', 'TradingRole', 'TradeSource', 'OffsetFlag', 'TradeType', 'HedgeFlag', 'Direction']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcSyncingInvestorField:
    def __init__(self, Mobile="", IsActive=0, CommModelID="", OpenDate="", MarginModelID="", InvestorID="", Address="", IdentifiedCardNo="", IdentifiedCardType='0', InvestorGroupID="", BrokerID="", InvestorName="", Telephone=""):
        self.Mobile=Mobile
        self.IsActive=IsActive
        self.CommModelID=CommModelID
        self.OpenDate=OpenDate
        self.MarginModelID=MarginModelID
        self.InvestorID=InvestorID
        self.Address=Address
        self.IdentifiedCardNo=IdentifiedCardNo
        self.IdentifiedCardType=IdentifiedCardType
        self.InvestorGroupID=InvestorGroupID
        self.BrokerID=BrokerID
        self.InvestorName=InvestorName
        self.Telephone=Telephone
        self.vcmap={'IdentifiedCardType': {"'0'": '组织机构代码', "'6'": '护照', "'7'": '台胞证', "'2'": '军官证', "'8'": '回乡证', "'3'": '警官证', "'1'": '身份证', "'x'": '其他证件', "'9'": '营业执照号', "'5'": '户口簿', "'A'": '税务登记号', "'4'": '士兵证'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['Mobile', 'IsActive', 'CommModelID', 'OpenDate', 'MarginModelID', 'InvestorID', 'Address', 'IdentifiedCardNo', 'IdentifiedCardType', 'InvestorGroupID', 'BrokerID', 'InvestorName', 'Telephone']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('Mobile', u'手机'),('IsActive', u'是否活跃'),('CommModelID', u'手续费率模板代码'),('OpenDate', u'开户日期'),('MarginModelID', u'保证金率模板代码'),('InvestorID', u'投资者代码'),('Address', u'通讯地址'),('IdentifiedCardNo', u'证件号码'),('IdentifiedCardType', u'证件类型'),('InvestorGroupID', u'投资者分组代码'),('BrokerID', u'经纪公司代码'),('InvestorName', u'投资者名称'),('Telephone', u'联系电话')]])
    def getval(self, n):
        if n in ['IdentifiedCardType']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcFrontStatusField:
    def __init__(self, LastReportTime="", IsActive=0, FrontID=0, LastReportDate=""):
        self.LastReportTime=LastReportTime
        self.IsActive=IsActive
        self.FrontID=FrontID
        self.LastReportDate=LastReportDate
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['LastReportTime', 'IsActive', 'FrontID', 'LastReportDate']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('LastReportTime', u'上次报告时间'),('IsActive', u'是否活跃'),('FrontID', u'前置编号'),('LastReportDate', u'上次报告日期')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcRspFutureSignInField:
    def __init__(self, TradeTime="", BrokerBranchID="", TID=0, ErrorMsg="", CurrencyID="", LastFragment='0', RequestID=0, BrokerID="", BankID="", BrokerIDByBank="", PinKey="", ErrorID=0, OperNo="", Digest="", BankBranchID="", TradeCode="", DeviceID="", PlateSerial=0, TradingDay="", InstallID=0, TradeDate="", MacKey="", BankSerial="", SessionID=0, UserID=""):
        self.TradeTime=TradeTime
        self.BrokerBranchID=BrokerBranchID
        self.TID=TID
        self.ErrorMsg=ErrorMsg
        self.CurrencyID=CurrencyID
        self.LastFragment=LastFragment
        self.RequestID=RequestID
        self.BrokerID=BrokerID
        self.BankID=BankID
        self.BrokerIDByBank=BrokerIDByBank
        self.PinKey=PinKey
        self.ErrorID=ErrorID
        self.OperNo=OperNo
        self.Digest=Digest
        self.BankBranchID=BankBranchID
        self.TradeCode=TradeCode
        self.DeviceID=DeviceID
        self.PlateSerial=PlateSerial
        self.TradingDay=TradingDay
        self.InstallID=InstallID
        self.TradeDate=TradeDate
        self.MacKey=MacKey
        self.BankSerial=BankSerial
        self.SessionID=SessionID
        self.UserID=UserID
        self.vcmap={'LastFragment': {"'0'": '是最后分片', "'1'": '不是最后分片'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['TradeTime', 'BrokerBranchID', 'TID', 'ErrorMsg', 'CurrencyID', 'LastFragment', 'RequestID', 'BrokerID', 'BankID', 'BrokerIDByBank', 'PinKey', 'ErrorID', 'OperNo', 'Digest', 'BankBranchID', 'TradeCode', 'DeviceID', 'PlateSerial', 'TradingDay', 'InstallID', 'TradeDate', 'MacKey', 'BankSerial', 'SessionID', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('TradeTime', u'交易时间'),('BrokerBranchID', u'期商分支机构代码'),('TID', u'交易ID'),('ErrorMsg', u'错误信息'),('CurrencyID', u'币种代码'),('LastFragment', u'最后分片标志'),('RequestID', u'请求编号'),('BrokerID', u'期商代码'),('BankID', u'银行代码'),('BrokerIDByBank', u'期货公司银行编码'),('PinKey', u'PIN密钥'),('ErrorID', u'错误代码'),('OperNo', u'交易柜员'),('Digest', u'摘要'),('BankBranchID', u'银行分支机构代码'),('TradeCode', u'业务功能码'),('DeviceID', u'渠道标志'),('PlateSerial', u'银期平台消息流水号'),('TradingDay', u'交易系统日期'),('InstallID', u'安装编号'),('TradeDate', u'交易日期'),('MacKey', u'MAC密钥'),('BankSerial', u'银行流水号'),('SessionID', u'会话号'),('UserID', u'用户标识')]])
    def getval(self, n):
        if n in ['LastFragment']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcReqQueryTradeResultBySerialField:
    def __init__(self, TradeTime="", AccountID="", TradeDate="", BankAccount="", TradeAmount=0, LastFragment='0', CurrencyID="", Digest="", BrokerID="", BankID="", RefrenceIssure="", Password="", CustType='0', CustomerName="", BrokerBranchID="", BankBranchID="", TradeCode="", RefrenceIssureType='0', BankPassWord="", IdentifiedCardNo="", IdCardType='0', TradingDay="", PlateSerial=0, Reference=0, BankSerial="", SessionID=0):
        self.TradeTime=TradeTime
        self.AccountID=AccountID
        self.TradeDate=TradeDate
        self.BankAccount=BankAccount
        self.TradeAmount=TradeAmount
        self.LastFragment=LastFragment
        self.CurrencyID=CurrencyID
        self.Digest=Digest
        self.BrokerID=BrokerID
        self.BankID=BankID
        self.RefrenceIssure=RefrenceIssure
        self.Password=Password
        self.CustType=CustType
        self.CustomerName=CustomerName
        self.BrokerBranchID=BrokerBranchID
        self.BankBranchID=BankBranchID
        self.TradeCode=TradeCode
        self.RefrenceIssureType=RefrenceIssureType
        self.BankPassWord=BankPassWord
        self.IdentifiedCardNo=IdentifiedCardNo
        self.IdCardType=IdCardType
        self.TradingDay=TradingDay
        self.PlateSerial=PlateSerial
        self.Reference=Reference
        self.BankSerial=BankSerial
        self.SessionID=SessionID
        self.vcmap={'IdCardType': {"'0'": '组织机构代码', "'6'": '护照', "'7'": '台胞证', "'2'": '军官证', "'8'": '回乡证', "'3'": '警官证', "'1'": '身份证', "'x'": '其他证件', "'9'": '营业执照号', "'5'": '户口簿', "'A'": '税务登记号', "'4'": '士兵证'}, 'CustType': {"'0'": '自然人', "'1'": '机构户'}, 'LastFragment': {"'0'": '是最后分片', "'1'": '不是最后分片'}, 'RefrenceIssureType': {"'2'": '券商', "'0'": '银行', "'1'": '期商'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['TradeTime', 'AccountID', 'TradeDate', 'BankAccount', 'TradeAmount', 'LastFragment', 'CurrencyID', 'Digest', 'BrokerID', 'BankID', 'RefrenceIssure', 'Password', 'CustType', 'CustomerName', 'BrokerBranchID', 'BankBranchID', 'TradeCode', 'RefrenceIssureType', 'BankPassWord', 'IdentifiedCardNo', 'IdCardType', 'TradingDay', 'PlateSerial', 'Reference', 'BankSerial', 'SessionID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('TradeTime', u'交易时间'),('AccountID', u'投资者帐号'),('TradeDate', u'交易日期'),('BankAccount', u'银行帐号'),('TradeAmount', u'转帐金额'),('LastFragment', u'最后分片标志'),('CurrencyID', u'币种代码'),('Digest', u'摘要'),('BrokerID', u'期商代码'),('BankID', u'银行代码'),('RefrenceIssure', u'本流水号发布者机构编码'),('Password', u'期货密码'),('CustType', u'客户类型'),('CustomerName', u'客户姓名'),('BrokerBranchID', u'期商分支机构代码'),('BankBranchID', u'银行分支机构代码'),('TradeCode', u'业务功能码'),('RefrenceIssureType', u'本流水号发布者的机构类型'),('BankPassWord', u'银行密码'),('IdentifiedCardNo', u'证件号码'),('IdCardType', u'证件类型'),('TradingDay', u'交易系统日期'),('PlateSerial', u'银期平台消息流水号'),('Reference', u'流水号'),('BankSerial', u'银行流水号'),('SessionID', u'会话号')]])
    def getval(self, n):
        if n in ['LastFragment', 'CustType', 'RefrenceIssureType', 'IdCardType']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcBrokerSyncField:
    def __init__(self, BrokerID=""):
        self.BrokerID=BrokerID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('BrokerID', u'经纪公司代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcCFMMCBrokerKeyField:
    def __init__(self, ParticipantID="", KeyKind='R', KeyID=0, CreateTime="", BrokerID="", CreateDate="", CurrentKey=""):
        self.ParticipantID=ParticipantID
        self.KeyKind=KeyKind
        self.KeyID=KeyID
        self.CreateTime=CreateTime
        self.BrokerID=BrokerID
        self.CreateDate=CreateDate
        self.CurrentKey=CurrentKey
        self.vcmap={'KeyKind': {"'R'": '主动请求更新', "'M'": 'CFMMC手动更新', "'A'": 'CFMMC自动更新'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ParticipantID', 'KeyKind', 'KeyID', 'CreateTime', 'BrokerID', 'CreateDate', 'CurrentKey']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ParticipantID', u'经纪公司统一编码'),('KeyKind', u'动态密钥类型'),('KeyID', u'密钥编号'),('CreateTime', u'密钥生成时间'),('BrokerID', u'经纪公司代码'),('CreateDate', u'密钥生成日期'),('CurrentKey', u'动态密钥')]])
    def getval(self, n):
        if n in ['KeyKind']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcLogoutAllField:
    def __init__(self, SystemName="", SessionID=0, FrontID=0):
        self.SystemName=SystemName
        self.SessionID=SessionID
        self.FrontID=FrontID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['SystemName', 'SessionID', 'FrontID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('SystemName', u'系统名称'),('SessionID', u'会话编号'),('FrontID', u'前置编号')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcExchangeMarginRateField:
    def __init__(self, BrokerID="", LongMarginRatioByMoney=0, ShortMarginRatioByMoney=0, HedgeFlag='1', LongMarginRatioByVolume=0, InstrumentID="", ShortMarginRatioByVolume=0):
        self.BrokerID=BrokerID
        self.LongMarginRatioByMoney=LongMarginRatioByMoney
        self.ShortMarginRatioByMoney=ShortMarginRatioByMoney
        self.HedgeFlag=HedgeFlag
        self.LongMarginRatioByVolume=LongMarginRatioByVolume
        self.InstrumentID=InstrumentID
        self.ShortMarginRatioByVolume=ShortMarginRatioByVolume
        self.vcmap={'HedgeFlag': {"'2'": '套利', "'3'": '套保', "'1'": '投机'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['BrokerID', 'LongMarginRatioByMoney', 'ShortMarginRatioByMoney', 'HedgeFlag', 'LongMarginRatioByVolume', 'InstrumentID', 'ShortMarginRatioByVolume']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('BrokerID', u'经纪公司代码'),('LongMarginRatioByMoney', u'多头保证金率'),('ShortMarginRatioByMoney', u'空头保证金率'),('HedgeFlag', u'投机套保标志'),('LongMarginRatioByVolume', u'多头保证金费'),('InstrumentID', u'合约代码'),('ShortMarginRatioByVolume', u'空头保证金费')]])
    def getval(self, n):
        if n in ['HedgeFlag']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryPartBrokerField:
    def __init__(self, ParticipantID="", ExchangeID="", BrokerID=""):
        self.ParticipantID=ParticipantID
        self.ExchangeID=ExchangeID
        self.BrokerID=BrokerID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ParticipantID', 'ExchangeID', 'BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ParticipantID', u'会员代码'),('ExchangeID', u'交易所代码'),('BrokerID', u'经纪公司代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcTransferBankField:
    def __init__(self, BankBrchID="", IsActive=0, BankName="", BankID=""):
        self.BankBrchID=BankBrchID
        self.IsActive=IsActive
        self.BankName=BankName
        self.BankID=BankID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['BankBrchID', 'IsActive', 'BankName', 'BankID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('BankBrchID', u'银行分中心代码'),('IsActive', u'是否活跃'),('BankName', u'银行名称'),('BankID', u'银行代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcSyncDepositField:
    def __init__(self, Deposit=0, IsForce=0, InvestorID="", BrokerID="", DepositSeqNo=""):
        self.Deposit=Deposit
        self.IsForce=IsForce
        self.InvestorID=InvestorID
        self.BrokerID=BrokerID
        self.DepositSeqNo=DepositSeqNo
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['Deposit', 'IsForce', 'InvestorID', 'BrokerID', 'DepositSeqNo']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('Deposit', u'入金金额'),('IsForce', u'是否强制进行'),('InvestorID', u'投资者代码'),('BrokerID', u'经纪公司代码'),('DepositSeqNo', u'出入金流水号')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcRspQueryAccountField:
    def __init__(self, TradeTime="", Digest="", BankUseAmount=0, TradeDate="", BankAccount="", VerifyCertNoFlag='0', LastFragment='0', TradeCode="", SecuPwdFlag='0', BankPwdFlag='0', RequestID=0, BrokerID="", BankID="", BankSecuAcc="", FutureSerial=0, BankSecuAccType='1', CustType='0', InstallID=0, TID=0, DeviceID="", CurrencyID="", CustomerName="", OperNo="", BrokerBranchID="", BankBranchID="", IdCardType='0', Password="", BankAccType='1', BankPassWord="", IdentifiedCardNo="", AccountID="", TradingDay="", BrokerIDByBank="", PlateSerial=0, BankSerial="", SessionID=0, BankFetchAmount=0, UserID=""):
        self.TradeTime=TradeTime
        self.Digest=Digest
        self.BankUseAmount=BankUseAmount
        self.TradeDate=TradeDate
        self.BankAccount=BankAccount
        self.VerifyCertNoFlag=VerifyCertNoFlag
        self.LastFragment=LastFragment
        self.TradeCode=TradeCode
        self.SecuPwdFlag=SecuPwdFlag
        self.BankPwdFlag=BankPwdFlag
        self.RequestID=RequestID
        self.BrokerID=BrokerID
        self.BankID=BankID
        self.BankSecuAcc=BankSecuAcc
        self.FutureSerial=FutureSerial
        self.BankSecuAccType=BankSecuAccType
        self.CustType=CustType
        self.InstallID=InstallID
        self.TID=TID
        self.DeviceID=DeviceID
        self.CurrencyID=CurrencyID
        self.CustomerName=CustomerName
        self.OperNo=OperNo
        self.BrokerBranchID=BrokerBranchID
        self.BankBranchID=BankBranchID
        self.IdCardType=IdCardType
        self.Password=Password
        self.BankAccType=BankAccType
        self.BankPassWord=BankPassWord
        self.IdentifiedCardNo=IdentifiedCardNo
        self.AccountID=AccountID
        self.TradingDay=TradingDay
        self.BrokerIDByBank=BrokerIDByBank
        self.PlateSerial=PlateSerial
        self.BankSerial=BankSerial
        self.SessionID=SessionID
        self.BankFetchAmount=BankFetchAmount
        self.UserID=UserID
        self.vcmap={'IdCardType': {"'0'": '组织机构代码', "'6'": '护照', "'7'": '台胞证', "'2'": '军官证', "'8'": '回乡证', "'3'": '警官证', "'1'": '身份证', "'x'": '其他证件', "'9'": '营业执照号', "'5'": '户口簿', "'A'": '税务登记号', "'4'": '士兵证'}, 'VerifyCertNoFlag': {"'0'": '是', "'1'": '否'}, 'CustType': {"'0'": '自然人', "'1'": '机构户'}, 'BankSecuAccType': {"'2'": '储蓄卡', "'3'": '信用卡', "'1'": '银行存折'}, 'BankPwdFlag': {"'2'": '密文核对', "'0'": '不核对', "'1'": '明文核对'}, 'LastFragment': {"'0'": '是最后分片', "'1'": '不是最后分片'}, 'BankAccType': {"'2'": '储蓄卡', "'3'": '信用卡', "'1'": '银行存折'}, 'SecuPwdFlag': {"'2'": '密文核对', "'0'": '不核对', "'1'": '明文核对'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['TradeTime', 'Digest', 'BankUseAmount', 'TradeDate', 'BankAccount', 'VerifyCertNoFlag', 'LastFragment', 'TradeCode', 'SecuPwdFlag', 'BankPwdFlag', 'RequestID', 'BrokerID', 'BankID', 'BankSecuAcc', 'FutureSerial', 'BankSecuAccType', 'CustType', 'InstallID', 'TID', 'DeviceID', 'CurrencyID', 'CustomerName', 'OperNo', 'BrokerBranchID', 'BankBranchID', 'IdCardType', 'Password', 'BankAccType', 'BankPassWord', 'IdentifiedCardNo', 'AccountID', 'TradingDay', 'BrokerIDByBank', 'PlateSerial', 'BankSerial', 'SessionID', 'BankFetchAmount', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('TradeTime', u'交易时间'),('Digest', u'摘要'),('BankUseAmount', u'银行可用金额'),('TradeDate', u'交易日期'),('BankAccount', u'银行帐号'),('VerifyCertNoFlag', u'验证客户证件号码标志'),('LastFragment', u'最后分片标志'),('TradeCode', u'业务功能码'),('SecuPwdFlag', u'期货资金密码核对标志'),('BankPwdFlag', u'银行密码标志'),('RequestID', u'请求编号'),('BrokerID', u'期商代码'),('BankID', u'银行代码'),('BankSecuAcc', u'期货单位帐号'),('FutureSerial', u'期货公司流水号'),('BankSecuAccType', u'期货单位帐号类型'),('CustType', u'客户类型'),('InstallID', u'安装编号'),('TID', u'交易ID'),('DeviceID', u'渠道标志'),('CurrencyID', u'币种代码'),('CustomerName', u'客户姓名'),('OperNo', u'交易柜员'),('BrokerBranchID', u'期商分支机构代码'),('BankBranchID', u'银行分支机构代码'),('IdCardType', u'证件类型'),('Password', u'期货密码'),('BankAccType', u'银行帐号类型'),('BankPassWord', u'银行密码'),('IdentifiedCardNo', u'证件号码'),('AccountID', u'投资者帐号'),('TradingDay', u'交易系统日期'),('BrokerIDByBank', u'期货公司银行编码'),('PlateSerial', u'银期平台消息流水号'),('BankSerial', u'银行流水号'),('SessionID', u'会话号'),('BankFetchAmount', u'银行可取金额'),('UserID', u'用户标识')]])
    def getval(self, n):
        if n in ['VerifyCertNoFlag', 'LastFragment', 'SecuPwdFlag', 'BankPwdFlag', 'BankSecuAccType', 'CustType', 'IdCardType', 'BankAccType']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcInvestorWithdrawAlgorithmField:
    def __init__(self, InvestorRange='1', InvestorID="", BrokerID="", UsingRatio=0):
        self.InvestorRange=InvestorRange
        self.InvestorID=InvestorID
        self.BrokerID=BrokerID
        self.UsingRatio=UsingRatio
        self.vcmap={'InvestorRange': {"'2'": '投资者组', "'3'": '单一投资者', "'1'": '所有'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['InvestorRange', 'InvestorID', 'BrokerID', 'UsingRatio']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('InvestorRange', u'投资者范围'),('InvestorID', u'投资者代码'),('BrokerID', u'经纪公司代码'),('UsingRatio', u'可提资金比例')]])
    def getval(self, n):
        if n in ['InvestorRange']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcUserPasswordUpdateField:
    def __init__(self, OldPassword="", NewPassword="", BrokerID="", UserID=""):
        self.OldPassword=OldPassword
        self.NewPassword=NewPassword
        self.BrokerID=BrokerID
        self.UserID=UserID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['OldPassword', 'NewPassword', 'BrokerID', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('OldPassword', u'原来的口令'),('NewPassword', u'新的口令'),('BrokerID', u'经纪公司代码'),('UserID', u'用户代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryExchangeMarginRateAdjustField:
    def __init__(self, HedgeFlag='1', BrokerID="", InstrumentID=""):
        self.HedgeFlag=HedgeFlag
        self.BrokerID=BrokerID
        self.InstrumentID=InstrumentID
        self.vcmap={'HedgeFlag': {"'2'": '套利', "'3'": '套保', "'1'": '投机'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['HedgeFlag', 'BrokerID', 'InstrumentID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('HedgeFlag', u'投机套保标志'),('BrokerID', u'经纪公司代码'),('InstrumentID', u'合约代码')]])
    def getval(self, n):
        if n in ['HedgeFlag']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcMarketDataBaseField:
    def __init__(self, PreClosePrice=0, PreDelta=0, TradingDay="", PreSettlementPrice=0, PreOpenInterest=0):
        self.PreClosePrice=PreClosePrice
        self.PreDelta=PreDelta
        self.TradingDay=TradingDay
        self.PreSettlementPrice=PreSettlementPrice
        self.PreOpenInterest=PreOpenInterest
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['PreClosePrice', 'PreDelta', 'TradingDay', 'PreSettlementPrice', 'PreOpenInterest']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('PreClosePrice', u'昨收盘'),('PreDelta', u'昨虚实度'),('TradingDay', u'交易日'),('PreSettlementPrice', u'上次结算价'),('PreOpenInterest', u'昨持仓量')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcCommRateModelField:
    def __init__(self, CommModelName="", BrokerID="", CommModelID=""):
        self.CommModelName=CommModelName
        self.BrokerID=BrokerID
        self.CommModelID=CommModelID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['CommModelName', 'BrokerID', 'CommModelID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('CommModelName', u'模板名称'),('BrokerID', u'经纪公司代码'),('CommModelID', u'手续费率模板代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryInvestorPositionDetailField:
    def __init__(self, InvestorID="", BrokerID="", InstrumentID=""):
        self.InvestorID=InvestorID
        self.BrokerID=BrokerID
        self.InstrumentID=InstrumentID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['InvestorID', 'BrokerID', 'InstrumentID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('InvestorID', u'投资者代码'),('BrokerID', u'经纪公司代码'),('InstrumentID', u'合约代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcMarketDataBid45Field:
    def __init__(self, BidVolume4=0, BidVolume5=0, BidPrice4=0, BidPrice5=0):
        self.BidVolume4=BidVolume4
        self.BidVolume5=BidVolume5
        self.BidPrice4=BidPrice4
        self.BidPrice5=BidPrice5
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['BidVolume4', 'BidVolume5', 'BidPrice4', 'BidPrice5']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('BidVolume4', u'申买量四'),('BidVolume5', u'申买量五'),('BidPrice4', u'申买价四'),('BidPrice5', u'申买价五')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcExchangeField:
    def __init__(self, ExchangeID="", ExchangeProperty='0', ExchangeName=""):
        self.ExchangeID=ExchangeID
        self.ExchangeProperty=ExchangeProperty
        self.ExchangeName=ExchangeName
        self.vcmap={'ExchangeProperty': {"'0'": '正常', "'1'": '根据成交生成报单'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ExchangeID', 'ExchangeProperty', 'ExchangeName']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ExchangeID', u'交易所代码'),('ExchangeProperty', u'交易所属性'),('ExchangeName', u'交易所名称')]])
    def getval(self, n):
        if n in ['ExchangeProperty']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcInstrumentCommissionRateField:
    def __init__(self, CloseRatioByMoney=0, InvestorRange='1', OpenRatioByVolume=0, BrokerID="", OpenRatioByMoney=0, CloseTodayRatioByVolume=0, CloseRatioByVolume=0, InvestorID="", InstrumentID="", CloseTodayRatioByMoney=0):
        self.CloseRatioByMoney=CloseRatioByMoney
        self.InvestorRange=InvestorRange
        self.OpenRatioByVolume=OpenRatioByVolume
        self.BrokerID=BrokerID
        self.OpenRatioByMoney=OpenRatioByMoney
        self.CloseTodayRatioByVolume=CloseTodayRatioByVolume
        self.CloseRatioByVolume=CloseRatioByVolume
        self.InvestorID=InvestorID
        self.InstrumentID=InstrumentID
        self.CloseTodayRatioByMoney=CloseTodayRatioByMoney
        self.vcmap={'InvestorRange': {"'2'": '投资者组', "'3'": '单一投资者', "'1'": '所有'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['CloseRatioByMoney', 'InvestorRange', 'OpenRatioByVolume', 'BrokerID', 'OpenRatioByMoney', 'CloseTodayRatioByVolume', 'CloseRatioByVolume', 'InvestorID', 'InstrumentID', 'CloseTodayRatioByMoney']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('CloseRatioByMoney', u'平仓手续费率'),('InvestorRange', u'投资者范围'),('OpenRatioByVolume', u'开仓手续费'),('BrokerID', u'经纪公司代码'),('OpenRatioByMoney', u'开仓手续费率'),('CloseTodayRatioByVolume', u'平今手续费'),('CloseRatioByVolume', u'平仓手续费'),('InvestorID', u'投资者代码'),('InstrumentID', u'合约代码'),('CloseTodayRatioByMoney', u'平今手续费率')]])
    def getval(self, n):
        if n in ['InvestorRange']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcMulticastGroupInfoField:
    def __init__(self, GroupIP="", GroupPort=0, SourceIP=""):
        self.GroupIP=GroupIP
        self.GroupPort=GroupPort
        self.SourceIP=SourceIP
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['GroupIP', 'GroupPort', 'SourceIP']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('GroupIP', u'组播组IP地址'),('GroupPort', u'组播组IP端口'),('SourceIP', u'源地址')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcBrokerUserField:
    def __init__(self, UserName="", IsActive=0, BrokerID="", IsUsingOTP=0, UserType='0', UserID=""):
        self.UserName=UserName
        self.IsActive=IsActive
        self.BrokerID=BrokerID
        self.IsUsingOTP=IsUsingOTP
        self.UserType=UserType
        self.UserID=UserID
        self.vcmap={'UserType': {"'2'": '管理员', "'0'": '投资者', "'1'": '操作员'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['UserName', 'IsActive', 'BrokerID', 'IsUsingOTP', 'UserType', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('UserName', u'用户名称'),('IsActive', u'是否活跃'),('BrokerID', u'经纪公司代码'),('IsUsingOTP', u'是否使用令牌'),('UserType', u'用户类型'),('UserID', u'用户代码')]])
    def getval(self, n):
        if n in ['UserType']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcSettlementInfoField:
    def __init__(self, SequenceNo=0, TradingDay="", BrokerID="", Content="", InvestorID="", SettlementID=0):
        self.SequenceNo=SequenceNo
        self.TradingDay=TradingDay
        self.BrokerID=BrokerID
        self.Content=Content
        self.InvestorID=InvestorID
        self.SettlementID=SettlementID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['SequenceNo', 'TradingDay', 'BrokerID', 'Content', 'InvestorID', 'SettlementID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('SequenceNo', u'序号'),('TradingDay', u'交易日'),('BrokerID', u'经纪公司代码'),('Content', u'消息正文'),('InvestorID', u'投资者代码'),('SettlementID', u'结算编号')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryOrderActionField:
    def __init__(self, ExchangeID="", InvestorID="", BrokerID=""):
        self.ExchangeID=ExchangeID
        self.InvestorID=InvestorID
        self.BrokerID=BrokerID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ExchangeID', 'InvestorID', 'BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ExchangeID', u'交易所代码'),('InvestorID', u'投资者代码'),('BrokerID', u'经纪公司代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcInvestorProductGroupMarginField:
    def __init__(self, ProductGroupID="", LongExchOffsetAmount=0, InvestorID="", FrozenMargin=0, ShortExchOffsetAmount=0, FrozenCash=0, ShortOffsetAmount=0, BrokerID="", CashIn=0, Commission=0, ShortFrozenMargin=0, LongFrozenMargin=0, FrozenCommission=0, LongOffsetAmount=0, UseMargin=0, ShortExchMargin=0, LongExchMargin=0, OffsetAmount=0, SettlementID=0, PositionProfit=0, TradingDay="", LongUseMargin=0, ShortUseMargin=0, ExchMargin=0, ExchOffsetAmount=0, CloseProfit=0):
        self.ProductGroupID=ProductGroupID
        self.LongExchOffsetAmount=LongExchOffsetAmount
        self.InvestorID=InvestorID
        self.FrozenMargin=FrozenMargin
        self.ShortExchOffsetAmount=ShortExchOffsetAmount
        self.FrozenCash=FrozenCash
        self.ShortOffsetAmount=ShortOffsetAmount
        self.BrokerID=BrokerID
        self.CashIn=CashIn
        self.Commission=Commission
        self.ShortFrozenMargin=ShortFrozenMargin
        self.LongFrozenMargin=LongFrozenMargin
        self.FrozenCommission=FrozenCommission
        self.LongOffsetAmount=LongOffsetAmount
        self.UseMargin=UseMargin
        self.ShortExchMargin=ShortExchMargin
        self.LongExchMargin=LongExchMargin
        self.OffsetAmount=OffsetAmount
        self.SettlementID=SettlementID
        self.PositionProfit=PositionProfit
        self.TradingDay=TradingDay
        self.LongUseMargin=LongUseMargin
        self.ShortUseMargin=ShortUseMargin
        self.ExchMargin=ExchMargin
        self.ExchOffsetAmount=ExchOffsetAmount
        self.CloseProfit=CloseProfit
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ProductGroupID', 'LongExchOffsetAmount', 'InvestorID', 'FrozenMargin', 'ShortExchOffsetAmount', 'FrozenCash', 'ShortOffsetAmount', 'BrokerID', 'CashIn', 'Commission', 'ShortFrozenMargin', 'LongFrozenMargin', 'FrozenCommission', 'LongOffsetAmount', 'UseMargin', 'ShortExchMargin', 'LongExchMargin', 'OffsetAmount', 'SettlementID', 'PositionProfit', 'TradingDay', 'LongUseMargin', 'ShortUseMargin', 'ExchMargin', 'ExchOffsetAmount', 'CloseProfit']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ProductGroupID', u'品种/跨品种标示'),('LongExchOffsetAmount', u'交易所多头折抵总金额'),('InvestorID', u'投资者代码'),('FrozenMargin', u'冻结的保证金'),('ShortExchOffsetAmount', u'交易所空头折抵总金额'),('FrozenCash', u'冻结的资金'),('ShortOffsetAmount', u'空头折抵总金额'),('BrokerID', u'经纪公司代码'),('CashIn', u'资金差额'),('Commission', u'手续费'),('ShortFrozenMargin', u'空头冻结的保证金'),('LongFrozenMargin', u'多头冻结的保证金'),('FrozenCommission', u'冻结的手续费'),('LongOffsetAmount', u'多头折抵总金额'),('UseMargin', u'占用的保证金'),('ShortExchMargin', u'交易所空头保证金'),('LongExchMargin', u'交易所多头保证金'),('OffsetAmount', u'折抵总金额'),('SettlementID', u'结算编号'),('PositionProfit', u'持仓盈亏'),('TradingDay', u'交易日'),('LongUseMargin', u'多头保证金'),('ShortUseMargin', u'空头保证金'),('ExchMargin', u'交易所保证金'),('ExchOffsetAmount', u'交易所折抵总金额'),('CloseProfit', u'平仓盈亏')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcRspSyncKeyField:
    def __init__(self, TradeTime="", TID=0, ErrorMsg="", LastFragment='0', Message="", RequestID=0, BrokerID="", BankID="", BrokerIDByBank="", ErrorID=0, OperNo="", BrokerBranchID="", BankBranchID="", TradeCode="", DeviceID="", PlateSerial=0, TradingDay="", InstallID=0, TradeDate="", BankSerial="", SessionID=0, UserID=""):
        self.TradeTime=TradeTime
        self.TID=TID
        self.ErrorMsg=ErrorMsg
        self.LastFragment=LastFragment
        self.Message=Message
        self.RequestID=RequestID
        self.BrokerID=BrokerID
        self.BankID=BankID
        self.BrokerIDByBank=BrokerIDByBank
        self.ErrorID=ErrorID
        self.OperNo=OperNo
        self.BrokerBranchID=BrokerBranchID
        self.BankBranchID=BankBranchID
        self.TradeCode=TradeCode
        self.DeviceID=DeviceID
        self.PlateSerial=PlateSerial
        self.TradingDay=TradingDay
        self.InstallID=InstallID
        self.TradeDate=TradeDate
        self.BankSerial=BankSerial
        self.SessionID=SessionID
        self.UserID=UserID
        self.vcmap={'LastFragment': {"'0'": '是最后分片', "'1'": '不是最后分片'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['TradeTime', 'TID', 'ErrorMsg', 'LastFragment', 'Message', 'RequestID', 'BrokerID', 'BankID', 'BrokerIDByBank', 'ErrorID', 'OperNo', 'BrokerBranchID', 'BankBranchID', 'TradeCode', 'DeviceID', 'PlateSerial', 'TradingDay', 'InstallID', 'TradeDate', 'BankSerial', 'SessionID', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('TradeTime', u'交易时间'),('TID', u'交易ID'),('ErrorMsg', u'错误信息'),('LastFragment', u'最后分片标志'),('Message', u'交易核心给银期报盘的消息'),('RequestID', u'请求编号'),('BrokerID', u'期商代码'),('BankID', u'银行代码'),('BrokerIDByBank', u'期货公司银行编码'),('ErrorID', u'错误代码'),('OperNo', u'交易柜员'),('BrokerBranchID', u'期商分支机构代码'),('BankBranchID', u'银行分支机构代码'),('TradeCode', u'业务功能码'),('DeviceID', u'渠道标志'),('PlateSerial', u'银期平台消息流水号'),('TradingDay', u'交易系统日期'),('InstallID', u'安装编号'),('TradeDate', u'交易日期'),('BankSerial', u'银行流水号'),('SessionID', u'会话号'),('UserID', u'用户标识')]])
    def getval(self, n):
        if n in ['LastFragment']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcProductField:
    def __init__(self, MinLimitOrderVolume=0, MaxMarketOrderVolume=0, MinMarketOrderVolume=0, PositionDateType='1', ProductID="", PositionType='1', MaxLimitOrderVolume=0, PriceTick=0, ProductClass='1', CloseDealType='0', ExchangeID="", ProductName="", VolumeMultiple=0):
        self.MinLimitOrderVolume=MinLimitOrderVolume
        self.MaxMarketOrderVolume=MaxMarketOrderVolume
        self.MinMarketOrderVolume=MinMarketOrderVolume
        self.PositionDateType=PositionDateType
        self.ProductID=ProductID
        self.PositionType=PositionType
        self.MaxLimitOrderVolume=MaxLimitOrderVolume
        self.PriceTick=PriceTick
        self.ProductClass=ProductClass
        self.CloseDealType=CloseDealType
        self.ExchangeID=ExchangeID
        self.ProductName=ProductName
        self.VolumeMultiple=VolumeMultiple
        self.vcmap={'PositionDateType': {"'2'": '不使用历史持仓', "'1'": '使用历史持仓'}, 'PositionType': {"'2'": '综合持仓', "'1'": '净持仓'}, 'CloseDealType': {"'0'": '正常', "'1'": '投机平仓优先'}, 'ProductClass': {"'2'": '期权', "'5'": '期转现', "'3'": '组合', "'1'": '期货', "'4'": '即期'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['MinLimitOrderVolume', 'MaxMarketOrderVolume', 'MinMarketOrderVolume', 'PositionDateType', 'ProductID', 'PositionType', 'MaxLimitOrderVolume', 'PriceTick', 'ProductClass', 'CloseDealType', 'ExchangeID', 'ProductName', 'VolumeMultiple']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('MinLimitOrderVolume', u'限价单最小下单量'),('MaxMarketOrderVolume', u'市价单最大下单量'),('MinMarketOrderVolume', u'市价单最小下单量'),('PositionDateType', u'持仓日期类型'),('ProductID', u'产品代码'),('PositionType', u'持仓类型'),('MaxLimitOrderVolume', u'限价单最大下单量'),('PriceTick', u'最小变动价位'),('ProductClass', u'产品类型'),('CloseDealType', u'平仓处理类型'),('ExchangeID', u'交易所代码'),('ProductName', u'产品名称'),('VolumeMultiple', u'合约数量乘数')]])
    def getval(self, n):
        if n in ['PositionDateType', 'PositionType', 'ProductClass', 'CloseDealType']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcBrokerUserRightAssignField:
    def __init__(self, Tradeable=0, DRIdentityID=0, BrokerID=""):
        self.Tradeable=Tradeable
        self.DRIdentityID=DRIdentityID
        self.BrokerID=BrokerID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['Tradeable', 'DRIdentityID', 'BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('Tradeable', u'能否交易'),('DRIdentityID', u'交易中心代码'),('BrokerID', u'应用单元代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcMarketDataExchangeField:
    def __init__(self, ExchangeID=""):
        self.ExchangeID=ExchangeID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ExchangeID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ExchangeID', u'交易所代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcInstrumentStatusField:
    def __init__(self, TradingSegmentSN=0, EnterReason='1', ExchangeInstID="", InstrumentStatus='0', EnterTime="", SettlementGroupID="", ExchangeID="", InstrumentID=""):
        self.TradingSegmentSN=TradingSegmentSN
        self.EnterReason=EnterReason
        self.ExchangeInstID=ExchangeInstID
        self.InstrumentStatus=InstrumentStatus
        self.EnterTime=EnterTime
        self.SettlementGroupID=SettlementGroupID
        self.ExchangeID=ExchangeID
        self.InstrumentID=InstrumentID
        self.vcmap={'EnterReason': {"'2'": '手动切换', "'3'": '熔断', "'1'": '自动切换'}, 'InstrumentStatus': {"'0'": '开盘前', "'6'": '收盘', "'2'": '连续交易', "'5'": '集合竞价撮合', "'3'": '集合竞价报单', "'1'": '非交易', "'4'": '集合竞价价格平衡'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['TradingSegmentSN', 'EnterReason', 'ExchangeInstID', 'InstrumentStatus', 'EnterTime', 'SettlementGroupID', 'ExchangeID', 'InstrumentID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('TradingSegmentSN', u'交易阶段编号'),('EnterReason', u'进入本状态原因'),('ExchangeInstID', u'合约在交易所的代码'),('InstrumentStatus', u'合约交易状态'),('EnterTime', u'进入本状态时间'),('SettlementGroupID', u'结算组代码'),('ExchangeID', u'交易所代码'),('InstrumentID', u'合约代码')]])
    def getval(self, n):
        if n in ['EnterReason', 'InstrumentStatus']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcMarketDataBestPriceField:
    def __init__(self, BidPrice1=0, AskVolume1=0, AskPrice1=0, BidVolume1=0):
        self.BidPrice1=BidPrice1
        self.AskVolume1=AskVolume1
        self.AskPrice1=AskPrice1
        self.BidVolume1=BidVolume1
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['BidPrice1', 'AskVolume1', 'AskPrice1', 'BidVolume1']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('BidPrice1', u'申买价一'),('AskVolume1', u'申卖量一'),('AskPrice1', u'申卖价一'),('BidVolume1', u'申买量一')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcNotifyFutureSignOutField:
    def __init__(self, TradeTime="", BrokerBranchID="", TID=0, ErrorMsg="", CurrencyID="", LastFragment='0', RequestID=0, BrokerID="", BankID="", BrokerIDByBank="", ErrorID=0, OperNo="", Digest="", BankBranchID="", TradeCode="", DeviceID="", PlateSerial=0, TradingDay="", InstallID=0, TradeDate="", BankSerial="", SessionID=0, UserID=""):
        self.TradeTime=TradeTime
        self.BrokerBranchID=BrokerBranchID
        self.TID=TID
        self.ErrorMsg=ErrorMsg
        self.CurrencyID=CurrencyID
        self.LastFragment=LastFragment
        self.RequestID=RequestID
        self.BrokerID=BrokerID
        self.BankID=BankID
        self.BrokerIDByBank=BrokerIDByBank
        self.ErrorID=ErrorID
        self.OperNo=OperNo
        self.Digest=Digest
        self.BankBranchID=BankBranchID
        self.TradeCode=TradeCode
        self.DeviceID=DeviceID
        self.PlateSerial=PlateSerial
        self.TradingDay=TradingDay
        self.InstallID=InstallID
        self.TradeDate=TradeDate
        self.BankSerial=BankSerial
        self.SessionID=SessionID
        self.UserID=UserID
        self.vcmap={'LastFragment': {"'0'": '是最后分片', "'1'": '不是最后分片'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['TradeTime', 'BrokerBranchID', 'TID', 'ErrorMsg', 'CurrencyID', 'LastFragment', 'RequestID', 'BrokerID', 'BankID', 'BrokerIDByBank', 'ErrorID', 'OperNo', 'Digest', 'BankBranchID', 'TradeCode', 'DeviceID', 'PlateSerial', 'TradingDay', 'InstallID', 'TradeDate', 'BankSerial', 'SessionID', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('TradeTime', u'交易时间'),('BrokerBranchID', u'期商分支机构代码'),('TID', u'交易ID'),('ErrorMsg', u'错误信息'),('CurrencyID', u'币种代码'),('LastFragment', u'最后分片标志'),('RequestID', u'请求编号'),('BrokerID', u'期商代码'),('BankID', u'银行代码'),('BrokerIDByBank', u'期货公司银行编码'),('ErrorID', u'错误代码'),('OperNo', u'交易柜员'),('Digest', u'摘要'),('BankBranchID', u'银行分支机构代码'),('TradeCode', u'业务功能码'),('DeviceID', u'渠道标志'),('PlateSerial', u'银期平台消息流水号'),('TradingDay', u'交易系统日期'),('InstallID', u'安装编号'),('TradeDate', u'交易日期'),('BankSerial', u'银行流水号'),('SessionID', u'会话号'),('UserID', u'用户标识')]])
    def getval(self, n):
        if n in ['LastFragment']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcErrOrderActionField:
    def __init__(self, OrderActionRef=0, VolumeChange=0, OrderActionStatus='a', OrderSysID="", InvestorID="", OrderRef="", InstrumentID="", TraderID="", OrderLocalID="", RequestID=0, BrokerID="", ActionFlag='0', ActionTime="", LimitPrice=0, InstallID=0, ParticipantID="", ExchangeID="", ErrorID=0, ErrorMsg="", ActionDate="", UserID="", StatusMsg="", ClientID="", FrontID=0, SessionID=0, ActionLocalID="", BusinessUnit=""):
        self.OrderActionRef=OrderActionRef
        self.VolumeChange=VolumeChange
        self.OrderActionStatus=OrderActionStatus
        self.OrderSysID=OrderSysID
        self.InvestorID=InvestorID
        self.OrderRef=OrderRef
        self.InstrumentID=InstrumentID
        self.TraderID=TraderID
        self.OrderLocalID=OrderLocalID
        self.RequestID=RequestID
        self.BrokerID=BrokerID
        self.ActionFlag=ActionFlag
        self.ActionTime=ActionTime
        self.LimitPrice=LimitPrice
        self.InstallID=InstallID
        self.ParticipantID=ParticipantID
        self.ExchangeID=ExchangeID
        self.ErrorID=ErrorID
        self.ErrorMsg=ErrorMsg
        self.ActionDate=ActionDate
        self.UserID=UserID
        self.StatusMsg=StatusMsg
        self.ClientID=ClientID
        self.FrontID=FrontID
        self.SessionID=SessionID
        self.ActionLocalID=ActionLocalID
        self.BusinessUnit=BusinessUnit
        self.vcmap={'OrderActionStatus': {"'b'": '已经接受', "'c'": '已经被拒绝', "'a'": '已经提交'}, 'ActionFlag': {"'0'": '删除', "'3'": '修改'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['OrderActionRef', 'VolumeChange', 'OrderActionStatus', 'OrderSysID', 'InvestorID', 'OrderRef', 'InstrumentID', 'TraderID', 'OrderLocalID', 'RequestID', 'BrokerID', 'ActionFlag', 'ActionTime', 'LimitPrice', 'InstallID', 'ParticipantID', 'ExchangeID', 'ErrorID', 'ErrorMsg', 'ActionDate', 'UserID', 'StatusMsg', 'ClientID', 'FrontID', 'SessionID', 'ActionLocalID', 'BusinessUnit']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('OrderActionRef', u'报单操作引用'),('VolumeChange', u'数量变化'),('OrderActionStatus', u'报单操作状态'),('OrderSysID', u'报单编号'),('InvestorID', u'投资者代码'),('OrderRef', u'报单引用'),('InstrumentID', u'合约代码'),('TraderID', u'交易所交易员代码'),('OrderLocalID', u'本地报单编号'),('RequestID', u'请求编号'),('BrokerID', u'经纪公司代码'),('ActionFlag', u'操作标志'),('ActionTime', u'操作时间'),('LimitPrice', u'价格'),('InstallID', u'安装编号'),('ParticipantID', u'会员代码'),('ExchangeID', u'交易所代码'),('ErrorID', u'错误代码'),('ErrorMsg', u'错误信息'),('ActionDate', u'操作日期'),('UserID', u'用户代码'),('StatusMsg', u'状态信息'),('ClientID', u'客户代码'),('FrontID', u'前置编号'),('SessionID', u'会话编号'),('ActionLocalID', u'操作本地编号'),('BusinessUnit', u'业务单元')]])
    def getval(self, n):
        if n in ['OrderActionStatus', 'ActionFlag']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcParkedOrderField:
    def __init__(self, ContingentCondition='1', OrderRef="", IsAutoSuspend=0, ForceCloseReason='0', CombOffsetFlag="", InvestorID="", VolumeTotalOriginal=0, IsSwapOrder=0, UserID="", RequestID=0, BrokerID="", LimitPrice=0, OrderPriceType='1', CombHedgeFlag="", StopPrice=0, GTDDate="", ErrorID=0, MinVolume=0, ErrorMsg="", InstrumentID="", ParkedOrderID="", VolumeCondition='1', Status='1', BusinessUnit="", UserForceClose=0, ExchangeID="", UserType='0', TimeCondition='1', Direction='0'):
        self.ContingentCondition=ContingentCondition
        self.OrderRef=OrderRef
        self.IsAutoSuspend=IsAutoSuspend
        self.ForceCloseReason=ForceCloseReason
        self.CombOffsetFlag=CombOffsetFlag
        self.InvestorID=InvestorID
        self.VolumeTotalOriginal=VolumeTotalOriginal
        self.IsSwapOrder=IsSwapOrder
        self.UserID=UserID
        self.RequestID=RequestID
        self.BrokerID=BrokerID
        self.LimitPrice=LimitPrice
        self.OrderPriceType=OrderPriceType
        self.CombHedgeFlag=CombHedgeFlag
        self.StopPrice=StopPrice
        self.GTDDate=GTDDate
        self.ErrorID=ErrorID
        self.MinVolume=MinVolume
        self.ErrorMsg=ErrorMsg
        self.InstrumentID=InstrumentID
        self.ParkedOrderID=ParkedOrderID
        self.VolumeCondition=VolumeCondition
        self.Status=Status
        self.BusinessUnit=BusinessUnit
        self.UserForceClose=UserForceClose
        self.ExchangeID=ExchangeID
        self.UserType=UserType
        self.TimeCondition=TimeCondition
        self.Direction=Direction
        self.vcmap={'ContingentCondition': {"'6'": '最新价大于等于条件价', "'7'": '最新价小于条件价', "'2'": '止损', "'E'": '买一价大于等于条件价', "'8'": '最新价小于等于条件价', "'3'": '止赢', "'1'": '立即', "'D'": '买一价大于条件价', "'F'": '买一价小于条件价', "'9'": '卖一价大于条件价', "'B'": '卖一价小于条件价', "'5'": '最新价大于条件价', "'H'": '买一价小于等于条件价', "'C'": '卖一价小于等于条件价', "'A'": '卖一价大于等于条件价', "'4'": '预埋单'}, 'Status': {"'2'": '已发送', "'3'": '已删除', "'1'": '未发送'}, 'UserType': {"'2'": '管理员', "'0'": '投资者', "'1'": '操作员'}, 'ForceCloseReason': {"'0'": '非强平', "'6'": '其它', "'7'": '自然人临近交割', "'2'": '客户超仓', "'5'": '违规', "'3'": '会员超仓', "'1'": '资金不足', "'4'": '持仓非整数倍'}, 'Direction': {"'0'": '买', "'1'": '卖'}, 'OrderPriceType': {"'6'": '最新价浮动上浮2个ticks', "'7'": '最新价浮动上浮3个ticks', "'2'": '限价', "'E'": '买一价浮动上浮2个ticks', "'8'": '卖一价', "'3'": '最优价', "'1'": '任意价', "'D'": '买一价浮动上浮1个ticks', "'F'": '买一价浮动上浮3个ticks', "'9'": '卖一价浮动上浮1个ticks', "'B'": '卖一价浮动上浮3个ticks', "'5'": '最新价浮动上浮1个ticks', "'C'": '买一价', "'A'": '卖一价浮动上浮2个ticks', "'4'": '最新价'}, 'TimeCondition': {"'6'": '集合竞价有效', "'2'": '本节有效', "'5'": '撤销前有效', "'3'": '当日有效', "'1'": '立即完成，否则撤销', "'4'": '指定日期前有效'}, 'VolumeCondition': {"'2'": '最小数量', "'3'": '全部数量', "'1'": '任何数量'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ContingentCondition', 'OrderRef', 'IsAutoSuspend', 'ForceCloseReason', 'CombOffsetFlag', 'InvestorID', 'VolumeTotalOriginal', 'IsSwapOrder', 'UserID', 'RequestID', 'BrokerID', 'LimitPrice', 'OrderPriceType', 'CombHedgeFlag', 'StopPrice', 'GTDDate', 'ErrorID', 'MinVolume', 'ErrorMsg', 'InstrumentID', 'ParkedOrderID', 'VolumeCondition', 'Status', 'BusinessUnit', 'UserForceClose', 'ExchangeID', 'UserType', 'TimeCondition', 'Direction']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ContingentCondition', u'触发条件'),('OrderRef', u'报单引用'),('IsAutoSuspend', u'自动挂起标志'),('ForceCloseReason', u'强平原因'),('CombOffsetFlag', u'组合开平标志'),('InvestorID', u'投资者代码'),('VolumeTotalOriginal', u'数量'),('IsSwapOrder', u'互换单标志'),('UserID', u'用户代码'),('RequestID', u'请求编号'),('BrokerID', u'经纪公司代码'),('LimitPrice', u'价格'),('OrderPriceType', u'报单价格条件'),('CombHedgeFlag', u'组合投机套保标志'),('StopPrice', u'止损价'),('GTDDate', u'GTD日期'),('ErrorID', u'错误代码'),('MinVolume', u'最小成交量'),('ErrorMsg', u'错误信息'),('InstrumentID', u'合约代码'),('ParkedOrderID', u'预埋报单编号'),('VolumeCondition', u'成交量类型'),('Status', u'预埋单状态'),('BusinessUnit', u'业务单元'),('UserForceClose', u'用户强评标志'),('ExchangeID', u'交易所代码'),('UserType', u'用户类型'),('TimeCondition', u'有效期类型'),('Direction', u'买卖方向')]])
    def getval(self, n):
        if n in ['ContingentCondition', 'ForceCloseReason', 'OrderPriceType', 'VolumeCondition', 'Status', 'UserType', 'TimeCondition', 'Direction']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcTraderOfferField:
    def __init__(self, ParticipantID="", LastReportTime="", StartTime="", ConnectDate="", ConnectTime="", ConnectRequestDate="", ConnectRequestTime="", TraderConnectStatus='1', MaxTradeID="", LastReportDate="", Password="", StartDate="", TraderID="", OrderLocalID="", TradingDay="", BrokerID="", MaxOrderMessageReference="", ExchangeID="", InstallID=0):
        self.ParticipantID=ParticipantID
        self.LastReportTime=LastReportTime
        self.StartTime=StartTime
        self.ConnectDate=ConnectDate
        self.ConnectTime=ConnectTime
        self.ConnectRequestDate=ConnectRequestDate
        self.ConnectRequestTime=ConnectRequestTime
        self.TraderConnectStatus=TraderConnectStatus
        self.MaxTradeID=MaxTradeID
        self.LastReportDate=LastReportDate
        self.Password=Password
        self.StartDate=StartDate
        self.TraderID=TraderID
        self.OrderLocalID=OrderLocalID
        self.TradingDay=TradingDay
        self.BrokerID=BrokerID
        self.MaxOrderMessageReference=MaxOrderMessageReference
        self.ExchangeID=ExchangeID
        self.InstallID=InstallID
        self.vcmap={'TraderConnectStatus': {"'2'": '已经连接', "'3'": '已经发出合约查询请求', "'1'": '没有任何连接', "'4'": '订阅私有流'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ParticipantID', 'LastReportTime', 'StartTime', 'ConnectDate', 'ConnectTime', 'ConnectRequestDate', 'ConnectRequestTime', 'TraderConnectStatus', 'MaxTradeID', 'LastReportDate', 'Password', 'StartDate', 'TraderID', 'OrderLocalID', 'TradingDay', 'BrokerID', 'MaxOrderMessageReference', 'ExchangeID', 'InstallID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ParticipantID', u'会员代码'),('LastReportTime', u'上次报告时间'),('StartTime', u'启动时间'),('ConnectDate', u'完成连接日期'),('ConnectTime', u'完成连接时间'),('ConnectRequestDate', u'发出连接请求的日期'),('ConnectRequestTime', u'发出连接请求的时间'),('TraderConnectStatus', u'交易所交易员连接状态'),('MaxTradeID', u'本席位最大成交编号'),('LastReportDate', u'上次报告日期'),('Password', u'密码'),('StartDate', u'启动日期'),('TraderID', u'交易所交易员代码'),('OrderLocalID', u'本地报单编号'),('TradingDay', u'交易日'),('BrokerID', u'经纪公司代码'),('MaxOrderMessageReference', u'本席位最大报单备拷'),('ExchangeID', u'交易所代码'),('InstallID', u'安装编号')]])
    def getval(self, n):
        if n in ['TraderConnectStatus']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcVerifyCustInfoField:
    def __init__(self, IdentifiedCardNo="", IdCardType='0', CustType='0', CustomerName=""):
        self.IdentifiedCardNo=IdentifiedCardNo
        self.IdCardType=IdCardType
        self.CustType=CustType
        self.CustomerName=CustomerName
        self.vcmap={'IdCardType': {"'0'": '组织机构代码', "'6'": '护照', "'7'": '台胞证', "'2'": '军官证', "'8'": '回乡证', "'3'": '警官证', "'1'": '身份证', "'x'": '其他证件', "'9'": '营业执照号', "'5'": '户口簿', "'A'": '税务登记号', "'4'": '士兵证'}, 'CustType': {"'0'": '自然人', "'1'": '机构户'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['IdentifiedCardNo', 'IdCardType', 'CustType', 'CustomerName']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('IdentifiedCardNo', u'证件号码'),('IdCardType', u'证件类型'),('CustType', u'客户类型'),('CustomerName', u'客户姓名')]])
    def getval(self, n):
        if n in ['IdCardType', 'CustType']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryExchangeSequenceField:
    def __init__(self, ExchangeID=""):
        self.ExchangeID=ExchangeID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ExchangeID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ExchangeID', u'交易所代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryLinkManField:
    def __init__(self, InvestorID="", BrokerID=""):
        self.InvestorID=InvestorID
        self.BrokerID=BrokerID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['InvestorID', 'BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('InvestorID', u'投资者代码'),('BrokerID', u'经纪公司代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryBrokerUserFunctionField:
    def __init__(self, BrokerID="", UserID=""):
        self.BrokerID=BrokerID
        self.UserID=UserID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['BrokerID', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('BrokerID', u'经纪公司代码'),('UserID', u'用户代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcExchangeOrderField:
    def __init__(self, ContingentCondition='1', ParticipantID="", IsAutoSuspend=0, NotifySequence=0, ForceCloseReason='0', CombOffsetFlag="", CancelTime="", SuspendTime="", VolumeTotalOriginal=0, SequenceNo=0, TraderID="", OrderLocalID="", RequestID=0, SettlementID=0, MinVolume=0, OrderSysID="", LimitPrice=0, OrderPriceType='1', InstallID=0, UpdateTime="", CombHedgeFlag="", VolumeTraded=0, ExchangeInstID="", GTDDate="", ActiveTime="", InsertTime="", TimeCondition='1', OrderType='0', ActiveTraderID="", VolumeCondition='1', InsertDate="", ClearingPartID="", VolumeTotal=0, StopPrice=0, TradingDay="", OrderSource='0', ClientID="", OrderStatus='0', ExchangeID="", BusinessUnit="", OrderSubmitStatus='0', Direction='0'):
        self.ContingentCondition=ContingentCondition
        self.ParticipantID=ParticipantID
        self.IsAutoSuspend=IsAutoSuspend
        self.NotifySequence=NotifySequence
        self.ForceCloseReason=ForceCloseReason
        self.CombOffsetFlag=CombOffsetFlag
        self.CancelTime=CancelTime
        self.SuspendTime=SuspendTime
        self.VolumeTotalOriginal=VolumeTotalOriginal
        self.SequenceNo=SequenceNo
        self.TraderID=TraderID
        self.OrderLocalID=OrderLocalID
        self.RequestID=RequestID
        self.SettlementID=SettlementID
        self.MinVolume=MinVolume
        self.OrderSysID=OrderSysID
        self.LimitPrice=LimitPrice
        self.OrderPriceType=OrderPriceType
        self.InstallID=InstallID
        self.UpdateTime=UpdateTime
        self.CombHedgeFlag=CombHedgeFlag
        self.VolumeTraded=VolumeTraded
        self.ExchangeInstID=ExchangeInstID
        self.GTDDate=GTDDate
        self.ActiveTime=ActiveTime
        self.InsertTime=InsertTime
        self.TimeCondition=TimeCondition
        self.OrderType=OrderType
        self.ActiveTraderID=ActiveTraderID
        self.VolumeCondition=VolumeCondition
        self.InsertDate=InsertDate
        self.ClearingPartID=ClearingPartID
        self.VolumeTotal=VolumeTotal
        self.StopPrice=StopPrice
        self.TradingDay=TradingDay
        self.OrderSource=OrderSource
        self.ClientID=ClientID
        self.OrderStatus=OrderStatus
        self.ExchangeID=ExchangeID
        self.BusinessUnit=BusinessUnit
        self.OrderSubmitStatus=OrderSubmitStatus
        self.Direction=Direction
        self.vcmap={'ContingentCondition': {"'6'": '最新价大于等于条件价', "'7'": '最新价小于条件价', "'2'": '止损', "'E'": '买一价大于等于条件价', "'8'": '最新价小于等于条件价', "'3'": '止赢', "'1'": '立即', "'D'": '买一价大于条件价', "'F'": '买一价小于条件价', "'9'": '卖一价大于条件价', "'B'": '卖一价小于条件价', "'5'": '最新价大于条件价', "'H'": '买一价小于等于条件价', "'C'": '卖一价小于等于条件价', "'A'": '卖一价大于等于条件价', "'4'": '预埋单'}, 'OrderStatus': {"'b'": '尚未触发', "'0'": '全部成交', "'3'": '未成交还在队列中', "'2'": '部分成交不在队列中', "'5'": '撤单', "'c'": '已触发', "'a'": '未知', "'4'": '未成交不在队列中', "'1'": '部分成交还在队列中'}, 'OrderSource': {"'0'": '来自参与者', "'1'": '来自管理员'}, 'OrderPriceType': {"'6'": '最新价浮动上浮2个ticks', "'7'": '最新价浮动上浮3个ticks', "'2'": '限价', "'E'": '买一价浮动上浮2个ticks', "'8'": '卖一价', "'3'": '最优价', "'1'": '任意价', "'D'": '买一价浮动上浮1个ticks', "'F'": '买一价浮动上浮3个ticks', "'9'": '卖一价浮动上浮1个ticks', "'B'": '卖一价浮动上浮3个ticks', "'5'": '最新价浮动上浮1个ticks', "'C'": '买一价', "'A'": '卖一价浮动上浮2个ticks', "'4'": '最新价'}, 'ForceCloseReason': {"'0'": '非强平', "'6'": '其它', "'7'": '自然人临近交割', "'2'": '客户超仓', "'5'": '违规', "'3'": '会员超仓', "'1'": '资金不足', "'4'": '持仓非整数倍'}, 'Direction': {"'0'": '买', "'1'": '卖'}, 'OrderType': {"'0'": '正常', "'2'": '组合衍生', "'5'": '互换单', "'3'": '组合报单', "'1'": '报价衍生', "'4'": '条件单'}, 'TimeCondition': {"'6'": '集合竞价有效', "'2'": '本节有效', "'5'": '撤销前有效', "'3'": '当日有效', "'1'": '立即完成，否则撤销', "'4'": '指定日期前有效'}, 'OrderSubmitStatus': {"'0'": '已经提交', "'6'": '改单已经被拒绝', "'2'": '修改已经提交', "'5'": '撤单已经被拒绝', "'3'": '已经接受', "'1'": '撤单已经提交', "'4'": '报单已经被拒绝'}, 'VolumeCondition': {"'2'": '最小数量', "'3'": '全部数量', "'1'": '任何数量'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ContingentCondition', 'ParticipantID', 'IsAutoSuspend', 'NotifySequence', 'ForceCloseReason', 'CombOffsetFlag', 'CancelTime', 'SuspendTime', 'VolumeTotalOriginal', 'SequenceNo', 'TraderID', 'OrderLocalID', 'RequestID', 'SettlementID', 'MinVolume', 'OrderSysID', 'LimitPrice', 'OrderPriceType', 'InstallID', 'UpdateTime', 'CombHedgeFlag', 'VolumeTraded', 'ExchangeInstID', 'GTDDate', 'ActiveTime', 'InsertTime', 'TimeCondition', 'OrderType', 'ActiveTraderID', 'VolumeCondition', 'InsertDate', 'ClearingPartID', 'VolumeTotal', 'StopPrice', 'TradingDay', 'OrderSource', 'ClientID', 'OrderStatus', 'ExchangeID', 'BusinessUnit', 'OrderSubmitStatus', 'Direction']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ContingentCondition', u'触发条件'),('ParticipantID', u'会员代码'),('IsAutoSuspend', u'自动挂起标志'),('NotifySequence', u'报单提示序号'),('ForceCloseReason', u'强平原因'),('CombOffsetFlag', u'组合开平标志'),('CancelTime', u'撤销时间'),('SuspendTime', u'挂起时间'),('VolumeTotalOriginal', u'数量'),('SequenceNo', u'序号'),('TraderID', u'交易所交易员代码'),('OrderLocalID', u'本地报单编号'),('RequestID', u'请求编号'),('SettlementID', u'结算编号'),('MinVolume', u'最小成交量'),('OrderSysID', u'报单编号'),('LimitPrice', u'价格'),('OrderPriceType', u'报单价格条件'),('InstallID', u'安装编号'),('UpdateTime', u'最后修改时间'),('CombHedgeFlag', u'组合投机套保标志'),('VolumeTraded', u'今成交数量'),('ExchangeInstID', u'合约在交易所的代码'),('GTDDate', u'GTD日期'),('ActiveTime', u'激活时间'),('InsertTime', u'委托时间'),('TimeCondition', u'有效期类型'),('OrderType', u'报单类型'),('ActiveTraderID', u'最后修改交易所交易员代码'),('VolumeCondition', u'成交量类型'),('InsertDate', u'报单日期'),('ClearingPartID', u'结算会员编号'),('VolumeTotal', u'剩余数量'),('StopPrice', u'止损价'),('TradingDay', u'交易日'),('OrderSource', u'报单来源'),('ClientID', u'客户代码'),('OrderStatus', u'报单状态'),('ExchangeID', u'交易所代码'),('BusinessUnit', u'业务单元'),('OrderSubmitStatus', u'报单提交状态'),('Direction', u'买卖方向')]])
    def getval(self, n):
        if n in ['ContingentCondition', 'ForceCloseReason', 'OrderPriceType', 'TimeCondition', 'OrderType', 'VolumeCondition', 'OrderSource', 'OrderStatus', 'OrderSubmitStatus', 'Direction']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcSyncStatusField:
    def __init__(self, DataSyncStatus='1', TradingDay=""):
        self.DataSyncStatus=DataSyncStatus
        self.TradingDay=TradingDay
        self.vcmap={'DataSyncStatus': {"'2'": '同步中', "'3'": '已同步', "'1'": '未同步'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['DataSyncStatus', 'TradingDay']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('DataSyncStatus', u'数据同步状态'),('TradingDay', u'交易日')]])
    def getval(self, n):
        if n in ['DataSyncStatus']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcReqSyncKeyField:
    def __init__(self, TradeTime="", Message="", BankID="", OperNo="", BrokerIDByBank="", BrokerBranchID="", BankBranchID="", TradeCode="", LastFragment='0', DeviceID="", PlateSerial=0, TradingDay="", BrokerID="", TradeDate="", BankSerial="", SessionID=0, RequestID=0, UserID="", InstallID=0, TID=0):
        self.TradeTime=TradeTime
        self.Message=Message
        self.BankID=BankID
        self.OperNo=OperNo
        self.BrokerIDByBank=BrokerIDByBank
        self.BrokerBranchID=BrokerBranchID
        self.BankBranchID=BankBranchID
        self.TradeCode=TradeCode
        self.LastFragment=LastFragment
        self.DeviceID=DeviceID
        self.PlateSerial=PlateSerial
        self.TradingDay=TradingDay
        self.BrokerID=BrokerID
        self.TradeDate=TradeDate
        self.BankSerial=BankSerial
        self.SessionID=SessionID
        self.RequestID=RequestID
        self.UserID=UserID
        self.InstallID=InstallID
        self.TID=TID
        self.vcmap={'LastFragment': {"'0'": '是最后分片', "'1'": '不是最后分片'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['TradeTime', 'Message', 'BankID', 'OperNo', 'BrokerIDByBank', 'BrokerBranchID', 'BankBranchID', 'TradeCode', 'LastFragment', 'DeviceID', 'PlateSerial', 'TradingDay', 'BrokerID', 'TradeDate', 'BankSerial', 'SessionID', 'RequestID', 'UserID', 'InstallID', 'TID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('TradeTime', u'交易时间'),('Message', u'交易核心给银期报盘的消息'),('BankID', u'银行代码'),('OperNo', u'交易柜员'),('BrokerIDByBank', u'期货公司银行编码'),('BrokerBranchID', u'期商分支机构代码'),('BankBranchID', u'银行分支机构代码'),('TradeCode', u'业务功能码'),('LastFragment', u'最后分片标志'),('DeviceID', u'渠道标志'),('PlateSerial', u'银期平台消息流水号'),('TradingDay', u'交易系统日期'),('BrokerID', u'期商代码'),('TradeDate', u'交易日期'),('BankSerial', u'银行流水号'),('SessionID', u'会话号'),('RequestID', u'请求编号'),('UserID', u'用户标识'),('InstallID', u'安装编号'),('TID', u'交易ID')]])
    def getval(self, n):
        if n in ['LastFragment']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcInvestorGroupField:
    def __init__(self, InvestorGroupName="", InvestorGroupID="", BrokerID=""):
        self.InvestorGroupName=InvestorGroupName
        self.InvestorGroupID=InvestorGroupID
        self.BrokerID=BrokerID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['InvestorGroupName', 'InvestorGroupID', 'BrokerID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('InvestorGroupName', u'投资者分组名称'),('InvestorGroupID', u'投资者分组代码'),('BrokerID', u'经纪公司代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcNotifyFutureSignInField:
    def __init__(self, TradeTime="", BrokerBranchID="", TID=0, ErrorMsg="", CurrencyID="", LastFragment='0', RequestID=0, BrokerID="", BankID="", BrokerIDByBank="", PinKey="", ErrorID=0, OperNo="", Digest="", BankBranchID="", TradeCode="", DeviceID="", PlateSerial=0, TradingDay="", InstallID=0, TradeDate="", MacKey="", BankSerial="", SessionID=0, UserID=""):
        self.TradeTime=TradeTime
        self.BrokerBranchID=BrokerBranchID
        self.TID=TID
        self.ErrorMsg=ErrorMsg
        self.CurrencyID=CurrencyID
        self.LastFragment=LastFragment
        self.RequestID=RequestID
        self.BrokerID=BrokerID
        self.BankID=BankID
        self.BrokerIDByBank=BrokerIDByBank
        self.PinKey=PinKey
        self.ErrorID=ErrorID
        self.OperNo=OperNo
        self.Digest=Digest
        self.BankBranchID=BankBranchID
        self.TradeCode=TradeCode
        self.DeviceID=DeviceID
        self.PlateSerial=PlateSerial
        self.TradingDay=TradingDay
        self.InstallID=InstallID
        self.TradeDate=TradeDate
        self.MacKey=MacKey
        self.BankSerial=BankSerial
        self.SessionID=SessionID
        self.UserID=UserID
        self.vcmap={'LastFragment': {"'0'": '是最后分片', "'1'": '不是最后分片'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['TradeTime', 'BrokerBranchID', 'TID', 'ErrorMsg', 'CurrencyID', 'LastFragment', 'RequestID', 'BrokerID', 'BankID', 'BrokerIDByBank', 'PinKey', 'ErrorID', 'OperNo', 'Digest', 'BankBranchID', 'TradeCode', 'DeviceID', 'PlateSerial', 'TradingDay', 'InstallID', 'TradeDate', 'MacKey', 'BankSerial', 'SessionID', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('TradeTime', u'交易时间'),('BrokerBranchID', u'期商分支机构代码'),('TID', u'交易ID'),('ErrorMsg', u'错误信息'),('CurrencyID', u'币种代码'),('LastFragment', u'最后分片标志'),('RequestID', u'请求编号'),('BrokerID', u'期商代码'),('BankID', u'银行代码'),('BrokerIDByBank', u'期货公司银行编码'),('PinKey', u'PIN密钥'),('ErrorID', u'错误代码'),('OperNo', u'交易柜员'),('Digest', u'摘要'),('BankBranchID', u'银行分支机构代码'),('TradeCode', u'业务功能码'),('DeviceID', u'渠道标志'),('PlateSerial', u'银期平台消息流水号'),('TradingDay', u'交易系统日期'),('InstallID', u'安装编号'),('TradeDate', u'交易日期'),('MacKey', u'MAC密钥'),('BankSerial', u'银行流水号'),('SessionID', u'会话号'),('UserID', u'用户标识')]])
    def getval(self, n):
        if n in ['LastFragment']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcErrOrderField:
    def __init__(self, ContingentCondition='1', OrderRef="", IsAutoSuspend=0, ForceCloseReason='0', CombOffsetFlag="", InvestorID="", VolumeTotalOriginal=0, IsSwapOrder=0, UserID="", RequestID=0, BrokerID="", LimitPrice=0, OrderPriceType='1', CombHedgeFlag="", StopPrice=0, GTDDate="", ErrorID=0, MinVolume=0, ErrorMsg="", InstrumentID="", VolumeCondition='1', BusinessUnit="", UserForceClose=0, TimeCondition='1', Direction='0'):
        self.ContingentCondition=ContingentCondition
        self.OrderRef=OrderRef
        self.IsAutoSuspend=IsAutoSuspend
        self.ForceCloseReason=ForceCloseReason
        self.CombOffsetFlag=CombOffsetFlag
        self.InvestorID=InvestorID
        self.VolumeTotalOriginal=VolumeTotalOriginal
        self.IsSwapOrder=IsSwapOrder
        self.UserID=UserID
        self.RequestID=RequestID
        self.BrokerID=BrokerID
        self.LimitPrice=LimitPrice
        self.OrderPriceType=OrderPriceType
        self.CombHedgeFlag=CombHedgeFlag
        self.StopPrice=StopPrice
        self.GTDDate=GTDDate
        self.ErrorID=ErrorID
        self.MinVolume=MinVolume
        self.ErrorMsg=ErrorMsg
        self.InstrumentID=InstrumentID
        self.VolumeCondition=VolumeCondition
        self.BusinessUnit=BusinessUnit
        self.UserForceClose=UserForceClose
        self.TimeCondition=TimeCondition
        self.Direction=Direction
        self.vcmap={'ContingentCondition': {"'6'": '最新价大于等于条件价', "'7'": '最新价小于条件价', "'2'": '止损', "'E'": '买一价大于等于条件价', "'8'": '最新价小于等于条件价', "'3'": '止赢', "'1'": '立即', "'D'": '买一价大于条件价', "'F'": '买一价小于条件价', "'9'": '卖一价大于条件价', "'B'": '卖一价小于条件价', "'5'": '最新价大于条件价', "'H'": '买一价小于等于条件价', "'C'": '卖一价小于等于条件价', "'A'": '卖一价大于等于条件价', "'4'": '预埋单'}, 'ForceCloseReason': {"'0'": '非强平', "'6'": '其它', "'7'": '自然人临近交割', "'2'": '客户超仓', "'5'": '违规', "'3'": '会员超仓', "'1'": '资金不足', "'4'": '持仓非整数倍'}, 'Direction': {"'0'": '买', "'1'": '卖'}, 'OrderPriceType': {"'6'": '最新价浮动上浮2个ticks', "'7'": '最新价浮动上浮3个ticks', "'2'": '限价', "'E'": '买一价浮动上浮2个ticks', "'8'": '卖一价', "'3'": '最优价', "'1'": '任意价', "'D'": '买一价浮动上浮1个ticks', "'F'": '买一价浮动上浮3个ticks', "'9'": '卖一价浮动上浮1个ticks', "'B'": '卖一价浮动上浮3个ticks', "'5'": '最新价浮动上浮1个ticks', "'C'": '买一价', "'A'": '卖一价浮动上浮2个ticks', "'4'": '最新价'}, 'TimeCondition': {"'6'": '集合竞价有效', "'2'": '本节有效', "'5'": '撤销前有效', "'3'": '当日有效', "'1'": '立即完成，否则撤销', "'4'": '指定日期前有效'}, 'VolumeCondition': {"'2'": '最小数量', "'3'": '全部数量', "'1'": '任何数量'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['ContingentCondition', 'OrderRef', 'IsAutoSuspend', 'ForceCloseReason', 'CombOffsetFlag', 'InvestorID', 'VolumeTotalOriginal', 'IsSwapOrder', 'UserID', 'RequestID', 'BrokerID', 'LimitPrice', 'OrderPriceType', 'CombHedgeFlag', 'StopPrice', 'GTDDate', 'ErrorID', 'MinVolume', 'ErrorMsg', 'InstrumentID', 'VolumeCondition', 'BusinessUnit', 'UserForceClose', 'TimeCondition', 'Direction']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('ContingentCondition', u'触发条件'),('OrderRef', u'报单引用'),('IsAutoSuspend', u'自动挂起标志'),('ForceCloseReason', u'强平原因'),('CombOffsetFlag', u'组合开平标志'),('InvestorID', u'投资者代码'),('VolumeTotalOriginal', u'数量'),('IsSwapOrder', u'互换单标志'),('UserID', u'用户代码'),('RequestID', u'请求编号'),('BrokerID', u'经纪公司代码'),('LimitPrice', u'价格'),('OrderPriceType', u'报单价格条件'),('CombHedgeFlag', u'组合投机套保标志'),('StopPrice', u'止损价'),('GTDDate', u'GTD日期'),('ErrorID', u'错误代码'),('MinVolume', u'最小成交量'),('ErrorMsg', u'错误信息'),('InstrumentID', u'合约代码'),('VolumeCondition', u'成交量类型'),('BusinessUnit', u'业务单元'),('UserForceClose', u'用户强评标志'),('TimeCondition', u'有效期类型'),('Direction', u'买卖方向')]])
    def getval(self, n):
        if n in ['ContingentCondition', 'ForceCloseReason', 'OrderPriceType', 'VolumeCondition', 'TimeCondition', 'Direction']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcAuthenticationInfoField:
    def __init__(self, AuthInfo="", UserProductInfo="", BrokerID="", IsResult=0, UserID=""):
        self.AuthInfo=AuthInfo
        self.UserProductInfo=UserProductInfo
        self.BrokerID=BrokerID
        self.IsResult=IsResult
        self.UserID=UserID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['AuthInfo', 'UserProductInfo', 'BrokerID', 'IsResult', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('AuthInfo', u'认证信息'),('UserProductInfo', u'用户端产品信息'),('BrokerID', u'经纪公司代码'),('IsResult', u'是否为认证结果'),('UserID', u'用户代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcUserRightsAssignField:
    def __init__(self, DRIdentityID=0, BrokerID="", UserID=""):
        self.DRIdentityID=DRIdentityID
        self.BrokerID=BrokerID
        self.UserID=UserID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['DRIdentityID', 'BrokerID', 'UserID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('DRIdentityID', u'交易中心代码'),('BrokerID', u'应用单元代码'),('UserID', u'用户代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryOrderField:
    def __init__(self, InsertTimeStart="", InsertTimeEnd="", BrokerID="", OrderSysID="", ExchangeID="", InvestorID="", InstrumentID=""):
        self.InsertTimeStart=InsertTimeStart
        self.InsertTimeEnd=InsertTimeEnd
        self.BrokerID=BrokerID
        self.OrderSysID=OrderSysID
        self.ExchangeID=ExchangeID
        self.InvestorID=InvestorID
        self.InstrumentID=InstrumentID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['InsertTimeStart', 'InsertTimeEnd', 'BrokerID', 'OrderSysID', 'ExchangeID', 'InvestorID', 'InstrumentID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('InsertTimeStart', u'开始时间'),('InsertTimeEnd', u'结束时间'),('BrokerID', u'经纪公司代码'),('OrderSysID', u'报单编号'),('ExchangeID', u'交易所代码'),('InvestorID', u'投资者代码'),('InstrumentID', u'合约代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcRspUserLoginField:
    def __init__(self, SHFETime="", SessionID=0, DCETime="", TradingDay="", BrokerID="", SystemName="", LoginTime="", CZCETime="", MaxOrderRef="", UserID="", FrontID=0, FFEXTime=""):
        self.SHFETime=SHFETime
        self.SessionID=SessionID
        self.DCETime=DCETime
        self.TradingDay=TradingDay
        self.BrokerID=BrokerID
        self.SystemName=SystemName
        self.LoginTime=LoginTime
        self.CZCETime=CZCETime
        self.MaxOrderRef=MaxOrderRef
        self.UserID=UserID
        self.FrontID=FrontID
        self.FFEXTime=FFEXTime
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['SHFETime', 'SessionID', 'DCETime', 'TradingDay', 'BrokerID', 'SystemName', 'LoginTime', 'CZCETime', 'MaxOrderRef', 'UserID', 'FrontID', 'FFEXTime']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('SHFETime', u'上期所时间'),('SessionID', u'会话编号'),('DCETime', u'大商所时间'),('TradingDay', u'交易日'),('BrokerID', u'经纪公司代码'),('SystemName', u'交易系统名称'),('LoginTime', u'登录成功时间'),('CZCETime', u'郑商所时间'),('MaxOrderRef', u'最大报单引用'),('UserID', u'用户代码'),('FrontID', u'前置编号'),('FFEXTime', u'中金所时间')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcInvestorPositionCombineDetailField:
    def __init__(self, CombInstrumentID="", TotalAmt=0, ExchangeID="", TradeGroupID=0, ComTradeID="", ExchMargin=0, InvestorID="", InstrumentID="", LegMultiple=0, SettlementID=0, OpenDate="", TradingDay="", BrokerID="", Margin=0, LegID=0, HedgeFlag='1', MarginRateByVolume=0, TradeID="", MarginRateByMoney=0, Direction='0'):
        self.CombInstrumentID=CombInstrumentID
        self.TotalAmt=TotalAmt
        self.ExchangeID=ExchangeID
        self.TradeGroupID=TradeGroupID
        self.ComTradeID=ComTradeID
        self.ExchMargin=ExchMargin
        self.InvestorID=InvestorID
        self.InstrumentID=InstrumentID
        self.LegMultiple=LegMultiple
        self.SettlementID=SettlementID
        self.OpenDate=OpenDate
        self.TradingDay=TradingDay
        self.BrokerID=BrokerID
        self.Margin=Margin
        self.LegID=LegID
        self.HedgeFlag=HedgeFlag
        self.MarginRateByVolume=MarginRateByVolume
        self.TradeID=TradeID
        self.MarginRateByMoney=MarginRateByMoney
        self.Direction=Direction
        self.vcmap={'HedgeFlag': {"'2'": '套利', "'3'": '套保', "'1'": '投机'}, 'Direction': {"'0'": '买', "'1'": '卖'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['CombInstrumentID', 'TotalAmt', 'ExchangeID', 'TradeGroupID', 'ComTradeID', 'ExchMargin', 'InvestorID', 'InstrumentID', 'LegMultiple', 'SettlementID', 'OpenDate', 'TradingDay', 'BrokerID', 'Margin', 'LegID', 'HedgeFlag', 'MarginRateByVolume', 'TradeID', 'MarginRateByMoney', 'Direction']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('CombInstrumentID', u'组合持仓合约编码'),('TotalAmt', u'持仓量'),('ExchangeID', u'交易所代码'),('TradeGroupID', u'成交组号'),('ComTradeID', u'组合编号'),('ExchMargin', u'交易所保证金'),('InvestorID', u'投资者代码'),('InstrumentID', u'合约代码'),('LegMultiple', u'单腿乘数'),('SettlementID', u'结算编号'),('OpenDate', u'开仓日期'),('TradingDay', u'交易日'),('BrokerID', u'经纪公司代码'),('Margin', u'投资者保证金'),('LegID', u'单腿编号'),('HedgeFlag', u'投机套保标志'),('MarginRateByVolume', u'保证金率(按手数)'),('TradeID', u'撮合编号'),('MarginRateByMoney', u'保证金率'),('Direction', u'买卖')]])
    def getval(self, n):
        if n in ['HedgeFlag', 'Direction']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQueryMaxOrderVolumeWithPriceField:
    def __init__(self, BrokerID="", HedgeFlag='1', MaxVolume=0, InvestorID="", Price=0, OffsetFlag='0', InstrumentID="", Direction='0'):
        self.BrokerID=BrokerID
        self.HedgeFlag=HedgeFlag
        self.MaxVolume=MaxVolume
        self.InvestorID=InvestorID
        self.Price=Price
        self.OffsetFlag=OffsetFlag
        self.InstrumentID=InstrumentID
        self.Direction=Direction
        self.vcmap={'HedgeFlag': {"'2'": '套利', "'3'": '套保', "'1'": '投机'}, 'OffsetFlag': {"'0'": '开仓', "'6'": '本地强平', "'2'": '强平', "'5'": '强减', "'3'": '平今', "'1'": '平仓', "'4'": '平昨'}, 'Direction': {"'0'": '买', "'1'": '卖'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['BrokerID', 'HedgeFlag', 'MaxVolume', 'InvestorID', 'Price', 'OffsetFlag', 'InstrumentID', 'Direction']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('BrokerID', u'经纪公司代码'),('HedgeFlag', u'投机套保标志'),('MaxVolume', u'最大允许报单数量'),('InvestorID', u'投资者代码'),('Price', u'报单价格'),('OffsetFlag', u'开平标志'),('InstrumentID', u'合约代码'),('Direction', u'买卖方向')]])
    def getval(self, n):
        if n in ['HedgeFlag', 'OffsetFlag', 'Direction']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcTransferBankToFutureReqField:
    def __init__(self, FuturePwdFlag='0', FutureAccPwd="", TradeAmt=0, CurrencyCode="", FutureAccount="", CustFee=0):
        self.FuturePwdFlag=FuturePwdFlag
        self.FutureAccPwd=FutureAccPwd
        self.TradeAmt=TradeAmt
        self.CurrencyCode=CurrencyCode
        self.FutureAccount=FutureAccount
        self.CustFee=CustFee
        self.vcmap={'FuturePwdFlag': {"'0'": '不核对', "'1'": '核对'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['FuturePwdFlag', 'FutureAccPwd', 'TradeAmt', 'CurrencyCode', 'FutureAccount', 'CustFee']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('FuturePwdFlag', u'密码标志'),('FutureAccPwd', u'密码'),('TradeAmt', u'转账金额'),('CurrencyCode', u'币种：RMB-人民币 USD-美圆 HKD-港元'),('FutureAccount', u'期货资金账户'),('CustFee', u'客户手续费')]])
    def getval(self, n):
        if n in ['FuturePwdFlag']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcBrokerField:
    def __init__(self, IsActive=0, BrokerID="", BrokerName="", BrokerAbbr=""):
        self.IsActive=IsActive
        self.BrokerID=BrokerID
        self.BrokerName=BrokerName
        self.BrokerAbbr=BrokerAbbr
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['IsActive', 'BrokerID', 'BrokerName', 'BrokerAbbr']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('IsActive', u'是否活跃'),('BrokerID', u'经纪公司代码'),('BrokerName', u'经纪公司名称'),('BrokerAbbr', u'经纪公司简称')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcQryTransferBankField:
    def __init__(self, BankBrchID="", BankID=""):
        self.BankBrchID=BankBrchID
        self.BankID=BankID
        self.vcmap={}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['BankBrchID', 'BankID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('BankBrchID', u'银行分中心代码'),('BankID', u'银行代码')]])
    def getval(self, n):
        if n in []:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
class CThostFtdcVerifyFuturePasswordField:
    def __init__(self, TradeTime="", AccountID="", BankID="", BankAccount="", BrokerBranchID="", BankBranchID="", TradeCode="", Password="", LastFragment='0', BankPassWord="", PlateSerial=0, TradingDay="", BrokerID="", TradeDate="", BankSerial="", SessionID=0, InstallID=0, TID=0):
        self.TradeTime=TradeTime
        self.AccountID=AccountID
        self.BankID=BankID
        self.BankAccount=BankAccount
        self.BrokerBranchID=BrokerBranchID
        self.BankBranchID=BankBranchID
        self.TradeCode=TradeCode
        self.Password=Password
        self.LastFragment=LastFragment
        self.BankPassWord=BankPassWord
        self.PlateSerial=PlateSerial
        self.TradingDay=TradingDay
        self.BrokerID=BrokerID
        self.TradeDate=TradeDate
        self.BankSerial=BankSerial
        self.SessionID=SessionID
        self.InstallID=InstallID
        self.TID=TID
        self.vcmap={'LastFragment': {"'0'": '是最后分片', "'1'": '不是最后分片'}}
    def __repr__(self): return "<%s>" % ",".join(["%s:%s" % (x, getattr(self, x)) for x in ['TradeTime', 'AccountID', 'BankID', 'BankAccount', 'BrokerBranchID', 'BankBranchID', 'TradeCode', 'Password', 'LastFragment', 'BankPassWord', 'PlateSerial', 'TradingDay', 'BrokerID', 'TradeDate', 'BankSerial', 'SessionID', 'InstallID', 'TID']])
    def __str__(self):  return "<%s>" % ",".join(["%s:%s" % (y, self.getval(x)) for x,y in [('TradeTime', u'交易时间'),('AccountID', u'投资者帐号'),('BankID', u'银行代码'),('BankAccount', u'银行帐号'),('BrokerBranchID', u'期商分支机构代码'),('BankBranchID', u'银行分支机构代码'),('TradeCode', u'业务功能码'),('Password', u'期货密码'),('LastFragment', u'最后分片标志'),('BankPassWord', u'银行密码'),('PlateSerial', u'银期平台消息流水号'),('TradingDay', u'交易系统日期'),('BrokerID', u'期商代码'),('TradeDate', u'交易日期'),('BankSerial', u'银行流水号'),('SessionID', u'会话号'),('InstallID', u'安装编号'),('TID', u'交易ID')]])
    def getval(self, n):
        if n in ['LastFragment']:
            return self.vcmap[n]["'%s'" % getattr(self, n)]
        else: return getattr(self, n)
# Set short name alias for the stupid Hungarian Notation
QryTradingAccount=CThostFtdcQryTradingAccountField
MarketDataUpdateTime=CThostFtdcMarketDataUpdateTimeField
QryTraderOffer=CThostFtdcQryTraderOfferField
SyncingInstrumentTradingRight=CThostFtdcSyncingInstrumentTradingRightField
FensUserInfo=CThostFtdcFensUserInfoField
QryInstrumentStatus=CThostFtdcQryInstrumentStatusField
BrokerWithdrawAlgorithm=CThostFtdcBrokerWithdrawAlgorithmField
InputOrder=CThostFtdcInputOrderField
PositionProfitAlgorithm=CThostFtdcPositionProfitAlgorithmField
ChangeAccount=CThostFtdcChangeAccountField
QrySettlementInfo=CThostFtdcQrySettlementInfoField
RspQueryTradeResultBySerial=CThostFtdcRspQueryTradeResultBySerialField
CommPhase=CThostFtdcCommPhaseField
VerifyInvestorPassword=CThostFtdcVerifyInvestorPasswordField
QryEWarrantOffset=CThostFtdcQryEWarrantOffsetField
MarketDataStatic=CThostFtdcMarketDataStaticField
QrySuperUserFunction=CThostFtdcQrySuperUserFunctionField
Order=CThostFtdcOrderField
LoginInfo=CThostFtdcLoginInfoField
SyncingInstrumentMarginRate=CThostFtdcSyncingInstrumentMarginRateField
UserSession=CThostFtdcUserSessionField
BrokerUserEvent=CThostFtdcBrokerUserEventField
TradingNotice=CThostFtdcTradingNoticeField
QryInstrumentTradingRight=CThostFtdcQryInstrumentTradingRightField
Dissemination=CThostFtdcDisseminationField
QryInvestorProductGroupMargin=CThostFtdcQryInvestorProductGroupMarginField
QryTrader=CThostFtdcQryTraderField
InstrumentMarginRateAdjust=CThostFtdcInstrumentMarginRateAdjustField
BrokerDeposit=CThostFtdcBrokerDepositField
BrokerTradingParams=CThostFtdcBrokerTradingParamsField
SyncingTradingAccount=CThostFtdcSyncingTradingAccountField
NotifySyncKey=CThostFtdcNotifySyncKeyField
QryInstrumentCommissionRate=CThostFtdcQryInstrumentCommissionRateField
Accountregister=CThostFtdcAccountregisterField
SyncingInvestorPosition=CThostFtdcSyncingInvestorPositionField
RspRepeal=CThostFtdcRspRepealField
QryAccountregister=CThostFtdcQryAccountregisterField
TradingAccount=CThostFtdcTradingAccountField
QryMarginModel=CThostFtdcQryMarginModelField
QryDepthMarketData=CThostFtdcQryDepthMarketDataField
TradingNoticeInfo=CThostFtdcTradingNoticeInfoField
MarketDataAsk45=CThostFtdcMarketDataAsk45Field
ExchangeOrderAction=CThostFtdcExchangeOrderActionField
PartBroker=CThostFtdcPartBrokerField
RspTransfer=CThostFtdcRspTransferField
DRTransfer=CThostFtdcDRTransferField
QryParkedOrder=CThostFtdcQryParkedOrderField
ReqQueryAccount=CThostFtdcReqQueryAccountField
ExchangeOrderActionError=CThostFtdcExchangeOrderActionErrorField
ExchangeMarginRateAdjust=CThostFtdcExchangeMarginRateAdjustField
QryParkedOrderAction=CThostFtdcQryParkedOrderActionField
TransferFutureToBankReq=CThostFtdcTransferFutureToBankReqField
ErrorConditionalOrder=CThostFtdcErrorConditionalOrderField
RemoveParkedOrderAction=CThostFtdcRemoveParkedOrderActionField
TradingAccountPassword=CThostFtdcTradingAccountPasswordField
QryErrOrderAction=CThostFtdcQryErrOrderActionField
QryTrade=CThostFtdcQryTradeField
QryLoginForbiddenUser=CThostFtdcQryLoginForbiddenUserField
TransferFutureToBankRsp=CThostFtdcTransferFutureToBankRspField
QryInvestorPositionCombineDetail=CThostFtdcQryInvestorPositionCombineDetailField
ExchangeOrderInsertError=CThostFtdcExchangeOrderInsertErrorField
QryCommRateModel=CThostFtdcQryCommRateModelField
QryExchange=CThostFtdcQryExchangeField
SpecificInstrument=CThostFtdcSpecificInstrumentField
RemoveParkedOrder=CThostFtdcRemoveParkedOrderField
QryCFMMCBrokerKey=CThostFtdcQryCFMMCBrokerKeyField
OpenAccount=CThostFtdcOpenAccountField
MarginModel=CThostFtdcMarginModelField
QryCFMMCTradingAccountKey=CThostFtdcQryCFMMCTradingAccountKeyField
FutureSignIO=CThostFtdcFutureSignIOField
QryCombinationLeg=CThostFtdcQryCombinationLegField
EWarrantOffset=CThostFtdcEWarrantOffsetField
ForceUserLogout=CThostFtdcForceUserLogoutField
TradingAccountPasswordUpdate=CThostFtdcTradingAccountPasswordUpdateField
QryBrokerTradingAlgos=CThostFtdcQryBrokerTradingAlgosField
SyncingInvestorGroup=CThostFtdcSyncingInvestorGroupField
InputOrderAction=CThostFtdcInputOrderActionField
InvestorPositionDetail=CThostFtdcInvestorPositionDetailField
ReqOpenAccount=CThostFtdcReqOpenAccountField
QryUserSession=CThostFtdcQryUserSessionField
ReqTransfer=CThostFtdcReqTransferField
QryHisOrder=CThostFtdcQryHisOrderField
Instrument=CThostFtdcInstrumentField
QryBroker=CThostFtdcQryBrokerField
TradingCode=CThostFtdcTradingCodeField
InstrumentTradingRight=CThostFtdcInstrumentTradingRightField
SuperUser=CThostFtdcSuperUserField
VerifyFuturePasswordAndCustInfo=CThostFtdcVerifyFuturePasswordAndCustInfoField
QueryMaxOrderVolume=CThostFtdcQueryMaxOrderVolumeField
ReqAuthenticate=CThostFtdcReqAuthenticateField
ContractBank=CThostFtdcContractBankField
QrySettlementInfoConfirm=CThostFtdcQrySettlementInfoConfirmField
LinkMan=CThostFtdcLinkManField
QueryBrokerDeposit=CThostFtdcQueryBrokerDepositField
MarketDataAveragePrice=CThostFtdcMarketDataAveragePriceField
TransferQryBankRsp=CThostFtdcTransferQryBankRspField
ReqFutureSignOut=CThostFtdcReqFutureSignOutField
QryNotice=CThostFtdcQryNoticeField
UserRight=CThostFtdcUserRightField
ReqCancelAccount=CThostFtdcReqCancelAccountField
TradingAccountReserve=CThostFtdcTradingAccountReserveField
InstrumentMarginRate=CThostFtdcInstrumentMarginRateField
Notice=CThostFtdcNoticeField
CurrentTime=CThostFtdcCurrentTimeField
ReqRepeal=CThostFtdcReqRepealField
TransferSerial=CThostFtdcTransferSerialField
InvestorPosition=CThostFtdcInvestorPositionField
BrokerUserFunction=CThostFtdcBrokerUserFunctionField
OrderAction=CThostFtdcOrderActionField
QryInvestorGroup=CThostFtdcQryInvestorGroupField
TransferQryDetailReq=CThostFtdcTransferQryDetailReqField
ExchangeSequence=CThostFtdcExchangeSequenceField
QryProduct=CThostFtdcQryProductField
UserIP=CThostFtdcUserIPField
MDTraderOffer=CThostFtdcMDTraderOfferField
MarketData=CThostFtdcMarketDataField
CombinationLeg=CThostFtdcCombinationLegField
RspFutureSignOut=CThostFtdcRspFutureSignOutField
SyncingInstrumentCommissionRate=CThostFtdcSyncingInstrumentCommissionRateField
SuperUserFunction=CThostFtdcSuperUserFunctionField
QrySyncDeposit=CThostFtdcQrySyncDepositField
BrokerTradingAlgos=CThostFtdcBrokerTradingAlgosField
CurrTransferIdentity=CThostFtdcCurrTransferIdentityField
TransferBankToFutureRsp=CThostFtdcTransferBankToFutureRspField
Discount=CThostFtdcDiscountField
ReqUserLogin=CThostFtdcReqUserLoginField
QryErrOrder=CThostFtdcQryErrOrderField
QrySyncStatus=CThostFtdcQrySyncStatusField
QryInvestor=CThostFtdcQryInvestorField
DepthMarketData=CThostFtdcDepthMarketDataField
TransferQryBankReq=CThostFtdcTransferQryBankReqField
TradingAccountPasswordUpdateV1=CThostFtdcTradingAccountPasswordUpdateV1Field
Trade=CThostFtdcTradeField
Trader=CThostFtdcTraderField
MarketDataBid23=CThostFtdcMarketDataBid23Field
QryTransferSerial=CThostFtdcQryTransferSerialField
QrySuperUser=CThostFtdcQrySuperUserField
MarketDataAsk23=CThostFtdcMarketDataAsk23Field
QryTradingNotice=CThostFtdcQryTradingNoticeField
RspInfo=CThostFtdcRspInfoField
BrokerUserOTPParam=CThostFtdcBrokerUserOTPParamField
ReqChangeAccount=CThostFtdcReqChangeAccountField
QryExchangeMarginRate=CThostFtdcQryExchangeMarginRateField
ParkedOrderAction=CThostFtdcParkedOrderActionField
QryExchangeOrder=CThostFtdcQryExchangeOrderField
QryBrokerUserEvent=CThostFtdcQryBrokerUserEventField
SettlementRef=CThostFtdcSettlementRefField
QryInvestorPosition=CThostFtdcQryInvestorPositionField
QryExchangeOrderAction=CThostFtdcQryExchangeOrderActionField
TransferQryDetailRsp=CThostFtdcTransferQryDetailRspField
SyncingTradingCode=CThostFtdcSyncingTradingCodeField
QryBrokerUser=CThostFtdcQryBrokerUserField
QryInstrumentMarginRate=CThostFtdcQryInstrumentMarginRateField
LoginForbiddenUser=CThostFtdcLoginForbiddenUserField
QryFrontStatus=CThostFtdcQryFrontStatusField
InvestorAccount=CThostFtdcInvestorAccountField
DepositResultInform=CThostFtdcDepositResultInformField
BrokerUserPassword=CThostFtdcBrokerUserPasswordField
QryMDTraderOffer=CThostFtdcQryMDTraderOfferField
QryTradingCode=CThostFtdcQryTradingCodeField
CFMMCTradingAccountKey=CThostFtdcCFMMCTradingAccountKeyField
RspAuthenticate=CThostFtdcRspAuthenticateField
NotifyQueryAccount=CThostFtdcNotifyQueryAccountField
ManualSyncBrokerUserOTP=CThostFtdcManualSyncBrokerUserOTPField
LoadSettlementInfo=CThostFtdcLoadSettlementInfoField
QryBrokerTradingParams=CThostFtdcQryBrokerTradingParamsField
TransferHeader=CThostFtdcTransferHeaderField
ReqDayEndFileReady=CThostFtdcReqDayEndFileReadyField
MarketDataLastMatch=CThostFtdcMarketDataLastMatchField
CancelAccount=CThostFtdcCancelAccountField
UserLogout=CThostFtdcUserLogoutField
Investor=CThostFtdcInvestorField
QryContractBank=CThostFtdcQryContractBankField
ReturnResult=CThostFtdcReturnResultField
QryInstrument=CThostFtdcQryInstrumentField
SettlementInfoConfirm=CThostFtdcSettlementInfoConfirmField
ExchangeTrade=CThostFtdcExchangeTradeField
SyncingInvestor=CThostFtdcSyncingInvestorField
FrontStatus=CThostFtdcFrontStatusField
RspFutureSignIn=CThostFtdcRspFutureSignInField
ReqQueryTradeResultBySerial=CThostFtdcReqQueryTradeResultBySerialField
BrokerSync=CThostFtdcBrokerSyncField
CFMMCBrokerKey=CThostFtdcCFMMCBrokerKeyField
LogoutAll=CThostFtdcLogoutAllField
ExchangeMarginRate=CThostFtdcExchangeMarginRateField
QryPartBroker=CThostFtdcQryPartBrokerField
TransferBank=CThostFtdcTransferBankField
SyncDeposit=CThostFtdcSyncDepositField
RspQueryAccount=CThostFtdcRspQueryAccountField
InvestorWithdrawAlgorithm=CThostFtdcInvestorWithdrawAlgorithmField
UserPasswordUpdate=CThostFtdcUserPasswordUpdateField
QryExchangeMarginRateAdjust=CThostFtdcQryExchangeMarginRateAdjustField
MarketDataBase=CThostFtdcMarketDataBaseField
CommRateModel=CThostFtdcCommRateModelField
QryInvestorPositionDetail=CThostFtdcQryInvestorPositionDetailField
MarketDataBid45=CThostFtdcMarketDataBid45Field
Exchange=CThostFtdcExchangeField
InstrumentCommissionRate=CThostFtdcInstrumentCommissionRateField
MulticastGroupInfo=CThostFtdcMulticastGroupInfoField
BrokerUser=CThostFtdcBrokerUserField
SettlementInfo=CThostFtdcSettlementInfoField
QryOrderAction=CThostFtdcQryOrderActionField
InvestorProductGroupMargin=CThostFtdcInvestorProductGroupMarginField
RspSyncKey=CThostFtdcRspSyncKeyField
Product=CThostFtdcProductField
BrokerUserRightAssign=CThostFtdcBrokerUserRightAssignField
MarketDataExchange=CThostFtdcMarketDataExchangeField
InstrumentStatus=CThostFtdcInstrumentStatusField
MarketDataBestPrice=CThostFtdcMarketDataBestPriceField
NotifyFutureSignOut=CThostFtdcNotifyFutureSignOutField
ErrOrderAction=CThostFtdcErrOrderActionField
ParkedOrder=CThostFtdcParkedOrderField
TraderOffer=CThostFtdcTraderOfferField
VerifyCustInfo=CThostFtdcVerifyCustInfoField
QryExchangeSequence=CThostFtdcQryExchangeSequenceField
QryLinkMan=CThostFtdcQryLinkManField
QryBrokerUserFunction=CThostFtdcQryBrokerUserFunctionField
ExchangeOrder=CThostFtdcExchangeOrderField
SyncStatus=CThostFtdcSyncStatusField
ReqSyncKey=CThostFtdcReqSyncKeyField
InvestorGroup=CThostFtdcInvestorGroupField
NotifyFutureSignIn=CThostFtdcNotifyFutureSignInField
ErrOrder=CThostFtdcErrOrderField
AuthenticationInfo=CThostFtdcAuthenticationInfoField
UserRightsAssign=CThostFtdcUserRightsAssignField
QryOrder=CThostFtdcQryOrderField
RspUserLogin=CThostFtdcRspUserLoginField
InvestorPositionCombineDetail=CThostFtdcInvestorPositionCombineDetailField
QueryMaxOrderVolumeWithPrice=CThostFtdcQueryMaxOrderVolumeWithPriceField
TransferBankToFutureReq=CThostFtdcTransferBankToFutureReqField
Broker=CThostFtdcBrokerField
QryTransferBank=CThostFtdcQryTransferBankField
VerifyFuturePassword=CThostFtdcVerifyFuturePasswordField
