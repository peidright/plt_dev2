/*
A wrapper for CTP's Api library
author: Lvsoft@gmail.com
date: 2010-07-20

This file is part of python-ctp library

python-ctp is free software; you can redistribute it and/or modify it
under the terms of the GUL Lesser General Public License as published
by the Free Software Foundation; either version 2.1 of the License, or
(at your option) any later version.

python-ctp is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY of FITNESS FOR A PARTICULAR PURPOSE. See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along the python-ctp; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
02110-1301 USA
*/

//This file is auto generated! Please don't edit directly.

#include "struct.h"

static PyObject * mod=NULL;
PyObject * register_struct(PyObject * self, PyObject * args){
  mod = PyTuple_GET_ITEM(args,0);
  Py_INCREF(Py_None);
  return Py_None;
}

//当前银期所属交易中心
PyObject * new_CThostFtdcCurrTransferIdentityField(CThostFtdcCurrTransferIdentityField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcCurrTransferIdentityField", (char*)"i",
p->IdentityID);
}
CThostFtdcCurrTransferIdentityField * from_CThostFtdcCurrTransferIdentityField(PyObject * p){
  CThostFtdcCurrTransferIdentityField *t = (CThostFtdcCurrTransferIdentityField *)calloc(1, sizeof(CThostFtdcCurrTransferIdentityField));
  memset(t,0,sizeof(CThostFtdcCurrTransferIdentityField));
  //交易中心代码
  t->IdentityID =   PyLong_AsLong(PyObject_GetAttrString(p, "IdentityID"));

  return t;
};

//合约手续费率
PyObject * new_CThostFtdcInstrumentCommissionRateField(CThostFtdcInstrumentCommissionRateField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcInstrumentCommissionRateField", (char*)"dyddddyycd",
p->CloseTodayRatioByMoney, p->InstrumentID, p->OpenRatioByVolume, p->CloseTodayRatioByVolume, p->OpenRatioByMoney, p->CloseRatioByVolume, p->BrokerID, p->InvestorID, p->InvestorRange, p->CloseRatioByMoney);
}
CThostFtdcInstrumentCommissionRateField * from_CThostFtdcInstrumentCommissionRateField(PyObject * p){
  CThostFtdcInstrumentCommissionRateField *t = (CThostFtdcInstrumentCommissionRateField *)calloc(1, sizeof(CThostFtdcInstrumentCommissionRateField));
  memset(t,0,sizeof(CThostFtdcInstrumentCommissionRateField));
  //平今手续费率
  t->CloseTodayRatioByMoney =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CloseTodayRatioByMoney"));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //开仓手续费
  t->OpenRatioByVolume =   PyFloat_AsDouble(PyObject_GetAttrString(p, "OpenRatioByVolume"));
  //平今手续费
  t->CloseTodayRatioByVolume =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CloseTodayRatioByVolume"));
  //开仓手续费率
  t->OpenRatioByMoney =   PyFloat_AsDouble(PyObject_GetAttrString(p, "OpenRatioByMoney"));
  //平仓手续费
  t->CloseRatioByVolume =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CloseRatioByVolume"));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //投资者范围
  //enum类型
  //THOST_FTDC_IR_Single -> '3', 单一投资者
  //THOST_FTDC_IR_All -> '1', 所有
  //THOST_FTDC_IR_Group -> '2', 投资者组
  t->InvestorRange =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorRange"),"gbk","Error!"))[0];
  //平仓手续费率
  t->CloseRatioByMoney =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CloseRatioByMoney"));

  return t;
};

//正在同步中的合约交易权限
PyObject * new_CThostFtdcSyncingInstrumentTradingRightField(CThostFtdcSyncingInstrumentTradingRightField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcSyncingInstrumentTradingRightField", (char*)"yycyc",
p->InstrumentID, p->InvestorID, p->InvestorRange, p->BrokerID, p->TradingRight);
}
CThostFtdcSyncingInstrumentTradingRightField * from_CThostFtdcSyncingInstrumentTradingRightField(PyObject * p){
  CThostFtdcSyncingInstrumentTradingRightField *t = (CThostFtdcSyncingInstrumentTradingRightField *)calloc(1, sizeof(CThostFtdcSyncingInstrumentTradingRightField));
  memset(t,0,sizeof(CThostFtdcSyncingInstrumentTradingRightField));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //投资者范围
  //enum类型
  //THOST_FTDC_IR_Single -> '3', 单一投资者
  //THOST_FTDC_IR_All -> '1', 所有
  //THOST_FTDC_IR_Group -> '2', 投资者组
  t->InvestorRange =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorRange"),"gbk","Error!"))[0];
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //交易权限
  //enum类型
  //THOST_FTDC_TR_Allow -> '0', 可以交易
  //THOST_FTDC_TR_CloseOnly -> '1', 只能平仓
  //THOST_FTDC_TR_Forbidden -> '2', 不能交易
  t->TradingRight =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingRight"),"gbk","Error!"))[0];

  return t;
};

//期货资金转银行请求响应
PyObject * new_CThostFtdcTransferFutureToBankRspField(CThostFtdcTransferFutureToBankRspField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcTransferFutureToBankRspField", (char*)"yyyddy",
p->FutureAccount, p->RetCode, p->RetInfo, p->TradeAmt, p->CustFee, p->CurrencyCode);
}
CThostFtdcTransferFutureToBankRspField * from_CThostFtdcTransferFutureToBankRspField(PyObject * p){
  CThostFtdcTransferFutureToBankRspField *t = (CThostFtdcTransferFutureToBankRspField *)calloc(1, sizeof(CThostFtdcTransferFutureToBankRspField));
  memset(t,0,sizeof(CThostFtdcTransferFutureToBankRspField));
  //资金账户
  strcpy(t->FutureAccount, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "FutureAccount"),"gbk","Error!")));
  //响应代码
  strcpy(t->RetCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "RetCode"),"gbk","Error!")));
  //响应信息
  strcpy(t->RetInfo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "RetInfo"),"gbk","Error!")));
  //转帐金额
  t->TradeAmt =   PyFloat_AsDouble(PyObject_GetAttrString(p, "TradeAmt"));
  //应收客户手续费
  t->CustFee =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CustFee"));
  //币种
  strcpy(t->CurrencyCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrencyCode"),"gbk","Error!")));

  return t;
};

//投资者保证金率模板
PyObject * new_CThostFtdcMarginModelField(CThostFtdcMarginModelField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcMarginModelField", (char*)"yyy",
p->BrokerID, p->MarginModelID, p->MarginModelName);
}
CThostFtdcMarginModelField * from_CThostFtdcMarginModelField(PyObject * p){
  CThostFtdcMarginModelField *t = (CThostFtdcMarginModelField *)calloc(1, sizeof(CThostFtdcMarginModelField));
  memset(t,0,sizeof(CThostFtdcMarginModelField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //保证金率模板代码
  strcpy(t->MarginModelID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "MarginModelID"),"gbk","Error!")));
  //模板名称
  strcpy(t->MarginModelName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "MarginModelName"),"gbk","Error!")));

  return t;
};

//查询行情
PyObject * new_CThostFtdcQryDepthMarketDataField(CThostFtdcQryDepthMarketDataField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryDepthMarketDataField", (char*)"y",
p->InstrumentID);
}
CThostFtdcQryDepthMarketDataField * from_CThostFtdcQryDepthMarketDataField(PyObject * p){
  CThostFtdcQryDepthMarketDataField *t = (CThostFtdcQryDepthMarketDataField *)calloc(1, sizeof(CThostFtdcQryDepthMarketDataField));
  memset(t,0,sizeof(CThostFtdcQryDepthMarketDataField));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));

  return t;
};

//查询账户信息响应
PyObject * new_CThostFtdcRspQueryAccountField(CThostFtdcRspQueryAccountField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcRspQueryAccountField", (char*)"cyyiyiyiyycdcdyycyyyyycicyyccyyyyyiyyi",
p->BankPwdFlag, p->TradingDay, p->TradeTime, p->FutureSerial, p->DeviceID, p->InstallID, p->BrokerID, p->SessionID, p->IdentifiedCardNo, p->AccountID, p->SecuPwdFlag, p->BankFetchAmount, p->VerifyCertNoFlag, p->BankUseAmount, p->BankID, p->CurrencyID, p->BankSecuAccType, p->OperNo, p->BankAccount, p->Digest, p->BankSecuAcc, p->Password, p->LastFragment, p->RequestID, p->BankAccType, p->TradeDate, p->UserID, p->CustType, p->IdCardType, p->BankSerial, p->BrokerIDByBank, p->TradeCode, p->CustomerName, p->BankPassWord, p->TID, p->BankBranchID, p->BrokerBranchID, p->PlateSerial);
}
CThostFtdcRspQueryAccountField * from_CThostFtdcRspQueryAccountField(PyObject * p){
  CThostFtdcRspQueryAccountField *t = (CThostFtdcRspQueryAccountField *)calloc(1, sizeof(CThostFtdcRspQueryAccountField));
  memset(t,0,sizeof(CThostFtdcRspQueryAccountField));
  //银行密码标志
  //enum类型
  //THOST_FTDC_BPWDF_NoCheck -> '0', 不核对
  //THOST_FTDC_BPWDF_BlankCheck -> '1', 明文核对
  //THOST_FTDC_BPWDF_EncryptCheck -> '2', 密文核对
  t->BankPwdFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankPwdFlag"),"gbk","Error!"))[0];
  //交易系统日期
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //交易时间
  strcpy(t->TradeTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeTime"),"gbk","Error!")));
  //期货公司流水号
  t->FutureSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "FutureSerial"));
  //渠道标志
  strcpy(t->DeviceID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "DeviceID"),"gbk","Error!")));
  //安装编号
  t->InstallID =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallID"));
  //期商代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //会话号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //证件号码
  strcpy(t->IdentifiedCardNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdentifiedCardNo"),"gbk","Error!")));
  //投资者帐号
  strcpy(t->AccountID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AccountID"),"gbk","Error!")));
  //期货资金密码核对标志
  //enum类型
  //THOST_FTDC_BPWDF_NoCheck -> '0', 不核对
  //THOST_FTDC_BPWDF_BlankCheck -> '1', 明文核对
  //THOST_FTDC_BPWDF_EncryptCheck -> '2', 密文核对
  t->SecuPwdFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "SecuPwdFlag"),"gbk","Error!"))[0];
  //银行可取金额
  t->BankFetchAmount =   PyFloat_AsDouble(PyObject_GetAttrString(p, "BankFetchAmount"));
  //验证客户证件号码标志
  //enum类型
  //THOST_FTDC_YNI_No -> '1', 否
  //THOST_FTDC_YNI_Yes -> '0', 是
  t->VerifyCertNoFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "VerifyCertNoFlag"),"gbk","Error!"))[0];
  //银行可用金额
  t->BankUseAmount =   PyFloat_AsDouble(PyObject_GetAttrString(p, "BankUseAmount"));
  //银行代码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //币种代码
  strcpy(t->CurrencyID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrencyID"),"gbk","Error!")));
  //期货单位帐号类型
  //enum类型
  //THOST_FTDC_BAT_SavingCard -> '2', 储蓄卡
  //THOST_FTDC_BAT_CreditCard -> '3', 信用卡
  //THOST_FTDC_BAT_BankBook -> '1', 银行存折
  t->BankSecuAccType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSecuAccType"),"gbk","Error!"))[0];
  //交易柜员
  strcpy(t->OperNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OperNo"),"gbk","Error!")));
  //银行帐号
  strcpy(t->BankAccount, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccount"),"gbk","Error!")));
  //摘要
  strcpy(t->Digest, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Digest"),"gbk","Error!")));
  //期货单位帐号
  strcpy(t->BankSecuAcc, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSecuAcc"),"gbk","Error!")));
  //期货密码
  strcpy(t->Password, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Password"),"gbk","Error!")));
  //最后分片标志
  //enum类型
  //THOST_FTDC_LF_No -> '1', 不是最后分片
  //THOST_FTDC_LF_Yes -> '0', 是最后分片
  t->LastFragment =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LastFragment"),"gbk","Error!"))[0];
  //请求编号
  t->RequestID =   PyLong_AsLong(PyObject_GetAttrString(p, "RequestID"));
  //银行帐号类型
  //enum类型
  //THOST_FTDC_BAT_SavingCard -> '2', 储蓄卡
  //THOST_FTDC_BAT_CreditCard -> '3', 信用卡
  //THOST_FTDC_BAT_BankBook -> '1', 银行存折
  t->BankAccType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccType"),"gbk","Error!"))[0];
  //交易日期
  strcpy(t->TradeDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeDate"),"gbk","Error!")));
  //用户标识
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //客户类型
  //enum类型
  //THOST_FTDC_CUSTT_Person -> '0', 自然人
  //THOST_FTDC_CUSTT_Institution -> '1', 机构户
  t->CustType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustType"),"gbk","Error!"))[0];
  //证件类型
  //enum类型
  //THOST_FTDC_ICT_TaiwanCompatriotIDCard -> '7', 台胞证
  //THOST_FTDC_ICT_Passport -> '6', 护照
  //THOST_FTDC_ICT_LicenseNo -> '9', 营业执照号
  //THOST_FTDC_ICT_OtherCard -> 'x', 其他证件
  //THOST_FTDC_ICT_IDCard -> '1', 身份证
  //THOST_FTDC_ICT_EID -> '0', 组织机构代码
  //THOST_FTDC_ICT_TaxNo -> 'A', 税务登记号
  //THOST_FTDC_ICT_HomeComingCard -> '8', 回乡证
  //THOST_FTDC_ICT_OfficerIDCard -> '2', 军官证
  //THOST_FTDC_ICT_HouseholdRegister -> '5', 户口簿
  //THOST_FTDC_ICT_SoldierIDCard -> '4', 士兵证
  //THOST_FTDC_ICT_PoliceIDCard -> '3', 警官证
  t->IdCardType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdCardType"),"gbk","Error!"))[0];
  //银行流水号
  strcpy(t->BankSerial, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSerial"),"gbk","Error!")));
  //期货公司银行编码
  strcpy(t->BrokerIDByBank, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerIDByBank"),"gbk","Error!")));
  //业务功能码
  strcpy(t->TradeCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeCode"),"gbk","Error!")));
  //客户姓名
  strcpy(t->CustomerName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustomerName"),"gbk","Error!")));
  //银行密码
  strcpy(t->BankPassWord, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankPassWord"),"gbk","Error!")));
  //交易ID
  t->TID =   PyLong_AsLong(PyObject_GetAttrString(p, "TID"));
  //银行分支机构代码
  strcpy(t->BankBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBranchID"),"gbk","Error!")));
  //期商分支机构代码
  strcpy(t->BrokerBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerBranchID"),"gbk","Error!")));
  //银期平台消息流水号
  t->PlateSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "PlateSerial"));

  return t;
};

//查询仓单折抵信息
PyObject * new_CThostFtdcQryEWarrantOffsetField(CThostFtdcQryEWarrantOffsetField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryEWarrantOffsetField", (char*)"yyyy",
p->BrokerID, p->InvestorID, p->ExchangeID, p->InstrumentID);
}
CThostFtdcQryEWarrantOffsetField * from_CThostFtdcQryEWarrantOffsetField(PyObject * p){
  CThostFtdcQryEWarrantOffsetField *t = (CThostFtdcQryEWarrantOffsetField *)calloc(1, sizeof(CThostFtdcQryEWarrantOffsetField));
  memset(t,0,sizeof(CThostFtdcQryEWarrantOffsetField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));

  return t;
};

//前置状态
PyObject * new_CThostFtdcFrontStatusField(CThostFtdcFrontStatusField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcFrontStatusField", (char*)"yiiy",
p->LastReportDate, p->FrontID, p->IsActive, p->LastReportTime);
}
CThostFtdcFrontStatusField * from_CThostFtdcFrontStatusField(PyObject * p){
  CThostFtdcFrontStatusField *t = (CThostFtdcFrontStatusField *)calloc(1, sizeof(CThostFtdcFrontStatusField));
  memset(t,0,sizeof(CThostFtdcFrontStatusField));
  //上次报告日期
  strcpy(t->LastReportDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LastReportDate"),"gbk","Error!")));
  //前置编号
  t->FrontID =   PyLong_AsLong(PyObject_GetAttrString(p, "FrontID"));
  //是否活跃
  t->IsActive =   PyLong_AsLong(PyObject_GetAttrString(p, "IsActive"));
  //上次报告时间
  strcpy(t->LastReportTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LastReportTime"),"gbk","Error!")));

  return t;
};

//信息分发
PyObject * new_CThostFtdcDisseminationField(CThostFtdcDisseminationField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcDisseminationField", (char*)"hi",
p->SequenceSeries, p->SequenceNo);
}
CThostFtdcDisseminationField * from_CThostFtdcDisseminationField(PyObject * p){
  CThostFtdcDisseminationField *t = (CThostFtdcDisseminationField *)calloc(1, sizeof(CThostFtdcDisseminationField));
  memset(t,0,sizeof(CThostFtdcDisseminationField));
  //序列系列号
  t->SequenceSeries =   PyLong_AsLong(PyObject_GetAttrString(p, "SequenceSeries"));
  //序列号
  t->SequenceNo =   PyLong_AsLong(PyObject_GetAttrString(p, "SequenceNo"));

  return t;
};

//正在同步中的投资者
PyObject * new_CThostFtdcSyncingInvestorField(CThostFtdcSyncingInvestorField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcSyncingInvestorField", (char*)"yyiyyycyyyyyy",
p->CommModelID, p->InvestorName, p->IsActive, p->Address, p->BrokerID, p->InvestorID, p->IdentifiedCardType, p->OpenDate, p->IdentifiedCardNo, p->Mobile, p->Telephone, p->InvestorGroupID, p->MarginModelID);
}
CThostFtdcSyncingInvestorField * from_CThostFtdcSyncingInvestorField(PyObject * p){
  CThostFtdcSyncingInvestorField *t = (CThostFtdcSyncingInvestorField *)calloc(1, sizeof(CThostFtdcSyncingInvestorField));
  memset(t,0,sizeof(CThostFtdcSyncingInvestorField));
  //手续费率模板代码
  strcpy(t->CommModelID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CommModelID"),"gbk","Error!")));
  //投资者名称
  strcpy(t->InvestorName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorName"),"gbk","Error!")));
  //是否活跃
  t->IsActive =   PyLong_AsLong(PyObject_GetAttrString(p, "IsActive"));
  //通讯地址
  strcpy(t->Address, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Address"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //证件类型
  //enum类型
  //THOST_FTDC_ICT_TaiwanCompatriotIDCard -> '7', 台胞证
  //THOST_FTDC_ICT_Passport -> '6', 护照
  //THOST_FTDC_ICT_LicenseNo -> '9', 营业执照号
  //THOST_FTDC_ICT_OtherCard -> 'x', 其他证件
  //THOST_FTDC_ICT_IDCard -> '1', 身份证
  //THOST_FTDC_ICT_EID -> '0', 组织机构代码
  //THOST_FTDC_ICT_TaxNo -> 'A', 税务登记号
  //THOST_FTDC_ICT_HomeComingCard -> '8', 回乡证
  //THOST_FTDC_ICT_OfficerIDCard -> '2', 军官证
  //THOST_FTDC_ICT_HouseholdRegister -> '5', 户口簿
  //THOST_FTDC_ICT_SoldierIDCard -> '4', 士兵证
  //THOST_FTDC_ICT_PoliceIDCard -> '3', 警官证
  t->IdentifiedCardType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdentifiedCardType"),"gbk","Error!"))[0];
  //开户日期
  strcpy(t->OpenDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OpenDate"),"gbk","Error!")));
  //证件号码
  strcpy(t->IdentifiedCardNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdentifiedCardNo"),"gbk","Error!")));
  //手机
  strcpy(t->Mobile, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Mobile"),"gbk","Error!")));
  //联系电话
  strcpy(t->Telephone, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Telephone"),"gbk","Error!")));
  //投资者分组代码
  strcpy(t->InvestorGroupID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorGroupID"),"gbk","Error!")));
  //保证金率模板代码
  strcpy(t->MarginModelID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "MarginModelID"),"gbk","Error!")));

  return t;
};

//转帐银行
PyObject * new_CThostFtdcTransferBankField(CThostFtdcTransferBankField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcTransferBankField", (char*)"iyyy",
p->IsActive, p->BankID, p->BankBrchID, p->BankName);
}
CThostFtdcTransferBankField * from_CThostFtdcTransferBankField(PyObject * p){
  CThostFtdcTransferBankField *t = (CThostFtdcTransferBankField *)calloc(1, sizeof(CThostFtdcTransferBankField));
  memset(t,0,sizeof(CThostFtdcTransferBankField));
  //是否活跃
  t->IsActive =   PyLong_AsLong(PyObject_GetAttrString(p, "IsActive"));
  //银行代码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //银行分中心代码
  strcpy(t->BankBrchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBrchID"),"gbk","Error!")));
  //银行名称
  strcpy(t->BankName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankName"),"gbk","Error!")));

  return t;
};

//通讯阶段
PyObject * new_CThostFtdcCommPhaseField(CThostFtdcCommPhaseField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcCommPhaseField", (char*)"yhy",
p->TradingDay, p->CommPhaseNo, p->SystemID);
}
CThostFtdcCommPhaseField * from_CThostFtdcCommPhaseField(PyObject * p){
  CThostFtdcCommPhaseField *t = (CThostFtdcCommPhaseField *)calloc(1, sizeof(CThostFtdcCommPhaseField));
  memset(t,0,sizeof(CThostFtdcCommPhaseField));
  //交易日
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //通讯时段编号
  t->CommPhaseNo =   PyLong_AsLong(PyObject_GetAttrString(p, "CommPhaseNo"));
  //系统编号
  strcpy(t->SystemID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "SystemID"),"gbk","Error!")));

  return t;
};

//查询产品
PyObject * new_CThostFtdcQryProductField(CThostFtdcQryProductField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryProductField", (char*)"y",
p->ProductID);
}
CThostFtdcQryProductField * from_CThostFtdcQryProductField(PyObject * p){
  CThostFtdcQryProductField *t = (CThostFtdcQryProductField *)calloc(1, sizeof(CThostFtdcQryProductField));
  memset(t,0,sizeof(CThostFtdcQryProductField));
  //产品代码
  strcpy(t->ProductID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ProductID"),"gbk","Error!")));

  return t;
};

//行情交易所代码属性
PyObject * new_CThostFtdcMarketDataExchangeField(CThostFtdcMarketDataExchangeField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcMarketDataExchangeField", (char*)"y",
p->ExchangeID);
}
CThostFtdcMarketDataExchangeField * from_CThostFtdcMarketDataExchangeField(PyObject * p){
  CThostFtdcMarketDataExchangeField *t = (CThostFtdcMarketDataExchangeField *)calloc(1, sizeof(CThostFtdcMarketDataExchangeField));
  memset(t,0,sizeof(CThostFtdcMarketDataExchangeField));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));

  return t;
};

//投资者组
PyObject * new_CThostFtdcInvestorGroupField(CThostFtdcInvestorGroupField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcInvestorGroupField", (char*)"yyy",
p->BrokerID, p->InvestorGroupID, p->InvestorGroupName);
}
CThostFtdcInvestorGroupField * from_CThostFtdcInvestorGroupField(PyObject * p){
  CThostFtdcInvestorGroupField *t = (CThostFtdcInvestorGroupField *)calloc(1, sizeof(CThostFtdcInvestorGroupField));
  memset(t,0,sizeof(CThostFtdcInvestorGroupField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者分组代码
  strcpy(t->InvestorGroupID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorGroupID"),"gbk","Error!")));
  //投资者分组名称
  strcpy(t->InvestorGroupName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorGroupName"),"gbk","Error!")));

  return t;
};

//会员资金折扣
PyObject * new_CThostFtdcDiscountField(CThostFtdcDiscountField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcDiscountField", (char*)"dyyc",
p->Discount, p->BrokerID, p->InvestorID, p->InvestorRange);
}
CThostFtdcDiscountField * from_CThostFtdcDiscountField(PyObject * p){
  CThostFtdcDiscountField *t = (CThostFtdcDiscountField *)calloc(1, sizeof(CThostFtdcDiscountField));
  memset(t,0,sizeof(CThostFtdcDiscountField));
  //资金折扣比例
  t->Discount =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Discount"));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //投资者范围
  //enum类型
  //THOST_FTDC_IR_Single -> '3', 单一投资者
  //THOST_FTDC_IR_All -> '1', 所有
  //THOST_FTDC_IR_Group -> '2', 投资者组
  t->InvestorRange =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorRange"),"gbk","Error!"))[0];

  return t;
};

//查询合约保证金率
PyObject * new_CThostFtdcQryInstrumentMarginRateField(CThostFtdcQryInstrumentMarginRateField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryInstrumentMarginRateField", (char*)"yyyc",
p->BrokerID, p->InvestorID, p->InstrumentID, p->HedgeFlag);
}
CThostFtdcQryInstrumentMarginRateField * from_CThostFtdcQryInstrumentMarginRateField(PyObject * p){
  CThostFtdcQryInstrumentMarginRateField *t = (CThostFtdcQryInstrumentMarginRateField *)calloc(1, sizeof(CThostFtdcQryInstrumentMarginRateField));
  memset(t,0,sizeof(CThostFtdcQryInstrumentMarginRateField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //投机套保标志
  //enum类型
  //THOST_FTDC_HF_Hedge -> '3', 套保
  //THOST_FTDC_HF_Arbitrage -> '2', 套利
  //THOST_FTDC_HF_Speculation -> '1', 投机
  t->HedgeFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "HedgeFlag"),"gbk","Error!"))[0];

  return t;
};

//投资者手续费率模板
PyObject * new_CThostFtdcCommRateModelField(CThostFtdcCommRateModelField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcCommRateModelField", (char*)"yyy",
p->CommModelID, p->BrokerID, p->CommModelName);
}
CThostFtdcCommRateModelField * from_CThostFtdcCommRateModelField(PyObject * p){
  CThostFtdcCommRateModelField *t = (CThostFtdcCommRateModelField *)calloc(1, sizeof(CThostFtdcCommRateModelField));
  memset(t,0,sizeof(CThostFtdcCommRateModelField));
  //手续费率模板代码
  strcpy(t->CommModelID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CommModelID"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //模板名称
  strcpy(t->CommModelName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CommModelName"),"gbk","Error!")));

  return t;
};

//投资者结算结果确认信息
PyObject * new_CThostFtdcSettlementInfoConfirmField(CThostFtdcSettlementInfoConfirmField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcSettlementInfoConfirmField", (char*)"yyyy",
p->BrokerID, p->InvestorID, p->ConfirmDate, p->ConfirmTime);
}
CThostFtdcSettlementInfoConfirmField * from_CThostFtdcSettlementInfoConfirmField(PyObject * p){
  CThostFtdcSettlementInfoConfirmField *t = (CThostFtdcSettlementInfoConfirmField *)calloc(1, sizeof(CThostFtdcSettlementInfoConfirmField));
  memset(t,0,sizeof(CThostFtdcSettlementInfoConfirmField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //确认日期
  strcpy(t->ConfirmDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ConfirmDate"),"gbk","Error!")));
  //确认时间
  strcpy(t->ConfirmTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ConfirmTime"),"gbk","Error!")));

  return t;
};

//强制交易员退出
PyObject * new_CThostFtdcForceUserLogoutField(CThostFtdcForceUserLogoutField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcForceUserLogoutField", (char*)"yy",
p->BrokerID, p->UserID);
}
CThostFtdcForceUserLogoutField * from_CThostFtdcForceUserLogoutField(PyObject * p){
  CThostFtdcForceUserLogoutField *t = (CThostFtdcForceUserLogoutField *)calloc(1, sizeof(CThostFtdcForceUserLogoutField));
  memset(t,0,sizeof(CThostFtdcForceUserLogoutField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));

  return t;
};

//经济公司是否有在本标示的交易权限
PyObject * new_CThostFtdcBrokerUserRightAssignField(CThostFtdcBrokerUserRightAssignField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcBrokerUserRightAssignField", (char*)"yii",
p->BrokerID, p->DRIdentityID, p->Tradeable);
}
CThostFtdcBrokerUserRightAssignField * from_CThostFtdcBrokerUserRightAssignField(PyObject * p){
  CThostFtdcBrokerUserRightAssignField *t = (CThostFtdcBrokerUserRightAssignField *)calloc(1, sizeof(CThostFtdcBrokerUserRightAssignField));
  memset(t,0,sizeof(CThostFtdcBrokerUserRightAssignField));
  //应用单元代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //交易中心代码
  t->DRIdentityID =   PyLong_AsLong(PyObject_GetAttrString(p, "DRIdentityID"));
  //能否交易
  t->Tradeable =   PyLong_AsLong(PyObject_GetAttrString(p, "Tradeable"));

  return t;
};

//灾备中心交易权限
PyObject * new_CThostFtdcUserRightsAssignField(CThostFtdcUserRightsAssignField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcUserRightsAssignField", (char*)"yyi",
p->BrokerID, p->UserID, p->DRIdentityID);
}
CThostFtdcUserRightsAssignField * from_CThostFtdcUserRightsAssignField(PyObject * p){
  CThostFtdcUserRightsAssignField *t = (CThostFtdcUserRightsAssignField *)calloc(1, sizeof(CThostFtdcUserRightsAssignField));
  memset(t,0,sizeof(CThostFtdcUserRightsAssignField));
  //应用单元代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //交易中心代码
  t->DRIdentityID =   PyLong_AsLong(PyObject_GetAttrString(p, "DRIdentityID"));

  return t;
};

//管理用户
PyObject * new_CThostFtdcSuperUserField(CThostFtdcSuperUserField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcSuperUserField", (char*)"yyiy",
p->Password, p->UserID, p->IsActive, p->UserName);
}
CThostFtdcSuperUserField * from_CThostFtdcSuperUserField(PyObject * p){
  CThostFtdcSuperUserField *t = (CThostFtdcSuperUserField *)calloc(1, sizeof(CThostFtdcSuperUserField));
  memset(t,0,sizeof(CThostFtdcSuperUserField));
  //密码
  strcpy(t->Password, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Password"),"gbk","Error!")));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //是否活跃
  t->IsActive =   PyLong_AsLong(PyObject_GetAttrString(p, "IsActive"));
  //用户名称
  strcpy(t->UserName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserName"),"gbk","Error!")));

  return t;
};

//查询错误报单
PyObject * new_CThostFtdcQryErrOrderField(CThostFtdcQryErrOrderField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryErrOrderField", (char*)"yy",
p->BrokerID, p->InvestorID);
}
CThostFtdcQryErrOrderField * from_CThostFtdcQryErrOrderField(PyObject * p){
  CThostFtdcQryErrOrderField *t = (CThostFtdcQryErrOrderField *)calloc(1, sizeof(CThostFtdcQryErrOrderField));
  memset(t,0,sizeof(CThostFtdcQryErrOrderField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));

  return t;
};

//投资者
PyObject * new_CThostFtdcInvestorField(CThostFtdcInvestorField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcInvestorField", (char*)"yyiyyycyyyyyy",
p->CommModelID, p->InvestorName, p->IsActive, p->Address, p->BrokerID, p->InvestorID, p->IdentifiedCardType, p->OpenDate, p->IdentifiedCardNo, p->Mobile, p->Telephone, p->InvestorGroupID, p->MarginModelID);
}
CThostFtdcInvestorField * from_CThostFtdcInvestorField(PyObject * p){
  CThostFtdcInvestorField *t = (CThostFtdcInvestorField *)calloc(1, sizeof(CThostFtdcInvestorField));
  memset(t,0,sizeof(CThostFtdcInvestorField));
  //手续费率模板代码
  strcpy(t->CommModelID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CommModelID"),"gbk","Error!")));
  //投资者名称
  strcpy(t->InvestorName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorName"),"gbk","Error!")));
  //是否活跃
  t->IsActive =   PyLong_AsLong(PyObject_GetAttrString(p, "IsActive"));
  //通讯地址
  strcpy(t->Address, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Address"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //证件类型
  //enum类型
  //THOST_FTDC_ICT_TaiwanCompatriotIDCard -> '7', 台胞证
  //THOST_FTDC_ICT_Passport -> '6', 护照
  //THOST_FTDC_ICT_LicenseNo -> '9', 营业执照号
  //THOST_FTDC_ICT_OtherCard -> 'x', 其他证件
  //THOST_FTDC_ICT_IDCard -> '1', 身份证
  //THOST_FTDC_ICT_EID -> '0', 组织机构代码
  //THOST_FTDC_ICT_TaxNo -> 'A', 税务登记号
  //THOST_FTDC_ICT_HomeComingCard -> '8', 回乡证
  //THOST_FTDC_ICT_OfficerIDCard -> '2', 军官证
  //THOST_FTDC_ICT_HouseholdRegister -> '5', 户口簿
  //THOST_FTDC_ICT_SoldierIDCard -> '4', 士兵证
  //THOST_FTDC_ICT_PoliceIDCard -> '3', 警官证
  t->IdentifiedCardType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdentifiedCardType"),"gbk","Error!"))[0];
  //开户日期
  strcpy(t->OpenDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OpenDate"),"gbk","Error!")));
  //证件号码
  strcpy(t->IdentifiedCardNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdentifiedCardNo"),"gbk","Error!")));
  //手机
  strcpy(t->Mobile, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Mobile"),"gbk","Error!")));
  //联系电话
  strcpy(t->Telephone, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Telephone"),"gbk","Error!")));
  //投资者分组代码
  strcpy(t->InvestorGroupID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorGroupID"),"gbk","Error!")));
  //保证金率模板代码
  strcpy(t->MarginModelID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "MarginModelID"),"gbk","Error!")));

  return t;
};

//查询交易员
PyObject * new_CThostFtdcQryTraderField(CThostFtdcQryTraderField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryTraderField", (char*)"yyy",
p->ExchangeID, p->TraderID, p->ParticipantID);
}
CThostFtdcQryTraderField * from_CThostFtdcQryTraderField(PyObject * p){
  CThostFtdcQryTraderField *t = (CThostFtdcQryTraderField *)calloc(1, sizeof(CThostFtdcQryTraderField));
  memset(t,0,sizeof(CThostFtdcQryTraderField));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //交易所交易员代码
  strcpy(t->TraderID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TraderID"),"gbk","Error!")));
  //会员代码
  strcpy(t->ParticipantID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ParticipantID"),"gbk","Error!")));

  return t;
};

//查询转帐银行
PyObject * new_CThostFtdcQryTransferBankField(CThostFtdcQryTransferBankField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryTransferBankField", (char*)"yy",
p->BankID, p->BankBrchID);
}
CThostFtdcQryTransferBankField * from_CThostFtdcQryTransferBankField(PyObject * p){
  CThostFtdcQryTransferBankField *t = (CThostFtdcQryTransferBankField *)calloc(1, sizeof(CThostFtdcQryTransferBankField));
  memset(t,0,sizeof(CThostFtdcQryTransferBankField));
  //银行代码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //银行分中心代码
  strcpy(t->BankBrchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBrchID"),"gbk","Error!")));

  return t;
};

//查询报单操作
PyObject * new_CThostFtdcQryOrderActionField(CThostFtdcQryOrderActionField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryOrderActionField", (char*)"yyy",
p->BrokerID, p->InvestorID, p->ExchangeID);
}
CThostFtdcQryOrderActionField * from_CThostFtdcQryOrderActionField(PyObject * p){
  CThostFtdcQryOrderActionField *t = (CThostFtdcQryOrderActionField *)calloc(1, sizeof(CThostFtdcQryOrderActionField));
  memset(t,0,sizeof(CThostFtdcQryOrderActionField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));

  return t;
};

//校验投资者密码
PyObject * new_CThostFtdcVerifyInvestorPasswordField(CThostFtdcVerifyInvestorPasswordField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcVerifyInvestorPasswordField", (char*)"yyy",
p->Password, p->BrokerID, p->InvestorID);
}
CThostFtdcVerifyInvestorPasswordField * from_CThostFtdcVerifyInvestorPasswordField(PyObject * p){
  CThostFtdcVerifyInvestorPasswordField *t = (CThostFtdcVerifyInvestorPasswordField *)calloc(1, sizeof(CThostFtdcVerifyInvestorPasswordField));
  memset(t,0,sizeof(CThostFtdcVerifyInvestorPasswordField));
  //密码
  strcpy(t->Password, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Password"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));

  return t;
};

//输入报单操作
PyObject * new_CThostFtdcInputOrderActionField(CThostFtdcInputOrderActionField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcInputOrderActionField", (char*)"yiiyiycydiiyyy",
p->OrderSysID, p->RequestID, p->SessionID, p->BrokerID, p->FrontID, p->InvestorID, p->ActionFlag, p->InstrumentID, p->LimitPrice, p->OrderActionRef, p->VolumeChange, p->ExchangeID, p->UserID, p->OrderRef);
}
CThostFtdcInputOrderActionField * from_CThostFtdcInputOrderActionField(PyObject * p){
  CThostFtdcInputOrderActionField *t = (CThostFtdcInputOrderActionField *)calloc(1, sizeof(CThostFtdcInputOrderActionField));
  memset(t,0,sizeof(CThostFtdcInputOrderActionField));
  //报单编号
  strcpy(t->OrderSysID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderSysID"),"gbk","Error!")));
  //请求编号
  t->RequestID =   PyLong_AsLong(PyObject_GetAttrString(p, "RequestID"));
  //会话编号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //前置编号
  t->FrontID =   PyLong_AsLong(PyObject_GetAttrString(p, "FrontID"));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //操作标志
  //enum类型
  //THOST_FTDC_AF_Delete -> '0', 删除
  //THOST_FTDC_AF_Modify -> '3', 修改
  t->ActionFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ActionFlag"),"gbk","Error!"))[0];
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //价格
  t->LimitPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LimitPrice"));
  //报单操作引用
  t->OrderActionRef =   PyLong_AsLong(PyObject_GetAttrString(p, "OrderActionRef"));
  //数量变化
  t->VolumeChange =   PyLong_AsLong(PyObject_GetAttrString(p, "VolumeChange"));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //报单引用
  strcpy(t->OrderRef, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderRef"),"gbk","Error!")));

  return t;
};

//错误报单操作
PyObject * new_CThostFtdcErrOrderActionField(CThostFtdcErrOrderActionField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcErrOrderActionField", (char*)"yyiyiiyyyiyyyyiyyyciycdiyyy",
p->InvestorID, p->ClientID, p->InstallID, p->BrokerID, p->FrontID, p->SessionID, p->TraderID, p->StatusMsg, p->ActionLocalID, p->VolumeChange, p->ActionDate, p->ErrorMsg, p->ExchangeID, p->OrderSysID, p->RequestID, p->UserID, p->InstrumentID, p->ParticipantID, p->ActionFlag, p->ErrorID, p->BusinessUnit, p->OrderActionStatus, p->LimitPrice, p->OrderActionRef, p->OrderRef, p->OrderLocalID, p->ActionTime);
}
CThostFtdcErrOrderActionField * from_CThostFtdcErrOrderActionField(PyObject * p){
  CThostFtdcErrOrderActionField *t = (CThostFtdcErrOrderActionField *)calloc(1, sizeof(CThostFtdcErrOrderActionField));
  memset(t,0,sizeof(CThostFtdcErrOrderActionField));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //客户代码
  strcpy(t->ClientID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ClientID"),"gbk","Error!")));
  //安装编号
  t->InstallID =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallID"));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //前置编号
  t->FrontID =   PyLong_AsLong(PyObject_GetAttrString(p, "FrontID"));
  //会话编号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //交易所交易员代码
  strcpy(t->TraderID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TraderID"),"gbk","Error!")));
  //状态信息
  strcpy(t->StatusMsg, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "StatusMsg"),"gbk","Error!")));
  //操作本地编号
  strcpy(t->ActionLocalID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ActionLocalID"),"gbk","Error!")));
  //数量变化
  t->VolumeChange =   PyLong_AsLong(PyObject_GetAttrString(p, "VolumeChange"));
  //操作日期
  strcpy(t->ActionDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ActionDate"),"gbk","Error!")));
  //错误信息
  strcpy(t->ErrorMsg, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ErrorMsg"),"gbk","Error!")));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //报单编号
  strcpy(t->OrderSysID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderSysID"),"gbk","Error!")));
  //请求编号
  t->RequestID =   PyLong_AsLong(PyObject_GetAttrString(p, "RequestID"));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //会员代码
  strcpy(t->ParticipantID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ParticipantID"),"gbk","Error!")));
  //操作标志
  //enum类型
  //THOST_FTDC_AF_Delete -> '0', 删除
  //THOST_FTDC_AF_Modify -> '3', 修改
  t->ActionFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ActionFlag"),"gbk","Error!"))[0];
  //错误代码
  t->ErrorID =   PyLong_AsLong(PyObject_GetAttrString(p, "ErrorID"));
  //业务单元
  strcpy(t->BusinessUnit, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BusinessUnit"),"gbk","Error!")));
  //报单操作状态
  //enum类型
  //THOST_FTDC_OAS_Submitted -> 'a', 已经提交
  //THOST_FTDC_OAS_Accepted -> 'b', 已经接受
  //THOST_FTDC_OAS_Rejected -> 'c', 已经被拒绝
  t->OrderActionStatus =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderActionStatus"),"gbk","Error!"))[0];
  //价格
  t->LimitPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LimitPrice"));
  //报单操作引用
  t->OrderActionRef =   PyLong_AsLong(PyObject_GetAttrString(p, "OrderActionRef"));
  //报单引用
  strcpy(t->OrderRef, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderRef"),"gbk","Error!")));
  //本地报单编号
  strcpy(t->OrderLocalID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderLocalID"),"gbk","Error!")));
  //操作时间
  strcpy(t->ActionTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ActionTime"),"gbk","Error!")));

  return t;
};

//查询交易编码
PyObject * new_CThostFtdcQryTradingCodeField(CThostFtdcQryTradingCodeField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryTradingCodeField", (char*)"ycyyy",
p->ClientID, p->ClientIDType, p->BrokerID, p->InvestorID, p->ExchangeID);
}
CThostFtdcQryTradingCodeField * from_CThostFtdcQryTradingCodeField(PyObject * p){
  CThostFtdcQryTradingCodeField *t = (CThostFtdcQryTradingCodeField *)calloc(1, sizeof(CThostFtdcQryTradingCodeField));
  memset(t,0,sizeof(CThostFtdcQryTradingCodeField));
  //客户代码
  strcpy(t->ClientID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ClientID"),"gbk","Error!")));
  //交易编码类型
  //enum类型
  //THOST_FTDC_CIDT_Arbitrage -> '2', 套利
  //THOST_FTDC_CIDT_Hedge -> '3', 套保
  //THOST_FTDC_CIDT_Speculation -> '1', 投机
  t->ClientIDType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ClientIDType"),"gbk","Error!"))[0];
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));

  return t;
};

//交易所保证金率调整
PyObject * new_CThostFtdcExchangeMarginRateAdjustField(CThostFtdcExchangeMarginRateAdjustField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcExchangeMarginRateAdjustField", (char*)"ddddddddyycdddd",
p->LongMarginRatioByMoney, p->NoShortMarginRatioByVolume, p->ShortMarginRatioByVolume, p->ExchLongMarginRatioByVolume, p->LongMarginRatioByVolume, p->ShortMarginRatioByMoney, p->ExchShortMarginRatioByVolume, p->NoLongMarginRatioByVolume, p->InstrumentID, p->BrokerID, p->HedgeFlag, p->ExchLongMarginRatioByMoney, p->NoLongMarginRatioByMoney, p->NoShortMarginRatioByMoney, p->ExchShortMarginRatioByMoney);
}
CThostFtdcExchangeMarginRateAdjustField * from_CThostFtdcExchangeMarginRateAdjustField(PyObject * p){
  CThostFtdcExchangeMarginRateAdjustField *t = (CThostFtdcExchangeMarginRateAdjustField *)calloc(1, sizeof(CThostFtdcExchangeMarginRateAdjustField));
  memset(t,0,sizeof(CThostFtdcExchangeMarginRateAdjustField));
  //跟随交易所投资者多头保证金率
  t->LongMarginRatioByMoney =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LongMarginRatioByMoney"));
  //不跟随交易所投资者空头保证金费
  t->NoShortMarginRatioByVolume =   PyFloat_AsDouble(PyObject_GetAttrString(p, "NoShortMarginRatioByVolume"));
  //跟随交易所投资者空头保证金费
  t->ShortMarginRatioByVolume =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ShortMarginRatioByVolume"));
  //交易所多头保证金费
  t->ExchLongMarginRatioByVolume =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ExchLongMarginRatioByVolume"));
  //跟随交易所投资者多头保证金费
  t->LongMarginRatioByVolume =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LongMarginRatioByVolume"));
  //跟随交易所投资者空头保证金率
  t->ShortMarginRatioByMoney =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ShortMarginRatioByMoney"));
  //交易所空头保证金费
  t->ExchShortMarginRatioByVolume =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ExchShortMarginRatioByVolume"));
  //不跟随交易所投资者多头保证金费
  t->NoLongMarginRatioByVolume =   PyFloat_AsDouble(PyObject_GetAttrString(p, "NoLongMarginRatioByVolume"));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投机套保标志
  //enum类型
  //THOST_FTDC_HF_Hedge -> '3', 套保
  //THOST_FTDC_HF_Arbitrage -> '2', 套利
  //THOST_FTDC_HF_Speculation -> '1', 投机
  t->HedgeFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "HedgeFlag"),"gbk","Error!"))[0];
  //交易所多头保证金率
  t->ExchLongMarginRatioByMoney =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ExchLongMarginRatioByMoney"));
  //不跟随交易所投资者多头保证金率
  t->NoLongMarginRatioByMoney =   PyFloat_AsDouble(PyObject_GetAttrString(p, "NoLongMarginRatioByMoney"));
  //不跟随交易所投资者空头保证金率
  t->NoShortMarginRatioByMoney =   PyFloat_AsDouble(PyObject_GetAttrString(p, "NoShortMarginRatioByMoney"));
  //交易所空头保证金率
  t->ExchShortMarginRatioByMoney =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ExchShortMarginRatioByMoney"));

  return t;
};

//Fens用户信息
PyObject * new_CThostFtdcFensUserInfoField(CThostFtdcFensUserInfoField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcFensUserInfoField", (char*)"yyc",
p->BrokerID, p->UserID, p->LoginMode);
}
CThostFtdcFensUserInfoField * from_CThostFtdcFensUserInfoField(PyObject * p){
  CThostFtdcFensUserInfoField *t = (CThostFtdcFensUserInfoField *)calloc(1, sizeof(CThostFtdcFensUserInfoField));
  memset(t,0,sizeof(CThostFtdcFensUserInfoField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //登录模式
  //enum类型
  //THOST_FTDC_LM_Trade -> '0', 交易
  //THOST_FTDC_LM_Transfer -> '1', 转账
  t->LoginMode =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LoginMode"),"gbk","Error!"))[0];

  return t;
};

//查询经纪公司交易算法
PyObject * new_CThostFtdcQryBrokerTradingAlgosField(CThostFtdcQryBrokerTradingAlgosField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryBrokerTradingAlgosField", (char*)"yyy",
p->BrokerID, p->ExchangeID, p->InstrumentID);
}
CThostFtdcQryBrokerTradingAlgosField * from_CThostFtdcQryBrokerTradingAlgosField(PyObject * p){
  CThostFtdcQryBrokerTradingAlgosField *t = (CThostFtdcQryBrokerTradingAlgosField *)calloc(1, sizeof(CThostFtdcQryBrokerTradingAlgosField));
  memset(t,0,sizeof(CThostFtdcQryBrokerTradingAlgosField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));

  return t;
};

//会员编码和经纪公司编码对照表
PyObject * new_CThostFtdcPartBrokerField(CThostFtdcPartBrokerField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcPartBrokerField", (char*)"iyyy",
p->IsActive, p->BrokerID, p->ExchangeID, p->ParticipantID);
}
CThostFtdcPartBrokerField * from_CThostFtdcPartBrokerField(PyObject * p){
  CThostFtdcPartBrokerField *t = (CThostFtdcPartBrokerField *)calloc(1, sizeof(CThostFtdcPartBrokerField));
  memset(t,0,sizeof(CThostFtdcPartBrokerField));
  //是否活跃
  t->IsActive =   PyLong_AsLong(PyObject_GetAttrString(p, "IsActive"));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //会员代码
  strcpy(t->ParticipantID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ParticipantID"),"gbk","Error!")));

  return t;
};

//查询最大报单数量
PyObject * new_CThostFtdcQueryMaxOrderVolumeField(CThostFtdcQueryMaxOrderVolumeField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQueryMaxOrderVolumeField", (char*)"yccicyy",
p->InstrumentID, p->OffsetFlag, p->HedgeFlag, p->MaxVolume, p->Direction, p->BrokerID, p->InvestorID);
}
CThostFtdcQueryMaxOrderVolumeField * from_CThostFtdcQueryMaxOrderVolumeField(PyObject * p){
  CThostFtdcQueryMaxOrderVolumeField *t = (CThostFtdcQueryMaxOrderVolumeField *)calloc(1, sizeof(CThostFtdcQueryMaxOrderVolumeField));
  memset(t,0,sizeof(CThostFtdcQueryMaxOrderVolumeField));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //开平标志
  //enum类型
  //THOST_FTDC_OF_Close -> '1', 平仓
  //THOST_FTDC_OF_CloseYesterday -> '4', 平昨
  //THOST_FTDC_OF_CloseToday -> '3', 平今
  //THOST_FTDC_OF_Open -> '0', 开仓
  //THOST_FTDC_OF_LocalForceClose -> '6', 本地强平
  //THOST_FTDC_OF_ForceClose -> '2', 强平
  //THOST_FTDC_OF_ForceOff -> '5', 强减
  t->OffsetFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OffsetFlag"),"gbk","Error!"))[0];
  //投机套保标志
  //enum类型
  //THOST_FTDC_HF_Hedge -> '3', 套保
  //THOST_FTDC_HF_Arbitrage -> '2', 套利
  //THOST_FTDC_HF_Speculation -> '1', 投机
  t->HedgeFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "HedgeFlag"),"gbk","Error!"))[0];
  //最大允许报单数量
  t->MaxVolume =   PyLong_AsLong(PyObject_GetAttrString(p, "MaxVolume"));
  //买卖方向
  //enum类型
  //THOST_FTDC_D_Buy -> '0', 买
  //THOST_FTDC_D_Sell -> '1', 卖
  t->Direction =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Direction"),"gbk","Error!"))[0];
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));

  return t;
};

//查询交易员报盘机
PyObject * new_CThostFtdcQryTraderOfferField(CThostFtdcQryTraderOfferField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryTraderOfferField", (char*)"yyy",
p->ExchangeID, p->TraderID, p->ParticipantID);
}
CThostFtdcQryTraderOfferField * from_CThostFtdcQryTraderOfferField(PyObject * p){
  CThostFtdcQryTraderOfferField *t = (CThostFtdcQryTraderOfferField *)calloc(1, sizeof(CThostFtdcQryTraderOfferField));
  memset(t,0,sizeof(CThostFtdcQryTraderOfferField));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //交易所交易员代码
  strcpy(t->TraderID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TraderID"),"gbk","Error!")));
  //会员代码
  strcpy(t->ParticipantID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ParticipantID"),"gbk","Error!")));

  return t;
};

//用户会话
PyObject * new_CThostFtdcUserSessionField(CThostFtdcUserSessionField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcUserSessionField", (char*)"yyyyyyyiiyy",
p->MacAddress, p->UserProductInfo, p->LoginDate, p->ProtocolInfo, p->LoginTime, p->InterfaceProductInfo, p->BrokerID, p->FrontID, p->SessionID, p->UserID, p->IPAddress);
}
CThostFtdcUserSessionField * from_CThostFtdcUserSessionField(PyObject * p){
  CThostFtdcUserSessionField *t = (CThostFtdcUserSessionField *)calloc(1, sizeof(CThostFtdcUserSessionField));
  memset(t,0,sizeof(CThostFtdcUserSessionField));
  //Mac地址
  strcpy(t->MacAddress, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "MacAddress"),"gbk","Error!")));
  //用户端产品信息
  strcpy(t->UserProductInfo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserProductInfo"),"gbk","Error!")));
  //登录日期
  strcpy(t->LoginDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LoginDate"),"gbk","Error!")));
  //协议信息
  strcpy(t->ProtocolInfo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ProtocolInfo"),"gbk","Error!")));
  //登录时间
  strcpy(t->LoginTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LoginTime"),"gbk","Error!")));
  //接口端产品信息
  strcpy(t->InterfaceProductInfo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InterfaceProductInfo"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //前置编号
  t->FrontID =   PyLong_AsLong(PyObject_GetAttrString(p, "FrontID"));
  //会话编号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //IP地址
  strcpy(t->IPAddress, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IPAddress"),"gbk","Error!")));

  return t;
};

//报单
PyObject * new_CThostFtdcOrderField(CThostFtdcOrderField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcOrderField", (char*)"yiccyiiiydyiiyyiyyycccyyiycyiyyiycyyiicyyiiiiycyycyyydyyy",
p->InsertDate, p->ZCETotalTradedVolume, p->Direction, p->OrderSubmitStatus, p->BrokerID, p->SessionID, p->MinVolume, p->VolumeTotalOriginal, p->CancelTime, p->StopPrice, p->InsertTime, p->BrokerOrderSeq, p->VolumeTraded, p->ExchangeInstID, p->ParticipantID, p->SettlementID, p->ActiveTime, p->GTDDate, p->OrderRef, p->ContingentCondition, p->VolumeCondition, p->OrderType, p->OrderLocalID, p->ActiveUserID, p->NotifySequence, p->RelativeOrderSysID, p->OrderPriceType, p->SuspendTime, p->VolumeTotal, p->ClientID, p->StatusMsg, p->InstallID, p->InvestorID, p->ForceCloseReason, p->TraderID, p->InstrumentID, p->FrontID, p->UserForceClose, p->OrderStatus, p->ExchangeID, p->OrderSysID, p->RequestID, p->IsAutoSuspend, p->IsSwapOrder, p->SequenceNo, p->CombOffsetFlag, p->OrderSource, p->TradingDay, p->ClearingPartID, p->TimeCondition, p->UpdateTime, p->BusinessUnit, p->UserProductInfo, p->LimitPrice, p->CombHedgeFlag, p->ActiveTraderID, p->UserID);
}
CThostFtdcOrderField * from_CThostFtdcOrderField(PyObject * p){
  CThostFtdcOrderField *t = (CThostFtdcOrderField *)calloc(1, sizeof(CThostFtdcOrderField));
  memset(t,0,sizeof(CThostFtdcOrderField));
  //报单日期
  strcpy(t->InsertDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InsertDate"),"gbk","Error!")));
  //郑商所成交数量
  t->ZCETotalTradedVolume =   PyLong_AsLong(PyObject_GetAttrString(p, "ZCETotalTradedVolume"));
  //买卖方向
  //enum类型
  //THOST_FTDC_D_Buy -> '0', 买
  //THOST_FTDC_D_Sell -> '1', 卖
  t->Direction =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Direction"),"gbk","Error!"))[0];
  //报单提交状态
  //enum类型
  //THOST_FTDC_OSS_ModifyRejected -> '6', 改单已经被拒绝
  //THOST_FTDC_OSS_InsertRejected -> '4', 报单已经被拒绝
  //THOST_FTDC_OSS_CancelSubmitted -> '1', 撤单已经提交
  //THOST_FTDC_OSS_ModifySubmitted -> '2', 修改已经提交
  //THOST_FTDC_OSS_Accepted -> '3', 已经接受
  //THOST_FTDC_OSS_InsertSubmitted -> '0', 已经提交
  //THOST_FTDC_OSS_CancelRejected -> '5', 撤单已经被拒绝
  t->OrderSubmitStatus =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderSubmitStatus"),"gbk","Error!"))[0];
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //会话编号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //最小成交量
  t->MinVolume =   PyLong_AsLong(PyObject_GetAttrString(p, "MinVolume"));
  //数量
  t->VolumeTotalOriginal =   PyLong_AsLong(PyObject_GetAttrString(p, "VolumeTotalOriginal"));
  //撤销时间
  strcpy(t->CancelTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CancelTime"),"gbk","Error!")));
  //止损价
  t->StopPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "StopPrice"));
  //委托时间
  strcpy(t->InsertTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InsertTime"),"gbk","Error!")));
  //经纪公司报单编号
  t->BrokerOrderSeq =   PyLong_AsLong(PyObject_GetAttrString(p, "BrokerOrderSeq"));
  //今成交数量
  t->VolumeTraded =   PyLong_AsLong(PyObject_GetAttrString(p, "VolumeTraded"));
  //合约在交易所的代码
  strcpy(t->ExchangeInstID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeInstID"),"gbk","Error!")));
  //会员代码
  strcpy(t->ParticipantID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ParticipantID"),"gbk","Error!")));
  //结算编号
  t->SettlementID =   PyLong_AsLong(PyObject_GetAttrString(p, "SettlementID"));
  //激活时间
  strcpy(t->ActiveTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ActiveTime"),"gbk","Error!")));
  //GTD日期
  strcpy(t->GTDDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "GTDDate"),"gbk","Error!")));
  //报单引用
  strcpy(t->OrderRef, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderRef"),"gbk","Error!")));
  //触发条件
  //enum类型
  //THOST_FTDC_CC_AskPriceLesserThanStopPrice -> 'B', 卖一价小于条件价
  //THOST_FTDC_CC_Touch -> '2', 止损
  //THOST_FTDC_CC_BidPriceGreaterThanStopPrice -> 'D', 买一价大于条件价
  //THOST_FTDC_CC_LastPriceGreaterEqualStopPrice -> '6', 最新价大于等于条件价
  //THOST_FTDC_CC_AskPriceLesserEqualStopPrice -> 'C', 卖一价小于等于条件价
  //THOST_FTDC_CC_LastPriceGreaterThanStopPrice -> '5', 最新价大于条件价
  //THOST_FTDC_CC_AskPriceGreaterEqualStopPrice -> 'A', 卖一价大于等于条件价
  //THOST_FTDC_CC_LastPriceLesserThanStopPrice -> '7', 最新价小于条件价
  //THOST_FTDC_CC_BidPriceGreaterEqualStopPrice -> 'E', 买一价大于等于条件价
  //THOST_FTDC_CC_Immediately -> '1', 立即
  //THOST_FTDC_CC_LastPriceLesserEqualStopPrice -> '8', 最新价小于等于条件价
  //THOST_FTDC_CC_AskPriceGreaterThanStopPrice -> '9', 卖一价大于条件价
  //THOST_FTDC_CC_BidPriceLesserEqualStopPrice -> 'H', 买一价小于等于条件价
  //THOST_FTDC_CC_ParkedOrder -> '4', 预埋单
  //THOST_FTDC_CC_TouchProfit -> '3', 止赢
  //THOST_FTDC_CC_BidPriceLesserThanStopPrice -> 'F', 买一价小于条件价
  t->ContingentCondition =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ContingentCondition"),"gbk","Error!"))[0];
  //成交量类型
  //enum类型
  //THOST_FTDC_VC_CV -> '3', 全部数量
  //THOST_FTDC_VC_MV -> '2', 最小数量
  //THOST_FTDC_VC_AV -> '1', 任何数量
  t->VolumeCondition =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "VolumeCondition"),"gbk","Error!"))[0];
  //报单类型
  //enum类型
  //THOST_FTDC_ORDT_DeriveFromCombination -> '2', 组合衍生
  //THOST_FTDC_ORDT_Normal -> '0', 正常
  //THOST_FTDC_ORDT_Combination -> '3', 组合报单
  //THOST_FTDC_ORDT_DeriveFromQuote -> '1', 报价衍生
  //THOST_FTDC_ORDT_Swap -> '5', 互换单
  //THOST_FTDC_ORDT_ConditionalOrder -> '4', 条件单
  t->OrderType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderType"),"gbk","Error!"))[0];
  //本地报单编号
  strcpy(t->OrderLocalID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderLocalID"),"gbk","Error!")));
  //操作用户代码
  strcpy(t->ActiveUserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ActiveUserID"),"gbk","Error!")));
  //报单提示序号
  t->NotifySequence =   PyLong_AsLong(PyObject_GetAttrString(p, "NotifySequence"));
  //相关报单
  strcpy(t->RelativeOrderSysID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "RelativeOrderSysID"),"gbk","Error!")));
  //报单价格条件
  //enum类型
  //THOST_FTDC_OPT_LastPricePlusOneTicks -> '5', 最新价浮动上浮1个ticks
  //THOST_FTDC_OPT_LastPricePlusTwoTicks -> '6', 最新价浮动上浮2个ticks
  //THOST_FTDC_OPT_BidPrice1PlusTwoTicks -> 'E', 买一价浮动上浮2个ticks
  //THOST_FTDC_OPT_AnyPrice -> '1', 任意价
  //THOST_FTDC_OPT_AskPrice1PlusTwoTicks -> 'A', 卖一价浮动上浮2个ticks
  //THOST_FTDC_OPT_AskPrice1PlusThreeTicks -> 'B', 卖一价浮动上浮3个ticks
  //THOST_FTDC_OPT_BidPrice1PlusThreeTicks -> 'F', 买一价浮动上浮3个ticks
  //THOST_FTDC_OPT_BestPrice -> '3', 最优价
  //THOST_FTDC_OPT_LimitPrice -> '2', 限价
  //THOST_FTDC_OPT_BidPrice1 -> 'C', 买一价
  //THOST_FTDC_OPT_AskPrice1PlusOneTicks -> '9', 卖一价浮动上浮1个ticks
  //THOST_FTDC_OPT_LastPricePlusThreeTicks -> '7', 最新价浮动上浮3个ticks
  //THOST_FTDC_OPT_LastPrice -> '4', 最新价
  //THOST_FTDC_OPT_AskPrice1 -> '8', 卖一价
  //THOST_FTDC_OPT_BidPrice1PlusOneTicks -> 'D', 买一价浮动上浮1个ticks
  t->OrderPriceType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderPriceType"),"gbk","Error!"))[0];
  //挂起时间
  strcpy(t->SuspendTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "SuspendTime"),"gbk","Error!")));
  //剩余数量
  t->VolumeTotal =   PyLong_AsLong(PyObject_GetAttrString(p, "VolumeTotal"));
  //客户代码
  strcpy(t->ClientID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ClientID"),"gbk","Error!")));
  //状态信息
  strcpy(t->StatusMsg, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "StatusMsg"),"gbk","Error!")));
  //安装编号
  t->InstallID =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallID"));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //强平原因
  //enum类型
  //THOST_FTDC_FCC_Other -> '6', 其它
  //THOST_FTDC_FCC_ClientOverPositionLimit -> '2', 客户超仓
  //THOST_FTDC_FCC_NotMultiple -> '4', 持仓非整数倍
  //THOST_FTDC_FCC_PersonDeliv -> '7', 自然人临近交割
  //THOST_FTDC_FCC_NotForceClose -> '0', 非强平
  //THOST_FTDC_FCC_Violation -> '5', 违规
  //THOST_FTDC_FCC_MemberOverPositionLimit -> '3', 会员超仓
  //THOST_FTDC_FCC_LackDeposit -> '1', 资金不足
  t->ForceCloseReason =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ForceCloseReason"),"gbk","Error!"))[0];
  //交易所交易员代码
  strcpy(t->TraderID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TraderID"),"gbk","Error!")));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //前置编号
  t->FrontID =   PyLong_AsLong(PyObject_GetAttrString(p, "FrontID"));
  //用户强评标志
  t->UserForceClose =   PyLong_AsLong(PyObject_GetAttrString(p, "UserForceClose"));
  //报单状态
  //enum类型
  //THOST_FTDC_OST_NoTradeQueueing -> '3', 未成交还在队列中
  //THOST_FTDC_OST_Touched -> 'c', 已触发
  //THOST_FTDC_OST_PartTradedQueueing -> '1', 部分成交还在队列中
  //THOST_FTDC_OST_NotTouched -> 'b', 尚未触发
  //THOST_FTDC_OST_NoTradeNotQueueing -> '4', 未成交不在队列中
  //THOST_FTDC_OST_PartTradedNotQueueing -> '2', 部分成交不在队列中
  //THOST_FTDC_OST_Unknown -> 'a', 未知
  //THOST_FTDC_OST_Canceled -> '5', 撤单
  //THOST_FTDC_OST_AllTraded -> '0', 全部成交
  t->OrderStatus =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderStatus"),"gbk","Error!"))[0];
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //报单编号
  strcpy(t->OrderSysID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderSysID"),"gbk","Error!")));
  //请求编号
  t->RequestID =   PyLong_AsLong(PyObject_GetAttrString(p, "RequestID"));
  //自动挂起标志
  t->IsAutoSuspend =   PyLong_AsLong(PyObject_GetAttrString(p, "IsAutoSuspend"));
  //互换单标志
  t->IsSwapOrder =   PyLong_AsLong(PyObject_GetAttrString(p, "IsSwapOrder"));
  //序号
  t->SequenceNo =   PyLong_AsLong(PyObject_GetAttrString(p, "SequenceNo"));
  //组合开平标志
  strcpy(t->CombOffsetFlag, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CombOffsetFlag"),"gbk","Error!")));
  //报单来源
  //enum类型
  //THOST_FTDC_OSRC_Administrator -> '1', 来自管理员
  //THOST_FTDC_OSRC_Participant -> '0', 来自参与者
  t->OrderSource =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderSource"),"gbk","Error!"))[0];
  //交易日
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //结算会员编号
  strcpy(t->ClearingPartID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ClearingPartID"),"gbk","Error!")));
  //有效期类型
  //enum类型
  //THOST_FTDC_TC_IOC -> '1', 立即完成，否则撤销
  //THOST_FTDC_TC_GFS -> '2', 本节有效
  //THOST_FTDC_TC_GTD -> '4', 指定日期前有效
  //THOST_FTDC_TC_GFA -> '6', 集合竞价有效
  //THOST_FTDC_TC_GTC -> '5', 撤销前有效
  //THOST_FTDC_TC_GFD -> '3', 当日有效
  t->TimeCondition =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TimeCondition"),"gbk","Error!"))[0];
  //最后修改时间
  strcpy(t->UpdateTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UpdateTime"),"gbk","Error!")));
  //业务单元
  strcpy(t->BusinessUnit, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BusinessUnit"),"gbk","Error!")));
  //用户端产品信息
  strcpy(t->UserProductInfo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserProductInfo"),"gbk","Error!")));
  //价格
  t->LimitPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LimitPrice"));
  //组合投机套保标志
  strcpy(t->CombHedgeFlag, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CombHedgeFlag"),"gbk","Error!")));
  //最后修改交易所交易员代码
  strcpy(t->ActiveTraderID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ActiveTraderID"),"gbk","Error!")));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));

  return t;
};

//查询经纪公司会员代码
PyObject * new_CThostFtdcQryPartBrokerField(CThostFtdcQryPartBrokerField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryPartBrokerField", (char*)"yyy",
p->BrokerID, p->ExchangeID, p->ParticipantID);
}
CThostFtdcQryPartBrokerField * from_CThostFtdcQryPartBrokerField(PyObject * p){
  CThostFtdcQryPartBrokerField *t = (CThostFtdcQryPartBrokerField *)calloc(1, sizeof(CThostFtdcQryPartBrokerField));
  memset(t,0,sizeof(CThostFtdcQryPartBrokerField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //会员代码
  strcpy(t->ParticipantID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ParticipantID"),"gbk","Error!")));

  return t;
};

//查询结算信息确认域
PyObject * new_CThostFtdcQrySettlementInfoConfirmField(CThostFtdcQrySettlementInfoConfirmField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQrySettlementInfoConfirmField", (char*)"yy",
p->BrokerID, p->InvestorID);
}
CThostFtdcQrySettlementInfoConfirmField * from_CThostFtdcQrySettlementInfoConfirmField(PyObject * p){
  CThostFtdcQrySettlementInfoConfirmField *t = (CThostFtdcQrySettlementInfoConfirmField *)calloc(1, sizeof(CThostFtdcQrySettlementInfoConfirmField));
  memset(t,0,sizeof(CThostFtdcQrySettlementInfoConfirmField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));

  return t;
};

//查询管理用户功能权限
PyObject * new_CThostFtdcQrySuperUserFunctionField(CThostFtdcQrySuperUserFunctionField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQrySuperUserFunctionField", (char*)"y",
p->UserID);
}
CThostFtdcQrySuperUserFunctionField * from_CThostFtdcQrySuperUserFunctionField(PyObject * p){
  CThostFtdcQrySuperUserFunctionField *t = (CThostFtdcQrySuperUserFunctionField *)calloc(1, sizeof(CThostFtdcQrySuperUserFunctionField));
  memset(t,0,sizeof(CThostFtdcQrySuperUserFunctionField));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));

  return t;
};

//查询交易所调整保证金率
PyObject * new_CThostFtdcQryExchangeMarginRateAdjustField(CThostFtdcQryExchangeMarginRateAdjustField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryExchangeMarginRateAdjustField", (char*)"yyc",
p->BrokerID, p->InstrumentID, p->HedgeFlag);
}
CThostFtdcQryExchangeMarginRateAdjustField * from_CThostFtdcQryExchangeMarginRateAdjustField(PyObject * p){
  CThostFtdcQryExchangeMarginRateAdjustField *t = (CThostFtdcQryExchangeMarginRateAdjustField *)calloc(1, sizeof(CThostFtdcQryExchangeMarginRateAdjustField));
  memset(t,0,sizeof(CThostFtdcQryExchangeMarginRateAdjustField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //投机套保标志
  //enum类型
  //THOST_FTDC_HF_Hedge -> '3', 套保
  //THOST_FTDC_HF_Arbitrage -> '2', 套利
  //THOST_FTDC_HF_Speculation -> '1', 投机
  t->HedgeFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "HedgeFlag"),"gbk","Error!"))[0];

  return t;
};

//查询指定流水号的交易结果请求
PyObject * new_CThostFtdcReqQueryTradeResultBySerialField(CThostFtdcReqQueryTradeResultBySerialField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcReqQueryTradeResultBySerialField", (char*)"yyyiyycdiyyyyycyccyyyyyyyi",
p->TradingDay, p->TradeTime, p->BrokerID, p->SessionID, p->IdentifiedCardNo, p->AccountID, p->RefrenceIssureType, p->TradeAmount, p->Reference, p->BankID, p->CurrencyID, p->BankAccount, p->Digest, p->Password, p->LastFragment, p->TradeDate, p->CustType, p->IdCardType, p->BankSerial, p->TradeCode, p->CustomerName, p->RefrenceIssure, p->BankPassWord, p->BankBranchID, p->BrokerBranchID, p->PlateSerial);
}
CThostFtdcReqQueryTradeResultBySerialField * from_CThostFtdcReqQueryTradeResultBySerialField(PyObject * p){
  CThostFtdcReqQueryTradeResultBySerialField *t = (CThostFtdcReqQueryTradeResultBySerialField *)calloc(1, sizeof(CThostFtdcReqQueryTradeResultBySerialField));
  memset(t,0,sizeof(CThostFtdcReqQueryTradeResultBySerialField));
  //交易系统日期
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //交易时间
  strcpy(t->TradeTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeTime"),"gbk","Error!")));
  //期商代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //会话号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //证件号码
  strcpy(t->IdentifiedCardNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdentifiedCardNo"),"gbk","Error!")));
  //投资者帐号
  strcpy(t->AccountID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AccountID"),"gbk","Error!")));
  //本流水号发布者的机构类型
  //enum类型
  //THOST_FTDC_TS_Store -> '2', 券商
  //THOST_FTDC_TS_Future -> '1', 期商
  //THOST_FTDC_TS_Bank -> '0', 银行
  t->RefrenceIssureType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "RefrenceIssureType"),"gbk","Error!"))[0];
  //转帐金额
  t->TradeAmount =   PyFloat_AsDouble(PyObject_GetAttrString(p, "TradeAmount"));
  //流水号
  t->Reference =   PyLong_AsLong(PyObject_GetAttrString(p, "Reference"));
  //银行代码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //币种代码
  strcpy(t->CurrencyID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrencyID"),"gbk","Error!")));
  //银行帐号
  strcpy(t->BankAccount, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccount"),"gbk","Error!")));
  //摘要
  strcpy(t->Digest, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Digest"),"gbk","Error!")));
  //期货密码
  strcpy(t->Password, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Password"),"gbk","Error!")));
  //最后分片标志
  //enum类型
  //THOST_FTDC_LF_No -> '1', 不是最后分片
  //THOST_FTDC_LF_Yes -> '0', 是最后分片
  t->LastFragment =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LastFragment"),"gbk","Error!"))[0];
  //交易日期
  strcpy(t->TradeDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeDate"),"gbk","Error!")));
  //客户类型
  //enum类型
  //THOST_FTDC_CUSTT_Person -> '0', 自然人
  //THOST_FTDC_CUSTT_Institution -> '1', 机构户
  t->CustType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustType"),"gbk","Error!"))[0];
  //证件类型
  //enum类型
  //THOST_FTDC_ICT_TaiwanCompatriotIDCard -> '7', 台胞证
  //THOST_FTDC_ICT_Passport -> '6', 护照
  //THOST_FTDC_ICT_LicenseNo -> '9', 营业执照号
  //THOST_FTDC_ICT_OtherCard -> 'x', 其他证件
  //THOST_FTDC_ICT_IDCard -> '1', 身份证
  //THOST_FTDC_ICT_EID -> '0', 组织机构代码
  //THOST_FTDC_ICT_TaxNo -> 'A', 税务登记号
  //THOST_FTDC_ICT_HomeComingCard -> '8', 回乡证
  //THOST_FTDC_ICT_OfficerIDCard -> '2', 军官证
  //THOST_FTDC_ICT_HouseholdRegister -> '5', 户口簿
  //THOST_FTDC_ICT_SoldierIDCard -> '4', 士兵证
  //THOST_FTDC_ICT_PoliceIDCard -> '3', 警官证
  t->IdCardType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdCardType"),"gbk","Error!"))[0];
  //银行流水号
  strcpy(t->BankSerial, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSerial"),"gbk","Error!")));
  //业务功能码
  strcpy(t->TradeCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeCode"),"gbk","Error!")));
  //客户姓名
  strcpy(t->CustomerName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustomerName"),"gbk","Error!")));
  //本流水号发布者机构编码
  strcpy(t->RefrenceIssure, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "RefrenceIssure"),"gbk","Error!")));
  //银行密码
  strcpy(t->BankPassWord, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankPassWord"),"gbk","Error!")));
  //银行分支机构代码
  strcpy(t->BankBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBranchID"),"gbk","Error!")));
  //期商分支机构代码
  strcpy(t->BrokerBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerBranchID"),"gbk","Error!")));
  //银期平台消息流水号
  t->PlateSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "PlateSerial"));

  return t;
};

//查询交易所报单操作
PyObject * new_CThostFtdcQryExchangeOrderActionField(CThostFtdcQryExchangeOrderActionField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryExchangeOrderActionField", (char*)"yyyy",
p->ClientID, p->ExchangeID, p->TraderID, p->ParticipantID);
}
CThostFtdcQryExchangeOrderActionField * from_CThostFtdcQryExchangeOrderActionField(PyObject * p){
  CThostFtdcQryExchangeOrderActionField *t = (CThostFtdcQryExchangeOrderActionField *)calloc(1, sizeof(CThostFtdcQryExchangeOrderActionField));
  memset(t,0,sizeof(CThostFtdcQryExchangeOrderActionField));
  //客户代码
  strcpy(t->ClientID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ClientID"),"gbk","Error!")));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //交易所交易员代码
  strcpy(t->TraderID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TraderID"),"gbk","Error!")));
  //会员代码
  strcpy(t->ParticipantID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ParticipantID"),"gbk","Error!")));

  return t;
};

//期商签到通知
PyObject * new_CThostFtdcNotifyFutureSignInField(CThostFtdcNotifyFutureSignInField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcNotifyFutureSignInField", (char*)"yyiiyiyyyyyyyciyyyyyyiyyi",
p->TradeTime, p->DeviceID, p->ErrorID, p->InstallID, p->BrokerID, p->SessionID, p->BankID, p->CurrencyID, p->ErrorMsg, p->PinKey, p->OperNo, p->MacKey, p->Digest, p->LastFragment, p->RequestID, p->TradeDate, p->UserID, p->TradingDay, p->BankSerial, p->BrokerIDByBank, p->TradeCode, p->TID, p->BankBranchID, p->BrokerBranchID, p->PlateSerial);
}
CThostFtdcNotifyFutureSignInField * from_CThostFtdcNotifyFutureSignInField(PyObject * p){
  CThostFtdcNotifyFutureSignInField *t = (CThostFtdcNotifyFutureSignInField *)calloc(1, sizeof(CThostFtdcNotifyFutureSignInField));
  memset(t,0,sizeof(CThostFtdcNotifyFutureSignInField));
  //交易时间
  strcpy(t->TradeTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeTime"),"gbk","Error!")));
  //渠道标志
  strcpy(t->DeviceID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "DeviceID"),"gbk","Error!")));
  //错误代码
  t->ErrorID =   PyLong_AsLong(PyObject_GetAttrString(p, "ErrorID"));
  //安装编号
  t->InstallID =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallID"));
  //期商代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //会话号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //银行代码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //币种代码
  strcpy(t->CurrencyID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrencyID"),"gbk","Error!")));
  //错误信息
  strcpy(t->ErrorMsg, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ErrorMsg"),"gbk","Error!")));
  //PIN密钥
  strcpy(t->PinKey, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "PinKey"),"gbk","Error!")));
  //交易柜员
  strcpy(t->OperNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OperNo"),"gbk","Error!")));
  //MAC密钥
  strcpy(t->MacKey, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "MacKey"),"gbk","Error!")));
  //摘要
  strcpy(t->Digest, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Digest"),"gbk","Error!")));
  //最后分片标志
  //enum类型
  //THOST_FTDC_LF_No -> '1', 不是最后分片
  //THOST_FTDC_LF_Yes -> '0', 是最后分片
  t->LastFragment =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LastFragment"),"gbk","Error!"))[0];
  //请求编号
  t->RequestID =   PyLong_AsLong(PyObject_GetAttrString(p, "RequestID"));
  //交易日期
  strcpy(t->TradeDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeDate"),"gbk","Error!")));
  //用户标识
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //交易系统日期
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //银行流水号
  strcpy(t->BankSerial, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSerial"),"gbk","Error!")));
  //期货公司银行编码
  strcpy(t->BrokerIDByBank, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerIDByBank"),"gbk","Error!")));
  //业务功能码
  strcpy(t->TradeCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeCode"),"gbk","Error!")));
  //交易ID
  t->TID =   PyLong_AsLong(PyObject_GetAttrString(p, "TID"));
  //银行分支机构代码
  strcpy(t->BankBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBranchID"),"gbk","Error!")));
  //期商分支机构代码
  strcpy(t->BrokerBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerBranchID"),"gbk","Error!")));
  //银期平台消息流水号
  t->PlateSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "PlateSerial"));

  return t;
};

//查询预埋撤单
PyObject * new_CThostFtdcQryParkedOrderActionField(CThostFtdcQryParkedOrderActionField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryParkedOrderActionField", (char*)"yyyy",
p->BrokerID, p->InvestorID, p->ExchangeID, p->InstrumentID);
}
CThostFtdcQryParkedOrderActionField * from_CThostFtdcQryParkedOrderActionField(PyObject * p){
  CThostFtdcQryParkedOrderActionField *t = (CThostFtdcQryParkedOrderActionField *)calloc(1, sizeof(CThostFtdcQryParkedOrderActionField));
  memset(t,0,sizeof(CThostFtdcQryParkedOrderActionField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));

  return t;
};

//UDP组播组信息
PyObject * new_CThostFtdcMulticastGroupInfoField(CThostFtdcMulticastGroupInfoField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcMulticastGroupInfoField", (char*)"iyy",
p->GroupPort, p->SourceIP, p->GroupIP);
}
CThostFtdcMulticastGroupInfoField * from_CThostFtdcMulticastGroupInfoField(PyObject * p){
  CThostFtdcMulticastGroupInfoField *t = (CThostFtdcMulticastGroupInfoField *)calloc(1, sizeof(CThostFtdcMulticastGroupInfoField));
  memset(t,0,sizeof(CThostFtdcMulticastGroupInfoField));
  //组播组IP端口
  t->GroupPort =   PyLong_AsLong(PyObject_GetAttrString(p, "GroupPort"));
  //源地址
  strcpy(t->SourceIP, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "SourceIP"),"gbk","Error!")));
  //组播组IP地址
  strcpy(t->GroupIP, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "GroupIP"),"gbk","Error!")));

  return t;
};

//投资者组合持仓明细
PyObject * new_CThostFtdcInvestorPositionCombineDetailField(CThostFtdcInvestorPositionCombineDetailField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcInvestorPositionCombineDetailField", (char*)"dyyyydciyydyiyiciydi",
p->ExchMargin, p->ComTradeID, p->TradingDay, p->TradeID, p->CombInstrumentID, p->Margin, p->Direction, p->LegMultiple, p->BrokerID, p->InvestorID, p->MarginRateByVolume, p->OpenDate, p->SettlementID, p->InstrumentID, p->TradeGroupID, p->HedgeFlag, p->LegID, p->ExchangeID, p->MarginRateByMoney, p->TotalAmt);
}
CThostFtdcInvestorPositionCombineDetailField * from_CThostFtdcInvestorPositionCombineDetailField(PyObject * p){
  CThostFtdcInvestorPositionCombineDetailField *t = (CThostFtdcInvestorPositionCombineDetailField *)calloc(1, sizeof(CThostFtdcInvestorPositionCombineDetailField));
  memset(t,0,sizeof(CThostFtdcInvestorPositionCombineDetailField));
  //交易所保证金
  t->ExchMargin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ExchMargin"));
  //组合编号
  strcpy(t->ComTradeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ComTradeID"),"gbk","Error!")));
  //交易日
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //撮合编号
  strcpy(t->TradeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeID"),"gbk","Error!")));
  //组合持仓合约编码
  strcpy(t->CombInstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CombInstrumentID"),"gbk","Error!")));
  //投资者保证金
  t->Margin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Margin"));
  //买卖
  //enum类型
  //THOST_FTDC_D_Buy -> '0', 买
  //THOST_FTDC_D_Sell -> '1', 卖
  t->Direction =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Direction"),"gbk","Error!"))[0];
  //单腿乘数
  t->LegMultiple =   PyLong_AsLong(PyObject_GetAttrString(p, "LegMultiple"));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //保证金率(按手数)
  t->MarginRateByVolume =   PyFloat_AsDouble(PyObject_GetAttrString(p, "MarginRateByVolume"));
  //开仓日期
  strcpy(t->OpenDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OpenDate"),"gbk","Error!")));
  //结算编号
  t->SettlementID =   PyLong_AsLong(PyObject_GetAttrString(p, "SettlementID"));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //成交组号
  t->TradeGroupID =   PyLong_AsLong(PyObject_GetAttrString(p, "TradeGroupID"));
  //投机套保标志
  //enum类型
  //THOST_FTDC_HF_Hedge -> '3', 套保
  //THOST_FTDC_HF_Arbitrage -> '2', 套利
  //THOST_FTDC_HF_Speculation -> '1', 投机
  t->HedgeFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "HedgeFlag"),"gbk","Error!"))[0];
  //单腿编号
  t->LegID =   PyLong_AsLong(PyObject_GetAttrString(p, "LegID"));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //保证金率
  t->MarginRateByMoney =   PyFloat_AsDouble(PyObject_GetAttrString(p, "MarginRateByMoney"));
  //持仓量
  t->TotalAmt =   PyLong_AsLong(PyObject_GetAttrString(p, "TotalAmt"));

  return t;
};

//查询投资者结算结果
PyObject * new_CThostFtdcQrySettlementInfoField(CThostFtdcQrySettlementInfoField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQrySettlementInfoField", (char*)"yyy",
p->BrokerID, p->InvestorID, p->TradingDay);
}
CThostFtdcQrySettlementInfoField * from_CThostFtdcQrySettlementInfoField(PyObject * p){
  CThostFtdcQrySettlementInfoField *t = (CThostFtdcQrySettlementInfoField *)calloc(1, sizeof(CThostFtdcQrySettlementInfoField));
  memset(t,0,sizeof(CThostFtdcQrySettlementInfoField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //交易日
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));

  return t;
};

//删除预埋单
PyObject * new_CThostFtdcRemoveParkedOrderField(CThostFtdcRemoveParkedOrderField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcRemoveParkedOrderField", (char*)"yyy",
p->ParkedOrderID, p->BrokerID, p->InvestorID);
}
CThostFtdcRemoveParkedOrderField * from_CThostFtdcRemoveParkedOrderField(PyObject * p){
  CThostFtdcRemoveParkedOrderField *t = (CThostFtdcRemoveParkedOrderField *)calloc(1, sizeof(CThostFtdcRemoveParkedOrderField));
  memset(t,0,sizeof(CThostFtdcRemoveParkedOrderField));
  //预埋报单编号
  strcpy(t->ParkedOrderID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ParkedOrderID"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));

  return t;
};

//资金账户基本准备金
PyObject * new_CThostFtdcTradingAccountReserveField(CThostFtdcTradingAccountReserveField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcTradingAccountReserveField", (char*)"dyy",
p->Reserve, p->BrokerID, p->InvestorID);
}
CThostFtdcTradingAccountReserveField * from_CThostFtdcTradingAccountReserveField(PyObject * p){
  CThostFtdcTradingAccountReserveField *t = (CThostFtdcTradingAccountReserveField *)calloc(1, sizeof(CThostFtdcTradingAccountReserveField));
  memset(t,0,sizeof(CThostFtdcTradingAccountReserveField));
  //基本准备金
  t->Reserve =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Reserve"));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));

  return t;
};

//正在同步中的合约保证金率
PyObject * new_CThostFtdcSyncingInstrumentMarginRateField(CThostFtdcSyncingInstrumentMarginRateField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcSyncingInstrumentMarginRateField", (char*)"yddciyycdd",
p->InstrumentID, p->ShortMarginRatioByVolume, p->LongMarginRatioByMoney, p->HedgeFlag, p->IsRelative, p->BrokerID, p->InvestorID, p->InvestorRange, p->LongMarginRatioByVolume, p->ShortMarginRatioByMoney);
}
CThostFtdcSyncingInstrumentMarginRateField * from_CThostFtdcSyncingInstrumentMarginRateField(PyObject * p){
  CThostFtdcSyncingInstrumentMarginRateField *t = (CThostFtdcSyncingInstrumentMarginRateField *)calloc(1, sizeof(CThostFtdcSyncingInstrumentMarginRateField));
  memset(t,0,sizeof(CThostFtdcSyncingInstrumentMarginRateField));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //空头保证金费
  t->ShortMarginRatioByVolume =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ShortMarginRatioByVolume"));
  //多头保证金率
  t->LongMarginRatioByMoney =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LongMarginRatioByMoney"));
  //投机套保标志
  //enum类型
  //THOST_FTDC_HF_Hedge -> '3', 套保
  //THOST_FTDC_HF_Arbitrage -> '2', 套利
  //THOST_FTDC_HF_Speculation -> '1', 投机
  t->HedgeFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "HedgeFlag"),"gbk","Error!"))[0];
  //是否相对交易所收取
  t->IsRelative =   PyLong_AsLong(PyObject_GetAttrString(p, "IsRelative"));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //投资者范围
  //enum类型
  //THOST_FTDC_IR_Single -> '3', 单一投资者
  //THOST_FTDC_IR_All -> '1', 所有
  //THOST_FTDC_IR_Group -> '2', 投资者组
  t->InvestorRange =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorRange"),"gbk","Error!"))[0];
  //多头保证金费
  t->LongMarginRatioByVolume =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LongMarginRatioByVolume"));
  //空头保证金率
  t->ShortMarginRatioByMoney =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ShortMarginRatioByMoney"));

  return t;
};

//转帐销户请求
PyObject * new_CThostFtdcReqCancelAccountField(CThostFtdcReqCancelAccountField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcReqCancelAccountField", (char*)"yyyyiycyycyyyccyycyyyycyiyyyiccycyyyyycyyciy",
p->TradingDay, p->DeviceID, p->BrokerID, p->ZipCode, p->SessionID, p->IdentifiedCardNo, p->IdCardType, p->MobilePhone, p->BankID, p->BankPwdFlag, p->OperNo, p->BankAccount, p->BankSecuAcc, p->LastFragment, p->Gender, p->Address, p->TradeDate, p->MoneyAccountStatus, p->AccountID, p->BankSerial, p->CustomerName, p->BankPassWord, p->CashExchangeCode, p->Digest, p->PlateSerial, p->Fax, p->EMail, p->TradeTime, p->InstallID, p->SecuPwdFlag, p->VerifyCertNoFlag, p->CurrencyID, p->BankSecuAccType, p->Password, p->BankBranchID, p->CountryCode, p->BrokerBranchID, p->UserID, p->CustType, p->BrokerIDByBank, p->TradeCode, p->BankAccType, p->TID, p->Telephone);
}
CThostFtdcReqCancelAccountField * from_CThostFtdcReqCancelAccountField(PyObject * p){
  CThostFtdcReqCancelAccountField *t = (CThostFtdcReqCancelAccountField *)calloc(1, sizeof(CThostFtdcReqCancelAccountField));
  memset(t,0,sizeof(CThostFtdcReqCancelAccountField));
  //交易系统日期
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //渠道标志
  strcpy(t->DeviceID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "DeviceID"),"gbk","Error!")));
  //期商代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //邮编
  strcpy(t->ZipCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ZipCode"),"gbk","Error!")));
  //会话号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //证件号码
  strcpy(t->IdentifiedCardNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdentifiedCardNo"),"gbk","Error!")));
  //证件类型
  //enum类型
  //THOST_FTDC_ICT_TaiwanCompatriotIDCard -> '7', 台胞证
  //THOST_FTDC_ICT_Passport -> '6', 护照
  //THOST_FTDC_ICT_LicenseNo -> '9', 营业执照号
  //THOST_FTDC_ICT_OtherCard -> 'x', 其他证件
  //THOST_FTDC_ICT_IDCard -> '1', 身份证
  //THOST_FTDC_ICT_EID -> '0', 组织机构代码
  //THOST_FTDC_ICT_TaxNo -> 'A', 税务登记号
  //THOST_FTDC_ICT_HomeComingCard -> '8', 回乡证
  //THOST_FTDC_ICT_OfficerIDCard -> '2', 军官证
  //THOST_FTDC_ICT_HouseholdRegister -> '5', 户口簿
  //THOST_FTDC_ICT_SoldierIDCard -> '4', 士兵证
  //THOST_FTDC_ICT_PoliceIDCard -> '3', 警官证
  t->IdCardType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdCardType"),"gbk","Error!"))[0];
  //手机
  strcpy(t->MobilePhone, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "MobilePhone"),"gbk","Error!")));
  //银行代码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //银行密码标志
  //enum类型
  //THOST_FTDC_BPWDF_NoCheck -> '0', 不核对
  //THOST_FTDC_BPWDF_BlankCheck -> '1', 明文核对
  //THOST_FTDC_BPWDF_EncryptCheck -> '2', 密文核对
  t->BankPwdFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankPwdFlag"),"gbk","Error!"))[0];
  //交易柜员
  strcpy(t->OperNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OperNo"),"gbk","Error!")));
  //银行帐号
  strcpy(t->BankAccount, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccount"),"gbk","Error!")));
  //期货单位帐号
  strcpy(t->BankSecuAcc, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSecuAcc"),"gbk","Error!")));
  //最后分片标志
  //enum类型
  //THOST_FTDC_LF_No -> '1', 不是最后分片
  //THOST_FTDC_LF_Yes -> '0', 是最后分片
  t->LastFragment =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LastFragment"),"gbk","Error!"))[0];
  //性别
  //enum类型
  //THOST_FTDC_GD_Male -> '1', 男
  //THOST_FTDC_GD_Unknown -> '0', 未知状态
  //THOST_FTDC_GD_Female -> '2', 女
  t->Gender =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Gender"),"gbk","Error!"))[0];
  //地址
  strcpy(t->Address, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Address"),"gbk","Error!")));
  //交易日期
  strcpy(t->TradeDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeDate"),"gbk","Error!")));
  //资金账户状态
  //enum类型
  //THOST_FTDC_MAS_Normal -> '0', 正常
  //THOST_FTDC_MAS_Cancel -> '1', 销户
  t->MoneyAccountStatus =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "MoneyAccountStatus"),"gbk","Error!"))[0];
  //投资者帐号
  strcpy(t->AccountID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AccountID"),"gbk","Error!")));
  //银行流水号
  strcpy(t->BankSerial, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSerial"),"gbk","Error!")));
  //客户姓名
  strcpy(t->CustomerName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustomerName"),"gbk","Error!")));
  //银行密码
  strcpy(t->BankPassWord, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankPassWord"),"gbk","Error!")));
  //汇钞标志
  //enum类型
  //THOST_FTDC_CEC_Cash -> '2', 钞
  //THOST_FTDC_CEC_Exchange -> '1', 汇
  t->CashExchangeCode =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CashExchangeCode"),"gbk","Error!"))[0];
  //摘要
  strcpy(t->Digest, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Digest"),"gbk","Error!")));
  //银期平台消息流水号
  t->PlateSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "PlateSerial"));
  //传真
  strcpy(t->Fax, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Fax"),"gbk","Error!")));
  //电子邮件
  strcpy(t->EMail, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "EMail"),"gbk","Error!")));
  //交易时间
  strcpy(t->TradeTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeTime"),"gbk","Error!")));
  //安装编号
  t->InstallID =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallID"));
  //期货资金密码核对标志
  //enum类型
  //THOST_FTDC_BPWDF_NoCheck -> '0', 不核对
  //THOST_FTDC_BPWDF_BlankCheck -> '1', 明文核对
  //THOST_FTDC_BPWDF_EncryptCheck -> '2', 密文核对
  t->SecuPwdFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "SecuPwdFlag"),"gbk","Error!"))[0];
  //验证客户证件号码标志
  //enum类型
  //THOST_FTDC_YNI_No -> '1', 否
  //THOST_FTDC_YNI_Yes -> '0', 是
  t->VerifyCertNoFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "VerifyCertNoFlag"),"gbk","Error!"))[0];
  //币种代码
  strcpy(t->CurrencyID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrencyID"),"gbk","Error!")));
  //期货单位帐号类型
  //enum类型
  //THOST_FTDC_BAT_SavingCard -> '2', 储蓄卡
  //THOST_FTDC_BAT_CreditCard -> '3', 信用卡
  //THOST_FTDC_BAT_BankBook -> '1', 银行存折
  t->BankSecuAccType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSecuAccType"),"gbk","Error!"))[0];
  //期货密码
  strcpy(t->Password, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Password"),"gbk","Error!")));
  //银行分支机构代码
  strcpy(t->BankBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBranchID"),"gbk","Error!")));
  //国家代码
  strcpy(t->CountryCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CountryCode"),"gbk","Error!")));
  //期商分支机构代码
  strcpy(t->BrokerBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerBranchID"),"gbk","Error!")));
  //用户标识
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //客户类型
  //enum类型
  //THOST_FTDC_CUSTT_Person -> '0', 自然人
  //THOST_FTDC_CUSTT_Institution -> '1', 机构户
  t->CustType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustType"),"gbk","Error!"))[0];
  //期货公司银行编码
  strcpy(t->BrokerIDByBank, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerIDByBank"),"gbk","Error!")));
  //业务功能码
  strcpy(t->TradeCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeCode"),"gbk","Error!")));
  //银行帐号类型
  //enum类型
  //THOST_FTDC_BAT_SavingCard -> '2', 储蓄卡
  //THOST_FTDC_BAT_CreditCard -> '3', 信用卡
  //THOST_FTDC_BAT_BankBook -> '1', 银行存折
  t->BankAccType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccType"),"gbk","Error!"))[0];
  //交易ID
  t->TID =   PyLong_AsLong(PyObject_GetAttrString(p, "TID"));
  //电话号码
  strcpy(t->Telephone, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Telephone"),"gbk","Error!")));

  return t;
};

//保证金监管系统经纪公司密钥
PyObject * new_CThostFtdcCFMMCBrokerKeyField(CThostFtdcCFMMCBrokerKeyField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcCFMMCBrokerKeyField", (char*)"yycyyiy",
p->CreateDate, p->CreateTime, p->KeyKind, p->CurrentKey, p->BrokerID, p->KeyID, p->ParticipantID);
}
CThostFtdcCFMMCBrokerKeyField * from_CThostFtdcCFMMCBrokerKeyField(PyObject * p){
  CThostFtdcCFMMCBrokerKeyField *t = (CThostFtdcCFMMCBrokerKeyField *)calloc(1, sizeof(CThostFtdcCFMMCBrokerKeyField));
  memset(t,0,sizeof(CThostFtdcCFMMCBrokerKeyField));
  //密钥生成日期
  strcpy(t->CreateDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CreateDate"),"gbk","Error!")));
  //密钥生成时间
  strcpy(t->CreateTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CreateTime"),"gbk","Error!")));
  //动态密钥类型
  //enum类型
  //THOST_FTDC_CFMMCKK_REQUEST -> 'R', 主动请求更新
  //THOST_FTDC_CFMMCKK_AUTO -> 'A', CFMMC自动更新
  //THOST_FTDC_CFMMCKK_MANUAL -> 'M', CFMMC手动更新
  t->KeyKind =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "KeyKind"),"gbk","Error!"))[0];
  //动态密钥
  strcpy(t->CurrentKey, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrentKey"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //密钥编号
  t->KeyID =   PyLong_AsLong(PyObject_GetAttrString(p, "KeyID"));
  //经纪公司统一编码
  strcpy(t->ParticipantID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ParticipantID"),"gbk","Error!")));

  return t;
};

//客户端认证信息
PyObject * new_CThostFtdcAuthenticationInfoField(CThostFtdcAuthenticationInfoField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcAuthenticationInfoField", (char*)"yiyyy",
p->AuthInfo, p->IsResult, p->BrokerID, p->UserProductInfo, p->UserID);
}
CThostFtdcAuthenticationInfoField * from_CThostFtdcAuthenticationInfoField(PyObject * p){
  CThostFtdcAuthenticationInfoField *t = (CThostFtdcAuthenticationInfoField *)calloc(1, sizeof(CThostFtdcAuthenticationInfoField));
  memset(t,0,sizeof(CThostFtdcAuthenticationInfoField));
  //认证信息
  strcpy(t->AuthInfo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AuthInfo"),"gbk","Error!")));
  //是否为认证结果
  t->IsResult =   PyLong_AsLong(PyObject_GetAttrString(p, "IsResult"));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //用户端产品信息
  strcpy(t->UserProductInfo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserProductInfo"),"gbk","Error!")));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));

  return t;
};

//查询管理用户
PyObject * new_CThostFtdcQrySuperUserField(CThostFtdcQrySuperUserField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQrySuperUserField", (char*)"y",
p->UserID);
}
CThostFtdcQrySuperUserField * from_CThostFtdcQrySuperUserField(PyObject * p){
  CThostFtdcQrySuperUserField *t = (CThostFtdcQrySuperUserField *)calloc(1, sizeof(CThostFtdcQrySuperUserField));
  memset(t,0,sizeof(CThostFtdcQrySuperUserField));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));

  return t;
};

//行情最新成交属性
PyObject * new_CThostFtdcMarketDataLastMatchField(CThostFtdcMarketDataLastMatchField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcMarketDataLastMatchField", (char*)"dddi",
p->LastPrice, p->OpenInterest, p->Turnover, p->Volume);
}
CThostFtdcMarketDataLastMatchField * from_CThostFtdcMarketDataLastMatchField(PyObject * p){
  CThostFtdcMarketDataLastMatchField *t = (CThostFtdcMarketDataLastMatchField *)calloc(1, sizeof(CThostFtdcMarketDataLastMatchField));
  memset(t,0,sizeof(CThostFtdcMarketDataLastMatchField));
  //最新价
  t->LastPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LastPrice"));
  //持仓量
  t->OpenInterest =   PyFloat_AsDouble(PyObject_GetAttrString(p, "OpenInterest"));
  //成交金额
  t->Turnover =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Turnover"));
  //数量
  t->Volume =   PyLong_AsLong(PyObject_GetAttrString(p, "Volume"));

  return t;
};

//查询交易所报单
PyObject * new_CThostFtdcQryExchangeOrderField(CThostFtdcQryExchangeOrderField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryExchangeOrderField", (char*)"yyyyy",
p->ClientID, p->ExchangeID, p->ExchangeInstID, p->TraderID, p->ParticipantID);
}
CThostFtdcQryExchangeOrderField * from_CThostFtdcQryExchangeOrderField(PyObject * p){
  CThostFtdcQryExchangeOrderField *t = (CThostFtdcQryExchangeOrderField *)calloc(1, sizeof(CThostFtdcQryExchangeOrderField));
  memset(t,0,sizeof(CThostFtdcQryExchangeOrderField));
  //客户代码
  strcpy(t->ClientID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ClientID"),"gbk","Error!")));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //合约在交易所的代码
  strcpy(t->ExchangeInstID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeInstID"),"gbk","Error!")));
  //交易所交易员代码
  strcpy(t->TraderID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TraderID"),"gbk","Error!")));
  //会员代码
  strcpy(t->ParticipantID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ParticipantID"),"gbk","Error!")));

  return t;
};

//合约状态
PyObject * new_CThostFtdcInstrumentStatusField(CThostFtdcInstrumentStatusField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcInstrumentStatusField", (char*)"ycyiyyyc",
p->InstrumentID, p->InstrumentStatus, p->SettlementGroupID, p->TradingSegmentSN, p->ExchangeID, p->ExchangeInstID, p->EnterTime, p->EnterReason);
}
CThostFtdcInstrumentStatusField * from_CThostFtdcInstrumentStatusField(PyObject * p){
  CThostFtdcInstrumentStatusField *t = (CThostFtdcInstrumentStatusField *)calloc(1, sizeof(CThostFtdcInstrumentStatusField));
  memset(t,0,sizeof(CThostFtdcInstrumentStatusField));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //合约交易状态
  //enum类型
  //THOST_FTDC_IS_AuctionMatch -> '5', 集合竞价撮合
  //THOST_FTDC_IS_NoTrading -> '1', 非交易
  //THOST_FTDC_IS_Closed -> '6', 收盘
  //THOST_FTDC_IS_AuctionBalance -> '4', 集合竞价价格平衡
  //THOST_FTDC_IS_Continous -> '2', 连续交易
  //THOST_FTDC_IS_BeforeTrading -> '0', 开盘前
  //THOST_FTDC_IS_AuctionOrdering -> '3', 集合竞价报单
  t->InstrumentStatus =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentStatus"),"gbk","Error!"))[0];
  //结算组代码
  strcpy(t->SettlementGroupID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "SettlementGroupID"),"gbk","Error!")));
  //交易阶段编号
  t->TradingSegmentSN =   PyLong_AsLong(PyObject_GetAttrString(p, "TradingSegmentSN"));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //合约在交易所的代码
  strcpy(t->ExchangeInstID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeInstID"),"gbk","Error!")));
  //进入本状态时间
  strcpy(t->EnterTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "EnterTime"),"gbk","Error!")));
  //进入本状态原因
  //enum类型
  //THOST_FTDC_IER_Manual -> '2', 手动切换
  //THOST_FTDC_IER_Fuse -> '3', 熔断
  //THOST_FTDC_IER_Automatic -> '1', 自动切换
  t->EnterReason =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "EnterReason"),"gbk","Error!"))[0];

  return t;
};

//客户端认证请求
PyObject * new_CThostFtdcReqAuthenticateField(CThostFtdcReqAuthenticateField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcReqAuthenticateField", (char*)"yyyy",
p->BrokerID, p->UserProductInfo, p->AuthCode, p->UserID);
}
CThostFtdcReqAuthenticateField * from_CThostFtdcReqAuthenticateField(PyObject * p){
  CThostFtdcReqAuthenticateField *t = (CThostFtdcReqAuthenticateField *)calloc(1, sizeof(CThostFtdcReqAuthenticateField));
  memset(t,0,sizeof(CThostFtdcReqAuthenticateField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //用户端产品信息
  strcpy(t->UserProductInfo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserProductInfo"),"gbk","Error!")));
  //认证码
  strcpy(t->AuthCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AuthCode"),"gbk","Error!")));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));

  return t;
};

//市场行情
PyObject * new_CThostFtdcMarketDataField(CThostFtdcMarketDataField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcMarketDataField", (char*)"ddddddydyiydidydydddydd",
p->LowestPrice, p->ClosePrice, p->CurrDelta, p->HighestPrice, p->OpenPrice, p->OpenInterest, p->InstrumentID, p->Turnover, p->ExchangeInstID, p->UpdateMillisec, p->UpdateTime, p->PreClosePrice, p->Volume, p->LastPrice, p->ExchangeID, p->LowerLimitPrice, p->TradingDay, p->SettlementPrice, p->PreOpenInterest, p->PreSettlementPrice, p->ActionDay, p->PreDelta, p->UpperLimitPrice);
}
CThostFtdcMarketDataField * from_CThostFtdcMarketDataField(PyObject * p){
  CThostFtdcMarketDataField *t = (CThostFtdcMarketDataField *)calloc(1, sizeof(CThostFtdcMarketDataField));
  memset(t,0,sizeof(CThostFtdcMarketDataField));
  //最低价
  t->LowestPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LowestPrice"));
  //今收盘
  t->ClosePrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ClosePrice"));
  //今虚实度
  t->CurrDelta =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CurrDelta"));
  //最高价
  t->HighestPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "HighestPrice"));
  //今开盘
  t->OpenPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "OpenPrice"));
  //持仓量
  t->OpenInterest =   PyFloat_AsDouble(PyObject_GetAttrString(p, "OpenInterest"));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //成交金额
  t->Turnover =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Turnover"));
  //合约在交易所的代码
  strcpy(t->ExchangeInstID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeInstID"),"gbk","Error!")));
  //最后修改毫秒
  t->UpdateMillisec =   PyLong_AsLong(PyObject_GetAttrString(p, "UpdateMillisec"));
  //最后修改时间
  strcpy(t->UpdateTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UpdateTime"),"gbk","Error!")));
  //昨收盘
  t->PreClosePrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PreClosePrice"));
  //数量
  t->Volume =   PyLong_AsLong(PyObject_GetAttrString(p, "Volume"));
  //最新价
  t->LastPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LastPrice"));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //跌停板价
  t->LowerLimitPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LowerLimitPrice"));
  //交易日
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //本次结算价
  t->SettlementPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "SettlementPrice"));
  //昨持仓量
  t->PreOpenInterest =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PreOpenInterest"));
  //上次结算价
  t->PreSettlementPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PreSettlementPrice"));
  //业务日期
  strcpy(t->ActionDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ActionDay"),"gbk","Error!")));
  //昨虚实度
  t->PreDelta =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PreDelta"));
  //涨停板价
  t->UpperLimitPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "UpperLimitPrice"));

  return t;
};

//查询手续费率
PyObject * new_CThostFtdcQryInstrumentCommissionRateField(CThostFtdcQryInstrumentCommissionRateField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryInstrumentCommissionRateField", (char*)"yyy",
p->BrokerID, p->InvestorID, p->InstrumentID);
}
CThostFtdcQryInstrumentCommissionRateField * from_CThostFtdcQryInstrumentCommissionRateField(PyObject * p){
  CThostFtdcQryInstrumentCommissionRateField *t = (CThostFtdcQryInstrumentCommissionRateField *)calloc(1, sizeof(CThostFtdcQryInstrumentCommissionRateField));
  memset(t,0,sizeof(CThostFtdcQryInstrumentCommissionRateField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));

  return t;
};

//保证金监管系统经纪公司资金账户密钥
PyObject * new_CThostFtdcCFMMCTradingAccountKeyField(CThostFtdcCFMMCTradingAccountKeyField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcCFMMCTradingAccountKeyField", (char*)"yyyiy",
p->CurrentKey, p->BrokerID, p->AccountID, p->KeyID, p->ParticipantID);
}
CThostFtdcCFMMCTradingAccountKeyField * from_CThostFtdcCFMMCTradingAccountKeyField(PyObject * p){
  CThostFtdcCFMMCTradingAccountKeyField *t = (CThostFtdcCFMMCTradingAccountKeyField *)calloc(1, sizeof(CThostFtdcCFMMCTradingAccountKeyField));
  memset(t,0,sizeof(CThostFtdcCFMMCTradingAccountKeyField));
  //动态密钥
  strcpy(t->CurrentKey, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrentKey"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者帐号
  strcpy(t->AccountID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AccountID"),"gbk","Error!")));
  //密钥编号
  t->KeyID =   PyLong_AsLong(PyObject_GetAttrString(p, "KeyID"));
  //经纪公司统一编码
  strcpy(t->ParticipantID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ParticipantID"),"gbk","Error!")));

  return t;
};

//查询交易所状态
PyObject * new_CThostFtdcQryExchangeSequenceField(CThostFtdcQryExchangeSequenceField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryExchangeSequenceField", (char*)"y",
p->ExchangeID);
}
CThostFtdcQryExchangeSequenceField * from_CThostFtdcQryExchangeSequenceField(PyObject * p){
  CThostFtdcQryExchangeSequenceField *t = (CThostFtdcQryExchangeSequenceField *)calloc(1, sizeof(CThostFtdcQryExchangeSequenceField));
  memset(t,0,sizeof(CThostFtdcQryExchangeSequenceField));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));

  return t;
};

//查询合约交易权限
PyObject * new_CThostFtdcQryInstrumentTradingRightField(CThostFtdcQryInstrumentTradingRightField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryInstrumentTradingRightField", (char*)"yyy",
p->BrokerID, p->InvestorID, p->InstrumentID);
}
CThostFtdcQryInstrumentTradingRightField * from_CThostFtdcQryInstrumentTradingRightField(PyObject * p){
  CThostFtdcQryInstrumentTradingRightField *t = (CThostFtdcQryInstrumentTradingRightField *)calloc(1, sizeof(CThostFtdcQryInstrumentTradingRightField));
  memset(t,0,sizeof(CThostFtdcQryInstrumentTradingRightField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));

  return t;
};

//用户登录应答
PyObject * new_CThostFtdcRspUserLoginField(CThostFtdcRspUserLoginField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcRspUserLoginField", (char*)"yyyyiiyyyyyy",
p->TradingDay, p->SystemName, p->SHFETime, p->BrokerID, p->FrontID, p->SessionID, p->FFEXTime, p->CZCETime, p->LoginTime, p->DCETime, p->MaxOrderRef, p->UserID);
}
CThostFtdcRspUserLoginField * from_CThostFtdcRspUserLoginField(PyObject * p){
  CThostFtdcRspUserLoginField *t = (CThostFtdcRspUserLoginField *)calloc(1, sizeof(CThostFtdcRspUserLoginField));
  memset(t,0,sizeof(CThostFtdcRspUserLoginField));
  //交易日
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //交易系统名称
  strcpy(t->SystemName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "SystemName"),"gbk","Error!")));
  //上期所时间
  strcpy(t->SHFETime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "SHFETime"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //前置编号
  t->FrontID =   PyLong_AsLong(PyObject_GetAttrString(p, "FrontID"));
  //会话编号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //中金所时间
  strcpy(t->FFEXTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "FFEXTime"),"gbk","Error!")));
  //郑商所时间
  strcpy(t->CZCETime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CZCETime"),"gbk","Error!")));
  //登录成功时间
  strcpy(t->LoginTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LoginTime"),"gbk","Error!")));
  //大商所时间
  strcpy(t->DCETime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "DCETime"),"gbk","Error!")));
  //最大报单引用
  strcpy(t->MaxOrderRef, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "MaxOrderRef"),"gbk","Error!")));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));

  return t;
};

//用户事件通知
PyObject * new_CThostFtdcTradingNoticeField(CThostFtdcTradingNoticeField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcTradingNoticeField", (char*)"hiyyycyy",
p->SequenceSeries, p->SequenceNo, p->SendTime, p->BrokerID, p->InvestorID, p->InvestorRange, p->UserID, p->FieldContent);
}
CThostFtdcTradingNoticeField * from_CThostFtdcTradingNoticeField(PyObject * p){
  CThostFtdcTradingNoticeField *t = (CThostFtdcTradingNoticeField *)calloc(1, sizeof(CThostFtdcTradingNoticeField));
  memset(t,0,sizeof(CThostFtdcTradingNoticeField));
  //序列系列号
  t->SequenceSeries =   PyLong_AsLong(PyObject_GetAttrString(p, "SequenceSeries"));
  //序列号
  t->SequenceNo =   PyLong_AsLong(PyObject_GetAttrString(p, "SequenceNo"));
  //发送时间
  strcpy(t->SendTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "SendTime"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //投资者范围
  //enum类型
  //THOST_FTDC_IR_Single -> '3', 单一投资者
  //THOST_FTDC_IR_All -> '1', 所有
  //THOST_FTDC_IR_Group -> '2', 投资者组
  t->InvestorRange =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorRange"),"gbk","Error!"))[0];
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //消息正文
  strcpy(t->FieldContent, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "FieldContent"),"gbk","Error!")));

  return t;
};

//查询经纪公司资金
PyObject * new_CThostFtdcQueryBrokerDepositField(CThostFtdcQueryBrokerDepositField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQueryBrokerDepositField", (char*)"yy",
p->BrokerID, p->ExchangeID);
}
CThostFtdcQueryBrokerDepositField * from_CThostFtdcQueryBrokerDepositField(PyObject * p){
  CThostFtdcQueryBrokerDepositField *t = (CThostFtdcQueryBrokerDepositField *)calloc(1, sizeof(CThostFtdcQueryBrokerDepositField));
  memset(t,0,sizeof(CThostFtdcQueryBrokerDepositField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));

  return t;
};

//合约保证金率
PyObject * new_CThostFtdcInstrumentMarginRateField(CThostFtdcInstrumentMarginRateField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcInstrumentMarginRateField", (char*)"yddciyycdd",
p->InstrumentID, p->ShortMarginRatioByVolume, p->LongMarginRatioByMoney, p->HedgeFlag, p->IsRelative, p->BrokerID, p->InvestorID, p->InvestorRange, p->LongMarginRatioByVolume, p->ShortMarginRatioByMoney);
}
CThostFtdcInstrumentMarginRateField * from_CThostFtdcInstrumentMarginRateField(PyObject * p){
  CThostFtdcInstrumentMarginRateField *t = (CThostFtdcInstrumentMarginRateField *)calloc(1, sizeof(CThostFtdcInstrumentMarginRateField));
  memset(t,0,sizeof(CThostFtdcInstrumentMarginRateField));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //空头保证金费
  t->ShortMarginRatioByVolume =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ShortMarginRatioByVolume"));
  //多头保证金率
  t->LongMarginRatioByMoney =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LongMarginRatioByMoney"));
  //投机套保标志
  //enum类型
  //THOST_FTDC_HF_Hedge -> '3', 套保
  //THOST_FTDC_HF_Arbitrage -> '2', 套利
  //THOST_FTDC_HF_Speculation -> '1', 投机
  t->HedgeFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "HedgeFlag"),"gbk","Error!"))[0];
  //是否相对交易所收取
  t->IsRelative =   PyLong_AsLong(PyObject_GetAttrString(p, "IsRelative"));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //投资者范围
  //enum类型
  //THOST_FTDC_IR_Single -> '3', 单一投资者
  //THOST_FTDC_IR_All -> '1', 所有
  //THOST_FTDC_IR_Group -> '2', 投资者组
  t->InvestorRange =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorRange"),"gbk","Error!"))[0];
  //多头保证金费
  t->LongMarginRatioByVolume =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LongMarginRatioByVolume"));
  //空头保证金率
  t->ShortMarginRatioByMoney =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ShortMarginRatioByMoney"));

  return t;
};

//验证客户信息
PyObject * new_CThostFtdcVerifyCustInfoField(CThostFtdcVerifyCustInfoField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcVerifyCustInfoField", (char*)"ycyc",
p->CustomerName, p->IdCardType, p->IdentifiedCardNo, p->CustType);
}
CThostFtdcVerifyCustInfoField * from_CThostFtdcVerifyCustInfoField(PyObject * p){
  CThostFtdcVerifyCustInfoField *t = (CThostFtdcVerifyCustInfoField *)calloc(1, sizeof(CThostFtdcVerifyCustInfoField));
  memset(t,0,sizeof(CThostFtdcVerifyCustInfoField));
  //客户姓名
  strcpy(t->CustomerName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustomerName"),"gbk","Error!")));
  //证件类型
  //enum类型
  //THOST_FTDC_ICT_TaiwanCompatriotIDCard -> '7', 台胞证
  //THOST_FTDC_ICT_Passport -> '6', 护照
  //THOST_FTDC_ICT_LicenseNo -> '9', 营业执照号
  //THOST_FTDC_ICT_OtherCard -> 'x', 其他证件
  //THOST_FTDC_ICT_IDCard -> '1', 身份证
  //THOST_FTDC_ICT_EID -> '0', 组织机构代码
  //THOST_FTDC_ICT_TaxNo -> 'A', 税务登记号
  //THOST_FTDC_ICT_HomeComingCard -> '8', 回乡证
  //THOST_FTDC_ICT_OfficerIDCard -> '2', 军官证
  //THOST_FTDC_ICT_HouseholdRegister -> '5', 户口簿
  //THOST_FTDC_ICT_SoldierIDCard -> '4', 士兵证
  //THOST_FTDC_ICT_PoliceIDCard -> '3', 警官证
  t->IdCardType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdCardType"),"gbk","Error!"))[0];
  //证件号码
  strcpy(t->IdentifiedCardNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdentifiedCardNo"),"gbk","Error!")));
  //客户类型
  //enum类型
  //THOST_FTDC_CUSTT_Person -> '0', 自然人
  //THOST_FTDC_CUSTT_Institution -> '1', 机构户
  t->CustType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustType"),"gbk","Error!"))[0];

  return t;
};

//浮动盈亏算法
PyObject * new_CThostFtdcPositionProfitAlgorithmField(CThostFtdcPositionProfitAlgorithmField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcPositionProfitAlgorithmField", (char*)"cyyy",
p->Algorithm, p->Memo, p->BrokerID, p->AccountID);
}
CThostFtdcPositionProfitAlgorithmField * from_CThostFtdcPositionProfitAlgorithmField(PyObject * p){
  CThostFtdcPositionProfitAlgorithmField *t = (CThostFtdcPositionProfitAlgorithmField *)calloc(1, sizeof(CThostFtdcPositionProfitAlgorithmField));
  memset(t,0,sizeof(CThostFtdcPositionProfitAlgorithmField));
  //盈亏算法
  //enum类型
  //THOST_FTDC_AG_None -> '4', 浮盈浮亏都不计算
  //THOST_FTDC_AG_OnlyLost -> '2', 浮盈不计，浮亏计
  //THOST_FTDC_AG_All -> '1', 浮盈浮亏都计算
  //THOST_FTDC_AG_OnlyGain -> '3', 浮盈计，浮亏不计
  t->Algorithm =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Algorithm"),"gbk","Error!"))[0];
  //备注
  strcpy(t->Memo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Memo"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者帐号
  strcpy(t->AccountID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AccountID"),"gbk","Error!")));

  return t;
};

//用户口令变更
PyObject * new_CThostFtdcUserPasswordUpdateField(CThostFtdcUserPasswordUpdateField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcUserPasswordUpdateField", (char*)"yyyy",
p->NewPassword, p->BrokerID, p->UserID, p->OldPassword);
}
CThostFtdcUserPasswordUpdateField * from_CThostFtdcUserPasswordUpdateField(PyObject * p){
  CThostFtdcUserPasswordUpdateField *t = (CThostFtdcUserPasswordUpdateField *)calloc(1, sizeof(CThostFtdcUserPasswordUpdateField));
  memset(t,0,sizeof(CThostFtdcUserPasswordUpdateField));
  //新的口令
  strcpy(t->NewPassword, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "NewPassword"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //原来的口令
  strcpy(t->OldPassword, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OldPassword"),"gbk","Error!")));

  return t;
};

//查询成交
PyObject * new_CThostFtdcQryTradeField(CThostFtdcQryTradeField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryTradeField", (char*)"yyyyyyy",
p->InstrumentID, p->TradeTimeStart, p->TradeID, p->BrokerID, p->InvestorID, p->ExchangeID, p->TradeTimeEnd);
}
CThostFtdcQryTradeField * from_CThostFtdcQryTradeField(PyObject * p){
  CThostFtdcQryTradeField *t = (CThostFtdcQryTradeField *)calloc(1, sizeof(CThostFtdcQryTradeField));
  memset(t,0,sizeof(CThostFtdcQryTradeField));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //开始时间
  strcpy(t->TradeTimeStart, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeTimeStart"),"gbk","Error!")));
  //成交编号
  strcpy(t->TradeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeID"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //结束时间
  strcpy(t->TradeTimeEnd, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeTimeEnd"),"gbk","Error!")));

  return t;
};

//验证期货资金密码和客户信息
PyObject * new_CThostFtdcDepositResultInformField(CThostFtdcDepositResultInformField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcDepositResultInformField", (char*)"yiyyyyd",
p->DepositSeqNo, p->RequestID, p->ReturnCode, p->DescrInfoForReturnCode, p->BrokerID, p->InvestorID, p->Deposit);
}
CThostFtdcDepositResultInformField * from_CThostFtdcDepositResultInformField(PyObject * p){
  CThostFtdcDepositResultInformField *t = (CThostFtdcDepositResultInformField *)calloc(1, sizeof(CThostFtdcDepositResultInformField));
  memset(t,0,sizeof(CThostFtdcDepositResultInformField));
  //出入金流水号，该流水号为银期报盘返回的流水号
  strcpy(t->DepositSeqNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "DepositSeqNo"),"gbk","Error!")));
  //请求编号
  t->RequestID =   PyLong_AsLong(PyObject_GetAttrString(p, "RequestID"));
  //返回代码
  strcpy(t->ReturnCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ReturnCode"),"gbk","Error!")));
  //返回码描述
  strcpy(t->DescrInfoForReturnCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "DescrInfoForReturnCode"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //入金金额
  t->Deposit =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Deposit"));

  return t;
};

//资金账户
PyObject * new_CThostFtdcTradingAccountField(CThostFtdcTradingAccountField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcTradingAccountField", (char*)"ddddyddddddddddddddddyydidddddd",
p->WithdrawQuota, p->DeliveryMargin, p->PreMortgage, p->Balance, p->BrokerID, p->Deposit, p->CashIn, p->Reserve, p->ExchangeMargin, p->CurrMargin, p->PositionProfit, p->FrozenMargin, p->Commission, p->Interest, p->Available, p->Credit, p->CloseProfit, p->ReserveBalance, p->ExchangeDeliveryMargin, p->FrozenCommission, p->InterestBase, p->TradingDay, p->AccountID, p->FrozenCash, p->SettlementID, p->Mortgage, p->PreCredit, p->PreDeposit, p->PreMargin, p->Withdraw, p->PreBalance);
}
CThostFtdcTradingAccountField * from_CThostFtdcTradingAccountField(PyObject * p){
  CThostFtdcTradingAccountField *t = (CThostFtdcTradingAccountField *)calloc(1, sizeof(CThostFtdcTradingAccountField));
  memset(t,0,sizeof(CThostFtdcTradingAccountField));
  //可取资金
  t->WithdrawQuota =   PyFloat_AsDouble(PyObject_GetAttrString(p, "WithdrawQuota"));
  //投资者交割保证金
  t->DeliveryMargin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "DeliveryMargin"));
  //上次质押金额
  t->PreMortgage =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PreMortgage"));
  //期货结算准备金
  t->Balance =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Balance"));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //入金金额
  t->Deposit =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Deposit"));
  //资金差额
  t->CashIn =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CashIn"));
  //基本准备金
  t->Reserve =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Reserve"));
  //交易所保证金
  t->ExchangeMargin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ExchangeMargin"));
  //当前保证金总额
  t->CurrMargin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CurrMargin"));
  //持仓盈亏
  t->PositionProfit =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PositionProfit"));
  //冻结的保证金
  t->FrozenMargin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "FrozenMargin"));
  //手续费
  t->Commission =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Commission"));
  //利息收入
  t->Interest =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Interest"));
  //可用资金
  t->Available =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Available"));
  //信用额度
  t->Credit =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Credit"));
  //平仓盈亏
  t->CloseProfit =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CloseProfit"));
  //保底期货结算准备金
  t->ReserveBalance =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ReserveBalance"));
  //交易所交割保证金
  t->ExchangeDeliveryMargin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ExchangeDeliveryMargin"));
  //冻结的手续费
  t->FrozenCommission =   PyFloat_AsDouble(PyObject_GetAttrString(p, "FrozenCommission"));
  //利息基数
  t->InterestBase =   PyFloat_AsDouble(PyObject_GetAttrString(p, "InterestBase"));
  //交易日
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //投资者帐号
  strcpy(t->AccountID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AccountID"),"gbk","Error!")));
  //冻结的资金
  t->FrozenCash =   PyFloat_AsDouble(PyObject_GetAttrString(p, "FrozenCash"));
  //结算编号
  t->SettlementID =   PyLong_AsLong(PyObject_GetAttrString(p, "SettlementID"));
  //质押金额
  t->Mortgage =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Mortgage"));
  //上次信用额度
  t->PreCredit =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PreCredit"));
  //上次存款额
  t->PreDeposit =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PreDeposit"));
  //上次占用的保证金
  t->PreMargin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PreMargin"));
  //出金金额
  t->Withdraw =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Withdraw"));
  //上次结算准备金
  t->PreBalance =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PreBalance"));

  return t;
};

//经纪公司用户功能权限
PyObject * new_CThostFtdcBrokerUserFunctionField(CThostFtdcBrokerUserFunctionField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcBrokerUserFunctionField", (char*)"ycy",
p->BrokerID, p->BrokerFunctionCode, p->UserID);
}
CThostFtdcBrokerUserFunctionField * from_CThostFtdcBrokerUserFunctionField(PyObject * p){
  CThostFtdcBrokerUserFunctionField *t = (CThostFtdcBrokerUserFunctionField *)calloc(1, sizeof(CThostFtdcBrokerUserFunctionField));
  memset(t,0,sizeof(CThostFtdcBrokerUserFunctionField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //经纪公司功能代码
  //enum类型
  //THOST_FTDC_BFC_QueryUserEvent -> 'p', 用户事件查询
  //THOST_FTDC_BFC_SyncOTP -> 'E', 同步动态令牌
  //THOST_FTDC_BFC_ForceClose -> 'u', 强平
  //THOST_FTDC_BFC_RemainCalc -> 'w', 权益反算
  //THOST_FTDC_BFC_QueryPosition -> 'n', 持仓查询
  //THOST_FTDC_BFC_ForceUserLogout -> '1', 强制用户登出
  //THOST_FTDC_BFC_QueryTradingCode -> 't', 交易编码查询
  //THOST_FTDC_BFC_QryBizNotice -> 'C', 业务通知查询
  //THOST_FTDC_BFC_RiskNotice -> 'i', 风控通知发送
  //THOST_FTDC_BFC_SyncBrokerData -> '3', 同步经纪公司数据
  //THOST_FTDC_BFC_QueryFundChange -> 'r', 出入金查询
  //THOST_FTDC_BFC_BachSyncBrokerData -> '4', 批量同步经纪公司数据
  //THOST_FTDC_BFC_TbCommand -> 'H', 交易终端应急功能
  //THOST_FTDC_BFC_CfgBizNotice -> 'D', 业务通知模板设置
  //THOST_FTDC_BFC_PressTest -> 'v', 压力测试
  //THOST_FTDC_BFC_CfgRiskLevelStd -> 'G', 风险级别标准设置
  //THOST_FTDC_BFC_RiskTargetSetup -> 'A', 风控指标设置
  //THOST_FTDC_BFC_Session -> 'g', 查询/管理：查询会话，踢人等
  //THOST_FTDC_BFC_QueryTrade -> 'm', 成交查询
  //THOST_FTDC_BFC_Trade -> 'd', 交易功能：报单，撤单
  //THOST_FTDC_BFC_OrderInsert -> '5', 报单插入
  //THOST_FTDC_BFC_MarketDataWarn -> 'B', 行情预警
  //THOST_FTDC_BFC_Risk -> 'f', 风险监控
  //THOST_FTDC_BFC_OrderAction -> '6', 报单操作
  //THOST_FTDC_BFC_DataExport -> 'z', 数据导出
  //THOST_FTDC_BFC_QueryOrder -> 'l', 报单查询
  //THOST_FTDC_BFC_SendBizNotice -> 'F', 发送业务通知
  //THOST_FTDC_BFC_log -> 'a', 系统功能：登入/登出/修改密码等
  //THOST_FTDC_BFC_BrokerDeposit -> 'j', 察看经纪公司资金权限
  //THOST_FTDC_BFC_NetPositionInd -> 'x', 净持仓保证金指标
  //THOST_FTDC_BFC_BaseQry -> 'b', 基本查询：查询基础数据，如合约，交易所等常量
  //THOST_FTDC_BFC_QueryFund -> 'k', 资金查询
  //THOST_FTDC_BFC_AllQuery -> '7', 全部查询
  //THOST_FTDC_BFC_TradeQry -> 'c', 交易查询：如查成交，委托
  //THOST_FTDC_BFC_QueryRiskNotify -> 'q', 风险通知查询
  //THOST_FTDC_BFC_RiskNoticeCtl -> 'h', 风控通知控制
  //THOST_FTDC_BFC_Virement -> 'e', 银期转账
  //THOST_FTDC_BFC_QueryMarketData -> 'o', 行情查询
  //THOST_FTDC_BFC_RiskPredict -> 'y', 风险预算
  //THOST_FTDC_BFC_QueryInvestor -> 's', 投资者信息查询
  //THOST_FTDC_BFC_UserPasswordUpdate -> '2', 变更用户口令
  t->BrokerFunctionCode =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerFunctionCode"),"gbk","Error!"))[0];
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));

  return t;
};

//交易编码
PyObject * new_CThostFtdcTradingCodeField(CThostFtdcTradingCodeField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcTradingCodeField", (char*)"iycyyy",
p->IsActive, p->ClientID, p->ClientIDType, p->BrokerID, p->InvestorID, p->ExchangeID);
}
CThostFtdcTradingCodeField * from_CThostFtdcTradingCodeField(PyObject * p){
  CThostFtdcTradingCodeField *t = (CThostFtdcTradingCodeField *)calloc(1, sizeof(CThostFtdcTradingCodeField));
  memset(t,0,sizeof(CThostFtdcTradingCodeField));
  //是否活跃
  t->IsActive =   PyLong_AsLong(PyObject_GetAttrString(p, "IsActive"));
  //客户代码
  strcpy(t->ClientID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ClientID"),"gbk","Error!")));
  //交易编码类型
  //enum类型
  //THOST_FTDC_CIDT_Arbitrage -> '2', 套利
  //THOST_FTDC_CIDT_Hedge -> '3', 套保
  //THOST_FTDC_CIDT_Speculation -> '1', 投机
  t->ClientIDType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ClientIDType"),"gbk","Error!"))[0];
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));

  return t;
};

//资金账户口令变更域
PyObject * new_CThostFtdcTradingAccountPasswordUpdateField(CThostFtdcTradingAccountPasswordUpdateField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcTradingAccountPasswordUpdateField", (char*)"yyyy",
p->NewPassword, p->BrokerID, p->AccountID, p->OldPassword);
}
CThostFtdcTradingAccountPasswordUpdateField * from_CThostFtdcTradingAccountPasswordUpdateField(PyObject * p){
  CThostFtdcTradingAccountPasswordUpdateField *t = (CThostFtdcTradingAccountPasswordUpdateField *)calloc(1, sizeof(CThostFtdcTradingAccountPasswordUpdateField));
  memset(t,0,sizeof(CThostFtdcTradingAccountPasswordUpdateField));
  //新的口令
  strcpy(t->NewPassword, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "NewPassword"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者帐号
  strcpy(t->AccountID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AccountID"),"gbk","Error!")));
  //原来的口令
  strcpy(t->OldPassword, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OldPassword"),"gbk","Error!")));

  return t;
};

//验证期货资金密码和客户信息
PyObject * new_CThostFtdcVerifyFuturePasswordAndCustInfoField(CThostFtdcVerifyFuturePasswordAndCustInfoField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcVerifyFuturePasswordAndCustInfoField", (char*)"yycyyc",
p->Password, p->CustomerName, p->CustType, p->AccountID, p->IdentifiedCardNo, p->IdCardType);
}
CThostFtdcVerifyFuturePasswordAndCustInfoField * from_CThostFtdcVerifyFuturePasswordAndCustInfoField(PyObject * p){
  CThostFtdcVerifyFuturePasswordAndCustInfoField *t = (CThostFtdcVerifyFuturePasswordAndCustInfoField *)calloc(1, sizeof(CThostFtdcVerifyFuturePasswordAndCustInfoField));
  memset(t,0,sizeof(CThostFtdcVerifyFuturePasswordAndCustInfoField));
  //期货密码
  strcpy(t->Password, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Password"),"gbk","Error!")));
  //客户姓名
  strcpy(t->CustomerName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustomerName"),"gbk","Error!")));
  //客户类型
  //enum类型
  //THOST_FTDC_CUSTT_Person -> '0', 自然人
  //THOST_FTDC_CUSTT_Institution -> '1', 机构户
  t->CustType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustType"),"gbk","Error!"))[0];
  //投资者帐号
  strcpy(t->AccountID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AccountID"),"gbk","Error!")));
  //证件号码
  strcpy(t->IdentifiedCardNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdentifiedCardNo"),"gbk","Error!")));
  //证件类型
  //enum类型
  //THOST_FTDC_ICT_TaiwanCompatriotIDCard -> '7', 台胞证
  //THOST_FTDC_ICT_Passport -> '6', 护照
  //THOST_FTDC_ICT_LicenseNo -> '9', 营业执照号
  //THOST_FTDC_ICT_OtherCard -> 'x', 其他证件
  //THOST_FTDC_ICT_IDCard -> '1', 身份证
  //THOST_FTDC_ICT_EID -> '0', 组织机构代码
  //THOST_FTDC_ICT_TaxNo -> 'A', 税务登记号
  //THOST_FTDC_ICT_HomeComingCard -> '8', 回乡证
  //THOST_FTDC_ICT_OfficerIDCard -> '2', 军官证
  //THOST_FTDC_ICT_HouseholdRegister -> '5', 户口簿
  //THOST_FTDC_ICT_SoldierIDCard -> '4', 士兵证
  //THOST_FTDC_ICT_PoliceIDCard -> '3', 警官证
  t->IdCardType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdCardType"),"gbk","Error!"))[0];

  return t;
};

//请求查询转帐流水
PyObject * new_CThostFtdcQryTransferSerialField(CThostFtdcQryTransferSerialField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryTransferSerialField", (char*)"yyy",
p->BankID, p->BrokerID, p->AccountID);
}
CThostFtdcQryTransferSerialField * from_CThostFtdcQryTransferSerialField(PyObject * p){
  CThostFtdcQryTransferSerialField *t = (CThostFtdcQryTransferSerialField *)calloc(1, sizeof(CThostFtdcQryTransferSerialField));
  memset(t,0,sizeof(CThostFtdcQryTransferSerialField));
  //银行编码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者帐号
  strcpy(t->AccountID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AccountID"),"gbk","Error!")));

  return t;
};

//查询错误报单操作
PyObject * new_CThostFtdcErrorConditionalOrderField(CThostFtdcErrorConditionalOrderField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcErrorConditionalOrderField", (char*)"yiccyiiiydyiyiyyiyyycccyyiycyiyyiiycyyiicyyiiiiycyycyyydyyy",
p->InsertDate, p->ZCETotalTradedVolume, p->Direction, p->OrderSubmitStatus, p->BrokerID, p->SessionID, p->MinVolume, p->VolumeTotalOriginal, p->CancelTime, p->StopPrice, p->InsertTime, p->BrokerOrderSeq, p->ErrorMsg, p->VolumeTraded, p->ExchangeInstID, p->ParticipantID, p->SettlementID, p->ActiveTime, p->GTDDate, p->OrderRef, p->ContingentCondition, p->VolumeCondition, p->OrderType, p->OrderLocalID, p->ActiveUserID, p->NotifySequence, p->RelativeOrderSysID, p->OrderPriceType, p->SuspendTime, p->VolumeTotal, p->ClientID, p->StatusMsg, p->InstallID, p->ErrorID, p->InvestorID, p->ForceCloseReason, p->TraderID, p->InstrumentID, p->FrontID, p->UserForceClose, p->OrderStatus, p->ExchangeID, p->OrderSysID, p->RequestID, p->IsAutoSuspend, p->IsSwapOrder, p->SequenceNo, p->CombOffsetFlag, p->OrderSource, p->TradingDay, p->ClearingPartID, p->TimeCondition, p->UpdateTime, p->BusinessUnit, p->UserProductInfo, p->LimitPrice, p->CombHedgeFlag, p->ActiveTraderID, p->UserID);
}
CThostFtdcErrorConditionalOrderField * from_CThostFtdcErrorConditionalOrderField(PyObject * p){
  CThostFtdcErrorConditionalOrderField *t = (CThostFtdcErrorConditionalOrderField *)calloc(1, sizeof(CThostFtdcErrorConditionalOrderField));
  memset(t,0,sizeof(CThostFtdcErrorConditionalOrderField));
  //报单日期
  strcpy(t->InsertDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InsertDate"),"gbk","Error!")));
  //郑商所成交数量
  t->ZCETotalTradedVolume =   PyLong_AsLong(PyObject_GetAttrString(p, "ZCETotalTradedVolume"));
  //买卖方向
  //enum类型
  //THOST_FTDC_D_Buy -> '0', 买
  //THOST_FTDC_D_Sell -> '1', 卖
  t->Direction =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Direction"),"gbk","Error!"))[0];
  //报单提交状态
  //enum类型
  //THOST_FTDC_OSS_ModifyRejected -> '6', 改单已经被拒绝
  //THOST_FTDC_OSS_InsertRejected -> '4', 报单已经被拒绝
  //THOST_FTDC_OSS_CancelSubmitted -> '1', 撤单已经提交
  //THOST_FTDC_OSS_ModifySubmitted -> '2', 修改已经提交
  //THOST_FTDC_OSS_Accepted -> '3', 已经接受
  //THOST_FTDC_OSS_InsertSubmitted -> '0', 已经提交
  //THOST_FTDC_OSS_CancelRejected -> '5', 撤单已经被拒绝
  t->OrderSubmitStatus =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderSubmitStatus"),"gbk","Error!"))[0];
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //会话编号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //最小成交量
  t->MinVolume =   PyLong_AsLong(PyObject_GetAttrString(p, "MinVolume"));
  //数量
  t->VolumeTotalOriginal =   PyLong_AsLong(PyObject_GetAttrString(p, "VolumeTotalOriginal"));
  //撤销时间
  strcpy(t->CancelTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CancelTime"),"gbk","Error!")));
  //止损价
  t->StopPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "StopPrice"));
  //委托时间
  strcpy(t->InsertTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InsertTime"),"gbk","Error!")));
  //经纪公司报单编号
  t->BrokerOrderSeq =   PyLong_AsLong(PyObject_GetAttrString(p, "BrokerOrderSeq"));
  //错误信息
  strcpy(t->ErrorMsg, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ErrorMsg"),"gbk","Error!")));
  //今成交数量
  t->VolumeTraded =   PyLong_AsLong(PyObject_GetAttrString(p, "VolumeTraded"));
  //合约在交易所的代码
  strcpy(t->ExchangeInstID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeInstID"),"gbk","Error!")));
  //会员代码
  strcpy(t->ParticipantID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ParticipantID"),"gbk","Error!")));
  //结算编号
  t->SettlementID =   PyLong_AsLong(PyObject_GetAttrString(p, "SettlementID"));
  //激活时间
  strcpy(t->ActiveTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ActiveTime"),"gbk","Error!")));
  //GTD日期
  strcpy(t->GTDDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "GTDDate"),"gbk","Error!")));
  //报单引用
  strcpy(t->OrderRef, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderRef"),"gbk","Error!")));
  //触发条件
  //enum类型
  //THOST_FTDC_CC_AskPriceLesserThanStopPrice -> 'B', 卖一价小于条件价
  //THOST_FTDC_CC_Touch -> '2', 止损
  //THOST_FTDC_CC_BidPriceGreaterThanStopPrice -> 'D', 买一价大于条件价
  //THOST_FTDC_CC_LastPriceGreaterEqualStopPrice -> '6', 最新价大于等于条件价
  //THOST_FTDC_CC_AskPriceLesserEqualStopPrice -> 'C', 卖一价小于等于条件价
  //THOST_FTDC_CC_LastPriceGreaterThanStopPrice -> '5', 最新价大于条件价
  //THOST_FTDC_CC_AskPriceGreaterEqualStopPrice -> 'A', 卖一价大于等于条件价
  //THOST_FTDC_CC_LastPriceLesserThanStopPrice -> '7', 最新价小于条件价
  //THOST_FTDC_CC_BidPriceGreaterEqualStopPrice -> 'E', 买一价大于等于条件价
  //THOST_FTDC_CC_Immediately -> '1', 立即
  //THOST_FTDC_CC_LastPriceLesserEqualStopPrice -> '8', 最新价小于等于条件价
  //THOST_FTDC_CC_AskPriceGreaterThanStopPrice -> '9', 卖一价大于条件价
  //THOST_FTDC_CC_BidPriceLesserEqualStopPrice -> 'H', 买一价小于等于条件价
  //THOST_FTDC_CC_ParkedOrder -> '4', 预埋单
  //THOST_FTDC_CC_TouchProfit -> '3', 止赢
  //THOST_FTDC_CC_BidPriceLesserThanStopPrice -> 'F', 买一价小于条件价
  t->ContingentCondition =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ContingentCondition"),"gbk","Error!"))[0];
  //成交量类型
  //enum类型
  //THOST_FTDC_VC_CV -> '3', 全部数量
  //THOST_FTDC_VC_MV -> '2', 最小数量
  //THOST_FTDC_VC_AV -> '1', 任何数量
  t->VolumeCondition =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "VolumeCondition"),"gbk","Error!"))[0];
  //报单类型
  //enum类型
  //THOST_FTDC_ORDT_DeriveFromCombination -> '2', 组合衍生
  //THOST_FTDC_ORDT_Normal -> '0', 正常
  //THOST_FTDC_ORDT_Combination -> '3', 组合报单
  //THOST_FTDC_ORDT_DeriveFromQuote -> '1', 报价衍生
  //THOST_FTDC_ORDT_Swap -> '5', 互换单
  //THOST_FTDC_ORDT_ConditionalOrder -> '4', 条件单
  t->OrderType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderType"),"gbk","Error!"))[0];
  //本地报单编号
  strcpy(t->OrderLocalID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderLocalID"),"gbk","Error!")));
  //操作用户代码
  strcpy(t->ActiveUserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ActiveUserID"),"gbk","Error!")));
  //报单提示序号
  t->NotifySequence =   PyLong_AsLong(PyObject_GetAttrString(p, "NotifySequence"));
  //相关报单
  strcpy(t->RelativeOrderSysID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "RelativeOrderSysID"),"gbk","Error!")));
  //报单价格条件
  //enum类型
  //THOST_FTDC_OPT_LastPricePlusOneTicks -> '5', 最新价浮动上浮1个ticks
  //THOST_FTDC_OPT_LastPricePlusTwoTicks -> '6', 最新价浮动上浮2个ticks
  //THOST_FTDC_OPT_BidPrice1PlusTwoTicks -> 'E', 买一价浮动上浮2个ticks
  //THOST_FTDC_OPT_AnyPrice -> '1', 任意价
  //THOST_FTDC_OPT_AskPrice1PlusTwoTicks -> 'A', 卖一价浮动上浮2个ticks
  //THOST_FTDC_OPT_AskPrice1PlusThreeTicks -> 'B', 卖一价浮动上浮3个ticks
  //THOST_FTDC_OPT_BidPrice1PlusThreeTicks -> 'F', 买一价浮动上浮3个ticks
  //THOST_FTDC_OPT_BestPrice -> '3', 最优价
  //THOST_FTDC_OPT_LimitPrice -> '2', 限价
  //THOST_FTDC_OPT_BidPrice1 -> 'C', 买一价
  //THOST_FTDC_OPT_AskPrice1PlusOneTicks -> '9', 卖一价浮动上浮1个ticks
  //THOST_FTDC_OPT_LastPricePlusThreeTicks -> '7', 最新价浮动上浮3个ticks
  //THOST_FTDC_OPT_LastPrice -> '4', 最新价
  //THOST_FTDC_OPT_AskPrice1 -> '8', 卖一价
  //THOST_FTDC_OPT_BidPrice1PlusOneTicks -> 'D', 买一价浮动上浮1个ticks
  t->OrderPriceType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderPriceType"),"gbk","Error!"))[0];
  //挂起时间
  strcpy(t->SuspendTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "SuspendTime"),"gbk","Error!")));
  //剩余数量
  t->VolumeTotal =   PyLong_AsLong(PyObject_GetAttrString(p, "VolumeTotal"));
  //客户代码
  strcpy(t->ClientID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ClientID"),"gbk","Error!")));
  //状态信息
  strcpy(t->StatusMsg, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "StatusMsg"),"gbk","Error!")));
  //安装编号
  t->InstallID =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallID"));
  //错误代码
  t->ErrorID =   PyLong_AsLong(PyObject_GetAttrString(p, "ErrorID"));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //强平原因
  //enum类型
  //THOST_FTDC_FCC_Other -> '6', 其它
  //THOST_FTDC_FCC_ClientOverPositionLimit -> '2', 客户超仓
  //THOST_FTDC_FCC_NotMultiple -> '4', 持仓非整数倍
  //THOST_FTDC_FCC_PersonDeliv -> '7', 自然人临近交割
  //THOST_FTDC_FCC_NotForceClose -> '0', 非强平
  //THOST_FTDC_FCC_Violation -> '5', 违规
  //THOST_FTDC_FCC_MemberOverPositionLimit -> '3', 会员超仓
  //THOST_FTDC_FCC_LackDeposit -> '1', 资金不足
  t->ForceCloseReason =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ForceCloseReason"),"gbk","Error!"))[0];
  //交易所交易员代码
  strcpy(t->TraderID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TraderID"),"gbk","Error!")));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //前置编号
  t->FrontID =   PyLong_AsLong(PyObject_GetAttrString(p, "FrontID"));
  //用户强评标志
  t->UserForceClose =   PyLong_AsLong(PyObject_GetAttrString(p, "UserForceClose"));
  //报单状态
  //enum类型
  //THOST_FTDC_OST_NoTradeQueueing -> '3', 未成交还在队列中
  //THOST_FTDC_OST_Touched -> 'c', 已触发
  //THOST_FTDC_OST_PartTradedQueueing -> '1', 部分成交还在队列中
  //THOST_FTDC_OST_NotTouched -> 'b', 尚未触发
  //THOST_FTDC_OST_NoTradeNotQueueing -> '4', 未成交不在队列中
  //THOST_FTDC_OST_PartTradedNotQueueing -> '2', 部分成交不在队列中
  //THOST_FTDC_OST_Unknown -> 'a', 未知
  //THOST_FTDC_OST_Canceled -> '5', 撤单
  //THOST_FTDC_OST_AllTraded -> '0', 全部成交
  t->OrderStatus =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderStatus"),"gbk","Error!"))[0];
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //报单编号
  strcpy(t->OrderSysID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderSysID"),"gbk","Error!")));
  //请求编号
  t->RequestID =   PyLong_AsLong(PyObject_GetAttrString(p, "RequestID"));
  //自动挂起标志
  t->IsAutoSuspend =   PyLong_AsLong(PyObject_GetAttrString(p, "IsAutoSuspend"));
  //互换单标志
  t->IsSwapOrder =   PyLong_AsLong(PyObject_GetAttrString(p, "IsSwapOrder"));
  //序号
  t->SequenceNo =   PyLong_AsLong(PyObject_GetAttrString(p, "SequenceNo"));
  //组合开平标志
  strcpy(t->CombOffsetFlag, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CombOffsetFlag"),"gbk","Error!")));
  //报单来源
  //enum类型
  //THOST_FTDC_OSRC_Administrator -> '1', 来自管理员
  //THOST_FTDC_OSRC_Participant -> '0', 来自参与者
  t->OrderSource =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderSource"),"gbk","Error!"))[0];
  //交易日
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //结算会员编号
  strcpy(t->ClearingPartID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ClearingPartID"),"gbk","Error!")));
  //有效期类型
  //enum类型
  //THOST_FTDC_TC_IOC -> '1', 立即完成，否则撤销
  //THOST_FTDC_TC_GFS -> '2', 本节有效
  //THOST_FTDC_TC_GTD -> '4', 指定日期前有效
  //THOST_FTDC_TC_GFA -> '6', 集合竞价有效
  //THOST_FTDC_TC_GTC -> '5', 撤销前有效
  //THOST_FTDC_TC_GFD -> '3', 当日有效
  t->TimeCondition =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TimeCondition"),"gbk","Error!"))[0];
  //最后修改时间
  strcpy(t->UpdateTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UpdateTime"),"gbk","Error!")));
  //业务单元
  strcpy(t->BusinessUnit, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BusinessUnit"),"gbk","Error!")));
  //用户端产品信息
  strcpy(t->UserProductInfo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserProductInfo"),"gbk","Error!")));
  //价格
  t->LimitPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LimitPrice"));
  //组合投机套保标志
  strcpy(t->CombHedgeFlag, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CombHedgeFlag"),"gbk","Error!")));
  //最后修改交易所交易员代码
  strcpy(t->ActiveTraderID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ActiveTraderID"),"gbk","Error!")));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));

  return t;
};

//查询组合合约分腿
PyObject * new_CThostFtdcQrySyncStatusField(CThostFtdcQrySyncStatusField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQrySyncStatusField", (char*)"y",
p->TradingDay);
}
CThostFtdcQrySyncStatusField * from_CThostFtdcQrySyncStatusField(PyObject * p){
  CThostFtdcQrySyncStatusField *t = (CThostFtdcQrySyncStatusField *)calloc(1, sizeof(CThostFtdcQrySyncStatusField));
  memset(t,0,sizeof(CThostFtdcQrySyncStatusField));
  //交易日
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));

  return t;
};

//查询客户通知
PyObject * new_CThostFtdcQryNoticeField(CThostFtdcQryNoticeField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryNoticeField", (char*)"y",
p->BrokerID);
}
CThostFtdcQryNoticeField * from_CThostFtdcQryNoticeField(PyObject * p){
  CThostFtdcQryNoticeField *t = (CThostFtdcQryNoticeField *)calloc(1, sizeof(CThostFtdcQryNoticeField));
  memset(t,0,sizeof(CThostFtdcQryNoticeField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));

  return t;
};

//正在同步中的合约手续费率
PyObject * new_CThostFtdcSyncingInstrumentCommissionRateField(CThostFtdcSyncingInstrumentCommissionRateField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcSyncingInstrumentCommissionRateField", (char*)"dyddddyycd",
p->CloseTodayRatioByMoney, p->InstrumentID, p->OpenRatioByVolume, p->CloseTodayRatioByVolume, p->OpenRatioByMoney, p->CloseRatioByVolume, p->BrokerID, p->InvestorID, p->InvestorRange, p->CloseRatioByMoney);
}
CThostFtdcSyncingInstrumentCommissionRateField * from_CThostFtdcSyncingInstrumentCommissionRateField(PyObject * p){
  CThostFtdcSyncingInstrumentCommissionRateField *t = (CThostFtdcSyncingInstrumentCommissionRateField *)calloc(1, sizeof(CThostFtdcSyncingInstrumentCommissionRateField));
  memset(t,0,sizeof(CThostFtdcSyncingInstrumentCommissionRateField));
  //平今手续费率
  t->CloseTodayRatioByMoney =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CloseTodayRatioByMoney"));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //开仓手续费
  t->OpenRatioByVolume =   PyFloat_AsDouble(PyObject_GetAttrString(p, "OpenRatioByVolume"));
  //平今手续费
  t->CloseTodayRatioByVolume =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CloseTodayRatioByVolume"));
  //开仓手续费率
  t->OpenRatioByMoney =   PyFloat_AsDouble(PyObject_GetAttrString(p, "OpenRatioByMoney"));
  //平仓手续费
  t->CloseRatioByVolume =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CloseRatioByVolume"));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //投资者范围
  //enum类型
  //THOST_FTDC_IR_Single -> '3', 单一投资者
  //THOST_FTDC_IR_All -> '1', 所有
  //THOST_FTDC_IR_Group -> '2', 投资者组
  t->InvestorRange =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorRange"),"gbk","Error!"))[0];
  //平仓手续费率
  t->CloseRatioByMoney =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CloseRatioByMoney"));

  return t;
};

//查询银行交易明细请求，TradeCode=204999
PyObject * new_CThostFtdcTransferQryDetailReqField(CThostFtdcTransferQryDetailReqField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcTransferQryDetailReqField", (char*)"y",
p->FutureAccount);
}
CThostFtdcTransferQryDetailReqField * from_CThostFtdcTransferQryDetailReqField(PyObject * p){
  CThostFtdcTransferQryDetailReqField *t = (CThostFtdcTransferQryDetailReqField *)calloc(1, sizeof(CThostFtdcTransferQryDetailReqField));
  memset(t,0,sizeof(CThostFtdcTransferQryDetailReqField));
  //期货资金账户
  strcpy(t->FutureAccount, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "FutureAccount"),"gbk","Error!")));

  return t;
};

//经纪公司用户
PyObject * new_CThostFtdcBrokerUserField(CThostFtdcBrokerUserField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcBrokerUserField", (char*)"iyycyi",
p->IsActive, p->UserName, p->BrokerID, p->UserType, p->UserID, p->IsUsingOTP);
}
CThostFtdcBrokerUserField * from_CThostFtdcBrokerUserField(PyObject * p){
  CThostFtdcBrokerUserField *t = (CThostFtdcBrokerUserField *)calloc(1, sizeof(CThostFtdcBrokerUserField));
  memset(t,0,sizeof(CThostFtdcBrokerUserField));
  //是否活跃
  t->IsActive =   PyLong_AsLong(PyObject_GetAttrString(p, "IsActive"));
  //用户名称
  strcpy(t->UserName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserName"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //用户类型
  //enum类型
  //THOST_FTDC_UT_SuperUser -> '2', 管理员
  //THOST_FTDC_UT_Operator -> '1', 操作员
  //THOST_FTDC_UT_Investor -> '0', 投资者
  t->UserType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserType"),"gbk","Error!"))[0];
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //是否使用令牌
  t->IsUsingOTP =   PyLong_AsLong(PyObject_GetAttrString(p, "IsUsingOTP"));

  return t;
};

//期商签退响应
PyObject * new_CThostFtdcRspFutureSignOutField(CThostFtdcRspFutureSignOutField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcRspFutureSignOutField", (char*)"yyiiyiyyyyyciyyyyyyiyyi",
p->TradeTime, p->DeviceID, p->ErrorID, p->InstallID, p->BrokerID, p->SessionID, p->BankID, p->CurrencyID, p->ErrorMsg, p->OperNo, p->Digest, p->LastFragment, p->RequestID, p->TradeDate, p->UserID, p->TradingDay, p->BankSerial, p->BrokerIDByBank, p->TradeCode, p->TID, p->BankBranchID, p->BrokerBranchID, p->PlateSerial);
}
CThostFtdcRspFutureSignOutField * from_CThostFtdcRspFutureSignOutField(PyObject * p){
  CThostFtdcRspFutureSignOutField *t = (CThostFtdcRspFutureSignOutField *)calloc(1, sizeof(CThostFtdcRspFutureSignOutField));
  memset(t,0,sizeof(CThostFtdcRspFutureSignOutField));
  //交易时间
  strcpy(t->TradeTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeTime"),"gbk","Error!")));
  //渠道标志
  strcpy(t->DeviceID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "DeviceID"),"gbk","Error!")));
  //错误代码
  t->ErrorID =   PyLong_AsLong(PyObject_GetAttrString(p, "ErrorID"));
  //安装编号
  t->InstallID =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallID"));
  //期商代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //会话号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //银行代码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //币种代码
  strcpy(t->CurrencyID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrencyID"),"gbk","Error!")));
  //错误信息
  strcpy(t->ErrorMsg, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ErrorMsg"),"gbk","Error!")));
  //交易柜员
  strcpy(t->OperNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OperNo"),"gbk","Error!")));
  //摘要
  strcpy(t->Digest, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Digest"),"gbk","Error!")));
  //最后分片标志
  //enum类型
  //THOST_FTDC_LF_No -> '1', 不是最后分片
  //THOST_FTDC_LF_Yes -> '0', 是最后分片
  t->LastFragment =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LastFragment"),"gbk","Error!"))[0];
  //请求编号
  t->RequestID =   PyLong_AsLong(PyObject_GetAttrString(p, "RequestID"));
  //交易日期
  strcpy(t->TradeDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeDate"),"gbk","Error!")));
  //用户标识
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //交易系统日期
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //银行流水号
  strcpy(t->BankSerial, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSerial"),"gbk","Error!")));
  //期货公司银行编码
  strcpy(t->BrokerIDByBank, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerIDByBank"),"gbk","Error!")));
  //业务功能码
  strcpy(t->TradeCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeCode"),"gbk","Error!")));
  //交易ID
  t->TID =   PyLong_AsLong(PyObject_GetAttrString(p, "TID"));
  //银行分支机构代码
  strcpy(t->BankBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBranchID"),"gbk","Error!")));
  //期商分支机构代码
  strcpy(t->BrokerBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerBranchID"),"gbk","Error!")));
  //银期平台消息流水号
  t->PlateSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "PlateSerial"));

  return t;
};

//银期销户信息
PyObject * new_CThostFtdcCancelAccountField(CThostFtdcCancelAccountField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcCancelAccountField", (char*)"yyiyyiycyycyyyccyycyyyycyiyyyiccyycyyyyycyyciy",
p->TradingDay, p->DeviceID, p->ErrorID, p->BrokerID, p->ZipCode, p->SessionID, p->IdentifiedCardNo, p->IdCardType, p->MobilePhone, p->BankID, p->BankPwdFlag, p->OperNo, p->BankAccount, p->BankSecuAcc, p->LastFragment, p->Gender, p->Address, p->TradeDate, p->MoneyAccountStatus, p->AccountID, p->BankSerial, p->CustomerName, p->BankPassWord, p->CashExchangeCode, p->Digest, p->PlateSerial, p->Fax, p->EMail, p->TradeTime, p->InstallID, p->SecuPwdFlag, p->VerifyCertNoFlag, p->CurrencyID, p->ErrorMsg, p->BankSecuAccType, p->Password, p->BankBranchID, p->CountryCode, p->BrokerBranchID, p->UserID, p->CustType, p->BrokerIDByBank, p->TradeCode, p->BankAccType, p->TID, p->Telephone);
}
CThostFtdcCancelAccountField * from_CThostFtdcCancelAccountField(PyObject * p){
  CThostFtdcCancelAccountField *t = (CThostFtdcCancelAccountField *)calloc(1, sizeof(CThostFtdcCancelAccountField));
  memset(t,0,sizeof(CThostFtdcCancelAccountField));
  //交易系统日期
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //渠道标志
  strcpy(t->DeviceID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "DeviceID"),"gbk","Error!")));
  //错误代码
  t->ErrorID =   PyLong_AsLong(PyObject_GetAttrString(p, "ErrorID"));
  //期商代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //邮编
  strcpy(t->ZipCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ZipCode"),"gbk","Error!")));
  //会话号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //证件号码
  strcpy(t->IdentifiedCardNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdentifiedCardNo"),"gbk","Error!")));
  //证件类型
  //enum类型
  //THOST_FTDC_ICT_TaiwanCompatriotIDCard -> '7', 台胞证
  //THOST_FTDC_ICT_Passport -> '6', 护照
  //THOST_FTDC_ICT_LicenseNo -> '9', 营业执照号
  //THOST_FTDC_ICT_OtherCard -> 'x', 其他证件
  //THOST_FTDC_ICT_IDCard -> '1', 身份证
  //THOST_FTDC_ICT_EID -> '0', 组织机构代码
  //THOST_FTDC_ICT_TaxNo -> 'A', 税务登记号
  //THOST_FTDC_ICT_HomeComingCard -> '8', 回乡证
  //THOST_FTDC_ICT_OfficerIDCard -> '2', 军官证
  //THOST_FTDC_ICT_HouseholdRegister -> '5', 户口簿
  //THOST_FTDC_ICT_SoldierIDCard -> '4', 士兵证
  //THOST_FTDC_ICT_PoliceIDCard -> '3', 警官证
  t->IdCardType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdCardType"),"gbk","Error!"))[0];
  //手机
  strcpy(t->MobilePhone, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "MobilePhone"),"gbk","Error!")));
  //银行代码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //银行密码标志
  //enum类型
  //THOST_FTDC_BPWDF_NoCheck -> '0', 不核对
  //THOST_FTDC_BPWDF_BlankCheck -> '1', 明文核对
  //THOST_FTDC_BPWDF_EncryptCheck -> '2', 密文核对
  t->BankPwdFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankPwdFlag"),"gbk","Error!"))[0];
  //交易柜员
  strcpy(t->OperNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OperNo"),"gbk","Error!")));
  //银行帐号
  strcpy(t->BankAccount, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccount"),"gbk","Error!")));
  //期货单位帐号
  strcpy(t->BankSecuAcc, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSecuAcc"),"gbk","Error!")));
  //最后分片标志
  //enum类型
  //THOST_FTDC_LF_No -> '1', 不是最后分片
  //THOST_FTDC_LF_Yes -> '0', 是最后分片
  t->LastFragment =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LastFragment"),"gbk","Error!"))[0];
  //性别
  //enum类型
  //THOST_FTDC_GD_Male -> '1', 男
  //THOST_FTDC_GD_Unknown -> '0', 未知状态
  //THOST_FTDC_GD_Female -> '2', 女
  t->Gender =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Gender"),"gbk","Error!"))[0];
  //地址
  strcpy(t->Address, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Address"),"gbk","Error!")));
  //交易日期
  strcpy(t->TradeDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeDate"),"gbk","Error!")));
  //资金账户状态
  //enum类型
  //THOST_FTDC_MAS_Normal -> '0', 正常
  //THOST_FTDC_MAS_Cancel -> '1', 销户
  t->MoneyAccountStatus =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "MoneyAccountStatus"),"gbk","Error!"))[0];
  //投资者帐号
  strcpy(t->AccountID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AccountID"),"gbk","Error!")));
  //银行流水号
  strcpy(t->BankSerial, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSerial"),"gbk","Error!")));
  //客户姓名
  strcpy(t->CustomerName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustomerName"),"gbk","Error!")));
  //银行密码
  strcpy(t->BankPassWord, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankPassWord"),"gbk","Error!")));
  //汇钞标志
  //enum类型
  //THOST_FTDC_CEC_Cash -> '2', 钞
  //THOST_FTDC_CEC_Exchange -> '1', 汇
  t->CashExchangeCode =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CashExchangeCode"),"gbk","Error!"))[0];
  //摘要
  strcpy(t->Digest, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Digest"),"gbk","Error!")));
  //银期平台消息流水号
  t->PlateSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "PlateSerial"));
  //传真
  strcpy(t->Fax, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Fax"),"gbk","Error!")));
  //电子邮件
  strcpy(t->EMail, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "EMail"),"gbk","Error!")));
  //交易时间
  strcpy(t->TradeTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeTime"),"gbk","Error!")));
  //安装编号
  t->InstallID =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallID"));
  //期货资金密码核对标志
  //enum类型
  //THOST_FTDC_BPWDF_NoCheck -> '0', 不核对
  //THOST_FTDC_BPWDF_BlankCheck -> '1', 明文核对
  //THOST_FTDC_BPWDF_EncryptCheck -> '2', 密文核对
  t->SecuPwdFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "SecuPwdFlag"),"gbk","Error!"))[0];
  //验证客户证件号码标志
  //enum类型
  //THOST_FTDC_YNI_No -> '1', 否
  //THOST_FTDC_YNI_Yes -> '0', 是
  t->VerifyCertNoFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "VerifyCertNoFlag"),"gbk","Error!"))[0];
  //币种代码
  strcpy(t->CurrencyID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrencyID"),"gbk","Error!")));
  //错误信息
  strcpy(t->ErrorMsg, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ErrorMsg"),"gbk","Error!")));
  //期货单位帐号类型
  //enum类型
  //THOST_FTDC_BAT_SavingCard -> '2', 储蓄卡
  //THOST_FTDC_BAT_CreditCard -> '3', 信用卡
  //THOST_FTDC_BAT_BankBook -> '1', 银行存折
  t->BankSecuAccType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSecuAccType"),"gbk","Error!"))[0];
  //期货密码
  strcpy(t->Password, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Password"),"gbk","Error!")));
  //银行分支机构代码
  strcpy(t->BankBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBranchID"),"gbk","Error!")));
  //国家代码
  strcpy(t->CountryCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CountryCode"),"gbk","Error!")));
  //期商分支机构代码
  strcpy(t->BrokerBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerBranchID"),"gbk","Error!")));
  //用户标识
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //客户类型
  //enum类型
  //THOST_FTDC_CUSTT_Person -> '0', 自然人
  //THOST_FTDC_CUSTT_Institution -> '1', 机构户
  t->CustType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustType"),"gbk","Error!"))[0];
  //期货公司银行编码
  strcpy(t->BrokerIDByBank, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerIDByBank"),"gbk","Error!")));
  //业务功能码
  strcpy(t->TradeCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeCode"),"gbk","Error!")));
  //银行帐号类型
  //enum类型
  //THOST_FTDC_BAT_SavingCard -> '2', 储蓄卡
  //THOST_FTDC_BAT_CreditCard -> '3', 信用卡
  //THOST_FTDC_BAT_BankBook -> '1', 银行存折
  t->BankAccType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccType"),"gbk","Error!"))[0];
  //交易ID
  t->TID =   PyLong_AsLong(PyObject_GetAttrString(p, "TID"));
  //电话号码
  strcpy(t->Telephone, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Telephone"),"gbk","Error!")));

  return t;
};

//查询组合持仓明细
PyObject * new_CThostFtdcQryInvestorPositionCombineDetailField(CThostFtdcQryInvestorPositionCombineDetailField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryInvestorPositionCombineDetailField", (char*)"yyy",
p->BrokerID, p->InvestorID, p->CombInstrumentID);
}
CThostFtdcQryInvestorPositionCombineDetailField * from_CThostFtdcQryInvestorPositionCombineDetailField(PyObject * p){
  CThostFtdcQryInvestorPositionCombineDetailField *t = (CThostFtdcQryInvestorPositionCombineDetailField *)calloc(1, sizeof(CThostFtdcQryInvestorPositionCombineDetailField));
  memset(t,0,sizeof(CThostFtdcQryInvestorPositionCombineDetailField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //组合持仓合约编码
  strcpy(t->CombInstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CombInstrumentID"),"gbk","Error!")));

  return t;
};

//经纪公司可提资金算法表
PyObject * new_CThostFtdcBrokerWithdrawAlgorithmField(CThostFtdcBrokerWithdrawAlgorithmField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcBrokerWithdrawAlgorithmField", (char*)"dcccyci",
p->UsingRatio, p->AllWithoutTrade, p->AvailIncludeCloseProfit, p->IncludeCloseProfit, p->BrokerID, p->WithdrawAlgorithm, p->IsBrokerUserEvent);
}
CThostFtdcBrokerWithdrawAlgorithmField * from_CThostFtdcBrokerWithdrawAlgorithmField(PyObject * p){
  CThostFtdcBrokerWithdrawAlgorithmField *t = (CThostFtdcBrokerWithdrawAlgorithmField *)calloc(1, sizeof(CThostFtdcBrokerWithdrawAlgorithmField));
  memset(t,0,sizeof(CThostFtdcBrokerWithdrawAlgorithmField));
  //资金使用率
  t->UsingRatio =   PyFloat_AsDouble(PyObject_GetAttrString(p, "UsingRatio"));
  //本日无仓且无成交客户是否受可提比例限制
  //enum类型
  //THOST_FTDC_AWT_Enable -> '0', 无仓无成交不受可提比例限制
  //THOST_FTDC_AWT_Disable -> '2', 受可提比例限制
  //THOST_FTDC_AWT_NoHoldEnable -> '3', 无仓不受可提比例限制
  t->AllWithoutTrade =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AllWithoutTrade"),"gbk","Error!"))[0];
  //可用是否包含平仓盈利
  //enum类型
  //THOST_FTDC_ICP_NotInclude -> '2', 不包含平仓盈利
  //THOST_FTDC_ICP_Include -> '0', 包含平仓盈利
  t->AvailIncludeCloseProfit =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AvailIncludeCloseProfit"),"gbk","Error!"))[0];
  //可提是否包含平仓盈利
  //enum类型
  //THOST_FTDC_ICP_NotInclude -> '2', 不包含平仓盈利
  //THOST_FTDC_ICP_Include -> '0', 包含平仓盈利
  t->IncludeCloseProfit =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IncludeCloseProfit"),"gbk","Error!"))[0];
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //可提资金算法
  //enum类型
  //THOST_FTDC_AG_None -> '4', 浮盈浮亏都不计算
  //THOST_FTDC_AG_OnlyLost -> '2', 浮盈不计，浮亏计
  //THOST_FTDC_AG_All -> '1', 浮盈浮亏都计算
  //THOST_FTDC_AG_OnlyGain -> '3', 浮盈计，浮亏不计
  t->WithdrawAlgorithm =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "WithdrawAlgorithm"),"gbk","Error!"))[0];
  //是否启用用户事件
  t->IsBrokerUserEvent =   PyLong_AsLong(PyObject_GetAttrString(p, "IsBrokerUserEvent"));

  return t;
};

//仓单折抵信息
PyObject * new_CThostFtdcEWarrantOffsetField(CThostFtdcEWarrantOffsetField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcEWarrantOffsetField", (char*)"yyiccyyy",
p->InstrumentID, p->InvestorID, p->Volume, p->HedgeFlag, p->Direction, p->BrokerID, p->TradingDay, p->ExchangeID);
}
CThostFtdcEWarrantOffsetField * from_CThostFtdcEWarrantOffsetField(PyObject * p){
  CThostFtdcEWarrantOffsetField *t = (CThostFtdcEWarrantOffsetField *)calloc(1, sizeof(CThostFtdcEWarrantOffsetField));
  memset(t,0,sizeof(CThostFtdcEWarrantOffsetField));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //数量
  t->Volume =   PyLong_AsLong(PyObject_GetAttrString(p, "Volume"));
  //投机套保标志
  //enum类型
  //THOST_FTDC_HF_Hedge -> '3', 套保
  //THOST_FTDC_HF_Arbitrage -> '2', 套利
  //THOST_FTDC_HF_Speculation -> '1', 投机
  t->HedgeFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "HedgeFlag"),"gbk","Error!"))[0];
  //买卖方向
  //enum类型
  //THOST_FTDC_D_Buy -> '0', 买
  //THOST_FTDC_D_Sell -> '1', 卖
  t->Direction =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Direction"),"gbk","Error!"))[0];
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //交易日期
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));

  return t;
};

//查询账户信息通知
PyObject * new_CThostFtdcNotifyQueryAccountField(CThostFtdcNotifyQueryAccountField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcNotifyQueryAccountField", (char*)"cyyiyiyiyycdcdyyycyyyyyciicyyccyyyyyiyyi",
p->BankPwdFlag, p->TradingDay, p->TradeTime, p->FutureSerial, p->DeviceID, p->InstallID, p->BrokerID, p->SessionID, p->IdentifiedCardNo, p->AccountID, p->SecuPwdFlag, p->BankFetchAmount, p->VerifyCertNoFlag, p->BankUseAmount, p->BankID, p->CurrencyID, p->ErrorMsg, p->BankSecuAccType, p->OperNo, p->BankAccount, p->Digest, p->BankSecuAcc, p->Password, p->LastFragment, p->RequestID, p->ErrorID, p->BankAccType, p->TradeDate, p->UserID, p->CustType, p->IdCardType, p->BankSerial, p->BrokerIDByBank, p->TradeCode, p->CustomerName, p->BankPassWord, p->TID, p->BankBranchID, p->BrokerBranchID, p->PlateSerial);
}
CThostFtdcNotifyQueryAccountField * from_CThostFtdcNotifyQueryAccountField(PyObject * p){
  CThostFtdcNotifyQueryAccountField *t = (CThostFtdcNotifyQueryAccountField *)calloc(1, sizeof(CThostFtdcNotifyQueryAccountField));
  memset(t,0,sizeof(CThostFtdcNotifyQueryAccountField));
  //银行密码标志
  //enum类型
  //THOST_FTDC_BPWDF_NoCheck -> '0', 不核对
  //THOST_FTDC_BPWDF_BlankCheck -> '1', 明文核对
  //THOST_FTDC_BPWDF_EncryptCheck -> '2', 密文核对
  t->BankPwdFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankPwdFlag"),"gbk","Error!"))[0];
  //交易系统日期
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //交易时间
  strcpy(t->TradeTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeTime"),"gbk","Error!")));
  //期货公司流水号
  t->FutureSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "FutureSerial"));
  //渠道标志
  strcpy(t->DeviceID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "DeviceID"),"gbk","Error!")));
  //安装编号
  t->InstallID =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallID"));
  //期商代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //会话号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //证件号码
  strcpy(t->IdentifiedCardNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdentifiedCardNo"),"gbk","Error!")));
  //投资者帐号
  strcpy(t->AccountID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AccountID"),"gbk","Error!")));
  //期货资金密码核对标志
  //enum类型
  //THOST_FTDC_BPWDF_NoCheck -> '0', 不核对
  //THOST_FTDC_BPWDF_BlankCheck -> '1', 明文核对
  //THOST_FTDC_BPWDF_EncryptCheck -> '2', 密文核对
  t->SecuPwdFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "SecuPwdFlag"),"gbk","Error!"))[0];
  //银行可取金额
  t->BankFetchAmount =   PyFloat_AsDouble(PyObject_GetAttrString(p, "BankFetchAmount"));
  //验证客户证件号码标志
  //enum类型
  //THOST_FTDC_YNI_No -> '1', 否
  //THOST_FTDC_YNI_Yes -> '0', 是
  t->VerifyCertNoFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "VerifyCertNoFlag"),"gbk","Error!"))[0];
  //银行可用金额
  t->BankUseAmount =   PyFloat_AsDouble(PyObject_GetAttrString(p, "BankUseAmount"));
  //银行代码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //币种代码
  strcpy(t->CurrencyID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrencyID"),"gbk","Error!")));
  //错误信息
  strcpy(t->ErrorMsg, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ErrorMsg"),"gbk","Error!")));
  //期货单位帐号类型
  //enum类型
  //THOST_FTDC_BAT_SavingCard -> '2', 储蓄卡
  //THOST_FTDC_BAT_CreditCard -> '3', 信用卡
  //THOST_FTDC_BAT_BankBook -> '1', 银行存折
  t->BankSecuAccType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSecuAccType"),"gbk","Error!"))[0];
  //交易柜员
  strcpy(t->OperNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OperNo"),"gbk","Error!")));
  //银行帐号
  strcpy(t->BankAccount, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccount"),"gbk","Error!")));
  //摘要
  strcpy(t->Digest, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Digest"),"gbk","Error!")));
  //期货单位帐号
  strcpy(t->BankSecuAcc, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSecuAcc"),"gbk","Error!")));
  //期货密码
  strcpy(t->Password, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Password"),"gbk","Error!")));
  //最后分片标志
  //enum类型
  //THOST_FTDC_LF_No -> '1', 不是最后分片
  //THOST_FTDC_LF_Yes -> '0', 是最后分片
  t->LastFragment =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LastFragment"),"gbk","Error!"))[0];
  //请求编号
  t->RequestID =   PyLong_AsLong(PyObject_GetAttrString(p, "RequestID"));
  //错误代码
  t->ErrorID =   PyLong_AsLong(PyObject_GetAttrString(p, "ErrorID"));
  //银行帐号类型
  //enum类型
  //THOST_FTDC_BAT_SavingCard -> '2', 储蓄卡
  //THOST_FTDC_BAT_CreditCard -> '3', 信用卡
  //THOST_FTDC_BAT_BankBook -> '1', 银行存折
  t->BankAccType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccType"),"gbk","Error!"))[0];
  //交易日期
  strcpy(t->TradeDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeDate"),"gbk","Error!")));
  //用户标识
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //客户类型
  //enum类型
  //THOST_FTDC_CUSTT_Person -> '0', 自然人
  //THOST_FTDC_CUSTT_Institution -> '1', 机构户
  t->CustType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustType"),"gbk","Error!"))[0];
  //证件类型
  //enum类型
  //THOST_FTDC_ICT_TaiwanCompatriotIDCard -> '7', 台胞证
  //THOST_FTDC_ICT_Passport -> '6', 护照
  //THOST_FTDC_ICT_LicenseNo -> '9', 营业执照号
  //THOST_FTDC_ICT_OtherCard -> 'x', 其他证件
  //THOST_FTDC_ICT_IDCard -> '1', 身份证
  //THOST_FTDC_ICT_EID -> '0', 组织机构代码
  //THOST_FTDC_ICT_TaxNo -> 'A', 税务登记号
  //THOST_FTDC_ICT_HomeComingCard -> '8', 回乡证
  //THOST_FTDC_ICT_OfficerIDCard -> '2', 军官证
  //THOST_FTDC_ICT_HouseholdRegister -> '5', 户口簿
  //THOST_FTDC_ICT_SoldierIDCard -> '4', 士兵证
  //THOST_FTDC_ICT_PoliceIDCard -> '3', 警官证
  t->IdCardType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdCardType"),"gbk","Error!"))[0];
  //银行流水号
  strcpy(t->BankSerial, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSerial"),"gbk","Error!")));
  //期货公司银行编码
  strcpy(t->BrokerIDByBank, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerIDByBank"),"gbk","Error!")));
  //业务功能码
  strcpy(t->TradeCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeCode"),"gbk","Error!")));
  //客户姓名
  strcpy(t->CustomerName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustomerName"),"gbk","Error!")));
  //银行密码
  strcpy(t->BankPassWord, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankPassWord"),"gbk","Error!")));
  //交易ID
  t->TID =   PyLong_AsLong(PyObject_GetAttrString(p, "TID"));
  //银行分支机构代码
  strcpy(t->BankBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBranchID"),"gbk","Error!")));
  //期商分支机构代码
  strcpy(t->BrokerBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerBranchID"),"gbk","Error!")));
  //银期平台消息流水号
  t->PlateSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "PlateSerial"));

  return t;
};

//经纪公司交易算法
PyObject * new_CThostFtdcBrokerTradingAlgosField(CThostFtdcBrokerTradingAlgosField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcBrokerTradingAlgosField", (char*)"cycyyc",
p->HandleTradingAccountAlgoID, p->InstrumentID, p->HandlePositionAlgoID, p->BrokerID, p->ExchangeID, p->FindMarginRateAlgoID);
}
CThostFtdcBrokerTradingAlgosField * from_CThostFtdcBrokerTradingAlgosField(PyObject * p){
  CThostFtdcBrokerTradingAlgosField *t = (CThostFtdcBrokerTradingAlgosField *)calloc(1, sizeof(CThostFtdcBrokerTradingAlgosField));
  memset(t,0,sizeof(CThostFtdcBrokerTradingAlgosField));
  //资金处理算法编号
  //enum类型
  //THOST_FTDC_HTAA_Base -> '1', 基本
  //THOST_FTDC_HTAA_DCE -> '2', 大连商品交易所
  //THOST_FTDC_HTAA_CZCE -> '3', 郑州商品交易所
  t->HandleTradingAccountAlgoID =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "HandleTradingAccountAlgoID"),"gbk","Error!"))[0];
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //持仓处理算法编号
  //enum类型
  //THOST_FTDC_HPA_Base -> '1', 基本
  //THOST_FTDC_HPA_DCE -> '2', 大连商品交易所
  //THOST_FTDC_HPA_CZCE -> '3', 郑州商品交易所
  t->HandlePositionAlgoID =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "HandlePositionAlgoID"),"gbk","Error!"))[0];
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //寻找保证金率算法编号
  //enum类型
  //THOST_FTDC_FMRA_Base -> '1', 基本
  //THOST_FTDC_FMRA_DCE -> '2', 大连商品交易所
  //THOST_FTDC_FMRA_CZCE -> '3', 郑州商品交易所
  t->FindMarginRateAlgoID =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "FindMarginRateAlgoID"),"gbk","Error!"))[0];

  return t;
};

//查询账户信息请求
PyObject * new_CThostFtdcReqQueryAccountField(CThostFtdcReqQueryAccountField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcReqQueryAccountField", (char*)"cyyiyiyiyyccyycyyyyycicyyccyyyyyiyyi",
p->BankPwdFlag, p->TradingDay, p->TradeTime, p->FutureSerial, p->DeviceID, p->InstallID, p->BrokerID, p->SessionID, p->IdentifiedCardNo, p->AccountID, p->SecuPwdFlag, p->VerifyCertNoFlag, p->BankID, p->CurrencyID, p->BankSecuAccType, p->OperNo, p->BankAccount, p->Digest, p->BankSecuAcc, p->Password, p->LastFragment, p->RequestID, p->BankAccType, p->TradeDate, p->UserID, p->CustType, p->IdCardType, p->BankSerial, p->BrokerIDByBank, p->TradeCode, p->CustomerName, p->BankPassWord, p->TID, p->BankBranchID, p->BrokerBranchID, p->PlateSerial);
}
CThostFtdcReqQueryAccountField * from_CThostFtdcReqQueryAccountField(PyObject * p){
  CThostFtdcReqQueryAccountField *t = (CThostFtdcReqQueryAccountField *)calloc(1, sizeof(CThostFtdcReqQueryAccountField));
  memset(t,0,sizeof(CThostFtdcReqQueryAccountField));
  //银行密码标志
  //enum类型
  //THOST_FTDC_BPWDF_NoCheck -> '0', 不核对
  //THOST_FTDC_BPWDF_BlankCheck -> '1', 明文核对
  //THOST_FTDC_BPWDF_EncryptCheck -> '2', 密文核对
  t->BankPwdFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankPwdFlag"),"gbk","Error!"))[0];
  //交易系统日期
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //交易时间
  strcpy(t->TradeTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeTime"),"gbk","Error!")));
  //期货公司流水号
  t->FutureSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "FutureSerial"));
  //渠道标志
  strcpy(t->DeviceID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "DeviceID"),"gbk","Error!")));
  //安装编号
  t->InstallID =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallID"));
  //期商代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //会话号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //证件号码
  strcpy(t->IdentifiedCardNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdentifiedCardNo"),"gbk","Error!")));
  //投资者帐号
  strcpy(t->AccountID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AccountID"),"gbk","Error!")));
  //期货资金密码核对标志
  //enum类型
  //THOST_FTDC_BPWDF_NoCheck -> '0', 不核对
  //THOST_FTDC_BPWDF_BlankCheck -> '1', 明文核对
  //THOST_FTDC_BPWDF_EncryptCheck -> '2', 密文核对
  t->SecuPwdFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "SecuPwdFlag"),"gbk","Error!"))[0];
  //验证客户证件号码标志
  //enum类型
  //THOST_FTDC_YNI_No -> '1', 否
  //THOST_FTDC_YNI_Yes -> '0', 是
  t->VerifyCertNoFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "VerifyCertNoFlag"),"gbk","Error!"))[0];
  //银行代码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //币种代码
  strcpy(t->CurrencyID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrencyID"),"gbk","Error!")));
  //期货单位帐号类型
  //enum类型
  //THOST_FTDC_BAT_SavingCard -> '2', 储蓄卡
  //THOST_FTDC_BAT_CreditCard -> '3', 信用卡
  //THOST_FTDC_BAT_BankBook -> '1', 银行存折
  t->BankSecuAccType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSecuAccType"),"gbk","Error!"))[0];
  //交易柜员
  strcpy(t->OperNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OperNo"),"gbk","Error!")));
  //银行帐号
  strcpy(t->BankAccount, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccount"),"gbk","Error!")));
  //摘要
  strcpy(t->Digest, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Digest"),"gbk","Error!")));
  //期货单位帐号
  strcpy(t->BankSecuAcc, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSecuAcc"),"gbk","Error!")));
  //期货密码
  strcpy(t->Password, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Password"),"gbk","Error!")));
  //最后分片标志
  //enum类型
  //THOST_FTDC_LF_No -> '1', 不是最后分片
  //THOST_FTDC_LF_Yes -> '0', 是最后分片
  t->LastFragment =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LastFragment"),"gbk","Error!"))[0];
  //请求编号
  t->RequestID =   PyLong_AsLong(PyObject_GetAttrString(p, "RequestID"));
  //银行帐号类型
  //enum类型
  //THOST_FTDC_BAT_SavingCard -> '2', 储蓄卡
  //THOST_FTDC_BAT_CreditCard -> '3', 信用卡
  //THOST_FTDC_BAT_BankBook -> '1', 银行存折
  t->BankAccType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccType"),"gbk","Error!"))[0];
  //交易日期
  strcpy(t->TradeDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeDate"),"gbk","Error!")));
  //用户标识
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //客户类型
  //enum类型
  //THOST_FTDC_CUSTT_Person -> '0', 自然人
  //THOST_FTDC_CUSTT_Institution -> '1', 机构户
  t->CustType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustType"),"gbk","Error!"))[0];
  //证件类型
  //enum类型
  //THOST_FTDC_ICT_TaiwanCompatriotIDCard -> '7', 台胞证
  //THOST_FTDC_ICT_Passport -> '6', 护照
  //THOST_FTDC_ICT_LicenseNo -> '9', 营业执照号
  //THOST_FTDC_ICT_OtherCard -> 'x', 其他证件
  //THOST_FTDC_ICT_IDCard -> '1', 身份证
  //THOST_FTDC_ICT_EID -> '0', 组织机构代码
  //THOST_FTDC_ICT_TaxNo -> 'A', 税务登记号
  //THOST_FTDC_ICT_HomeComingCard -> '8', 回乡证
  //THOST_FTDC_ICT_OfficerIDCard -> '2', 军官证
  //THOST_FTDC_ICT_HouseholdRegister -> '5', 户口簿
  //THOST_FTDC_ICT_SoldierIDCard -> '4', 士兵证
  //THOST_FTDC_ICT_PoliceIDCard -> '3', 警官证
  t->IdCardType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdCardType"),"gbk","Error!"))[0];
  //银行流水号
  strcpy(t->BankSerial, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSerial"),"gbk","Error!")));
  //期货公司银行编码
  strcpy(t->BrokerIDByBank, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerIDByBank"),"gbk","Error!")));
  //业务功能码
  strcpy(t->TradeCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeCode"),"gbk","Error!")));
  //客户姓名
  strcpy(t->CustomerName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustomerName"),"gbk","Error!")));
  //银行密码
  strcpy(t->BankPassWord, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankPassWord"),"gbk","Error!")));
  //交易ID
  t->TID =   PyLong_AsLong(PyObject_GetAttrString(p, "TID"));
  //银行分支机构代码
  strcpy(t->BankBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBranchID"),"gbk","Error!")));
  //期商分支机构代码
  strcpy(t->BrokerBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerBranchID"),"gbk","Error!")));
  //银期平台消息流水号
  t->PlateSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "PlateSerial"));

  return t;
};

//期商签到响应
PyObject * new_CThostFtdcRspFutureSignInField(CThostFtdcRspFutureSignInField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcRspFutureSignInField", (char*)"yyiiyiyyyyyyyciyyyyyyiyyi",
p->TradeTime, p->DeviceID, p->ErrorID, p->InstallID, p->BrokerID, p->SessionID, p->BankID, p->CurrencyID, p->ErrorMsg, p->PinKey, p->OperNo, p->MacKey, p->Digest, p->LastFragment, p->RequestID, p->TradeDate, p->UserID, p->TradingDay, p->BankSerial, p->BrokerIDByBank, p->TradeCode, p->TID, p->BankBranchID, p->BrokerBranchID, p->PlateSerial);
}
CThostFtdcRspFutureSignInField * from_CThostFtdcRspFutureSignInField(PyObject * p){
  CThostFtdcRspFutureSignInField *t = (CThostFtdcRspFutureSignInField *)calloc(1, sizeof(CThostFtdcRspFutureSignInField));
  memset(t,0,sizeof(CThostFtdcRspFutureSignInField));
  //交易时间
  strcpy(t->TradeTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeTime"),"gbk","Error!")));
  //渠道标志
  strcpy(t->DeviceID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "DeviceID"),"gbk","Error!")));
  //错误代码
  t->ErrorID =   PyLong_AsLong(PyObject_GetAttrString(p, "ErrorID"));
  //安装编号
  t->InstallID =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallID"));
  //期商代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //会话号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //银行代码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //币种代码
  strcpy(t->CurrencyID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrencyID"),"gbk","Error!")));
  //错误信息
  strcpy(t->ErrorMsg, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ErrorMsg"),"gbk","Error!")));
  //PIN密钥
  strcpy(t->PinKey, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "PinKey"),"gbk","Error!")));
  //交易柜员
  strcpy(t->OperNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OperNo"),"gbk","Error!")));
  //MAC密钥
  strcpy(t->MacKey, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "MacKey"),"gbk","Error!")));
  //摘要
  strcpy(t->Digest, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Digest"),"gbk","Error!")));
  //最后分片标志
  //enum类型
  //THOST_FTDC_LF_No -> '1', 不是最后分片
  //THOST_FTDC_LF_Yes -> '0', 是最后分片
  t->LastFragment =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LastFragment"),"gbk","Error!"))[0];
  //请求编号
  t->RequestID =   PyLong_AsLong(PyObject_GetAttrString(p, "RequestID"));
  //交易日期
  strcpy(t->TradeDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeDate"),"gbk","Error!")));
  //用户标识
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //交易系统日期
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //银行流水号
  strcpy(t->BankSerial, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSerial"),"gbk","Error!")));
  //期货公司银行编码
  strcpy(t->BrokerIDByBank, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerIDByBank"),"gbk","Error!")));
  //业务功能码
  strcpy(t->TradeCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeCode"),"gbk","Error!")));
  //交易ID
  t->TID =   PyLong_AsLong(PyObject_GetAttrString(p, "TID"));
  //银行分支机构代码
  strcpy(t->BankBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBranchID"),"gbk","Error!")));
  //期商分支机构代码
  strcpy(t->BrokerBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerBranchID"),"gbk","Error!")));
  //银期平台消息流水号
  t->PlateSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "PlateSerial"));

  return t;
};

//查询联系人
PyObject * new_CThostFtdcQryLinkManField(CThostFtdcQryLinkManField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryLinkManField", (char*)"yy",
p->BrokerID, p->InvestorID);
}
CThostFtdcQryLinkManField * from_CThostFtdcQryLinkManField(PyObject * p){
  CThostFtdcQryLinkManField *t = (CThostFtdcQryLinkManField *)calloc(1, sizeof(CThostFtdcQryLinkManField));
  memset(t,0,sizeof(CThostFtdcQryLinkManField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));

  return t;
};

//查询交易事件通知
PyObject * new_CThostFtdcQryTradingNoticeField(CThostFtdcQryTradingNoticeField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryTradingNoticeField", (char*)"yy",
p->BrokerID, p->InvestorID);
}
CThostFtdcQryTradingNoticeField * from_CThostFtdcQryTradingNoticeField(PyObject * p){
  CThostFtdcQryTradingNoticeField *t = (CThostFtdcQryTradingNoticeField *)calloc(1, sizeof(CThostFtdcQryTradingNoticeField));
  memset(t,0,sizeof(CThostFtdcQryTradingNoticeField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));

  return t;
};

//查询经纪公司用户事件
PyObject * new_CThostFtdcQryBrokerUserEventField(CThostFtdcQryBrokerUserEventField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryBrokerUserEventField", (char*)"ycy",
p->BrokerID, p->UserEventType, p->UserID);
}
CThostFtdcQryBrokerUserEventField * from_CThostFtdcQryBrokerUserEventField(PyObject * p){
  CThostFtdcQryBrokerUserEventField *t = (CThostFtdcQryBrokerUserEventField *)calloc(1, sizeof(CThostFtdcQryBrokerUserEventField));
  memset(t,0,sizeof(CThostFtdcQryBrokerUserEventField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //用户事件类型
  //enum类型
  //THOST_FTDC_UET_Authenticate -> '6', 客户端认证
  //THOST_FTDC_UET_UpdatePassword -> '5', 修改密码
  //THOST_FTDC_UET_Login -> '1', 登录
  //THOST_FTDC_UET_TradingError -> '4', 交易失败
  //THOST_FTDC_UET_Trading -> '3', 交易成功
  //THOST_FTDC_UET_Logout -> '2', 登出
  //THOST_FTDC_UET_Other -> '9', 其他
  t->UserEventType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserEventType"),"gbk","Error!"))[0];
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));

  return t;
};

//装载结算信息
PyObject * new_CThostFtdcLoadSettlementInfoField(CThostFtdcLoadSettlementInfoField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcLoadSettlementInfoField", (char*)"y",
p->BrokerID);
}
CThostFtdcLoadSettlementInfoField * from_CThostFtdcLoadSettlementInfoField(PyObject * p){
  CThostFtdcLoadSettlementInfoField *t = (CThostFtdcLoadSettlementInfoField *)calloc(1, sizeof(CThostFtdcLoadSettlementInfoField));
  memset(t,0,sizeof(CThostFtdcLoadSettlementInfoField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));

  return t;
};

//行情更新时间属性
PyObject * new_CThostFtdcMarketDataUpdateTimeField(CThostFtdcMarketDataUpdateTimeField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcMarketDataUpdateTimeField", (char*)"yyyi",
p->UpdateTime, p->InstrumentID, p->ActionDay, p->UpdateMillisec);
}
CThostFtdcMarketDataUpdateTimeField * from_CThostFtdcMarketDataUpdateTimeField(PyObject * p){
  CThostFtdcMarketDataUpdateTimeField *t = (CThostFtdcMarketDataUpdateTimeField *)calloc(1, sizeof(CThostFtdcMarketDataUpdateTimeField));
  memset(t,0,sizeof(CThostFtdcMarketDataUpdateTimeField));
  //最后修改时间
  strcpy(t->UpdateTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UpdateTime"),"gbk","Error!")));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //业务日期
  strcpy(t->ActionDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ActionDay"),"gbk","Error!")));
  //最后修改毫秒
  t->UpdateMillisec =   PyLong_AsLong(PyObject_GetAttrString(p, "UpdateMillisec"));

  return t;
};

//行情静态属性
PyObject * new_CThostFtdcMarketDataStaticField(CThostFtdcMarketDataStaticField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcMarketDataStaticField", (char*)"dddddddd",
p->LowestPrice, p->ClosePrice, p->UpperLimitPrice, p->HighestPrice, p->LowerLimitPrice, p->OpenPrice, p->SettlementPrice, p->CurrDelta);
}
CThostFtdcMarketDataStaticField * from_CThostFtdcMarketDataStaticField(PyObject * p){
  CThostFtdcMarketDataStaticField *t = (CThostFtdcMarketDataStaticField *)calloc(1, sizeof(CThostFtdcMarketDataStaticField));
  memset(t,0,sizeof(CThostFtdcMarketDataStaticField));
  //最低价
  t->LowestPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LowestPrice"));
  //今收盘
  t->ClosePrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ClosePrice"));
  //涨停板价
  t->UpperLimitPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "UpperLimitPrice"));
  //最高价
  t->HighestPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "HighestPrice"));
  //跌停板价
  t->LowerLimitPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LowerLimitPrice"));
  //今开盘
  t->OpenPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "OpenPrice"));
  //本次结算价
  t->SettlementPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "SettlementPrice"));
  //今虚实度
  t->CurrDelta =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CurrDelta"));

  return t;
};

//用户登出请求
PyObject * new_CThostFtdcUserLogoutField(CThostFtdcUserLogoutField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcUserLogoutField", (char*)"yy",
p->BrokerID, p->UserID);
}
CThostFtdcUserLogoutField * from_CThostFtdcUserLogoutField(PyObject * p){
  CThostFtdcUserLogoutField *t = (CThostFtdcUserLogoutField *)calloc(1, sizeof(CThostFtdcUserLogoutField));
  memset(t,0,sizeof(CThostFtdcUserLogoutField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));

  return t;
};

//深度行情
PyObject * new_CThostFtdcDepthMarketDataField(CThostFtdcDepthMarketDataField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcDepthMarketDataField", (char*)"dddddyiiiiiddddddiiiiidddydyiyiydydddddddddd",
p->ClosePrice, p->CurrDelta, p->HighestPrice, p->UpperLimitPrice, p->Turnover, p->ExchangeInstID, p->BidVolume1, p->BidVolume3, p->BidVolume2, p->BidVolume5, p->BidVolume4, p->LastPrice, p->LowerLimitPrice, p->SettlementPrice, p->PreOpenInterest, p->PreSettlementPrice, p->AveragePrice, p->AskVolume5, p->AskVolume4, p->AskVolume3, p->AskVolume2, p->AskVolume1, p->LowestPrice, p->OpenPrice, p->OpenInterest, p->InstrumentID, p->PreClosePrice, p->ExchangeID, p->UpdateMillisec, p->ActionDay, p->Volume, p->TradingDay, p->PreDelta, p->UpdateTime, p->BidPrice5, p->BidPrice4, p->BidPrice3, p->BidPrice2, p->BidPrice1, p->AskPrice5, p->AskPrice4, p->AskPrice1, p->AskPrice3, p->AskPrice2);
}
CThostFtdcDepthMarketDataField * from_CThostFtdcDepthMarketDataField(PyObject * p){
  CThostFtdcDepthMarketDataField *t = (CThostFtdcDepthMarketDataField *)calloc(1, sizeof(CThostFtdcDepthMarketDataField));
  memset(t,0,sizeof(CThostFtdcDepthMarketDataField));
  //今收盘
  t->ClosePrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ClosePrice"));
  //今虚实度
  t->CurrDelta =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CurrDelta"));
  //最高价
  t->HighestPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "HighestPrice"));
  //涨停板价
  t->UpperLimitPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "UpperLimitPrice"));
  //成交金额
  t->Turnover =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Turnover"));
  //合约在交易所的代码
  strcpy(t->ExchangeInstID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeInstID"),"gbk","Error!")));
  //申买量一
  t->BidVolume1 =   PyLong_AsLong(PyObject_GetAttrString(p, "BidVolume1"));
  //申买量三
  t->BidVolume3 =   PyLong_AsLong(PyObject_GetAttrString(p, "BidVolume3"));
  //申买量二
  t->BidVolume2 =   PyLong_AsLong(PyObject_GetAttrString(p, "BidVolume2"));
  //申买量五
  t->BidVolume5 =   PyLong_AsLong(PyObject_GetAttrString(p, "BidVolume5"));
  //申买量四
  t->BidVolume4 =   PyLong_AsLong(PyObject_GetAttrString(p, "BidVolume4"));
  //最新价
  t->LastPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LastPrice"));
  //跌停板价
  t->LowerLimitPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LowerLimitPrice"));
  //本次结算价
  t->SettlementPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "SettlementPrice"));
  //昨持仓量
  t->PreOpenInterest =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PreOpenInterest"));
  //上次结算价
  t->PreSettlementPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PreSettlementPrice"));
  //当日均价
  t->AveragePrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "AveragePrice"));
  //申卖量五
  t->AskVolume5 =   PyLong_AsLong(PyObject_GetAttrString(p, "AskVolume5"));
  //申卖量四
  t->AskVolume4 =   PyLong_AsLong(PyObject_GetAttrString(p, "AskVolume4"));
  //申卖量三
  t->AskVolume3 =   PyLong_AsLong(PyObject_GetAttrString(p, "AskVolume3"));
  //申卖量二
  t->AskVolume2 =   PyLong_AsLong(PyObject_GetAttrString(p, "AskVolume2"));
  //申卖量一
  t->AskVolume1 =   PyLong_AsLong(PyObject_GetAttrString(p, "AskVolume1"));
  //最低价
  t->LowestPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LowestPrice"));
  //今开盘
  t->OpenPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "OpenPrice"));
  //持仓量
  t->OpenInterest =   PyFloat_AsDouble(PyObject_GetAttrString(p, "OpenInterest"));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //昨收盘
  t->PreClosePrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PreClosePrice"));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //最后修改毫秒
  t->UpdateMillisec =   PyLong_AsLong(PyObject_GetAttrString(p, "UpdateMillisec"));
  //业务日期
  strcpy(t->ActionDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ActionDay"),"gbk","Error!")));
  //数量
  t->Volume =   PyLong_AsLong(PyObject_GetAttrString(p, "Volume"));
  //交易日
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //昨虚实度
  t->PreDelta =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PreDelta"));
  //最后修改时间
  strcpy(t->UpdateTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UpdateTime"),"gbk","Error!")));
  //申买价五
  t->BidPrice5 =   PyFloat_AsDouble(PyObject_GetAttrString(p, "BidPrice5"));
  //申买价四
  t->BidPrice4 =   PyFloat_AsDouble(PyObject_GetAttrString(p, "BidPrice4"));
  //申买价三
  t->BidPrice3 =   PyFloat_AsDouble(PyObject_GetAttrString(p, "BidPrice3"));
  //申买价二
  t->BidPrice2 =   PyFloat_AsDouble(PyObject_GetAttrString(p, "BidPrice2"));
  //申买价一
  t->BidPrice1 =   PyFloat_AsDouble(PyObject_GetAttrString(p, "BidPrice1"));
  //申卖价五
  t->AskPrice5 =   PyFloat_AsDouble(PyObject_GetAttrString(p, "AskPrice5"));
  //申卖价四
  t->AskPrice4 =   PyFloat_AsDouble(PyObject_GetAttrString(p, "AskPrice4"));
  //申卖价一
  t->AskPrice1 =   PyFloat_AsDouble(PyObject_GetAttrString(p, "AskPrice1"));
  //申卖价三
  t->AskPrice3 =   PyFloat_AsDouble(PyObject_GetAttrString(p, "AskPrice3"));
  //申卖价二
  t->AskPrice2 =   PyFloat_AsDouble(PyObject_GetAttrString(p, "AskPrice2"));

  return t;
};

//根据价格查询最大报单数量
PyObject * new_CThostFtdcQueryMaxOrderVolumeWithPriceField(CThostFtdcQueryMaxOrderVolumeWithPriceField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQueryMaxOrderVolumeWithPriceField", (char*)"dyccicyy",
p->Price, p->InstrumentID, p->OffsetFlag, p->HedgeFlag, p->MaxVolume, p->Direction, p->BrokerID, p->InvestorID);
}
CThostFtdcQueryMaxOrderVolumeWithPriceField * from_CThostFtdcQueryMaxOrderVolumeWithPriceField(PyObject * p){
  CThostFtdcQueryMaxOrderVolumeWithPriceField *t = (CThostFtdcQueryMaxOrderVolumeWithPriceField *)calloc(1, sizeof(CThostFtdcQueryMaxOrderVolumeWithPriceField));
  memset(t,0,sizeof(CThostFtdcQueryMaxOrderVolumeWithPriceField));
  //报单价格
  t->Price =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Price"));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //开平标志
  //enum类型
  //THOST_FTDC_OF_Close -> '1', 平仓
  //THOST_FTDC_OF_CloseYesterday -> '4', 平昨
  //THOST_FTDC_OF_CloseToday -> '3', 平今
  //THOST_FTDC_OF_Open -> '0', 开仓
  //THOST_FTDC_OF_LocalForceClose -> '6', 本地强平
  //THOST_FTDC_OF_ForceClose -> '2', 强平
  //THOST_FTDC_OF_ForceOff -> '5', 强减
  t->OffsetFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OffsetFlag"),"gbk","Error!"))[0];
  //投机套保标志
  //enum类型
  //THOST_FTDC_HF_Hedge -> '3', 套保
  //THOST_FTDC_HF_Arbitrage -> '2', 套利
  //THOST_FTDC_HF_Speculation -> '1', 投机
  t->HedgeFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "HedgeFlag"),"gbk","Error!"))[0];
  //最大允许报单数量
  t->MaxVolume =   PyLong_AsLong(PyObject_GetAttrString(p, "MaxVolume"));
  //买卖方向
  //enum类型
  //THOST_FTDC_D_Buy -> '0', 买
  //THOST_FTDC_D_Sell -> '1', 卖
  t->Direction =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Direction"),"gbk","Error!"))[0];
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));

  return t;
};

//查询交易所保证金率
PyObject * new_CThostFtdcQryExchangeMarginRateField(CThostFtdcQryExchangeMarginRateField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryExchangeMarginRateField", (char*)"yyc",
p->BrokerID, p->InstrumentID, p->HedgeFlag);
}
CThostFtdcQryExchangeMarginRateField * from_CThostFtdcQryExchangeMarginRateField(PyObject * p){
  CThostFtdcQryExchangeMarginRateField *t = (CThostFtdcQryExchangeMarginRateField *)calloc(1, sizeof(CThostFtdcQryExchangeMarginRateField));
  memset(t,0,sizeof(CThostFtdcQryExchangeMarginRateField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //投机套保标志
  //enum类型
  //THOST_FTDC_HF_Hedge -> '3', 套保
  //THOST_FTDC_HF_Arbitrage -> '2', 套利
  //THOST_FTDC_HF_Speculation -> '1', 投机
  t->HedgeFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "HedgeFlag"),"gbk","Error!"))[0];

  return t;
};

//数据同步状态
PyObject * new_CThostFtdcSyncStatusField(CThostFtdcSyncStatusField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcSyncStatusField", (char*)"yc",
p->TradingDay, p->DataSyncStatus);
}
CThostFtdcSyncStatusField * from_CThostFtdcSyncStatusField(PyObject * p){
  CThostFtdcSyncStatusField *t = (CThostFtdcSyncStatusField *)calloc(1, sizeof(CThostFtdcSyncStatusField));
  memset(t,0,sizeof(CThostFtdcSyncStatusField));
  //交易日
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //数据同步状态
  //enum类型
  //THOST_FTDC_DS_Synchronized -> '3', 已同步
  //THOST_FTDC_DS_Asynchronous -> '1', 未同步
  //THOST_FTDC_DS_Synchronizing -> '2', 同步中
  t->DataSyncStatus =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "DataSyncStatus"),"gbk","Error!"))[0];

  return t;
};

//指定的合约
PyObject * new_CThostFtdcSpecificInstrumentField(CThostFtdcSpecificInstrumentField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcSpecificInstrumentField", (char*)"y",
p->InstrumentID);
}
CThostFtdcSpecificInstrumentField * from_CThostFtdcSpecificInstrumentField(PyObject * p){
  CThostFtdcSpecificInstrumentField *t = (CThostFtdcSpecificInstrumentField *)calloc(1, sizeof(CThostFtdcSpecificInstrumentField));
  memset(t,0,sizeof(CThostFtdcSpecificInstrumentField));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));

  return t;
};

//银期转账交易流水表
PyObject * new_CThostFtdcTransferSerialField(CThostFtdcTransferSerialField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcTransferSerialField", (char*)"cyyiiyyiycdyyyyyycydcyyydyyi",
p->AvailabilityFlag, p->TradingDay, p->TradeTime, p->FutureSerial, p->ErrorID, p->BrokerID, p->InvestorID, p->SessionID, p->IdentifiedCardNo, p->IdCardType, p->TradeAmount, p->BankID, p->CurrencyID, p->ErrorMsg, p->BankNewAccount, p->BankAccount, p->OperatorCode, p->BankAccType, p->TradeDate, p->CustFee, p->FutureAccType, p->AccountID, p->BankSerial, p->TradeCode, p->BrokerFee, p->BankBranchID, p->BrokerBranchID, p->PlateSerial);
}
CThostFtdcTransferSerialField * from_CThostFtdcTransferSerialField(PyObject * p){
  CThostFtdcTransferSerialField *t = (CThostFtdcTransferSerialField *)calloc(1, sizeof(CThostFtdcTransferSerialField));
  memset(t,0,sizeof(CThostFtdcTransferSerialField));
  //有效标志
  //enum类型
  //THOST_FTDC_AVAF_Valid -> '1', 有效
  //THOST_FTDC_AVAF_Invalid -> '0', 未确认
  //THOST_FTDC_AVAF_Repeal -> '2', 冲正
  t->AvailabilityFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AvailabilityFlag"),"gbk","Error!"))[0];
  //交易日期
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //交易时间
  strcpy(t->TradeTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeTime"),"gbk","Error!")));
  //期货公司流水号
  t->FutureSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "FutureSerial"));
  //错误代码
  t->ErrorID =   PyLong_AsLong(PyObject_GetAttrString(p, "ErrorID"));
  //期货公司编码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //会话编号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //证件号码
  strcpy(t->IdentifiedCardNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdentifiedCardNo"),"gbk","Error!")));
  //证件类型
  //enum类型
  //THOST_FTDC_ICT_TaiwanCompatriotIDCard -> '7', 台胞证
  //THOST_FTDC_ICT_Passport -> '6', 护照
  //THOST_FTDC_ICT_LicenseNo -> '9', 营业执照号
  //THOST_FTDC_ICT_OtherCard -> 'x', 其他证件
  //THOST_FTDC_ICT_IDCard -> '1', 身份证
  //THOST_FTDC_ICT_EID -> '0', 组织机构代码
  //THOST_FTDC_ICT_TaxNo -> 'A', 税务登记号
  //THOST_FTDC_ICT_HomeComingCard -> '8', 回乡证
  //THOST_FTDC_ICT_OfficerIDCard -> '2', 军官证
  //THOST_FTDC_ICT_HouseholdRegister -> '5', 户口簿
  //THOST_FTDC_ICT_SoldierIDCard -> '4', 士兵证
  //THOST_FTDC_ICT_PoliceIDCard -> '3', 警官证
  t->IdCardType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdCardType"),"gbk","Error!"))[0];
  //交易金额
  t->TradeAmount =   PyFloat_AsDouble(PyObject_GetAttrString(p, "TradeAmount"));
  //银行编码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //币种代码
  strcpy(t->CurrencyID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrencyID"),"gbk","Error!")));
  //错误信息
  strcpy(t->ErrorMsg, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ErrorMsg"),"gbk","Error!")));
  //新银行帐号
  strcpy(t->BankNewAccount, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankNewAccount"),"gbk","Error!")));
  //银行帐号
  strcpy(t->BankAccount, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccount"),"gbk","Error!")));
  //操作员
  strcpy(t->OperatorCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OperatorCode"),"gbk","Error!")));
  //银行帐号类型
  //enum类型
  //THOST_FTDC_BAT_SavingCard -> '2', 储蓄卡
  //THOST_FTDC_BAT_CreditCard -> '3', 信用卡
  //THOST_FTDC_BAT_BankBook -> '1', 银行存折
  t->BankAccType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccType"),"gbk","Error!"))[0];
  //交易发起方日期
  strcpy(t->TradeDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeDate"),"gbk","Error!")));
  //应收客户费用
  t->CustFee =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CustFee"));
  //期货公司帐号类型
  //enum类型
  //THOST_FTDC_FAT_SavingCard -> '2', 储蓄卡
  //THOST_FTDC_FAT_CreditCard -> '3', 信用卡
  //THOST_FTDC_FAT_BankBook -> '1', 银行存折
  t->FutureAccType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "FutureAccType"),"gbk","Error!"))[0];
  //投资者帐号
  strcpy(t->AccountID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AccountID"),"gbk","Error!")));
  //银行流水号
  strcpy(t->BankSerial, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSerial"),"gbk","Error!")));
  //交易代码
  strcpy(t->TradeCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeCode"),"gbk","Error!")));
  //应收期货公司费用
  t->BrokerFee =   PyFloat_AsDouble(PyObject_GetAttrString(p, "BrokerFee"));
  //银行分支机构编码
  strcpy(t->BankBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBranchID"),"gbk","Error!")));
  //期商分支机构代码
  strcpy(t->BrokerBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerBranchID"),"gbk","Error!")));
  //平台流水号
  t->PlateSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "PlateSerial"));

  return t;
};

//用户动态令牌参数
PyObject * new_CThostFtdcBrokerUserOTPParamField(CThostFtdcBrokerUserOTPParamField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcBrokerUserOTPParamField", (char*)"yciyyyiy",
p->OTPVendorsID, p->OTPType, p->LastDrift, p->AuthKey, p->SerialNumber, p->BrokerID, p->LastSuccess, p->UserID);
}
CThostFtdcBrokerUserOTPParamField * from_CThostFtdcBrokerUserOTPParamField(PyObject * p){
  CThostFtdcBrokerUserOTPParamField *t = (CThostFtdcBrokerUserOTPParamField *)calloc(1, sizeof(CThostFtdcBrokerUserOTPParamField));
  memset(t,0,sizeof(CThostFtdcBrokerUserOTPParamField));
  //动态令牌提供商
  strcpy(t->OTPVendorsID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OTPVendorsID"),"gbk","Error!")));
  //动态令牌类型
  //enum类型
  //THOST_FTDC_OTP_NONE -> '0', 无动态令牌
  //THOST_FTDC_OTP_TOTP -> '1', 时间令牌
  t->OTPType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OTPType"),"gbk","Error!"))[0];
  //漂移值
  t->LastDrift =   PyLong_AsLong(PyObject_GetAttrString(p, "LastDrift"));
  //令牌密钥
  strcpy(t->AuthKey, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AuthKey"),"gbk","Error!")));
  //动态令牌序列号
  strcpy(t->SerialNumber, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "SerialNumber"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //成功值
  t->LastSuccess =   PyLong_AsLong(PyObject_GetAttrString(p, "LastSuccess"));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));

  return t;
};

//正在同步中的交易代码
PyObject * new_CThostFtdcSyncingTradingCodeField(CThostFtdcSyncingTradingCodeField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcSyncingTradingCodeField", (char*)"iycyyy",
p->IsActive, p->ClientID, p->ClientIDType, p->BrokerID, p->InvestorID, p->ExchangeID);
}
CThostFtdcSyncingTradingCodeField * from_CThostFtdcSyncingTradingCodeField(PyObject * p){
  CThostFtdcSyncingTradingCodeField *t = (CThostFtdcSyncingTradingCodeField *)calloc(1, sizeof(CThostFtdcSyncingTradingCodeField));
  memset(t,0,sizeof(CThostFtdcSyncingTradingCodeField));
  //是否活跃
  t->IsActive =   PyLong_AsLong(PyObject_GetAttrString(p, "IsActive"));
  //客户代码
  strcpy(t->ClientID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ClientID"),"gbk","Error!")));
  //交易编码类型
  //enum类型
  //THOST_FTDC_CIDT_Arbitrage -> '2', 套利
  //THOST_FTDC_CIDT_Hedge -> '3', 套保
  //THOST_FTDC_CIDT_Speculation -> '1', 投机
  t->ClientIDType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ClientIDType"),"gbk","Error!"))[0];
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));

  return t;
};

//查询经纪公司
PyObject * new_CThostFtdcQryBrokerField(CThostFtdcQryBrokerField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryBrokerField", (char*)"y",
p->BrokerID);
}
CThostFtdcQryBrokerField * from_CThostFtdcQryBrokerField(PyObject * p){
  CThostFtdcQryBrokerField *t = (CThostFtdcQryBrokerField *)calloc(1, sizeof(CThostFtdcQryBrokerField));
  memset(t,0,sizeof(CThostFtdcQryBrokerField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));

  return t;
};

//合约
PyObject * new_CThostFtdcInstrumentField(CThostFtdcInstrumentField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcInstrumentField", (char*)"yyiyicidccyyyidyiicyycidyi",
p->CreateDate, p->InstrumentName, p->DeliveryMonth, p->StartDelivDate, p->MinMarketOrderVolume, p->ProductClass, p->VolumeMultiple, p->PriceTick, p->InstLifePhase, p->MaxMarginSideAlgorithm, p->InstrumentID, p->ExpireDate, p->ExchangeInstID, p->DeliveryYear, p->ShortMarginRatio, p->EndDelivDate, p->MaxMarketOrderVolume, p->MinLimitOrderVolume, p->PositionType, p->ProductID, p->OpenDate, p->PositionDateType, p->IsTrading, p->LongMarginRatio, p->ExchangeID, p->MaxLimitOrderVolume);
}
CThostFtdcInstrumentField * from_CThostFtdcInstrumentField(PyObject * p){
  CThostFtdcInstrumentField *t = (CThostFtdcInstrumentField *)calloc(1, sizeof(CThostFtdcInstrumentField));
  memset(t,0,sizeof(CThostFtdcInstrumentField));
  //创建日
  strcpy(t->CreateDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CreateDate"),"gbk","Error!")));
  //合约名称
  strcpy(t->InstrumentName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentName"),"gbk","Error!")));
  //交割月
  t->DeliveryMonth =   PyLong_AsLong(PyObject_GetAttrString(p, "DeliveryMonth"));
  //开始交割日
  strcpy(t->StartDelivDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "StartDelivDate"),"gbk","Error!")));
  //市价单最小下单量
  t->MinMarketOrderVolume =   PyLong_AsLong(PyObject_GetAttrString(p, "MinMarketOrderVolume"));
  //产品类型
  //enum类型
  //THOST_FTDC_PC_Options -> '2', 期权
  //THOST_FTDC_PC_Futures -> '1', 期货
  //THOST_FTDC_PC_Spot -> '4', 即期
  //THOST_FTDC_PC_EFP -> '5', 期转现
  //THOST_FTDC_PC_Combination -> '3', 组合
  t->ProductClass =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ProductClass"),"gbk","Error!"))[0];
  //合约数量乘数
  t->VolumeMultiple =   PyLong_AsLong(PyObject_GetAttrString(p, "VolumeMultiple"));
  //最小变动价位
  t->PriceTick =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PriceTick"));
  //合约生命周期状态
  //enum类型
  //THOST_FTDC_IP_Started -> '1', 上市
  //THOST_FTDC_IP_NotStart -> '0', 未上市
  //THOST_FTDC_IP_Pause -> '2', 停牌
  //THOST_FTDC_IP_Expired -> '3', 到期
  t->InstLifePhase =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstLifePhase"),"gbk","Error!"))[0];
  //是否使用大额单边保证金算法
  //enum类型
  //THOST_FTDC_MMSA_NO -> '0', 不使用大额单边保证金算法
  //THOST_FTDC_MMSA_YES -> '1', 使用大额单边保证金算法
  t->MaxMarginSideAlgorithm =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "MaxMarginSideAlgorithm"),"gbk","Error!"))[0];
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //到期日
  strcpy(t->ExpireDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExpireDate"),"gbk","Error!")));
  //合约在交易所的代码
  strcpy(t->ExchangeInstID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeInstID"),"gbk","Error!")));
  //交割年份
  t->DeliveryYear =   PyLong_AsLong(PyObject_GetAttrString(p, "DeliveryYear"));
  //空头保证金率
  t->ShortMarginRatio =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ShortMarginRatio"));
  //结束交割日
  strcpy(t->EndDelivDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "EndDelivDate"),"gbk","Error!")));
  //市价单最大下单量
  t->MaxMarketOrderVolume =   PyLong_AsLong(PyObject_GetAttrString(p, "MaxMarketOrderVolume"));
  //限价单最小下单量
  t->MinLimitOrderVolume =   PyLong_AsLong(PyObject_GetAttrString(p, "MinLimitOrderVolume"));
  //持仓类型
  //enum类型
  //THOST_FTDC_PT_Net -> '1', 净持仓
  //THOST_FTDC_PT_Gross -> '2', 综合持仓
  t->PositionType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "PositionType"),"gbk","Error!"))[0];
  //产品代码
  strcpy(t->ProductID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ProductID"),"gbk","Error!")));
  //上市日
  strcpy(t->OpenDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OpenDate"),"gbk","Error!")));
  //持仓日期类型
  //enum类型
  //THOST_FTDC_PDT_NoUseHistory -> '2', 不使用历史持仓
  //THOST_FTDC_PDT_UseHistory -> '1', 使用历史持仓
  t->PositionDateType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "PositionDateType"),"gbk","Error!"))[0];
  //当前是否交易
  t->IsTrading =   PyLong_AsLong(PyObject_GetAttrString(p, "IsTrading"));
  //多头保证金率
  t->LongMarginRatio =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LongMarginRatio"));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //限价单最大下单量
  t->MaxLimitOrderVolume =   PyLong_AsLong(PyObject_GetAttrString(p, "MaxLimitOrderVolume"));

  return t;
};

//出入金同步
PyObject * new_CThostFtdcSyncDepositField(CThostFtdcSyncDepositField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcSyncDepositField", (char*)"yyyid",
p->DepositSeqNo, p->BrokerID, p->InvestorID, p->IsForce, p->Deposit);
}
CThostFtdcSyncDepositField * from_CThostFtdcSyncDepositField(PyObject * p){
  CThostFtdcSyncDepositField *t = (CThostFtdcSyncDepositField *)calloc(1, sizeof(CThostFtdcSyncDepositField));
  memset(t,0,sizeof(CThostFtdcSyncDepositField));
  //出入金流水号
  strcpy(t->DepositSeqNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "DepositSeqNo"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //是否强制进行
  t->IsForce =   PyLong_AsLong(PyObject_GetAttrString(p, "IsForce"));
  //入金金额
  t->Deposit =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Deposit"));

  return t;
};

//交易核心向银期报盘发出密钥同步响应
PyObject * new_CThostFtdcRspSyncKeyField(CThostFtdcRspSyncKeyField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcRspSyncKeyField", (char*)"yyiiyiyyyciyyyyyyyiyyi",
p->TradeTime, p->DeviceID, p->ErrorID, p->InstallID, p->BrokerID, p->SessionID, p->BankID, p->ErrorMsg, p->OperNo, p->LastFragment, p->RequestID, p->TradeDate, p->UserID, p->TradingDay, p->BankSerial, p->BrokerIDByBank, p->TradeCode, p->Message, p->TID, p->BankBranchID, p->BrokerBranchID, p->PlateSerial);
}
CThostFtdcRspSyncKeyField * from_CThostFtdcRspSyncKeyField(PyObject * p){
  CThostFtdcRspSyncKeyField *t = (CThostFtdcRspSyncKeyField *)calloc(1, sizeof(CThostFtdcRspSyncKeyField));
  memset(t,0,sizeof(CThostFtdcRspSyncKeyField));
  //交易时间
  strcpy(t->TradeTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeTime"),"gbk","Error!")));
  //渠道标志
  strcpy(t->DeviceID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "DeviceID"),"gbk","Error!")));
  //错误代码
  t->ErrorID =   PyLong_AsLong(PyObject_GetAttrString(p, "ErrorID"));
  //安装编号
  t->InstallID =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallID"));
  //期商代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //会话号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //银行代码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //错误信息
  strcpy(t->ErrorMsg, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ErrorMsg"),"gbk","Error!")));
  //交易柜员
  strcpy(t->OperNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OperNo"),"gbk","Error!")));
  //最后分片标志
  //enum类型
  //THOST_FTDC_LF_No -> '1', 不是最后分片
  //THOST_FTDC_LF_Yes -> '0', 是最后分片
  t->LastFragment =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LastFragment"),"gbk","Error!"))[0];
  //请求编号
  t->RequestID =   PyLong_AsLong(PyObject_GetAttrString(p, "RequestID"));
  //交易日期
  strcpy(t->TradeDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeDate"),"gbk","Error!")));
  //用户标识
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //交易系统日期
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //银行流水号
  strcpy(t->BankSerial, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSerial"),"gbk","Error!")));
  //期货公司银行编码
  strcpy(t->BrokerIDByBank, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerIDByBank"),"gbk","Error!")));
  //业务功能码
  strcpy(t->TradeCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeCode"),"gbk","Error!")));
  //交易核心给银期报盘的消息
  strcpy(t->Message, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Message"),"gbk","Error!")));
  //交易ID
  t->TID =   PyLong_AsLong(PyObject_GetAttrString(p, "TID"));
  //银行分支机构代码
  strcpy(t->BankBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBranchID"),"gbk","Error!")));
  //期商分支机构代码
  strcpy(t->BrokerBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerBranchID"),"gbk","Error!")));
  //银期平台消息流水号
  t->PlateSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "PlateSerial"));

  return t;
};

//行情最优价属性
PyObject * new_CThostFtdcMarketDataBestPriceField(CThostFtdcMarketDataBestPriceField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcMarketDataBestPriceField", (char*)"idid",
p->BidVolume1, p->AskPrice1, p->AskVolume1, p->BidPrice1);
}
CThostFtdcMarketDataBestPriceField * from_CThostFtdcMarketDataBestPriceField(PyObject * p){
  CThostFtdcMarketDataBestPriceField *t = (CThostFtdcMarketDataBestPriceField *)calloc(1, sizeof(CThostFtdcMarketDataBestPriceField));
  memset(t,0,sizeof(CThostFtdcMarketDataBestPriceField));
  //申买量一
  t->BidVolume1 =   PyLong_AsLong(PyObject_GetAttrString(p, "BidVolume1"));
  //申卖价一
  t->AskPrice1 =   PyFloat_AsDouble(PyObject_GetAttrString(p, "AskPrice1"));
  //申卖量一
  t->AskVolume1 =   PyLong_AsLong(PyObject_GetAttrString(p, "AskVolume1"));
  //申买价一
  t->BidPrice1 =   PyFloat_AsDouble(PyObject_GetAttrString(p, "BidPrice1"));

  return t;
};

//投资者持仓
PyObject * new_CThostFtdcInvestorPositionField(CThostFtdcInvestorPositionField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcInvestorPositionField", (char*)"icddyydddiyddidddiiiddddddydidddidciidic",
p->LongFrozen, p->PosiDirection, p->CloseProfitByTrade, p->SettlementPrice, p->BrokerID, p->InvestorID, p->OpenCost, p->Commission, p->CashIn, p->TodayPosition, p->InstrumentID, p->CloseProfit, p->ExchangeMargin, p->CombLongFrozen, p->PositionProfit, p->PreSettlementPrice, p->FrozenMargin, p->Position, p->ShortFrozen, p->SettlementID, p->LongFrozenAmount, p->ShortFrozenAmount, p->CloseProfitByDate, p->FrozenCommission, p->MarginRateByVolume, p->MarginRateByMoney, p->TradingDay, p->UseMargin, p->OpenVolume, p->FrozenCash, p->PositionCost, p->CloseAmount, p->YdPosition, p->OpenAmount, p->HedgeFlag, p->CloseVolume, p->CombPosition, p->PreMargin, p->CombShortFrozen, p->PositionDate);
}
CThostFtdcInvestorPositionField * from_CThostFtdcInvestorPositionField(PyObject * p){
  CThostFtdcInvestorPositionField *t = (CThostFtdcInvestorPositionField *)calloc(1, sizeof(CThostFtdcInvestorPositionField));
  memset(t,0,sizeof(CThostFtdcInvestorPositionField));
  //多头冻结
  t->LongFrozen =   PyLong_AsLong(PyObject_GetAttrString(p, "LongFrozen"));
  //持仓多空方向
  //enum类型
  //THOST_FTDC_PD_Net -> '1', 净
  //THOST_FTDC_PD_Long -> '2', 多头
  //THOST_FTDC_PD_Short -> '3', 空头
  t->PosiDirection =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "PosiDirection"),"gbk","Error!"))[0];
  //逐笔对冲平仓盈亏
  t->CloseProfitByTrade =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CloseProfitByTrade"));
  //本次结算价
  t->SettlementPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "SettlementPrice"));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //开仓成本
  t->OpenCost =   PyFloat_AsDouble(PyObject_GetAttrString(p, "OpenCost"));
  //手续费
  t->Commission =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Commission"));
  //资金差额
  t->CashIn =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CashIn"));
  //今日持仓
  t->TodayPosition =   PyLong_AsLong(PyObject_GetAttrString(p, "TodayPosition"));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //平仓盈亏
  t->CloseProfit =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CloseProfit"));
  //交易所保证金
  t->ExchangeMargin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ExchangeMargin"));
  //组合多头冻结
  t->CombLongFrozen =   PyLong_AsLong(PyObject_GetAttrString(p, "CombLongFrozen"));
  //持仓盈亏
  t->PositionProfit =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PositionProfit"));
  //上次结算价
  t->PreSettlementPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PreSettlementPrice"));
  //冻结的保证金
  t->FrozenMargin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "FrozenMargin"));
  //今日持仓
  t->Position =   PyLong_AsLong(PyObject_GetAttrString(p, "Position"));
  //空头冻结
  t->ShortFrozen =   PyLong_AsLong(PyObject_GetAttrString(p, "ShortFrozen"));
  //结算编号
  t->SettlementID =   PyLong_AsLong(PyObject_GetAttrString(p, "SettlementID"));
  //开仓冻结金额
  t->LongFrozenAmount =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LongFrozenAmount"));
  //开仓冻结金额
  t->ShortFrozenAmount =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ShortFrozenAmount"));
  //逐日盯市平仓盈亏
  t->CloseProfitByDate =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CloseProfitByDate"));
  //冻结的手续费
  t->FrozenCommission =   PyFloat_AsDouble(PyObject_GetAttrString(p, "FrozenCommission"));
  //保证金率(按手数)
  t->MarginRateByVolume =   PyFloat_AsDouble(PyObject_GetAttrString(p, "MarginRateByVolume"));
  //保证金率
  t->MarginRateByMoney =   PyFloat_AsDouble(PyObject_GetAttrString(p, "MarginRateByMoney"));
  //交易日
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //占用的保证金
  t->UseMargin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "UseMargin"));
  //开仓量
  t->OpenVolume =   PyLong_AsLong(PyObject_GetAttrString(p, "OpenVolume"));
  //冻结的资金
  t->FrozenCash =   PyFloat_AsDouble(PyObject_GetAttrString(p, "FrozenCash"));
  //持仓成本
  t->PositionCost =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PositionCost"));
  //平仓金额
  t->CloseAmount =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CloseAmount"));
  //上日持仓
  t->YdPosition =   PyLong_AsLong(PyObject_GetAttrString(p, "YdPosition"));
  //开仓金额
  t->OpenAmount =   PyFloat_AsDouble(PyObject_GetAttrString(p, "OpenAmount"));
  //投机套保标志
  //enum类型
  //THOST_FTDC_HF_Hedge -> '3', 套保
  //THOST_FTDC_HF_Arbitrage -> '2', 套利
  //THOST_FTDC_HF_Speculation -> '1', 投机
  t->HedgeFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "HedgeFlag"),"gbk","Error!"))[0];
  //平仓量
  t->CloseVolume =   PyLong_AsLong(PyObject_GetAttrString(p, "CloseVolume"));
  //组合成交形成的持仓
  t->CombPosition =   PyLong_AsLong(PyObject_GetAttrString(p, "CombPosition"));
  //上次占用的保证金
  t->PreMargin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PreMargin"));
  //组合空头冻结
  t->CombShortFrozen =   PyLong_AsLong(PyObject_GetAttrString(p, "CombShortFrozen"));
  //持仓日期
  //enum类型
  //THOST_FTDC_PSD_Today -> '1', 今日持仓
  //THOST_FTDC_PSD_History -> '2', 历史持仓
  t->PositionDate =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "PositionDate"),"gbk","Error!"))[0];

  return t;
};

//查询签约银行请求
PyObject * new_CThostFtdcQryContractBankField(CThostFtdcQryContractBankField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryContractBankField", (char*)"yyy",
p->BankID, p->BrokerID, p->BankBrchID);
}
CThostFtdcQryContractBankField * from_CThostFtdcQryContractBankField(PyObject * p){
  CThostFtdcQryContractBankField *t = (CThostFtdcQryContractBankField *)calloc(1, sizeof(CThostFtdcQryContractBankField));
  memset(t,0,sizeof(CThostFtdcQryContractBankField));
  //银行代码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //银行分中心代码
  strcpy(t->BankBrchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBrchID"),"gbk","Error!")));

  return t;
};

//请求查询投资者手续费率模板
PyObject * new_CThostFtdcQryCommRateModelField(CThostFtdcQryCommRateModelField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryCommRateModelField", (char*)"yy",
p->CommModelID, p->BrokerID);
}
CThostFtdcQryCommRateModelField * from_CThostFtdcQryCommRateModelField(PyObject * p){
  CThostFtdcQryCommRateModelField *t = (CThostFtdcQryCommRateModelField *)calloc(1, sizeof(CThostFtdcQryCommRateModelField));
  memset(t,0,sizeof(CThostFtdcQryCommRateModelField));
  //手续费率模板代码
  strcpy(t->CommModelID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CommModelID"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));

  return t;
};

//交易所报单
PyObject * new_CThostFtdcExchangeOrderField(CThostFtdcExchangeOrderField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcExchangeOrderField", (char*)"yccyyyiyiciyyycyiiyyiiiiydcyyyyicydyccycyc",
p->CombOffsetFlag, p->OrderPriceType, p->OrderSubmitStatus, p->OrderSysID, p->InsertTime, p->ClientID, p->InstallID, p->CombHedgeFlag, p->MinVolume, p->ForceCloseReason, p->VolumeTotalOriginal, p->InsertDate, p->CancelTime, p->TradingDay, p->OrderStatus, p->ExchangeInstID, p->VolumeTotal, p->NotifySequence, p->UpdateTime, p->SuspendTime, p->RequestID, p->IsAutoSuspend, p->SequenceNo, p->VolumeTraded, p->ActiveTime, p->StopPrice, p->OrderSource, p->ExchangeID, p->GTDDate, p->TraderID, p->ParticipantID, p->SettlementID, p->Direction, p->BusinessUnit, p->LimitPrice, p->ClearingPartID, p->ContingentCondition, p->VolumeCondition, p->ActiveTraderID, p->OrderType, p->OrderLocalID, p->TimeCondition);
}
CThostFtdcExchangeOrderField * from_CThostFtdcExchangeOrderField(PyObject * p){
  CThostFtdcExchangeOrderField *t = (CThostFtdcExchangeOrderField *)calloc(1, sizeof(CThostFtdcExchangeOrderField));
  memset(t,0,sizeof(CThostFtdcExchangeOrderField));
  //组合开平标志
  strcpy(t->CombOffsetFlag, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CombOffsetFlag"),"gbk","Error!")));
  //报单价格条件
  //enum类型
  //THOST_FTDC_OPT_LastPricePlusOneTicks -> '5', 最新价浮动上浮1个ticks
  //THOST_FTDC_OPT_LastPricePlusTwoTicks -> '6', 最新价浮动上浮2个ticks
  //THOST_FTDC_OPT_BidPrice1PlusTwoTicks -> 'E', 买一价浮动上浮2个ticks
  //THOST_FTDC_OPT_AnyPrice -> '1', 任意价
  //THOST_FTDC_OPT_AskPrice1PlusTwoTicks -> 'A', 卖一价浮动上浮2个ticks
  //THOST_FTDC_OPT_AskPrice1PlusThreeTicks -> 'B', 卖一价浮动上浮3个ticks
  //THOST_FTDC_OPT_BidPrice1PlusThreeTicks -> 'F', 买一价浮动上浮3个ticks
  //THOST_FTDC_OPT_BestPrice -> '3', 最优价
  //THOST_FTDC_OPT_LimitPrice -> '2', 限价
  //THOST_FTDC_OPT_BidPrice1 -> 'C', 买一价
  //THOST_FTDC_OPT_AskPrice1PlusOneTicks -> '9', 卖一价浮动上浮1个ticks
  //THOST_FTDC_OPT_LastPricePlusThreeTicks -> '7', 最新价浮动上浮3个ticks
  //THOST_FTDC_OPT_LastPrice -> '4', 最新价
  //THOST_FTDC_OPT_AskPrice1 -> '8', 卖一价
  //THOST_FTDC_OPT_BidPrice1PlusOneTicks -> 'D', 买一价浮动上浮1个ticks
  t->OrderPriceType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderPriceType"),"gbk","Error!"))[0];
  //报单提交状态
  //enum类型
  //THOST_FTDC_OSS_ModifyRejected -> '6', 改单已经被拒绝
  //THOST_FTDC_OSS_InsertRejected -> '4', 报单已经被拒绝
  //THOST_FTDC_OSS_CancelSubmitted -> '1', 撤单已经提交
  //THOST_FTDC_OSS_ModifySubmitted -> '2', 修改已经提交
  //THOST_FTDC_OSS_Accepted -> '3', 已经接受
  //THOST_FTDC_OSS_InsertSubmitted -> '0', 已经提交
  //THOST_FTDC_OSS_CancelRejected -> '5', 撤单已经被拒绝
  t->OrderSubmitStatus =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderSubmitStatus"),"gbk","Error!"))[0];
  //报单编号
  strcpy(t->OrderSysID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderSysID"),"gbk","Error!")));
  //委托时间
  strcpy(t->InsertTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InsertTime"),"gbk","Error!")));
  //客户代码
  strcpy(t->ClientID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ClientID"),"gbk","Error!")));
  //安装编号
  t->InstallID =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallID"));
  //组合投机套保标志
  strcpy(t->CombHedgeFlag, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CombHedgeFlag"),"gbk","Error!")));
  //最小成交量
  t->MinVolume =   PyLong_AsLong(PyObject_GetAttrString(p, "MinVolume"));
  //强平原因
  //enum类型
  //THOST_FTDC_FCC_Other -> '6', 其它
  //THOST_FTDC_FCC_ClientOverPositionLimit -> '2', 客户超仓
  //THOST_FTDC_FCC_NotMultiple -> '4', 持仓非整数倍
  //THOST_FTDC_FCC_PersonDeliv -> '7', 自然人临近交割
  //THOST_FTDC_FCC_NotForceClose -> '0', 非强平
  //THOST_FTDC_FCC_Violation -> '5', 违规
  //THOST_FTDC_FCC_MemberOverPositionLimit -> '3', 会员超仓
  //THOST_FTDC_FCC_LackDeposit -> '1', 资金不足
  t->ForceCloseReason =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ForceCloseReason"),"gbk","Error!"))[0];
  //数量
  t->VolumeTotalOriginal =   PyLong_AsLong(PyObject_GetAttrString(p, "VolumeTotalOriginal"));
  //报单日期
  strcpy(t->InsertDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InsertDate"),"gbk","Error!")));
  //撤销时间
  strcpy(t->CancelTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CancelTime"),"gbk","Error!")));
  //交易日
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //报单状态
  //enum类型
  //THOST_FTDC_OST_NoTradeQueueing -> '3', 未成交还在队列中
  //THOST_FTDC_OST_Touched -> 'c', 已触发
  //THOST_FTDC_OST_PartTradedQueueing -> '1', 部分成交还在队列中
  //THOST_FTDC_OST_NotTouched -> 'b', 尚未触发
  //THOST_FTDC_OST_NoTradeNotQueueing -> '4', 未成交不在队列中
  //THOST_FTDC_OST_PartTradedNotQueueing -> '2', 部分成交不在队列中
  //THOST_FTDC_OST_Unknown -> 'a', 未知
  //THOST_FTDC_OST_Canceled -> '5', 撤单
  //THOST_FTDC_OST_AllTraded -> '0', 全部成交
  t->OrderStatus =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderStatus"),"gbk","Error!"))[0];
  //合约在交易所的代码
  strcpy(t->ExchangeInstID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeInstID"),"gbk","Error!")));
  //剩余数量
  t->VolumeTotal =   PyLong_AsLong(PyObject_GetAttrString(p, "VolumeTotal"));
  //报单提示序号
  t->NotifySequence =   PyLong_AsLong(PyObject_GetAttrString(p, "NotifySequence"));
  //最后修改时间
  strcpy(t->UpdateTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UpdateTime"),"gbk","Error!")));
  //挂起时间
  strcpy(t->SuspendTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "SuspendTime"),"gbk","Error!")));
  //请求编号
  t->RequestID =   PyLong_AsLong(PyObject_GetAttrString(p, "RequestID"));
  //自动挂起标志
  t->IsAutoSuspend =   PyLong_AsLong(PyObject_GetAttrString(p, "IsAutoSuspend"));
  //序号
  t->SequenceNo =   PyLong_AsLong(PyObject_GetAttrString(p, "SequenceNo"));
  //今成交数量
  t->VolumeTraded =   PyLong_AsLong(PyObject_GetAttrString(p, "VolumeTraded"));
  //激活时间
  strcpy(t->ActiveTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ActiveTime"),"gbk","Error!")));
  //止损价
  t->StopPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "StopPrice"));
  //报单来源
  //enum类型
  //THOST_FTDC_OSRC_Administrator -> '1', 来自管理员
  //THOST_FTDC_OSRC_Participant -> '0', 来自参与者
  t->OrderSource =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderSource"),"gbk","Error!"))[0];
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //GTD日期
  strcpy(t->GTDDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "GTDDate"),"gbk","Error!")));
  //交易所交易员代码
  strcpy(t->TraderID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TraderID"),"gbk","Error!")));
  //会员代码
  strcpy(t->ParticipantID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ParticipantID"),"gbk","Error!")));
  //结算编号
  t->SettlementID =   PyLong_AsLong(PyObject_GetAttrString(p, "SettlementID"));
  //买卖方向
  //enum类型
  //THOST_FTDC_D_Buy -> '0', 买
  //THOST_FTDC_D_Sell -> '1', 卖
  t->Direction =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Direction"),"gbk","Error!"))[0];
  //业务单元
  strcpy(t->BusinessUnit, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BusinessUnit"),"gbk","Error!")));
  //价格
  t->LimitPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LimitPrice"));
  //结算会员编号
  strcpy(t->ClearingPartID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ClearingPartID"),"gbk","Error!")));
  //触发条件
  //enum类型
  //THOST_FTDC_CC_AskPriceLesserThanStopPrice -> 'B', 卖一价小于条件价
  //THOST_FTDC_CC_Touch -> '2', 止损
  //THOST_FTDC_CC_BidPriceGreaterThanStopPrice -> 'D', 买一价大于条件价
  //THOST_FTDC_CC_LastPriceGreaterEqualStopPrice -> '6', 最新价大于等于条件价
  //THOST_FTDC_CC_AskPriceLesserEqualStopPrice -> 'C', 卖一价小于等于条件价
  //THOST_FTDC_CC_LastPriceGreaterThanStopPrice -> '5', 最新价大于条件价
  //THOST_FTDC_CC_AskPriceGreaterEqualStopPrice -> 'A', 卖一价大于等于条件价
  //THOST_FTDC_CC_LastPriceLesserThanStopPrice -> '7', 最新价小于条件价
  //THOST_FTDC_CC_BidPriceGreaterEqualStopPrice -> 'E', 买一价大于等于条件价
  //THOST_FTDC_CC_Immediately -> '1', 立即
  //THOST_FTDC_CC_LastPriceLesserEqualStopPrice -> '8', 最新价小于等于条件价
  //THOST_FTDC_CC_AskPriceGreaterThanStopPrice -> '9', 卖一价大于条件价
  //THOST_FTDC_CC_BidPriceLesserEqualStopPrice -> 'H', 买一价小于等于条件价
  //THOST_FTDC_CC_ParkedOrder -> '4', 预埋单
  //THOST_FTDC_CC_TouchProfit -> '3', 止赢
  //THOST_FTDC_CC_BidPriceLesserThanStopPrice -> 'F', 买一价小于条件价
  t->ContingentCondition =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ContingentCondition"),"gbk","Error!"))[0];
  //成交量类型
  //enum类型
  //THOST_FTDC_VC_CV -> '3', 全部数量
  //THOST_FTDC_VC_MV -> '2', 最小数量
  //THOST_FTDC_VC_AV -> '1', 任何数量
  t->VolumeCondition =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "VolumeCondition"),"gbk","Error!"))[0];
  //最后修改交易所交易员代码
  strcpy(t->ActiveTraderID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ActiveTraderID"),"gbk","Error!")));
  //报单类型
  //enum类型
  //THOST_FTDC_ORDT_DeriveFromCombination -> '2', 组合衍生
  //THOST_FTDC_ORDT_Normal -> '0', 正常
  //THOST_FTDC_ORDT_Combination -> '3', 组合报单
  //THOST_FTDC_ORDT_DeriveFromQuote -> '1', 报价衍生
  //THOST_FTDC_ORDT_Swap -> '5', 互换单
  //THOST_FTDC_ORDT_ConditionalOrder -> '4', 条件单
  t->OrderType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderType"),"gbk","Error!"))[0];
  //本地报单编号
  strcpy(t->OrderLocalID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderLocalID"),"gbk","Error!")));
  //有效期类型
  //enum类型
  //THOST_FTDC_TC_IOC -> '1', 立即完成，否则撤销
  //THOST_FTDC_TC_GFS -> '2', 本节有效
  //THOST_FTDC_TC_GTD -> '4', 指定日期前有效
  //THOST_FTDC_TC_GFA -> '6', 集合竞价有效
  //THOST_FTDC_TC_GTC -> '5', 撤销前有效
  //THOST_FTDC_TC_GFD -> '3', 当日有效
  t->TimeCondition =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TimeCondition"),"gbk","Error!"))[0];

  return t;
};

//当前时间
PyObject * new_CThostFtdcCurrentTimeField(CThostFtdcCurrentTimeField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcCurrentTimeField", (char*)"yyyi",
p->CurrTime, p->CurrDate, p->ActionDay, p->CurrMillisec);
}
CThostFtdcCurrentTimeField * from_CThostFtdcCurrentTimeField(PyObject * p){
  CThostFtdcCurrentTimeField *t = (CThostFtdcCurrentTimeField *)calloc(1, sizeof(CThostFtdcCurrentTimeField));
  memset(t,0,sizeof(CThostFtdcCurrentTimeField));
  //当前时间
  strcpy(t->CurrTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrTime"),"gbk","Error!")));
  //当前日期
  strcpy(t->CurrDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrDate"),"gbk","Error!")));
  //业务日期
  strcpy(t->ActionDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ActionDay"),"gbk","Error!")));
  //当前时间（毫秒）
  t->CurrMillisec =   PyLong_AsLong(PyObject_GetAttrString(p, "CurrMillisec"));

  return t;
};

//经纪公司
PyObject * new_CThostFtdcBrokerField(CThostFtdcBrokerField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcBrokerField", (char*)"iyyy",
p->IsActive, p->BrokerID, p->BrokerName, p->BrokerAbbr);
}
CThostFtdcBrokerField * from_CThostFtdcBrokerField(PyObject * p){
  CThostFtdcBrokerField *t = (CThostFtdcBrokerField *)calloc(1, sizeof(CThostFtdcBrokerField));
  memset(t,0,sizeof(CThostFtdcBrokerField));
  //是否活跃
  t->IsActive =   PyLong_AsLong(PyObject_GetAttrString(p, "IsActive"));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //经纪公司名称
  strcpy(t->BrokerName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerName"),"gbk","Error!")));
  //经纪公司简称
  strcpy(t->BrokerAbbr, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerAbbr"),"gbk","Error!")));

  return t;
};

//交易所报单操作失败
PyObject * new_CThostFtdcExchangeOrderActionErrorField(CThostFtdcExchangeOrderActionErrorField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcExchangeOrderActionErrorField", (char*)"yyyiiyyy",
p->OrderSysID, p->ExchangeID, p->ActionLocalID, p->ErrorID, p->InstallID, p->ErrorMsg, p->OrderLocalID, p->TraderID);
}
CThostFtdcExchangeOrderActionErrorField * from_CThostFtdcExchangeOrderActionErrorField(PyObject * p){
  CThostFtdcExchangeOrderActionErrorField *t = (CThostFtdcExchangeOrderActionErrorField *)calloc(1, sizeof(CThostFtdcExchangeOrderActionErrorField));
  memset(t,0,sizeof(CThostFtdcExchangeOrderActionErrorField));
  //报单编号
  strcpy(t->OrderSysID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderSysID"),"gbk","Error!")));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //操作本地编号
  strcpy(t->ActionLocalID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ActionLocalID"),"gbk","Error!")));
  //错误代码
  t->ErrorID =   PyLong_AsLong(PyObject_GetAttrString(p, "ErrorID"));
  //安装编号
  t->InstallID =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallID"));
  //错误信息
  strcpy(t->ErrorMsg, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ErrorMsg"),"gbk","Error!")));
  //本地报单编号
  strcpy(t->OrderLocalID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderLocalID"),"gbk","Error!")));
  //交易所交易员代码
  strcpy(t->TraderID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TraderID"),"gbk","Error!")));

  return t;
};

//投资者品种/跨品种保证金
PyObject * new_CThostFtdcInvestorProductGroupMarginField(CThostFtdcInvestorProductGroupMarginField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcInvestorProductGroupMarginField", (char*)"ddyydddddyddddddddyddidddd",
p->FrozenCommission, p->CashIn, p->BrokerID, p->InvestorID, p->LongOffsetAmount, p->LongExchMargin, p->Commission, p->ExchMargin, p->CloseProfit, p->ProductGroupID, p->PositionProfit, p->ExchOffsetAmount, p->FrozenMargin, p->LongExchOffsetAmount, p->ShortUseMargin, p->OffsetAmount, p->ShortOffsetAmount, p->ShortExchMargin, p->TradingDay, p->UseMargin, p->FrozenCash, p->SettlementID, p->ShortExchOffsetAmount, p->ShortFrozenMargin, p->LongUseMargin, p->LongFrozenMargin);
}
CThostFtdcInvestorProductGroupMarginField * from_CThostFtdcInvestorProductGroupMarginField(PyObject * p){
  CThostFtdcInvestorProductGroupMarginField *t = (CThostFtdcInvestorProductGroupMarginField *)calloc(1, sizeof(CThostFtdcInvestorProductGroupMarginField));
  memset(t,0,sizeof(CThostFtdcInvestorProductGroupMarginField));
  //冻结的手续费
  t->FrozenCommission =   PyFloat_AsDouble(PyObject_GetAttrString(p, "FrozenCommission"));
  //资金差额
  t->CashIn =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CashIn"));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //多头折抵总金额
  t->LongOffsetAmount =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LongOffsetAmount"));
  //交易所多头保证金
  t->LongExchMargin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LongExchMargin"));
  //手续费
  t->Commission =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Commission"));
  //交易所保证金
  t->ExchMargin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ExchMargin"));
  //平仓盈亏
  t->CloseProfit =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CloseProfit"));
  //品种/跨品种标示
  strcpy(t->ProductGroupID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ProductGroupID"),"gbk","Error!")));
  //持仓盈亏
  t->PositionProfit =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PositionProfit"));
  //交易所折抵总金额
  t->ExchOffsetAmount =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ExchOffsetAmount"));
  //冻结的保证金
  t->FrozenMargin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "FrozenMargin"));
  //交易所多头折抵总金额
  t->LongExchOffsetAmount =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LongExchOffsetAmount"));
  //空头保证金
  t->ShortUseMargin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ShortUseMargin"));
  //折抵总金额
  t->OffsetAmount =   PyFloat_AsDouble(PyObject_GetAttrString(p, "OffsetAmount"));
  //空头折抵总金额
  t->ShortOffsetAmount =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ShortOffsetAmount"));
  //交易所空头保证金
  t->ShortExchMargin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ShortExchMargin"));
  //交易日
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //占用的保证金
  t->UseMargin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "UseMargin"));
  //冻结的资金
  t->FrozenCash =   PyFloat_AsDouble(PyObject_GetAttrString(p, "FrozenCash"));
  //结算编号
  t->SettlementID =   PyLong_AsLong(PyObject_GetAttrString(p, "SettlementID"));
  //交易所空头折抵总金额
  t->ShortExchOffsetAmount =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ShortExchOffsetAmount"));
  //空头冻结的保证金
  t->ShortFrozenMargin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ShortFrozenMargin"));
  //多头保证金
  t->LongUseMargin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LongUseMargin"));
  //多头冻结的保证金
  t->LongFrozenMargin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LongFrozenMargin"));

  return t;
};

//查询经纪公司用户事件
PyObject * new_CThostFtdcBrokerUserEventField(CThostFtdcBrokerUserEventField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcBrokerUserEventField", (char*)"yyyyyycyi",
p->UserEventInfo, p->InstrumentID, p->InvestorID, p->EventTime, p->BrokerID, p->EventDate, p->UserEventType, p->UserID, p->EventSequenceNo);
}
CThostFtdcBrokerUserEventField * from_CThostFtdcBrokerUserEventField(PyObject * p){
  CThostFtdcBrokerUserEventField *t = (CThostFtdcBrokerUserEventField *)calloc(1, sizeof(CThostFtdcBrokerUserEventField));
  memset(t,0,sizeof(CThostFtdcBrokerUserEventField));
  //用户事件信息
  strcpy(t->UserEventInfo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserEventInfo"),"gbk","Error!")));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //事件发生时间
  strcpy(t->EventTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "EventTime"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //事件发生日期
  strcpy(t->EventDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "EventDate"),"gbk","Error!")));
  //用户事件类型
  //enum类型
  //THOST_FTDC_UET_Authenticate -> '6', 客户端认证
  //THOST_FTDC_UET_UpdatePassword -> '5', 修改密码
  //THOST_FTDC_UET_Login -> '1', 登录
  //THOST_FTDC_UET_TradingError -> '4', 交易失败
  //THOST_FTDC_UET_Trading -> '3', 交易成功
  //THOST_FTDC_UET_Logout -> '2', 登出
  //THOST_FTDC_UET_Other -> '9', 其他
  t->UserEventType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserEventType"),"gbk","Error!"))[0];
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //用户事件序号
  t->EventSequenceNo =   PyLong_AsLong(PyObject_GetAttrString(p, "EventSequenceNo"));

  return t;
};

//投资者组
PyObject * new_CThostFtdcQryInvestorGroupField(CThostFtdcQryInvestorGroupField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryInvestorGroupField", (char*)"y",
p->BrokerID);
}
CThostFtdcQryInvestorGroupField * from_CThostFtdcQryInvestorGroupField(PyObject * p){
  CThostFtdcQryInvestorGroupField *t = (CThostFtdcQryInvestorGroupField *)calloc(1, sizeof(CThostFtdcQryInvestorGroupField));
  memset(t,0,sizeof(CThostFtdcQryInvestorGroupField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));

  return t;
};

//查询用户会话
PyObject * new_CThostFtdcQryUserSessionField(CThostFtdcQryUserSessionField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryUserSessionField", (char*)"yiiy",
p->BrokerID, p->FrontID, p->SessionID, p->UserID);
}
CThostFtdcQryUserSessionField * from_CThostFtdcQryUserSessionField(PyObject * p){
  CThostFtdcQryUserSessionField *t = (CThostFtdcQryUserSessionField *)calloc(1, sizeof(CThostFtdcQryUserSessionField));
  memset(t,0,sizeof(CThostFtdcQryUserSessionField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //前置编号
  t->FrontID =   PyLong_AsLong(PyObject_GetAttrString(p, "FrontID"));
  //会话编号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));

  return t;
};

//请求查询保证金监管系统经纪公司资金账户密钥
PyObject * new_CThostFtdcQryCFMMCTradingAccountKeyField(CThostFtdcQryCFMMCTradingAccountKeyField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryCFMMCTradingAccountKeyField", (char*)"yy",
p->BrokerID, p->InvestorID);
}
CThostFtdcQryCFMMCTradingAccountKeyField * from_CThostFtdcQryCFMMCTradingAccountKeyField(PyObject * p){
  CThostFtdcQryCFMMCTradingAccountKeyField *t = (CThostFtdcQryCFMMCTradingAccountKeyField *)calloc(1, sizeof(CThostFtdcQryCFMMCTradingAccountKeyField));
  memset(t,0,sizeof(CThostFtdcQryCFMMCTradingAccountKeyField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));

  return t;
};

//资金账户口令域
PyObject * new_CThostFtdcTradingAccountPasswordField(CThostFtdcTradingAccountPasswordField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcTradingAccountPasswordField", (char*)"yyy",
p->Password, p->BrokerID, p->AccountID);
}
CThostFtdcTradingAccountPasswordField * from_CThostFtdcTradingAccountPasswordField(PyObject * p){
  CThostFtdcTradingAccountPasswordField *t = (CThostFtdcTradingAccountPasswordField *)calloc(1, sizeof(CThostFtdcTradingAccountPasswordField));
  memset(t,0,sizeof(CThostFtdcTradingAccountPasswordField));
  //密码
  strcpy(t->Password, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Password"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者帐号
  strcpy(t->AccountID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AccountID"),"gbk","Error!")));

  return t;
};

//期商签退通知
PyObject * new_CThostFtdcNotifyFutureSignOutField(CThostFtdcNotifyFutureSignOutField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcNotifyFutureSignOutField", (char*)"yyiiyiyyyyyciyyyyyyiyyi",
p->TradeTime, p->DeviceID, p->ErrorID, p->InstallID, p->BrokerID, p->SessionID, p->BankID, p->CurrencyID, p->ErrorMsg, p->OperNo, p->Digest, p->LastFragment, p->RequestID, p->TradeDate, p->UserID, p->TradingDay, p->BankSerial, p->BrokerIDByBank, p->TradeCode, p->TID, p->BankBranchID, p->BrokerBranchID, p->PlateSerial);
}
CThostFtdcNotifyFutureSignOutField * from_CThostFtdcNotifyFutureSignOutField(PyObject * p){
  CThostFtdcNotifyFutureSignOutField *t = (CThostFtdcNotifyFutureSignOutField *)calloc(1, sizeof(CThostFtdcNotifyFutureSignOutField));
  memset(t,0,sizeof(CThostFtdcNotifyFutureSignOutField));
  //交易时间
  strcpy(t->TradeTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeTime"),"gbk","Error!")));
  //渠道标志
  strcpy(t->DeviceID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "DeviceID"),"gbk","Error!")));
  //错误代码
  t->ErrorID =   PyLong_AsLong(PyObject_GetAttrString(p, "ErrorID"));
  //安装编号
  t->InstallID =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallID"));
  //期商代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //会话号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //银行代码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //币种代码
  strcpy(t->CurrencyID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrencyID"),"gbk","Error!")));
  //错误信息
  strcpy(t->ErrorMsg, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ErrorMsg"),"gbk","Error!")));
  //交易柜员
  strcpy(t->OperNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OperNo"),"gbk","Error!")));
  //摘要
  strcpy(t->Digest, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Digest"),"gbk","Error!")));
  //最后分片标志
  //enum类型
  //THOST_FTDC_LF_No -> '1', 不是最后分片
  //THOST_FTDC_LF_Yes -> '0', 是最后分片
  t->LastFragment =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LastFragment"),"gbk","Error!"))[0];
  //请求编号
  t->RequestID =   PyLong_AsLong(PyObject_GetAttrString(p, "RequestID"));
  //交易日期
  strcpy(t->TradeDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeDate"),"gbk","Error!")));
  //用户标识
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //交易系统日期
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //银行流水号
  strcpy(t->BankSerial, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSerial"),"gbk","Error!")));
  //期货公司银行编码
  strcpy(t->BrokerIDByBank, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerIDByBank"),"gbk","Error!")));
  //业务功能码
  strcpy(t->TradeCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeCode"),"gbk","Error!")));
  //交易ID
  t->TID =   PyLong_AsLong(PyObject_GetAttrString(p, "TID"));
  //银行分支机构代码
  strcpy(t->BankBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBranchID"),"gbk","Error!")));
  //期商分支机构代码
  strcpy(t->BrokerBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerBranchID"),"gbk","Error!")));
  //银期平台消息流水号
  t->PlateSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "PlateSerial"));

  return t;
};

//查询投资者
PyObject * new_CThostFtdcQryInvestorField(CThostFtdcQryInvestorField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryInvestorField", (char*)"yy",
p->BrokerID, p->InvestorID);
}
CThostFtdcQryInvestorField * from_CThostFtdcQryInvestorField(PyObject * p){
  CThostFtdcQryInvestorField *t = (CThostFtdcQryInvestorField *)calloc(1, sizeof(CThostFtdcQryInvestorField));
  memset(t,0,sizeof(CThostFtdcQryInvestorField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));

  return t;
};

//转帐开户请求
PyObject * new_CThostFtdcReqOpenAccountField(CThostFtdcReqOpenAccountField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcReqOpenAccountField", (char*)"yyyyiycyycyyyccyycyyyycyiyyyiccycyyyyycyyciy",
p->TradingDay, p->DeviceID, p->BrokerID, p->ZipCode, p->SessionID, p->IdentifiedCardNo, p->IdCardType, p->MobilePhone, p->BankID, p->BankPwdFlag, p->OperNo, p->BankAccount, p->BankSecuAcc, p->LastFragment, p->Gender, p->Address, p->TradeDate, p->MoneyAccountStatus, p->AccountID, p->BankSerial, p->CustomerName, p->BankPassWord, p->CashExchangeCode, p->Digest, p->PlateSerial, p->Fax, p->EMail, p->TradeTime, p->InstallID, p->SecuPwdFlag, p->VerifyCertNoFlag, p->CurrencyID, p->BankSecuAccType, p->Password, p->BankBranchID, p->CountryCode, p->BrokerBranchID, p->UserID, p->CustType, p->BrokerIDByBank, p->TradeCode, p->BankAccType, p->TID, p->Telephone);
}
CThostFtdcReqOpenAccountField * from_CThostFtdcReqOpenAccountField(PyObject * p){
  CThostFtdcReqOpenAccountField *t = (CThostFtdcReqOpenAccountField *)calloc(1, sizeof(CThostFtdcReqOpenAccountField));
  memset(t,0,sizeof(CThostFtdcReqOpenAccountField));
  //交易系统日期
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //渠道标志
  strcpy(t->DeviceID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "DeviceID"),"gbk","Error!")));
  //期商代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //邮编
  strcpy(t->ZipCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ZipCode"),"gbk","Error!")));
  //会话号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //证件号码
  strcpy(t->IdentifiedCardNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdentifiedCardNo"),"gbk","Error!")));
  //证件类型
  //enum类型
  //THOST_FTDC_ICT_TaiwanCompatriotIDCard -> '7', 台胞证
  //THOST_FTDC_ICT_Passport -> '6', 护照
  //THOST_FTDC_ICT_LicenseNo -> '9', 营业执照号
  //THOST_FTDC_ICT_OtherCard -> 'x', 其他证件
  //THOST_FTDC_ICT_IDCard -> '1', 身份证
  //THOST_FTDC_ICT_EID -> '0', 组织机构代码
  //THOST_FTDC_ICT_TaxNo -> 'A', 税务登记号
  //THOST_FTDC_ICT_HomeComingCard -> '8', 回乡证
  //THOST_FTDC_ICT_OfficerIDCard -> '2', 军官证
  //THOST_FTDC_ICT_HouseholdRegister -> '5', 户口簿
  //THOST_FTDC_ICT_SoldierIDCard -> '4', 士兵证
  //THOST_FTDC_ICT_PoliceIDCard -> '3', 警官证
  t->IdCardType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdCardType"),"gbk","Error!"))[0];
  //手机
  strcpy(t->MobilePhone, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "MobilePhone"),"gbk","Error!")));
  //银行代码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //银行密码标志
  //enum类型
  //THOST_FTDC_BPWDF_NoCheck -> '0', 不核对
  //THOST_FTDC_BPWDF_BlankCheck -> '1', 明文核对
  //THOST_FTDC_BPWDF_EncryptCheck -> '2', 密文核对
  t->BankPwdFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankPwdFlag"),"gbk","Error!"))[0];
  //交易柜员
  strcpy(t->OperNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OperNo"),"gbk","Error!")));
  //银行帐号
  strcpy(t->BankAccount, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccount"),"gbk","Error!")));
  //期货单位帐号
  strcpy(t->BankSecuAcc, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSecuAcc"),"gbk","Error!")));
  //最后分片标志
  //enum类型
  //THOST_FTDC_LF_No -> '1', 不是最后分片
  //THOST_FTDC_LF_Yes -> '0', 是最后分片
  t->LastFragment =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LastFragment"),"gbk","Error!"))[0];
  //性别
  //enum类型
  //THOST_FTDC_GD_Male -> '1', 男
  //THOST_FTDC_GD_Unknown -> '0', 未知状态
  //THOST_FTDC_GD_Female -> '2', 女
  t->Gender =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Gender"),"gbk","Error!"))[0];
  //地址
  strcpy(t->Address, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Address"),"gbk","Error!")));
  //交易日期
  strcpy(t->TradeDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeDate"),"gbk","Error!")));
  //资金账户状态
  //enum类型
  //THOST_FTDC_MAS_Normal -> '0', 正常
  //THOST_FTDC_MAS_Cancel -> '1', 销户
  t->MoneyAccountStatus =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "MoneyAccountStatus"),"gbk","Error!"))[0];
  //投资者帐号
  strcpy(t->AccountID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AccountID"),"gbk","Error!")));
  //银行流水号
  strcpy(t->BankSerial, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSerial"),"gbk","Error!")));
  //客户姓名
  strcpy(t->CustomerName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustomerName"),"gbk","Error!")));
  //银行密码
  strcpy(t->BankPassWord, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankPassWord"),"gbk","Error!")));
  //汇钞标志
  //enum类型
  //THOST_FTDC_CEC_Cash -> '2', 钞
  //THOST_FTDC_CEC_Exchange -> '1', 汇
  t->CashExchangeCode =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CashExchangeCode"),"gbk","Error!"))[0];
  //摘要
  strcpy(t->Digest, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Digest"),"gbk","Error!")));
  //银期平台消息流水号
  t->PlateSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "PlateSerial"));
  //传真
  strcpy(t->Fax, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Fax"),"gbk","Error!")));
  //电子邮件
  strcpy(t->EMail, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "EMail"),"gbk","Error!")));
  //交易时间
  strcpy(t->TradeTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeTime"),"gbk","Error!")));
  //安装编号
  t->InstallID =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallID"));
  //期货资金密码核对标志
  //enum类型
  //THOST_FTDC_BPWDF_NoCheck -> '0', 不核对
  //THOST_FTDC_BPWDF_BlankCheck -> '1', 明文核对
  //THOST_FTDC_BPWDF_EncryptCheck -> '2', 密文核对
  t->SecuPwdFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "SecuPwdFlag"),"gbk","Error!"))[0];
  //验证客户证件号码标志
  //enum类型
  //THOST_FTDC_YNI_No -> '1', 否
  //THOST_FTDC_YNI_Yes -> '0', 是
  t->VerifyCertNoFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "VerifyCertNoFlag"),"gbk","Error!"))[0];
  //币种代码
  strcpy(t->CurrencyID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrencyID"),"gbk","Error!")));
  //期货单位帐号类型
  //enum类型
  //THOST_FTDC_BAT_SavingCard -> '2', 储蓄卡
  //THOST_FTDC_BAT_CreditCard -> '3', 信用卡
  //THOST_FTDC_BAT_BankBook -> '1', 银行存折
  t->BankSecuAccType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSecuAccType"),"gbk","Error!"))[0];
  //期货密码
  strcpy(t->Password, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Password"),"gbk","Error!")));
  //银行分支机构代码
  strcpy(t->BankBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBranchID"),"gbk","Error!")));
  //国家代码
  strcpy(t->CountryCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CountryCode"),"gbk","Error!")));
  //期商分支机构代码
  strcpy(t->BrokerBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerBranchID"),"gbk","Error!")));
  //用户标识
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //客户类型
  //enum类型
  //THOST_FTDC_CUSTT_Person -> '0', 自然人
  //THOST_FTDC_CUSTT_Institution -> '1', 机构户
  t->CustType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustType"),"gbk","Error!"))[0];
  //期货公司银行编码
  strcpy(t->BrokerIDByBank, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerIDByBank"),"gbk","Error!")));
  //业务功能码
  strcpy(t->TradeCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeCode"),"gbk","Error!")));
  //银行帐号类型
  //enum类型
  //THOST_FTDC_BAT_SavingCard -> '2', 储蓄卡
  //THOST_FTDC_BAT_CreditCard -> '3', 信用卡
  //THOST_FTDC_BAT_BankBook -> '1', 银行存折
  t->BankAccType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccType"),"gbk","Error!"))[0];
  //交易ID
  t->TID =   PyLong_AsLong(PyObject_GetAttrString(p, "TID"));
  //电话号码
  strcpy(t->Telephone, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Telephone"),"gbk","Error!")));

  return t;
};

//行情申卖二、三属性
PyObject * new_CThostFtdcMarketDataAsk23Field(CThostFtdcMarketDataAsk23Field * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcMarketDataAsk23Field", (char*)"iidd",
p->AskVolume3, p->AskVolume2, p->AskPrice3, p->AskPrice2);
}
CThostFtdcMarketDataAsk23Field * from_CThostFtdcMarketDataAsk23Field(PyObject * p){
  CThostFtdcMarketDataAsk23Field *t = (CThostFtdcMarketDataAsk23Field *)calloc(1, sizeof(CThostFtdcMarketDataAsk23Field));
  memset(t,0,sizeof(CThostFtdcMarketDataAsk23Field));
  //申卖量三
  t->AskVolume3 =   PyLong_AsLong(PyObject_GetAttrString(p, "AskVolume3"));
  //申卖量二
  t->AskVolume2 =   PyLong_AsLong(PyObject_GetAttrString(p, "AskVolume2"));
  //申卖价三
  t->AskPrice3 =   PyFloat_AsDouble(PyObject_GetAttrString(p, "AskPrice3"));
  //申卖价二
  t->AskPrice2 =   PyFloat_AsDouble(PyObject_GetAttrString(p, "AskPrice2"));

  return t;
};

//行情申买二、三属性
PyObject * new_CThostFtdcMarketDataBid23Field(CThostFtdcMarketDataBid23Field * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcMarketDataBid23Field", (char*)"iidd",
p->BidVolume3, p->BidVolume2, p->BidPrice3, p->BidPrice2);
}
CThostFtdcMarketDataBid23Field * from_CThostFtdcMarketDataBid23Field(PyObject * p){
  CThostFtdcMarketDataBid23Field *t = (CThostFtdcMarketDataBid23Field *)calloc(1, sizeof(CThostFtdcMarketDataBid23Field));
  memset(t,0,sizeof(CThostFtdcMarketDataBid23Field));
  //申买量三
  t->BidVolume3 =   PyLong_AsLong(PyObject_GetAttrString(p, "BidVolume3"));
  //申买量二
  t->BidVolume2 =   PyLong_AsLong(PyObject_GetAttrString(p, "BidVolume2"));
  //申买价三
  t->BidPrice3 =   PyFloat_AsDouble(PyObject_GetAttrString(p, "BidPrice3"));
  //申买价二
  t->BidPrice2 =   PyFloat_AsDouble(PyObject_GetAttrString(p, "BidPrice2"));

  return t;
};

//响应信息
PyObject * new_CThostFtdcRspInfoField(CThostFtdcRspInfoField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcRspInfoField", (char*)"iy",
p->ErrorID, p->ErrorMsg);
}
CThostFtdcRspInfoField * from_CThostFtdcRspInfoField(PyObject * p){
  CThostFtdcRspInfoField *t = (CThostFtdcRspInfoField *)calloc(1, sizeof(CThostFtdcRspInfoField));
  memset(t,0,sizeof(CThostFtdcRspInfoField));
  //错误代码
  t->ErrorID =   PyLong_AsLong(PyObject_GetAttrString(p, "ErrorID"));
  //错误信息
  strcpy(t->ErrorMsg, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ErrorMsg"),"gbk","Error!")));

  return t;
};

//登录信息
PyObject * new_CThostFtdcLoginInfoField(CThostFtdcLoginInfoField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcLoginInfoField", (char*)"yyyyyyiiyyyyyyyyyyy",
p->Password, p->LoginDate, p->SystemName, p->SHFETime, p->MacAddress, p->BrokerID, p->FrontID, p->SessionID, p->ProtocolInfo, p->OneTimePassword, p->FFEXTime, p->UserProductInfo, p->CZCETime, p->LoginTime, p->InterfaceProductInfo, p->DCETime, p->MaxOrderRef, p->UserID, p->IPAddress);
}
CThostFtdcLoginInfoField * from_CThostFtdcLoginInfoField(PyObject * p){
  CThostFtdcLoginInfoField *t = (CThostFtdcLoginInfoField *)calloc(1, sizeof(CThostFtdcLoginInfoField));
  memset(t,0,sizeof(CThostFtdcLoginInfoField));
  //密码
  strcpy(t->Password, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Password"),"gbk","Error!")));
  //登录日期
  strcpy(t->LoginDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LoginDate"),"gbk","Error!")));
  //系统名称
  strcpy(t->SystemName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "SystemName"),"gbk","Error!")));
  //上期所时间
  strcpy(t->SHFETime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "SHFETime"),"gbk","Error!")));
  //Mac地址
  strcpy(t->MacAddress, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "MacAddress"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //前置编号
  t->FrontID =   PyLong_AsLong(PyObject_GetAttrString(p, "FrontID"));
  //会话编号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //协议信息
  strcpy(t->ProtocolInfo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ProtocolInfo"),"gbk","Error!")));
  //动态密码
  strcpy(t->OneTimePassword, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OneTimePassword"),"gbk","Error!")));
  //中金所时间
  strcpy(t->FFEXTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "FFEXTime"),"gbk","Error!")));
  //用户端产品信息
  strcpy(t->UserProductInfo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserProductInfo"),"gbk","Error!")));
  //郑商所时间
  strcpy(t->CZCETime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CZCETime"),"gbk","Error!")));
  //登录时间
  strcpy(t->LoginTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LoginTime"),"gbk","Error!")));
  //接口端产品信息
  strcpy(t->InterfaceProductInfo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InterfaceProductInfo"),"gbk","Error!")));
  //大商所时间
  strcpy(t->DCETime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "DCETime"),"gbk","Error!")));
  //最大报单引用
  strcpy(t->MaxOrderRef, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "MaxOrderRef"),"gbk","Error!")));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //IP地址
  strcpy(t->IPAddress, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IPAddress"),"gbk","Error!")));

  return t;
};

//交易所报单操作
PyObject * new_CThostFtdcExchangeOrderActionField(CThostFtdcExchangeOrderActionField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcExchangeOrderActionField", (char*)"yyyyiyiyycycdyyy",
p->OrderSysID, p->ActionLocalID, p->BusinessUnit, p->ClientID, p->InstallID, p->UserID, p->VolumeChange, p->TraderID, p->ParticipantID, p->ActionFlag, p->ExchangeID, p->OrderActionStatus, p->LimitPrice, p->ActionTime, p->ActionDate, p->OrderLocalID);
}
CThostFtdcExchangeOrderActionField * from_CThostFtdcExchangeOrderActionField(PyObject * p){
  CThostFtdcExchangeOrderActionField *t = (CThostFtdcExchangeOrderActionField *)calloc(1, sizeof(CThostFtdcExchangeOrderActionField));
  memset(t,0,sizeof(CThostFtdcExchangeOrderActionField));
  //报单编号
  strcpy(t->OrderSysID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderSysID"),"gbk","Error!")));
  //操作本地编号
  strcpy(t->ActionLocalID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ActionLocalID"),"gbk","Error!")));
  //业务单元
  strcpy(t->BusinessUnit, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BusinessUnit"),"gbk","Error!")));
  //客户代码
  strcpy(t->ClientID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ClientID"),"gbk","Error!")));
  //安装编号
  t->InstallID =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallID"));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //数量变化
  t->VolumeChange =   PyLong_AsLong(PyObject_GetAttrString(p, "VolumeChange"));
  //交易所交易员代码
  strcpy(t->TraderID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TraderID"),"gbk","Error!")));
  //会员代码
  strcpy(t->ParticipantID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ParticipantID"),"gbk","Error!")));
  //操作标志
  //enum类型
  //THOST_FTDC_AF_Delete -> '0', 删除
  //THOST_FTDC_AF_Modify -> '3', 修改
  t->ActionFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ActionFlag"),"gbk","Error!"))[0];
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //报单操作状态
  //enum类型
  //THOST_FTDC_OAS_Submitted -> 'a', 已经提交
  //THOST_FTDC_OAS_Accepted -> 'b', 已经接受
  //THOST_FTDC_OAS_Rejected -> 'c', 已经被拒绝
  t->OrderActionStatus =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderActionStatus"),"gbk","Error!"))[0];
  //价格
  t->LimitPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LimitPrice"));
  //操作时间
  strcpy(t->ActionTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ActionTime"),"gbk","Error!")));
  //操作日期
  strcpy(t->ActionDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ActionDate"),"gbk","Error!")));
  //本地报单编号
  strcpy(t->OrderLocalID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderLocalID"),"gbk","Error!")));

  return t;
};

//期商签到签退
PyObject * new_CThostFtdcFutureSignIOField(CThostFtdcFutureSignIOField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcFutureSignIOField", (char*)"ciyyyyyyiyyyyiiyyyyiy",
p->LastFragment, p->RequestID, p->UserID, p->TradeTime, p->DeviceID, p->TradeDate, p->BrokerID, p->TradingDay, p->SessionID, p->BankSerial, p->OperNo, p->BrokerIDByBank, p->TradeCode, p->InstallID, p->TID, p->BankID, p->CurrencyID, p->BankBranchID, p->BrokerBranchID, p->PlateSerial, p->Digest);
}
CThostFtdcFutureSignIOField * from_CThostFtdcFutureSignIOField(PyObject * p){
  CThostFtdcFutureSignIOField *t = (CThostFtdcFutureSignIOField *)calloc(1, sizeof(CThostFtdcFutureSignIOField));
  memset(t,0,sizeof(CThostFtdcFutureSignIOField));
  //最后分片标志
  //enum类型
  //THOST_FTDC_LF_No -> '1', 不是最后分片
  //THOST_FTDC_LF_Yes -> '0', 是最后分片
  t->LastFragment =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LastFragment"),"gbk","Error!"))[0];
  //请求编号
  t->RequestID =   PyLong_AsLong(PyObject_GetAttrString(p, "RequestID"));
  //用户标识
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //交易时间
  strcpy(t->TradeTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeTime"),"gbk","Error!")));
  //渠道标志
  strcpy(t->DeviceID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "DeviceID"),"gbk","Error!")));
  //交易日期
  strcpy(t->TradeDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeDate"),"gbk","Error!")));
  //期商代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //交易系统日期
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //会话号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //银行流水号
  strcpy(t->BankSerial, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSerial"),"gbk","Error!")));
  //交易柜员
  strcpy(t->OperNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OperNo"),"gbk","Error!")));
  //期货公司银行编码
  strcpy(t->BrokerIDByBank, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerIDByBank"),"gbk","Error!")));
  //业务功能码
  strcpy(t->TradeCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeCode"),"gbk","Error!")));
  //安装编号
  t->InstallID =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallID"));
  //交易ID
  t->TID =   PyLong_AsLong(PyObject_GetAttrString(p, "TID"));
  //银行代码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //币种代码
  strcpy(t->CurrencyID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrencyID"),"gbk","Error!")));
  //银行分支机构代码
  strcpy(t->BankBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBranchID"),"gbk","Error!")));
  //期商分支机构代码
  strcpy(t->BrokerBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerBranchID"),"gbk","Error!")));
  //银期平台消息流水号
  t->PlateSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "PlateSerial"));
  //摘要
  strcpy(t->Digest, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Digest"),"gbk","Error!")));

  return t;
};

//投资者持仓明细
PyObject * new_CThostFtdcInvestorPositionDetailField(CThostFtdcInvestorPositionDetailField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcInvestorPositionDetailField", (char*)"yycyydcddyydddiddydyidcidd",
p->TradeID, p->CombInstrumentID, p->Direction, p->BrokerID, p->InvestorID, p->OpenPrice, p->TradeType, p->SettlementPrice, p->ExchMargin, p->InstrumentID, p->ExchangeID, p->CloseProfitByTrade, p->PositionProfitByDate, p->Margin, p->Volume, p->CloseAmount, p->MarginRateByMoney, p->TradingDay, p->MarginRateByVolume, p->OpenDate, p->SettlementID, p->PositionProfitByTrade, p->HedgeFlag, p->CloseVolume, p->CloseProfitByDate, p->LastSettlementPrice);
}
CThostFtdcInvestorPositionDetailField * from_CThostFtdcInvestorPositionDetailField(PyObject * p){
  CThostFtdcInvestorPositionDetailField *t = (CThostFtdcInvestorPositionDetailField *)calloc(1, sizeof(CThostFtdcInvestorPositionDetailField));
  memset(t,0,sizeof(CThostFtdcInvestorPositionDetailField));
  //成交编号
  strcpy(t->TradeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeID"),"gbk","Error!")));
  //组合合约代码
  strcpy(t->CombInstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CombInstrumentID"),"gbk","Error!")));
  //买卖
  //enum类型
  //THOST_FTDC_D_Buy -> '0', 买
  //THOST_FTDC_D_Sell -> '1', 卖
  t->Direction =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Direction"),"gbk","Error!"))[0];
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //开仓价
  t->OpenPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "OpenPrice"));
  //成交类型
  //enum类型
  //THOST_FTDC_TRDT_OptionsExecution -> '1', 期权执行
  //THOST_FTDC_TRDT_Common -> '0', 普通成交
  //THOST_FTDC_TRDT_CombinationDerived -> '4', 组合衍生成交
  //THOST_FTDC_TRDT_OTC -> '2', OTC成交
  //THOST_FTDC_TRDT_EFPDerived -> '3', 期转现衍生成交
  t->TradeType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeType"),"gbk","Error!"))[0];
  //结算价
  t->SettlementPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "SettlementPrice"));
  //交易所保证金
  t->ExchMargin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ExchMargin"));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //逐笔对冲平仓盈亏
  t->CloseProfitByTrade =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CloseProfitByTrade"));
  //逐日盯市持仓盈亏
  t->PositionProfitByDate =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PositionProfitByDate"));
  //投资者保证金
  t->Margin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Margin"));
  //数量
  t->Volume =   PyLong_AsLong(PyObject_GetAttrString(p, "Volume"));
  //平仓金额
  t->CloseAmount =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CloseAmount"));
  //保证金率
  t->MarginRateByMoney =   PyFloat_AsDouble(PyObject_GetAttrString(p, "MarginRateByMoney"));
  //交易日
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //保证金率(按手数)
  t->MarginRateByVolume =   PyFloat_AsDouble(PyObject_GetAttrString(p, "MarginRateByVolume"));
  //开仓日期
  strcpy(t->OpenDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OpenDate"),"gbk","Error!")));
  //结算编号
  t->SettlementID =   PyLong_AsLong(PyObject_GetAttrString(p, "SettlementID"));
  //逐笔对冲持仓盈亏
  t->PositionProfitByTrade =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PositionProfitByTrade"));
  //投机套保标志
  //enum类型
  //THOST_FTDC_HF_Hedge -> '3', 套保
  //THOST_FTDC_HF_Arbitrage -> '2', 套利
  //THOST_FTDC_HF_Speculation -> '1', 投机
  t->HedgeFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "HedgeFlag"),"gbk","Error!"))[0];
  //平仓量
  t->CloseVolume =   PyLong_AsLong(PyObject_GetAttrString(p, "CloseVolume"));
  //逐日盯市平仓盈亏
  t->CloseProfitByDate =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CloseProfitByDate"));
  //昨结算价
  t->LastSettlementPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LastSettlementPrice"));

  return t;
};

//客户端认证响应
PyObject * new_CThostFtdcRspAuthenticateField(CThostFtdcRspAuthenticateField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcRspAuthenticateField", (char*)"yyy",
p->BrokerID, p->UserProductInfo, p->UserID);
}
CThostFtdcRspAuthenticateField * from_CThostFtdcRspAuthenticateField(PyObject * p){
  CThostFtdcRspAuthenticateField *t = (CThostFtdcRspAuthenticateField *)calloc(1, sizeof(CThostFtdcRspAuthenticateField));
  memset(t,0,sizeof(CThostFtdcRspAuthenticateField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //用户端产品信息
  strcpy(t->UserProductInfo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserProductInfo"),"gbk","Error!")));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));

  return t;
};

//经纪公司可提资金算法表
PyObject * new_CThostFtdcInvestorWithdrawAlgorithmField(CThostFtdcInvestorWithdrawAlgorithmField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcInvestorWithdrawAlgorithmField", (char*)"dyyc",
p->UsingRatio, p->BrokerID, p->InvestorID, p->InvestorRange);
}
CThostFtdcInvestorWithdrawAlgorithmField * from_CThostFtdcInvestorWithdrawAlgorithmField(PyObject * p){
  CThostFtdcInvestorWithdrawAlgorithmField *t = (CThostFtdcInvestorWithdrawAlgorithmField *)calloc(1, sizeof(CThostFtdcInvestorWithdrawAlgorithmField));
  memset(t,0,sizeof(CThostFtdcInvestorWithdrawAlgorithmField));
  //可提资金比例
  t->UsingRatio =   PyFloat_AsDouble(PyObject_GetAttrString(p, "UsingRatio"));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //投资者范围
  //enum类型
  //THOST_FTDC_IR_Single -> '3', 单一投资者
  //THOST_FTDC_IR_All -> '1', 所有
  //THOST_FTDC_IR_Group -> '2', 投资者组
  t->InvestorRange =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorRange"),"gbk","Error!"))[0];

  return t;
};

//请求查询投资者保证金率模板
PyObject * new_CThostFtdcQryMarginModelField(CThostFtdcQryMarginModelField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryMarginModelField", (char*)"yy",
p->BrokerID, p->MarginModelID);
}
CThostFtdcQryMarginModelField * from_CThostFtdcQryMarginModelField(PyObject * p){
  CThostFtdcQryMarginModelField *t = (CThostFtdcQryMarginModelField *)calloc(1, sizeof(CThostFtdcQryMarginModelField));
  memset(t,0,sizeof(CThostFtdcQryMarginModelField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //保证金率模板代码
  strcpy(t->MarginModelID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "MarginModelID"),"gbk","Error!")));

  return t;
};

//交易所
PyObject * new_CThostFtdcExchangeField(CThostFtdcExchangeField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcExchangeField", (char*)"ycy",
p->ExchangeName, p->ExchangeProperty, p->ExchangeID);
}
CThostFtdcExchangeField * from_CThostFtdcExchangeField(PyObject * p){
  CThostFtdcExchangeField *t = (CThostFtdcExchangeField *)calloc(1, sizeof(CThostFtdcExchangeField));
  memset(t,0,sizeof(CThostFtdcExchangeField));
  //交易所名称
  strcpy(t->ExchangeName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeName"),"gbk","Error!")));
  //交易所属性
  //enum类型
  //THOST_FTDC_EXP_GenOrderByTrade -> '1', 根据成交生成报单
  //THOST_FTDC_EXP_Normal -> '0', 正常
  t->ExchangeProperty =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeProperty"),"gbk","Error!"))[0];
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));

  return t;
};

//组合交易合约的单腿
PyObject * new_CThostFtdcCombinationLegField(CThostFtdcCombinationLegField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcCombinationLegField", (char*)"cyiiiy",
p->Direction, p->CombInstrumentID, p->LegID, p->LegMultiple, p->ImplyLevel, p->LegInstrumentID);
}
CThostFtdcCombinationLegField * from_CThostFtdcCombinationLegField(PyObject * p){
  CThostFtdcCombinationLegField *t = (CThostFtdcCombinationLegField *)calloc(1, sizeof(CThostFtdcCombinationLegField));
  memset(t,0,sizeof(CThostFtdcCombinationLegField));
  //买卖方向
  //enum类型
  //THOST_FTDC_D_Buy -> '0', 买
  //THOST_FTDC_D_Sell -> '1', 卖
  t->Direction =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Direction"),"gbk","Error!"))[0];
  //组合合约代码
  strcpy(t->CombInstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CombInstrumentID"),"gbk","Error!")));
  //单腿编号
  t->LegID =   PyLong_AsLong(PyObject_GetAttrString(p, "LegID"));
  //单腿乘数
  t->LegMultiple =   PyLong_AsLong(PyObject_GetAttrString(p, "LegMultiple"));
  //派生层数
  t->ImplyLevel =   PyLong_AsLong(PyObject_GetAttrString(p, "ImplyLevel"));
  //单腿合约代码
  strcpy(t->LegInstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LegInstrumentID"),"gbk","Error!")));

  return t;
};

//结算引用
PyObject * new_CThostFtdcSettlementRefField(CThostFtdcSettlementRefField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcSettlementRefField", (char*)"iy",
p->SettlementID, p->TradingDay);
}
CThostFtdcSettlementRefField * from_CThostFtdcSettlementRefField(PyObject * p){
  CThostFtdcSettlementRefField *t = (CThostFtdcSettlementRefField *)calloc(1, sizeof(CThostFtdcSettlementRefField));
  memset(t,0,sizeof(CThostFtdcSettlementRefField));
  //结算编号
  t->SettlementID =   PyLong_AsLong(PyObject_GetAttrString(p, "SettlementID"));
  //交易日
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));

  return t;
};

//查询资金账户
PyObject * new_CThostFtdcQryTradingAccountField(CThostFtdcQryTradingAccountField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryTradingAccountField", (char*)"yy",
p->BrokerID, p->InvestorID);
}
CThostFtdcQryTradingAccountField * from_CThostFtdcQryTradingAccountField(PyObject * p){
  CThostFtdcQryTradingAccountField *t = (CThostFtdcQryTradingAccountField *)calloc(1, sizeof(CThostFtdcQryTradingAccountField));
  memset(t,0,sizeof(CThostFtdcQryTradingAccountField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));

  return t;
};

//管理用户功能权限
PyObject * new_CThostFtdcSuperUserFunctionField(CThostFtdcSuperUserFunctionField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcSuperUserFunctionField", (char*)"cy",
p->FunctionCode, p->UserID);
}
CThostFtdcSuperUserFunctionField * from_CThostFtdcSuperUserFunctionField(PyObject * p){
  CThostFtdcSuperUserFunctionField *t = (CThostFtdcSuperUserFunctionField *)calloc(1, sizeof(CThostFtdcSuperUserFunctionField));
  memset(t,0,sizeof(CThostFtdcSuperUserFunctionField));
  //功能代码
  //enum类型
  //THOST_FTDC_FC_BrokerPasswordUpdate -> '4', 变更经纪公司口令
  //THOST_FTDC_FC_ParkedOrderAction -> 'D', 报单操作
  //THOST_FTDC_FC_SyncOTP -> 'E', 同步动态令牌
  //THOST_FTDC_FC_SyncSystemData -> '8', 同步系统数据
  //THOST_FTDC_FC_SyncBrokerData -> '9', 同步经纪公司数据
  //THOST_FTDC_FC_BachSyncBrokerData -> 'A', 批量同步经纪公司数据
  //THOST_FTDC_FC_ForceUserLogout -> '2', 强制用户登出
  //THOST_FTDC_FC_SuperQuery -> 'B', 超级查询
  //THOST_FTDC_FC_UserPasswordUpdate -> '3', 变更管理用户口令
  //THOST_FTDC_FC_OrderAction -> '7', 报单操作
  //THOST_FTDC_FC_InvestorPasswordUpdate -> '5', 变更投资者口令
  //THOST_FTDC_FC_ParkedOrderInsert -> 'C', 报单插入
  //THOST_FTDC_FC_DataAsync -> '1', 数据异步化
  //THOST_FTDC_FC_OrderInsert -> '6', 报单插入
  t->FunctionCode =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "FunctionCode"),"gbk","Error!"))[0];
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));

  return t;
};

//行情基础属性
PyObject * new_CThostFtdcMarketDataBaseField(CThostFtdcMarketDataBaseField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcMarketDataBaseField", (char*)"ddydd",
p->PreOpenInterest, p->PreSettlementPrice, p->TradingDay, p->PreClosePrice, p->PreDelta);
}
CThostFtdcMarketDataBaseField * from_CThostFtdcMarketDataBaseField(PyObject * p){
  CThostFtdcMarketDataBaseField *t = (CThostFtdcMarketDataBaseField *)calloc(1, sizeof(CThostFtdcMarketDataBaseField));
  memset(t,0,sizeof(CThostFtdcMarketDataBaseField));
  //昨持仓量
  t->PreOpenInterest =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PreOpenInterest"));
  //上次结算价
  t->PreSettlementPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PreSettlementPrice"));
  //交易日
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //昨收盘
  t->PreClosePrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PreClosePrice"));
  //昨虚实度
  t->PreDelta =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PreDelta"));

  return t;
};

//正在同步中的交易账号
PyObject * new_CThostFtdcSyncingTradingAccountField(CThostFtdcSyncingTradingAccountField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcSyncingTradingAccountField", (char*)"ddddyddddddddddddddddyydidddddd",
p->WithdrawQuota, p->DeliveryMargin, p->PreMortgage, p->Balance, p->BrokerID, p->Deposit, p->CashIn, p->Reserve, p->ExchangeMargin, p->CurrMargin, p->PositionProfit, p->FrozenMargin, p->Commission, p->Interest, p->Available, p->Credit, p->CloseProfit, p->ReserveBalance, p->ExchangeDeliveryMargin, p->FrozenCommission, p->InterestBase, p->TradingDay, p->AccountID, p->FrozenCash, p->SettlementID, p->Mortgage, p->PreCredit, p->PreDeposit, p->PreMargin, p->Withdraw, p->PreBalance);
}
CThostFtdcSyncingTradingAccountField * from_CThostFtdcSyncingTradingAccountField(PyObject * p){
  CThostFtdcSyncingTradingAccountField *t = (CThostFtdcSyncingTradingAccountField *)calloc(1, sizeof(CThostFtdcSyncingTradingAccountField));
  memset(t,0,sizeof(CThostFtdcSyncingTradingAccountField));
  //可取资金
  t->WithdrawQuota =   PyFloat_AsDouble(PyObject_GetAttrString(p, "WithdrawQuota"));
  //投资者交割保证金
  t->DeliveryMargin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "DeliveryMargin"));
  //上次质押金额
  t->PreMortgage =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PreMortgage"));
  //期货结算准备金
  t->Balance =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Balance"));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //入金金额
  t->Deposit =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Deposit"));
  //资金差额
  t->CashIn =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CashIn"));
  //基本准备金
  t->Reserve =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Reserve"));
  //交易所保证金
  t->ExchangeMargin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ExchangeMargin"));
  //当前保证金总额
  t->CurrMargin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CurrMargin"));
  //持仓盈亏
  t->PositionProfit =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PositionProfit"));
  //冻结的保证金
  t->FrozenMargin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "FrozenMargin"));
  //手续费
  t->Commission =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Commission"));
  //利息收入
  t->Interest =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Interest"));
  //可用资金
  t->Available =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Available"));
  //信用额度
  t->Credit =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Credit"));
  //平仓盈亏
  t->CloseProfit =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CloseProfit"));
  //保底期货结算准备金
  t->ReserveBalance =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ReserveBalance"));
  //交易所交割保证金
  t->ExchangeDeliveryMargin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ExchangeDeliveryMargin"));
  //冻结的手续费
  t->FrozenCommission =   PyFloat_AsDouble(PyObject_GetAttrString(p, "FrozenCommission"));
  //利息基数
  t->InterestBase =   PyFloat_AsDouble(PyObject_GetAttrString(p, "InterestBase"));
  //交易日
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //投资者帐号
  strcpy(t->AccountID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AccountID"),"gbk","Error!")));
  //冻结的资金
  t->FrozenCash =   PyFloat_AsDouble(PyObject_GetAttrString(p, "FrozenCash"));
  //结算编号
  t->SettlementID =   PyLong_AsLong(PyObject_GetAttrString(p, "SettlementID"));
  //质押金额
  t->Mortgage =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Mortgage"));
  //上次信用额度
  t->PreCredit =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PreCredit"));
  //上次存款额
  t->PreDeposit =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PreDeposit"));
  //上次占用的保证金
  t->PreMargin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PreMargin"));
  //出金金额
  t->Withdraw =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Withdraw"));
  //上次结算准备金
  t->PreBalance =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PreBalance"));

  return t;
};

//投资者合约交易权限
PyObject * new_CThostFtdcInstrumentTradingRightField(CThostFtdcInstrumentTradingRightField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcInstrumentTradingRightField", (char*)"yycyc",
p->InstrumentID, p->InvestorID, p->InvestorRange, p->BrokerID, p->TradingRight);
}
CThostFtdcInstrumentTradingRightField * from_CThostFtdcInstrumentTradingRightField(PyObject * p){
  CThostFtdcInstrumentTradingRightField *t = (CThostFtdcInstrumentTradingRightField *)calloc(1, sizeof(CThostFtdcInstrumentTradingRightField));
  memset(t,0,sizeof(CThostFtdcInstrumentTradingRightField));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //投资者范围
  //enum类型
  //THOST_FTDC_IR_Single -> '3', 单一投资者
  //THOST_FTDC_IR_All -> '1', 所有
  //THOST_FTDC_IR_Group -> '2', 投资者组
  t->InvestorRange =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorRange"),"gbk","Error!"))[0];
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //交易权限
  //enum类型
  //THOST_FTDC_TR_Allow -> '0', 可以交易
  //THOST_FTDC_TR_CloseOnly -> '1', 只能平仓
  //THOST_FTDC_TR_Forbidden -> '2', 不能交易
  t->TradingRight =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingRight"),"gbk","Error!"))[0];

  return t;
};

//资金账户口令变更域
PyObject * new_CThostFtdcTradingAccountPasswordUpdateV1Field(CThostFtdcTradingAccountPasswordUpdateV1Field * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcTradingAccountPasswordUpdateV1Field", (char*)"yyyy",
p->NewPassword, p->BrokerID, p->InvestorID, p->OldPassword);
}
CThostFtdcTradingAccountPasswordUpdateV1Field * from_CThostFtdcTradingAccountPasswordUpdateV1Field(PyObject * p){
  CThostFtdcTradingAccountPasswordUpdateV1Field *t = (CThostFtdcTradingAccountPasswordUpdateV1Field *)calloc(1, sizeof(CThostFtdcTradingAccountPasswordUpdateV1Field));
  memset(t,0,sizeof(CThostFtdcTradingAccountPasswordUpdateV1Field));
  //新的口令
  strcpy(t->NewPassword, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "NewPassword"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //原来的口令
  strcpy(t->OldPassword, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OldPassword"),"gbk","Error!")));

  return t;
};

//查询银行交易明细请求响应
PyObject * new_CThostFtdcTransferQryDetailRspField(CThostFtdcTransferQryDetailRspField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcTransferQryDetailRspField", (char*)"yyiyyydiyyyycy",
p->FutureAccount, p->TradeTime, p->FutureSerial, p->TradeDate, p->CertCode, p->BankBrchID, p->TxAmount, p->BankSerial, p->CurrencyCode, p->TradeCode, p->FutureID, p->BankID, p->Flag, p->BankAccount);
}
CThostFtdcTransferQryDetailRspField * from_CThostFtdcTransferQryDetailRspField(PyObject * p){
  CThostFtdcTransferQryDetailRspField *t = (CThostFtdcTransferQryDetailRspField *)calloc(1, sizeof(CThostFtdcTransferQryDetailRspField));
  memset(t,0,sizeof(CThostFtdcTransferQryDetailRspField));
  //资金帐号
  strcpy(t->FutureAccount, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "FutureAccount"),"gbk","Error!")));
  //交易时间
  strcpy(t->TradeTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeTime"),"gbk","Error!")));
  //期货流水号
  t->FutureSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "FutureSerial"));
  //交易日期
  strcpy(t->TradeDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeDate"),"gbk","Error!")));
  //证件号码
  strcpy(t->CertCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CertCode"),"gbk","Error!")));
  //银行分中心代码
  strcpy(t->BankBrchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBrchID"),"gbk","Error!")));
  //发生金额
  t->TxAmount =   PyFloat_AsDouble(PyObject_GetAttrString(p, "TxAmount"));
  //银行流水号
  t->BankSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "BankSerial"));
  //货币代码
  strcpy(t->CurrencyCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrencyCode"),"gbk","Error!")));
  //交易代码
  strcpy(t->TradeCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeCode"),"gbk","Error!")));
  //期货公司代码
  strcpy(t->FutureID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "FutureID"),"gbk","Error!")));
  //银行代码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //有效标志
  //enum类型
  //THOST_FTDC_TVF_Invalid -> '0', 无效或失败
  //THOST_FTDC_TVF_Valid -> '1', 有效
  //THOST_FTDC_TVF_Reverse -> '2', 冲正
  t->Flag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Flag"),"gbk","Error!"))[0];
  //银行账号
  strcpy(t->BankAccount, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccount"),"gbk","Error!")));

  return t;
};

//交易核心向银期报盘发出密钥同步处理结果的通知
PyObject * new_CThostFtdcNotifySyncKeyField(CThostFtdcNotifySyncKeyField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcNotifySyncKeyField", (char*)"yyiiyiyyyciyyyyyyyiyyi",
p->TradeTime, p->DeviceID, p->ErrorID, p->InstallID, p->BrokerID, p->SessionID, p->BankID, p->ErrorMsg, p->OperNo, p->LastFragment, p->RequestID, p->TradeDate, p->UserID, p->TradingDay, p->BankSerial, p->BrokerIDByBank, p->TradeCode, p->Message, p->TID, p->BankBranchID, p->BrokerBranchID, p->PlateSerial);
}
CThostFtdcNotifySyncKeyField * from_CThostFtdcNotifySyncKeyField(PyObject * p){
  CThostFtdcNotifySyncKeyField *t = (CThostFtdcNotifySyncKeyField *)calloc(1, sizeof(CThostFtdcNotifySyncKeyField));
  memset(t,0,sizeof(CThostFtdcNotifySyncKeyField));
  //交易时间
  strcpy(t->TradeTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeTime"),"gbk","Error!")));
  //渠道标志
  strcpy(t->DeviceID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "DeviceID"),"gbk","Error!")));
  //错误代码
  t->ErrorID =   PyLong_AsLong(PyObject_GetAttrString(p, "ErrorID"));
  //安装编号
  t->InstallID =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallID"));
  //期商代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //会话号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //银行代码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //错误信息
  strcpy(t->ErrorMsg, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ErrorMsg"),"gbk","Error!")));
  //交易柜员
  strcpy(t->OperNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OperNo"),"gbk","Error!")));
  //最后分片标志
  //enum类型
  //THOST_FTDC_LF_No -> '1', 不是最后分片
  //THOST_FTDC_LF_Yes -> '0', 是最后分片
  t->LastFragment =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LastFragment"),"gbk","Error!"))[0];
  //请求编号
  t->RequestID =   PyLong_AsLong(PyObject_GetAttrString(p, "RequestID"));
  //交易日期
  strcpy(t->TradeDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeDate"),"gbk","Error!")));
  //用户标识
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //交易系统日期
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //银行流水号
  strcpy(t->BankSerial, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSerial"),"gbk","Error!")));
  //期货公司银行编码
  strcpy(t->BrokerIDByBank, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerIDByBank"),"gbk","Error!")));
  //业务功能码
  strcpy(t->TradeCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeCode"),"gbk","Error!")));
  //交易核心给银期报盘的消息
  strcpy(t->Message, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Message"),"gbk","Error!")));
  //交易ID
  t->TID =   PyLong_AsLong(PyObject_GetAttrString(p, "TID"));
  //银行分支机构代码
  strcpy(t->BankBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBranchID"),"gbk","Error!")));
  //期商分支机构代码
  strcpy(t->BrokerBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerBranchID"),"gbk","Error!")));
  //银期平台消息流水号
  t->PlateSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "PlateSerial"));

  return t;
};

//交易所状态
PyObject * new_CThostFtdcExchangeSequenceField(CThostFtdcExchangeSequenceField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcExchangeSequenceField", (char*)"cyi",
p->MarketStatus, p->ExchangeID, p->SequenceNo);
}
CThostFtdcExchangeSequenceField * from_CThostFtdcExchangeSequenceField(PyObject * p){
  CThostFtdcExchangeSequenceField *t = (CThostFtdcExchangeSequenceField *)calloc(1, sizeof(CThostFtdcExchangeSequenceField));
  memset(t,0,sizeof(CThostFtdcExchangeSequenceField));
  //合约交易状态
  //enum类型
  //THOST_FTDC_IS_AuctionMatch -> '5', 集合竞价撮合
  //THOST_FTDC_IS_NoTrading -> '1', 非交易
  //THOST_FTDC_IS_Closed -> '6', 收盘
  //THOST_FTDC_IS_AuctionBalance -> '4', 集合竞价价格平衡
  //THOST_FTDC_IS_Continous -> '2', 连续交易
  //THOST_FTDC_IS_BeforeTrading -> '0', 开盘前
  //THOST_FTDC_IS_AuctionOrdering -> '3', 集合竞价报单
  t->MarketStatus =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "MarketStatus"),"gbk","Error!"))[0];
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //序号
  t->SequenceNo =   PyLong_AsLong(PyObject_GetAttrString(p, "SequenceNo"));

  return t;
};

//银行发起银行资金转期货响应
PyObject * new_CThostFtdcRspTransferField(CThostFtdcRspTransferField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcRspTransferField", (char*)"cyiyiycdycyyycydyydyyycyidyiiccyycyicyyyyyyci",
p->CustType, p->DeviceID, p->ErrorID, p->BrokerID, p->SessionID, p->IdentifiedCardNo, p->IdCardType, p->FutureFetchAmount, p->BankID, p->BankPwdFlag, p->OperNo, p->BankAccount, p->BankSecuAcc, p->LastFragment, p->TradeDate, p->CustFee, p->AccountID, p->BankSerial, p->BrokerFee, p->CustomerName, p->BankPassWord, p->Message, p->TransferStatus, p->Digest, p->PlateSerial, p->TradeAmount, p->TradeTime, p->FutureSerial, p->InstallID, p->SecuPwdFlag, p->VerifyCertNoFlag, p->CurrencyID, p->ErrorMsg, p->BankSecuAccType, p->Password, p->RequestID, p->BankAccType, p->BrokerBranchID, p->UserID, p->TradingDay, p->BrokerIDByBank, p->TradeCode, p->BankBranchID, p->FeePayFlag, p->TID);
}
CThostFtdcRspTransferField * from_CThostFtdcRspTransferField(PyObject * p){
  CThostFtdcRspTransferField *t = (CThostFtdcRspTransferField *)calloc(1, sizeof(CThostFtdcRspTransferField));
  memset(t,0,sizeof(CThostFtdcRspTransferField));
  //客户类型
  //enum类型
  //THOST_FTDC_CUSTT_Person -> '0', 自然人
  //THOST_FTDC_CUSTT_Institution -> '1', 机构户
  t->CustType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustType"),"gbk","Error!"))[0];
  //渠道标志
  strcpy(t->DeviceID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "DeviceID"),"gbk","Error!")));
  //错误代码
  t->ErrorID =   PyLong_AsLong(PyObject_GetAttrString(p, "ErrorID"));
  //期商代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //会话号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //证件号码
  strcpy(t->IdentifiedCardNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdentifiedCardNo"),"gbk","Error!")));
  //证件类型
  //enum类型
  //THOST_FTDC_ICT_TaiwanCompatriotIDCard -> '7', 台胞证
  //THOST_FTDC_ICT_Passport -> '6', 护照
  //THOST_FTDC_ICT_LicenseNo -> '9', 营业执照号
  //THOST_FTDC_ICT_OtherCard -> 'x', 其他证件
  //THOST_FTDC_ICT_IDCard -> '1', 身份证
  //THOST_FTDC_ICT_EID -> '0', 组织机构代码
  //THOST_FTDC_ICT_TaxNo -> 'A', 税务登记号
  //THOST_FTDC_ICT_HomeComingCard -> '8', 回乡证
  //THOST_FTDC_ICT_OfficerIDCard -> '2', 军官证
  //THOST_FTDC_ICT_HouseholdRegister -> '5', 户口簿
  //THOST_FTDC_ICT_SoldierIDCard -> '4', 士兵证
  //THOST_FTDC_ICT_PoliceIDCard -> '3', 警官证
  t->IdCardType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdCardType"),"gbk","Error!"))[0];
  //期货可取金额
  t->FutureFetchAmount =   PyFloat_AsDouble(PyObject_GetAttrString(p, "FutureFetchAmount"));
  //银行代码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //银行密码标志
  //enum类型
  //THOST_FTDC_BPWDF_NoCheck -> '0', 不核对
  //THOST_FTDC_BPWDF_BlankCheck -> '1', 明文核对
  //THOST_FTDC_BPWDF_EncryptCheck -> '2', 密文核对
  t->BankPwdFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankPwdFlag"),"gbk","Error!"))[0];
  //交易柜员
  strcpy(t->OperNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OperNo"),"gbk","Error!")));
  //银行帐号
  strcpy(t->BankAccount, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccount"),"gbk","Error!")));
  //期货单位帐号
  strcpy(t->BankSecuAcc, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSecuAcc"),"gbk","Error!")));
  //最后分片标志
  //enum类型
  //THOST_FTDC_LF_No -> '1', 不是最后分片
  //THOST_FTDC_LF_Yes -> '0', 是最后分片
  t->LastFragment =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LastFragment"),"gbk","Error!"))[0];
  //交易日期
  strcpy(t->TradeDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeDate"),"gbk","Error!")));
  //应收客户费用
  t->CustFee =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CustFee"));
  //投资者帐号
  strcpy(t->AccountID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AccountID"),"gbk","Error!")));
  //银行流水号
  strcpy(t->BankSerial, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSerial"),"gbk","Error!")));
  //应收期货公司费用
  t->BrokerFee =   PyFloat_AsDouble(PyObject_GetAttrString(p, "BrokerFee"));
  //客户姓名
  strcpy(t->CustomerName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustomerName"),"gbk","Error!")));
  //银行密码
  strcpy(t->BankPassWord, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankPassWord"),"gbk","Error!")));
  //发送方给接收方的消息
  strcpy(t->Message, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Message"),"gbk","Error!")));
  //转账交易状态
  //enum类型
  //THOST_FTDC_TRFS_Normal -> '0', 正常
  //THOST_FTDC_TRFS_Repealed -> '1', 被冲正
  t->TransferStatus =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TransferStatus"),"gbk","Error!"))[0];
  //摘要
  strcpy(t->Digest, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Digest"),"gbk","Error!")));
  //银期平台消息流水号
  t->PlateSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "PlateSerial"));
  //转帐金额
  t->TradeAmount =   PyFloat_AsDouble(PyObject_GetAttrString(p, "TradeAmount"));
  //交易时间
  strcpy(t->TradeTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeTime"),"gbk","Error!")));
  //期货公司流水号
  t->FutureSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "FutureSerial"));
  //安装编号
  t->InstallID =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallID"));
  //期货资金密码核对标志
  //enum类型
  //THOST_FTDC_BPWDF_NoCheck -> '0', 不核对
  //THOST_FTDC_BPWDF_BlankCheck -> '1', 明文核对
  //THOST_FTDC_BPWDF_EncryptCheck -> '2', 密文核对
  t->SecuPwdFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "SecuPwdFlag"),"gbk","Error!"))[0];
  //验证客户证件号码标志
  //enum类型
  //THOST_FTDC_YNI_No -> '1', 否
  //THOST_FTDC_YNI_Yes -> '0', 是
  t->VerifyCertNoFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "VerifyCertNoFlag"),"gbk","Error!"))[0];
  //币种代码
  strcpy(t->CurrencyID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrencyID"),"gbk","Error!")));
  //错误信息
  strcpy(t->ErrorMsg, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ErrorMsg"),"gbk","Error!")));
  //期货单位帐号类型
  //enum类型
  //THOST_FTDC_BAT_SavingCard -> '2', 储蓄卡
  //THOST_FTDC_BAT_CreditCard -> '3', 信用卡
  //THOST_FTDC_BAT_BankBook -> '1', 银行存折
  t->BankSecuAccType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSecuAccType"),"gbk","Error!"))[0];
  //期货密码
  strcpy(t->Password, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Password"),"gbk","Error!")));
  //请求编号
  t->RequestID =   PyLong_AsLong(PyObject_GetAttrString(p, "RequestID"));
  //银行帐号类型
  //enum类型
  //THOST_FTDC_BAT_SavingCard -> '2', 储蓄卡
  //THOST_FTDC_BAT_CreditCard -> '3', 信用卡
  //THOST_FTDC_BAT_BankBook -> '1', 银行存折
  t->BankAccType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccType"),"gbk","Error!"))[0];
  //期商分支机构代码
  strcpy(t->BrokerBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerBranchID"),"gbk","Error!")));
  //用户标识
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //交易系统日期
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //期货公司银行编码
  strcpy(t->BrokerIDByBank, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerIDByBank"),"gbk","Error!")));
  //业务功能码
  strcpy(t->TradeCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeCode"),"gbk","Error!")));
  //银行分支机构代码
  strcpy(t->BankBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBranchID"),"gbk","Error!")));
  //费用支付标志
  //enum类型
  //THOST_FTDC_FPF_SHA -> '2', 由发送方支付发起的费用，受益方支付接受的费用
  //THOST_FTDC_FPF_BEN -> '0', 由受益方支付费用
  //THOST_FTDC_FPF_OUR -> '1', 由发送方支付费用
  t->FeePayFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "FeePayFlag"),"gbk","Error!"))[0];
  //交易ID
  t->TID =   PyLong_AsLong(PyObject_GetAttrString(p, "TID"));

  return t;
};

//登录信息
PyObject * new_CThostFtdcLogoutAllField(CThostFtdcLogoutAllField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcLogoutAllField", (char*)"iiy",
p->FrontID, p->SessionID, p->SystemName);
}
CThostFtdcLogoutAllField * from_CThostFtdcLogoutAllField(PyObject * p){
  CThostFtdcLogoutAllField *t = (CThostFtdcLogoutAllField *)calloc(1, sizeof(CThostFtdcLogoutAllField));
  memset(t,0,sizeof(CThostFtdcLogoutAllField));
  //前置编号
  t->FrontID =   PyLong_AsLong(PyObject_GetAttrString(p, "FrontID"));
  //会话编号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //系统名称
  strcpy(t->SystemName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "SystemName"),"gbk","Error!")));

  return t;
};

//交易核心向银期报盘发出密钥同步请求
PyObject * new_CThostFtdcReqSyncKeyField(CThostFtdcReqSyncKeyField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcReqSyncKeyField", (char*)"ciyyyyyyiyyyyiyyiyyi",
p->LastFragment, p->RequestID, p->UserID, p->TradeTime, p->DeviceID, p->TradeDate, p->BrokerID, p->TradingDay, p->SessionID, p->BankSerial, p->OperNo, p->BrokerIDByBank, p->TradeCode, p->InstallID, p->Message, p->BankID, p->TID, p->BankBranchID, p->BrokerBranchID, p->PlateSerial);
}
CThostFtdcReqSyncKeyField * from_CThostFtdcReqSyncKeyField(PyObject * p){
  CThostFtdcReqSyncKeyField *t = (CThostFtdcReqSyncKeyField *)calloc(1, sizeof(CThostFtdcReqSyncKeyField));
  memset(t,0,sizeof(CThostFtdcReqSyncKeyField));
  //最后分片标志
  //enum类型
  //THOST_FTDC_LF_No -> '1', 不是最后分片
  //THOST_FTDC_LF_Yes -> '0', 是最后分片
  t->LastFragment =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LastFragment"),"gbk","Error!"))[0];
  //请求编号
  t->RequestID =   PyLong_AsLong(PyObject_GetAttrString(p, "RequestID"));
  //用户标识
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //交易时间
  strcpy(t->TradeTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeTime"),"gbk","Error!")));
  //渠道标志
  strcpy(t->DeviceID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "DeviceID"),"gbk","Error!")));
  //交易日期
  strcpy(t->TradeDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeDate"),"gbk","Error!")));
  //期商代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //交易系统日期
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //会话号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //银行流水号
  strcpy(t->BankSerial, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSerial"),"gbk","Error!")));
  //交易柜员
  strcpy(t->OperNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OperNo"),"gbk","Error!")));
  //期货公司银行编码
  strcpy(t->BrokerIDByBank, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerIDByBank"),"gbk","Error!")));
  //业务功能码
  strcpy(t->TradeCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeCode"),"gbk","Error!")));
  //安装编号
  t->InstallID =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallID"));
  //交易核心给银期报盘的消息
  strcpy(t->Message, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Message"),"gbk","Error!")));
  //银行代码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //交易ID
  t->TID =   PyLong_AsLong(PyObject_GetAttrString(p, "TID"));
  //银行分支机构代码
  strcpy(t->BankBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBranchID"),"gbk","Error!")));
  //期商分支机构代码
  strcpy(t->BrokerBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerBranchID"),"gbk","Error!")));
  //银期平台消息流水号
  t->PlateSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "PlateSerial"));

  return t;
};

//查询合约
PyObject * new_CThostFtdcQryInstrumentField(CThostFtdcQryInstrumentField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryInstrumentField", (char*)"yyyy",
p->ExchangeInstID, p->InstrumentID, p->ExchangeID, p->ProductID);
}
CThostFtdcQryInstrumentField * from_CThostFtdcQryInstrumentField(PyObject * p){
  CThostFtdcQryInstrumentField *t = (CThostFtdcQryInstrumentField *)calloc(1, sizeof(CThostFtdcQryInstrumentField));
  memset(t,0,sizeof(CThostFtdcQryInstrumentField));
  //合约在交易所的代码
  strcpy(t->ExchangeInstID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeInstID"),"gbk","Error!")));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //产品代码
  strcpy(t->ProductID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ProductID"),"gbk","Error!")));

  return t;
};

//成交均价
PyObject * new_CThostFtdcMarketDataAveragePriceField(CThostFtdcMarketDataAveragePriceField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcMarketDataAveragePriceField", (char*)"d",
p->AveragePrice);
}
CThostFtdcMarketDataAveragePriceField * from_CThostFtdcMarketDataAveragePriceField(PyObject * p){
  CThostFtdcMarketDataAveragePriceField *t = (CThostFtdcMarketDataAveragePriceField *)calloc(1, sizeof(CThostFtdcMarketDataAveragePriceField));
  memset(t,0,sizeof(CThostFtdcMarketDataAveragePriceField));
  //当日均价
  t->AveragePrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "AveragePrice"));

  return t;
};

//查询签约银行响应
PyObject * new_CThostFtdcContractBankField(CThostFtdcContractBankField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcContractBankField", (char*)"yyyy",
p->BankID, p->BrokerID, p->BankBrchID, p->BankName);
}
CThostFtdcContractBankField * from_CThostFtdcContractBankField(PyObject * p){
  CThostFtdcContractBankField *t = (CThostFtdcContractBankField *)calloc(1, sizeof(CThostFtdcContractBankField));
  memset(t,0,sizeof(CThostFtdcContractBankField));
  //银行代码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //银行分中心代码
  strcpy(t->BankBrchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBrchID"),"gbk","Error!")));
  //银行名称
  strcpy(t->BankName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankName"),"gbk","Error!")));

  return t;
};

//日终文件就绪请求
PyObject * new_CThostFtdcReqDayEndFileReadyField(CThostFtdcReqDayEndFileReadyField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcReqDayEndFileReadyField", (char*)"ccyyyyiyyyyyiy",
p->LastFragment, p->FileBusinessCode, p->TradeTime, p->TradeDate, p->BrokerID, p->TradingDay, p->SessionID, p->BankSerial, p->TradeCode, p->BankID, p->BankBranchID, p->BrokerBranchID, p->PlateSerial, p->Digest);
}
CThostFtdcReqDayEndFileReadyField * from_CThostFtdcReqDayEndFileReadyField(PyObject * p){
  CThostFtdcReqDayEndFileReadyField *t = (CThostFtdcReqDayEndFileReadyField *)calloc(1, sizeof(CThostFtdcReqDayEndFileReadyField));
  memset(t,0,sizeof(CThostFtdcReqDayEndFileReadyField));
  //最后分片标志
  //enum类型
  //THOST_FTDC_LF_No -> '1', 不是最后分片
  //THOST_FTDC_LF_Yes -> '0', 是最后分片
  t->LastFragment =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LastFragment"),"gbk","Error!"))[0];
  //文件业务功能
  //enum类型
  //THOST_FTDC_FBC_CustCancelAccountInfo -> '6', 客户销户结息明细对账
  //THOST_FTDC_FBC_FutureAccountChangeInfoDetails -> '4', 期货账户信息变更明细对账
  //THOST_FTDC_FBC_CustMoneyResult -> '7', 客户资金余额对账结果
  //THOST_FTDC_FBC_AccountTradeDetails -> '3', 账户类交易明细对账
  //THOST_FTDC_FBC_CorporationMoneyTotal -> 'b', 法人存管银行资金交收汇总
  //THOST_FTDC_FBC_PreparationMoney -> 'e', 存管银行备付金余额
  //THOST_FTDC_FBC_CustAccStatus -> '2', 客户账户状态对账
  //THOST_FTDC_FBC_OthersExceptionResult -> '8', 其它对账异常结果文件
  //THOST_FTDC_FBC_Others -> '0', 其他
  //THOST_FTDC_FBC_MainPartMonitorData -> 'd', 总分平衡监管数据
  //THOST_FTDC_FBC_MainbodyMoneyTotal -> 'c', 主体间资金交收汇总
  //THOST_FTDC_FBC_BankMoneyMonitorData -> 'f', 协办存管银行资金监管数据
  //THOST_FTDC_FBC_CustMoneySendAndReceiveDetails -> 'a', 客户资金交收明细
  //THOST_FTDC_FBC_TransferDetails -> '1', 转账交易明细对账
  //THOST_FTDC_FBC_CustMoneyDetail -> '5', 客户资金台账余额明细对账
  //THOST_FTDC_FBC_CustInterestNetMoneyDetails -> '9', 客户结息净额明细
  t->FileBusinessCode =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "FileBusinessCode"),"gbk","Error!"))[0];
  //交易时间
  strcpy(t->TradeTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeTime"),"gbk","Error!")));
  //交易日期
  strcpy(t->TradeDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeDate"),"gbk","Error!")));
  //期商代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //交易系统日期
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //会话号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //银行流水号
  strcpy(t->BankSerial, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSerial"),"gbk","Error!")));
  //业务功能码
  strcpy(t->TradeCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeCode"),"gbk","Error!")));
  //银行代码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //银行分支机构代码
  strcpy(t->BankBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBranchID"),"gbk","Error!")));
  //期商分支机构代码
  strcpy(t->BrokerBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerBranchID"),"gbk","Error!")));
  //银期平台消息流水号
  t->PlateSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "PlateSerial"));
  //摘要
  strcpy(t->Digest, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Digest"),"gbk","Error!")));

  return t;
};

//银期转帐报文头
PyObject * new_CThostFtdcTransferHeaderField(CThostFtdcTransferHeaderField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcTransferHeaderField", (char*)"iyyyiyyyyyyyy",
p->RequestID, p->TradeTime, p->DeviceID, p->TradeDate, p->SessionID, p->TradeSerial, p->BankBrchID, p->RecordNum, p->Version, p->TradeCode, p->FutureID, p->BankID, p->OperNo);
}
CThostFtdcTransferHeaderField * from_CThostFtdcTransferHeaderField(PyObject * p){
  CThostFtdcTransferHeaderField *t = (CThostFtdcTransferHeaderField *)calloc(1, sizeof(CThostFtdcTransferHeaderField));
  memset(t,0,sizeof(CThostFtdcTransferHeaderField));
  //请求编号，N/A
  t->RequestID =   PyLong_AsLong(PyObject_GetAttrString(p, "RequestID"));
  //交易时间，必填，格式：hhmmss
  strcpy(t->TradeTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeTime"),"gbk","Error!")));
  //交易设备类型，N/A
  strcpy(t->DeviceID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "DeviceID"),"gbk","Error!")));
  //交易日期，必填，格式：yyyymmdd
  strcpy(t->TradeDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeDate"),"gbk","Error!")));
  //会话编号，N/A
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //发起方流水号，N/A
  strcpy(t->TradeSerial, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeSerial"),"gbk","Error!")));
  //银行分中心代码，根据查询银行得到，必填
  strcpy(t->BankBrchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBrchID"),"gbk","Error!")));
  //记录数，N/A
  strcpy(t->RecordNum, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "RecordNum"),"gbk","Error!")));
  //版本号，常量，1.0
  strcpy(t->Version, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Version"),"gbk","Error!")));
  //交易代码，必填
  strcpy(t->TradeCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeCode"),"gbk","Error!")));
  //期货公司代码，必填
  strcpy(t->FutureID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "FutureID"),"gbk","Error!")));
  //银行代码，根据查询银行得到，必填
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //操作员，N/A
  strcpy(t->OperNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OperNo"),"gbk","Error!")));

  return t;
};

//输入预埋单操作
PyObject * new_CThostFtdcParkedOrderActionField(CThostFtdcParkedOrderActionField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcParkedOrderActionField", (char*)"yyiciyiycciydiiyyyy",
p->OrderSysID, p->ParkedOrderActionID, p->RequestID, p->UserType, p->SessionID, p->BrokerID, p->FrontID, p->InvestorID, p->Status, p->ActionFlag, p->ErrorID, p->InstrumentID, p->LimitPrice, p->OrderActionRef, p->VolumeChange, p->ErrorMsg, p->ExchangeID, p->UserID, p->OrderRef);
}
CThostFtdcParkedOrderActionField * from_CThostFtdcParkedOrderActionField(PyObject * p){
  CThostFtdcParkedOrderActionField *t = (CThostFtdcParkedOrderActionField *)calloc(1, sizeof(CThostFtdcParkedOrderActionField));
  memset(t,0,sizeof(CThostFtdcParkedOrderActionField));
  //报单编号
  strcpy(t->OrderSysID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderSysID"),"gbk","Error!")));
  //预埋撤单单编号
  strcpy(t->ParkedOrderActionID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ParkedOrderActionID"),"gbk","Error!")));
  //请求编号
  t->RequestID =   PyLong_AsLong(PyObject_GetAttrString(p, "RequestID"));
  //用户类型
  //enum类型
  //THOST_FTDC_UT_SuperUser -> '2', 管理员
  //THOST_FTDC_UT_Operator -> '1', 操作员
  //THOST_FTDC_UT_Investor -> '0', 投资者
  t->UserType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserType"),"gbk","Error!"))[0];
  //会话编号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //前置编号
  t->FrontID =   PyLong_AsLong(PyObject_GetAttrString(p, "FrontID"));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //预埋撤单状态
  //enum类型
  //THOST_FTDC_PAOS_Deleted -> '3', 已删除
  //THOST_FTDC_PAOS_NotSend -> '1', 未发送
  //THOST_FTDC_PAOS_Send -> '2', 已发送
  t->Status =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Status"),"gbk","Error!"))[0];
  //操作标志
  //enum类型
  //THOST_FTDC_AF_Delete -> '0', 删除
  //THOST_FTDC_AF_Modify -> '3', 修改
  t->ActionFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ActionFlag"),"gbk","Error!"))[0];
  //错误代码
  t->ErrorID =   PyLong_AsLong(PyObject_GetAttrString(p, "ErrorID"));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //价格
  t->LimitPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LimitPrice"));
  //报单操作引用
  t->OrderActionRef =   PyLong_AsLong(PyObject_GetAttrString(p, "OrderActionRef"));
  //数量变化
  t->VolumeChange =   PyLong_AsLong(PyObject_GetAttrString(p, "VolumeChange"));
  //错误信息
  strcpy(t->ErrorMsg, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ErrorMsg"),"gbk","Error!")));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //报单引用
  strcpy(t->OrderRef, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderRef"),"gbk","Error!")));

  return t;
};

//经纪公司同步
PyObject * new_CThostFtdcBrokerSyncField(CThostFtdcBrokerSyncField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcBrokerSyncField", (char*)"y",
p->BrokerID);
}
CThostFtdcBrokerSyncField * from_CThostFtdcBrokerSyncField(PyObject * p){
  CThostFtdcBrokerSyncField *t = (CThostFtdcBrokerSyncField *)calloc(1, sizeof(CThostFtdcBrokerSyncField));
  memset(t,0,sizeof(CThostFtdcBrokerSyncField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));

  return t;
};

//查询投资者持仓
PyObject * new_CThostFtdcQryInvestorPositionField(CThostFtdcQryInvestorPositionField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryInvestorPositionField", (char*)"yyy",
p->BrokerID, p->InvestorID, p->InstrumentID);
}
CThostFtdcQryInvestorPositionField * from_CThostFtdcQryInvestorPositionField(PyObject * p){
  CThostFtdcQryInvestorPositionField *t = (CThostFtdcQryInvestorPositionField *)calloc(1, sizeof(CThostFtdcQryInvestorPositionField));
  memset(t,0,sizeof(CThostFtdcQryInvestorPositionField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));

  return t;
};

//验证期货资金密码
PyObject * new_CThostFtdcVerifyFuturePasswordField(CThostFtdcVerifyFuturePasswordField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcVerifyFuturePasswordField", (char*)"ycyiyyyiyyyyyiyyiy",
p->Password, p->LastFragment, p->TradeTime, p->InstallID, p->TradeDate, p->BrokerID, p->TradingDay, p->SessionID, p->AccountID, p->BankSerial, p->TradeCode, p->BankPassWord, p->BankID, p->TID, p->BankBranchID, p->BrokerBranchID, p->PlateSerial, p->BankAccount);
}
CThostFtdcVerifyFuturePasswordField * from_CThostFtdcVerifyFuturePasswordField(PyObject * p){
  CThostFtdcVerifyFuturePasswordField *t = (CThostFtdcVerifyFuturePasswordField *)calloc(1, sizeof(CThostFtdcVerifyFuturePasswordField));
  memset(t,0,sizeof(CThostFtdcVerifyFuturePasswordField));
  //期货密码
  strcpy(t->Password, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Password"),"gbk","Error!")));
  //最后分片标志
  //enum类型
  //THOST_FTDC_LF_No -> '1', 不是最后分片
  //THOST_FTDC_LF_Yes -> '0', 是最后分片
  t->LastFragment =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LastFragment"),"gbk","Error!"))[0];
  //交易时间
  strcpy(t->TradeTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeTime"),"gbk","Error!")));
  //安装编号
  t->InstallID =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallID"));
  //交易日期
  strcpy(t->TradeDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeDate"),"gbk","Error!")));
  //期商代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //交易系统日期
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //会话号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //投资者帐号
  strcpy(t->AccountID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AccountID"),"gbk","Error!")));
  //银行流水号
  strcpy(t->BankSerial, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSerial"),"gbk","Error!")));
  //业务功能码
  strcpy(t->TradeCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeCode"),"gbk","Error!")));
  //银行密码
  strcpy(t->BankPassWord, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankPassWord"),"gbk","Error!")));
  //银行代码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //交易ID
  t->TID =   PyLong_AsLong(PyObject_GetAttrString(p, "TID"));
  //银行分支机构代码
  strcpy(t->BankBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBranchID"),"gbk","Error!")));
  //期商分支机构代码
  strcpy(t->BrokerBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerBranchID"),"gbk","Error!")));
  //银期平台消息流水号
  t->PlateSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "PlateSerial"));
  //银行帐号
  strcpy(t->BankAccount, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccount"),"gbk","Error!")));

  return t;
};

//手工同步用户动态令牌
PyObject * new_CThostFtdcManualSyncBrokerUserOTPField(CThostFtdcManualSyncBrokerUserOTPField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcManualSyncBrokerUserOTPField", (char*)"yycyy",
p->SecondOTP, p->BrokerID, p->OTPType, p->UserID, p->FirstOTP);
}
CThostFtdcManualSyncBrokerUserOTPField * from_CThostFtdcManualSyncBrokerUserOTPField(PyObject * p){
  CThostFtdcManualSyncBrokerUserOTPField *t = (CThostFtdcManualSyncBrokerUserOTPField *)calloc(1, sizeof(CThostFtdcManualSyncBrokerUserOTPField));
  memset(t,0,sizeof(CThostFtdcManualSyncBrokerUserOTPField));
  //第二个动态密码
  strcpy(t->SecondOTP, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "SecondOTP"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //动态令牌类型
  //enum类型
  //THOST_FTDC_OTP_NONE -> '0', 无动态令牌
  //THOST_FTDC_OTP_TOTP -> '1', 时间令牌
  t->OTPType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OTPType"),"gbk","Error!"))[0];
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //第一个动态密码
  strcpy(t->FirstOTP, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "FirstOTP"),"gbk","Error!")));

  return t;
};

//查询经纪公司用户权限
PyObject * new_CThostFtdcQryBrokerUserFunctionField(CThostFtdcQryBrokerUserFunctionField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryBrokerUserFunctionField", (char*)"yy",
p->BrokerID, p->UserID);
}
CThostFtdcQryBrokerUserFunctionField * from_CThostFtdcQryBrokerUserFunctionField(PyObject * p){
  CThostFtdcQryBrokerUserFunctionField *t = (CThostFtdcQryBrokerUserFunctionField *)calloc(1, sizeof(CThostFtdcQryBrokerUserFunctionField));
  memset(t,0,sizeof(CThostFtdcQryBrokerUserFunctionField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));

  return t;
};

//输入报单
PyObject * new_CThostFtdcInputOrderField(CThostFtdcInputOrderField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcInputOrderField", (char*)"ccyyiciycidiiiyyydyycyc",
p->OrderPriceType, p->Direction, p->BrokerID, p->InvestorID, p->MinVolume, p->ForceCloseReason, p->VolumeTotalOriginal, p->InstrumentID, p->ContingentCondition, p->UserForceClose, p->StopPrice, p->RequestID, p->IsAutoSuspend, p->IsSwapOrder, p->UserID, p->GTDDate, p->BusinessUnit, p->LimitPrice, p->OrderRef, p->CombHedgeFlag, p->VolumeCondition, p->CombOffsetFlag, p->TimeCondition);
}
CThostFtdcInputOrderField * from_CThostFtdcInputOrderField(PyObject * p){
  CThostFtdcInputOrderField *t = (CThostFtdcInputOrderField *)calloc(1, sizeof(CThostFtdcInputOrderField));
  memset(t,0,sizeof(CThostFtdcInputOrderField));
  //报单价格条件
  //enum类型
  //THOST_FTDC_OPT_LastPricePlusOneTicks -> '5', 最新价浮动上浮1个ticks
  //THOST_FTDC_OPT_LastPricePlusTwoTicks -> '6', 最新价浮动上浮2个ticks
  //THOST_FTDC_OPT_BidPrice1PlusTwoTicks -> 'E', 买一价浮动上浮2个ticks
  //THOST_FTDC_OPT_AnyPrice -> '1', 任意价
  //THOST_FTDC_OPT_AskPrice1PlusTwoTicks -> 'A', 卖一价浮动上浮2个ticks
  //THOST_FTDC_OPT_AskPrice1PlusThreeTicks -> 'B', 卖一价浮动上浮3个ticks
  //THOST_FTDC_OPT_BidPrice1PlusThreeTicks -> 'F', 买一价浮动上浮3个ticks
  //THOST_FTDC_OPT_BestPrice -> '3', 最优价
  //THOST_FTDC_OPT_LimitPrice -> '2', 限价
  //THOST_FTDC_OPT_BidPrice1 -> 'C', 买一价
  //THOST_FTDC_OPT_AskPrice1PlusOneTicks -> '9', 卖一价浮动上浮1个ticks
  //THOST_FTDC_OPT_LastPricePlusThreeTicks -> '7', 最新价浮动上浮3个ticks
  //THOST_FTDC_OPT_LastPrice -> '4', 最新价
  //THOST_FTDC_OPT_AskPrice1 -> '8', 卖一价
  //THOST_FTDC_OPT_BidPrice1PlusOneTicks -> 'D', 买一价浮动上浮1个ticks
  t->OrderPriceType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderPriceType"),"gbk","Error!"))[0];
  //买卖方向
  //enum类型
  //THOST_FTDC_D_Buy -> '0', 买
  //THOST_FTDC_D_Sell -> '1', 卖
  t->Direction =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Direction"),"gbk","Error!"))[0];
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //最小成交量
  t->MinVolume =   PyLong_AsLong(PyObject_GetAttrString(p, "MinVolume"));
  //强平原因
  //enum类型
  //THOST_FTDC_FCC_Other -> '6', 其它
  //THOST_FTDC_FCC_ClientOverPositionLimit -> '2', 客户超仓
  //THOST_FTDC_FCC_NotMultiple -> '4', 持仓非整数倍
  //THOST_FTDC_FCC_PersonDeliv -> '7', 自然人临近交割
  //THOST_FTDC_FCC_NotForceClose -> '0', 非强平
  //THOST_FTDC_FCC_Violation -> '5', 违规
  //THOST_FTDC_FCC_MemberOverPositionLimit -> '3', 会员超仓
  //THOST_FTDC_FCC_LackDeposit -> '1', 资金不足
  t->ForceCloseReason =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ForceCloseReason"),"gbk","Error!"))[0];
  //数量
  t->VolumeTotalOriginal =   PyLong_AsLong(PyObject_GetAttrString(p, "VolumeTotalOriginal"));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //触发条件
  //enum类型
  //THOST_FTDC_CC_AskPriceLesserThanStopPrice -> 'B', 卖一价小于条件价
  //THOST_FTDC_CC_Touch -> '2', 止损
  //THOST_FTDC_CC_BidPriceGreaterThanStopPrice -> 'D', 买一价大于条件价
  //THOST_FTDC_CC_LastPriceGreaterEqualStopPrice -> '6', 最新价大于等于条件价
  //THOST_FTDC_CC_AskPriceLesserEqualStopPrice -> 'C', 卖一价小于等于条件价
  //THOST_FTDC_CC_LastPriceGreaterThanStopPrice -> '5', 最新价大于条件价
  //THOST_FTDC_CC_AskPriceGreaterEqualStopPrice -> 'A', 卖一价大于等于条件价
  //THOST_FTDC_CC_LastPriceLesserThanStopPrice -> '7', 最新价小于条件价
  //THOST_FTDC_CC_BidPriceGreaterEqualStopPrice -> 'E', 买一价大于等于条件价
  //THOST_FTDC_CC_Immediately -> '1', 立即
  //THOST_FTDC_CC_LastPriceLesserEqualStopPrice -> '8', 最新价小于等于条件价
  //THOST_FTDC_CC_AskPriceGreaterThanStopPrice -> '9', 卖一价大于条件价
  //THOST_FTDC_CC_BidPriceLesserEqualStopPrice -> 'H', 买一价小于等于条件价
  //THOST_FTDC_CC_ParkedOrder -> '4', 预埋单
  //THOST_FTDC_CC_TouchProfit -> '3', 止赢
  //THOST_FTDC_CC_BidPriceLesserThanStopPrice -> 'F', 买一价小于条件价
  t->ContingentCondition =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ContingentCondition"),"gbk","Error!"))[0];
  //用户强评标志
  t->UserForceClose =   PyLong_AsLong(PyObject_GetAttrString(p, "UserForceClose"));
  //止损价
  t->StopPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "StopPrice"));
  //请求编号
  t->RequestID =   PyLong_AsLong(PyObject_GetAttrString(p, "RequestID"));
  //自动挂起标志
  t->IsAutoSuspend =   PyLong_AsLong(PyObject_GetAttrString(p, "IsAutoSuspend"));
  //互换单标志
  t->IsSwapOrder =   PyLong_AsLong(PyObject_GetAttrString(p, "IsSwapOrder"));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //GTD日期
  strcpy(t->GTDDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "GTDDate"),"gbk","Error!")));
  //业务单元
  strcpy(t->BusinessUnit, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BusinessUnit"),"gbk","Error!")));
  //价格
  t->LimitPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LimitPrice"));
  //报单引用
  strcpy(t->OrderRef, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderRef"),"gbk","Error!")));
  //组合投机套保标志
  strcpy(t->CombHedgeFlag, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CombHedgeFlag"),"gbk","Error!")));
  //成交量类型
  //enum类型
  //THOST_FTDC_VC_CV -> '3', 全部数量
  //THOST_FTDC_VC_MV -> '2', 最小数量
  //THOST_FTDC_VC_AV -> '1', 任何数量
  t->VolumeCondition =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "VolumeCondition"),"gbk","Error!"))[0];
  //组合开平标志
  strcpy(t->CombOffsetFlag, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CombOffsetFlag"),"gbk","Error!")));
  //有效期类型
  //enum类型
  //THOST_FTDC_TC_IOC -> '1', 立即完成，否则撤销
  //THOST_FTDC_TC_GFS -> '2', 本节有效
  //THOST_FTDC_TC_GTD -> '4', 指定日期前有效
  //THOST_FTDC_TC_GFA -> '6', 集合竞价有效
  //THOST_FTDC_TC_GTC -> '5', 撤销前有效
  //THOST_FTDC_TC_GFD -> '3', 当日有效
  t->TimeCondition =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TimeCondition"),"gbk","Error!"))[0];

  return t;
};

//查询银行资金请求，TradeCode=204002
PyObject * new_CThostFtdcTransferQryBankReqField(CThostFtdcTransferQryBankReqField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcTransferQryBankReqField", (char*)"yyyc",
p->CurrencyCode, p->FutureAccount, p->FutureAccPwd, p->FuturePwdFlag);
}
CThostFtdcTransferQryBankReqField * from_CThostFtdcTransferQryBankReqField(PyObject * p){
  CThostFtdcTransferQryBankReqField *t = (CThostFtdcTransferQryBankReqField *)calloc(1, sizeof(CThostFtdcTransferQryBankReqField));
  memset(t,0,sizeof(CThostFtdcTransferQryBankReqField));
  //币种：RMB-人民币 USD-美圆 HKD-港元
  strcpy(t->CurrencyCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrencyCode"),"gbk","Error!")));
  //期货资金账户
  strcpy(t->FutureAccount, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "FutureAccount"),"gbk","Error!")));
  //密码
  strcpy(t->FutureAccPwd, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "FutureAccPwd"),"gbk","Error!")));
  //密码标志
  //enum类型
  //THOST_FTDC_FPWD_Check -> '1', 核对
  //THOST_FTDC_FPWD_UnCheck -> '0', 不核对
  t->FuturePwdFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "FuturePwdFlag"),"gbk","Error!"))[0];

  return t;
};

//查询报单
PyObject * new_CThostFtdcQryOrderField(CThostFtdcQryOrderField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryOrderField", (char*)"yyyyyyy",
p->OrderSysID, p->InstrumentID, p->InsertTimeEnd, p->BrokerID, p->InvestorID, p->ExchangeID, p->InsertTimeStart);
}
CThostFtdcQryOrderField * from_CThostFtdcQryOrderField(PyObject * p){
  CThostFtdcQryOrderField *t = (CThostFtdcQryOrderField *)calloc(1, sizeof(CThostFtdcQryOrderField));
  memset(t,0,sizeof(CThostFtdcQryOrderField));
  //报单编号
  strcpy(t->OrderSysID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderSysID"),"gbk","Error!")));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //结束时间
  strcpy(t->InsertTimeEnd, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InsertTimeEnd"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //开始时间
  strcpy(t->InsertTimeStart, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InsertTimeStart"),"gbk","Error!")));

  return t;
};

//行情申买四、五属性
PyObject * new_CThostFtdcMarketDataBid45Field(CThostFtdcMarketDataBid45Field * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcMarketDataBid45Field", (char*)"ddii",
p->BidPrice5, p->BidPrice4, p->BidVolume5, p->BidVolume4);
}
CThostFtdcMarketDataBid45Field * from_CThostFtdcMarketDataBid45Field(PyObject * p){
  CThostFtdcMarketDataBid45Field *t = (CThostFtdcMarketDataBid45Field *)calloc(1, sizeof(CThostFtdcMarketDataBid45Field));
  memset(t,0,sizeof(CThostFtdcMarketDataBid45Field));
  //申买价五
  t->BidPrice5 =   PyFloat_AsDouble(PyObject_GetAttrString(p, "BidPrice5"));
  //申买价四
  t->BidPrice4 =   PyFloat_AsDouble(PyObject_GetAttrString(p, "BidPrice4"));
  //申买量五
  t->BidVolume5 =   PyLong_AsLong(PyObject_GetAttrString(p, "BidVolume5"));
  //申买量四
  t->BidVolume4 =   PyLong_AsLong(PyObject_GetAttrString(p, "BidVolume4"));

  return t;
};

//冲正请求
PyObject * new_CThostFtdcReqRepealField(CThostFtdcReqRepealField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcReqRepealField", (char*)"yyyiycidyccyyciydyyydyyyyyiicdyiiccyciycyicyycyyci",
p->TradingDay, p->DeviceID, p->BrokerID, p->SessionID, p->IdentifiedCardNo, p->IdCardType, p->FutureRepealSerial, p->FutureFetchAmount, p->BankID, p->BankPwdFlag, p->BankRepealFlag, p->BankAccount, p->BankSecuAcc, p->LastFragment, p->PlateRepealSerial, p->TradeDate, p->CustFee, p->AccountID, p->BankSerial, p->OperNo, p->BrokerFee, p->CustomerName, p->BankPassWord, p->Message, p->BankBranchID, p->Digest, p->PlateSerial, p->RepealedTimes, p->TransferStatus, p->TradeAmount, p->TradeTime, p->FutureSerial, p->InstallID, p->SecuPwdFlag, p->BrokerRepealFlag, p->BankRepealSerial, p->VerifyCertNoFlag, p->RepealTimeInterval, p->CurrencyID, p->BankSecuAccType, p->Password, p->RequestID, p->BankAccType, p->BrokerBranchID, p->UserID, p->CustType, p->BrokerIDByBank, p->TradeCode, p->FeePayFlag, p->TID);
}
CThostFtdcReqRepealField * from_CThostFtdcReqRepealField(PyObject * p){
  CThostFtdcReqRepealField *t = (CThostFtdcReqRepealField *)calloc(1, sizeof(CThostFtdcReqRepealField));
  memset(t,0,sizeof(CThostFtdcReqRepealField));
  //交易系统日期
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //渠道标志
  strcpy(t->DeviceID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "DeviceID"),"gbk","Error!")));
  //期商代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //会话号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //证件号码
  strcpy(t->IdentifiedCardNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdentifiedCardNo"),"gbk","Error!")));
  //证件类型
  //enum类型
  //THOST_FTDC_ICT_TaiwanCompatriotIDCard -> '7', 台胞证
  //THOST_FTDC_ICT_Passport -> '6', 护照
  //THOST_FTDC_ICT_LicenseNo -> '9', 营业执照号
  //THOST_FTDC_ICT_OtherCard -> 'x', 其他证件
  //THOST_FTDC_ICT_IDCard -> '1', 身份证
  //THOST_FTDC_ICT_EID -> '0', 组织机构代码
  //THOST_FTDC_ICT_TaxNo -> 'A', 税务登记号
  //THOST_FTDC_ICT_HomeComingCard -> '8', 回乡证
  //THOST_FTDC_ICT_OfficerIDCard -> '2', 军官证
  //THOST_FTDC_ICT_HouseholdRegister -> '5', 户口簿
  //THOST_FTDC_ICT_SoldierIDCard -> '4', 士兵证
  //THOST_FTDC_ICT_PoliceIDCard -> '3', 警官证
  t->IdCardType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdCardType"),"gbk","Error!"))[0];
  //被冲正期货流水号
  t->FutureRepealSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "FutureRepealSerial"));
  //期货可取金额
  t->FutureFetchAmount =   PyFloat_AsDouble(PyObject_GetAttrString(p, "FutureFetchAmount"));
  //银行代码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //银行密码标志
  //enum类型
  //THOST_FTDC_BPWDF_NoCheck -> '0', 不核对
  //THOST_FTDC_BPWDF_BlankCheck -> '1', 明文核对
  //THOST_FTDC_BPWDF_EncryptCheck -> '2', 密文核对
  t->BankPwdFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankPwdFlag"),"gbk","Error!"))[0];
  //银行冲正标志
  //enum类型
  //THOST_FTDC_BRF_BankNotNeedRepeal -> '0', 银行无需自动冲正
  //THOST_FTDC_BRF_BankBeenRepealed -> '2', 银行已自动冲正
  //THOST_FTDC_BRF_BankWaitingRepeal -> '1', 银行待自动冲正
  t->BankRepealFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankRepealFlag"),"gbk","Error!"))[0];
  //银行帐号
  strcpy(t->BankAccount, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccount"),"gbk","Error!")));
  //期货单位帐号
  strcpy(t->BankSecuAcc, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSecuAcc"),"gbk","Error!")));
  //最后分片标志
  //enum类型
  //THOST_FTDC_LF_No -> '1', 不是最后分片
  //THOST_FTDC_LF_Yes -> '0', 是最后分片
  t->LastFragment =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LastFragment"),"gbk","Error!"))[0];
  //被冲正平台流水号
  t->PlateRepealSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "PlateRepealSerial"));
  //交易日期
  strcpy(t->TradeDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeDate"),"gbk","Error!")));
  //应收客户费用
  t->CustFee =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CustFee"));
  //投资者帐号
  strcpy(t->AccountID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AccountID"),"gbk","Error!")));
  //银行流水号
  strcpy(t->BankSerial, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSerial"),"gbk","Error!")));
  //交易柜员
  strcpy(t->OperNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OperNo"),"gbk","Error!")));
  //应收期货公司费用
  t->BrokerFee =   PyFloat_AsDouble(PyObject_GetAttrString(p, "BrokerFee"));
  //客户姓名
  strcpy(t->CustomerName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustomerName"),"gbk","Error!")));
  //银行密码
  strcpy(t->BankPassWord, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankPassWord"),"gbk","Error!")));
  //发送方给接收方的消息
  strcpy(t->Message, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Message"),"gbk","Error!")));
  //银行分支机构代码
  strcpy(t->BankBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBranchID"),"gbk","Error!")));
  //摘要
  strcpy(t->Digest, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Digest"),"gbk","Error!")));
  //银期平台消息流水号
  t->PlateSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "PlateSerial"));
  //已经冲正次数
  t->RepealedTimes =   PyLong_AsLong(PyObject_GetAttrString(p, "RepealedTimes"));
  //转账交易状态
  //enum类型
  //THOST_FTDC_TRFS_Normal -> '0', 正常
  //THOST_FTDC_TRFS_Repealed -> '1', 被冲正
  t->TransferStatus =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TransferStatus"),"gbk","Error!"))[0];
  //转帐金额
  t->TradeAmount =   PyFloat_AsDouble(PyObject_GetAttrString(p, "TradeAmount"));
  //交易时间
  strcpy(t->TradeTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeTime"),"gbk","Error!")));
  //期货公司流水号
  t->FutureSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "FutureSerial"));
  //安装编号
  t->InstallID =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallID"));
  //期货资金密码核对标志
  //enum类型
  //THOST_FTDC_BPWDF_NoCheck -> '0', 不核对
  //THOST_FTDC_BPWDF_BlankCheck -> '1', 明文核对
  //THOST_FTDC_BPWDF_EncryptCheck -> '2', 密文核对
  t->SecuPwdFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "SecuPwdFlag"),"gbk","Error!"))[0];
  //期商冲正标志
  //enum类型
  //THOST_FTDC_BRORF_BrokerBeenRepealed -> '2', 期商已自动冲正
  //THOST_FTDC_BRORF_BrokerWaitingRepeal -> '1', 期商待自动冲正
  //THOST_FTDC_BRORF_BrokerNotNeedRepeal -> '0', 期商无需自动冲正
  t->BrokerRepealFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerRepealFlag"),"gbk","Error!"))[0];
  //被冲正银行流水号
  strcpy(t->BankRepealSerial, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankRepealSerial"),"gbk","Error!")));
  //验证客户证件号码标志
  //enum类型
  //THOST_FTDC_YNI_No -> '1', 否
  //THOST_FTDC_YNI_Yes -> '0', 是
  t->VerifyCertNoFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "VerifyCertNoFlag"),"gbk","Error!"))[0];
  //冲正时间间隔
  t->RepealTimeInterval =   PyLong_AsLong(PyObject_GetAttrString(p, "RepealTimeInterval"));
  //币种代码
  strcpy(t->CurrencyID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrencyID"),"gbk","Error!")));
  //期货单位帐号类型
  //enum类型
  //THOST_FTDC_BAT_SavingCard -> '2', 储蓄卡
  //THOST_FTDC_BAT_CreditCard -> '3', 信用卡
  //THOST_FTDC_BAT_BankBook -> '1', 银行存折
  t->BankSecuAccType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSecuAccType"),"gbk","Error!"))[0];
  //期货密码
  strcpy(t->Password, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Password"),"gbk","Error!")));
  //请求编号
  t->RequestID =   PyLong_AsLong(PyObject_GetAttrString(p, "RequestID"));
  //银行帐号类型
  //enum类型
  //THOST_FTDC_BAT_SavingCard -> '2', 储蓄卡
  //THOST_FTDC_BAT_CreditCard -> '3', 信用卡
  //THOST_FTDC_BAT_BankBook -> '1', 银行存折
  t->BankAccType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccType"),"gbk","Error!"))[0];
  //期商分支机构代码
  strcpy(t->BrokerBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerBranchID"),"gbk","Error!")));
  //用户标识
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //客户类型
  //enum类型
  //THOST_FTDC_CUSTT_Person -> '0', 自然人
  //THOST_FTDC_CUSTT_Institution -> '1', 机构户
  t->CustType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustType"),"gbk","Error!"))[0];
  //期货公司银行编码
  strcpy(t->BrokerIDByBank, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerIDByBank"),"gbk","Error!")));
  //业务功能码
  strcpy(t->TradeCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeCode"),"gbk","Error!")));
  //费用支付标志
  //enum类型
  //THOST_FTDC_FPF_SHA -> '2', 由发送方支付发起的费用，受益方支付接受的费用
  //THOST_FTDC_FPF_BEN -> '0', 由受益方支付费用
  //THOST_FTDC_FPF_OUR -> '1', 由发送方支付费用
  t->FeePayFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "FeePayFlag"),"gbk","Error!"))[0];
  //交易ID
  t->TID =   PyLong_AsLong(PyObject_GetAttrString(p, "TID"));

  return t;
};

//客户开销户信息表
PyObject * new_CThostFtdcAccountregisterField(CThostFtdcAccountregisterField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcAccountregisterField", (char*)"ycyccyyiycyyyyyyy",
p->RegDate, p->OpenOrDestroy, p->TradeDay, p->CustType, p->IdCardType, p->IdentifiedCardNo, p->AccountID, p->TID, p->CustomerName, p->BankAccType, p->OutDate, p->BankID, p->CurrencyID, p->BankBranchID, p->BrokerBranchID, p->BrokerID, p->BankAccount);
}
CThostFtdcAccountregisterField * from_CThostFtdcAccountregisterField(PyObject * p){
  CThostFtdcAccountregisterField *t = (CThostFtdcAccountregisterField *)calloc(1, sizeof(CThostFtdcAccountregisterField));
  memset(t,0,sizeof(CThostFtdcAccountregisterField));
  //签约日期
  strcpy(t->RegDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "RegDate"),"gbk","Error!")));
  //开销户类别
  //enum类型
  //THOST_FTDC_OOD_Destroy -> '0', 销户
  //THOST_FTDC_OOD_Open -> '1', 开户
  t->OpenOrDestroy =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OpenOrDestroy"),"gbk","Error!"))[0];
  //交易日期
  strcpy(t->TradeDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeDay"),"gbk","Error!")));
  //客户类型
  //enum类型
  //THOST_FTDC_CUSTT_Person -> '0', 自然人
  //THOST_FTDC_CUSTT_Institution -> '1', 机构户
  t->CustType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustType"),"gbk","Error!"))[0];
  //证件类型
  //enum类型
  //THOST_FTDC_ICT_TaiwanCompatriotIDCard -> '7', 台胞证
  //THOST_FTDC_ICT_Passport -> '6', 护照
  //THOST_FTDC_ICT_LicenseNo -> '9', 营业执照号
  //THOST_FTDC_ICT_OtherCard -> 'x', 其他证件
  //THOST_FTDC_ICT_IDCard -> '1', 身份证
  //THOST_FTDC_ICT_EID -> '0', 组织机构代码
  //THOST_FTDC_ICT_TaxNo -> 'A', 税务登记号
  //THOST_FTDC_ICT_HomeComingCard -> '8', 回乡证
  //THOST_FTDC_ICT_OfficerIDCard -> '2', 军官证
  //THOST_FTDC_ICT_HouseholdRegister -> '5', 户口簿
  //THOST_FTDC_ICT_SoldierIDCard -> '4', 士兵证
  //THOST_FTDC_ICT_PoliceIDCard -> '3', 警官证
  t->IdCardType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdCardType"),"gbk","Error!"))[0];
  //证件号码
  strcpy(t->IdentifiedCardNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdentifiedCardNo"),"gbk","Error!")));
  //投资者帐号
  strcpy(t->AccountID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AccountID"),"gbk","Error!")));
  //交易ID
  t->TID =   PyLong_AsLong(PyObject_GetAttrString(p, "TID"));
  //客户姓名
  strcpy(t->CustomerName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustomerName"),"gbk","Error!")));
  //银行帐号类型
  //enum类型
  //THOST_FTDC_BAT_SavingCard -> '2', 储蓄卡
  //THOST_FTDC_BAT_CreditCard -> '3', 信用卡
  //THOST_FTDC_BAT_BankBook -> '1', 银行存折
  t->BankAccType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccType"),"gbk","Error!"))[0];
  //解约日期
  strcpy(t->OutDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OutDate"),"gbk","Error!")));
  //银行编码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //币种代码
  strcpy(t->CurrencyID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrencyID"),"gbk","Error!")));
  //银行分支机构编码
  strcpy(t->BankBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBranchID"),"gbk","Error!")));
  //期货公司分支机构编码
  strcpy(t->BrokerBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerBranchID"),"gbk","Error!")));
  //期货公司编码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //银行帐号
  strcpy(t->BankAccount, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccount"),"gbk","Error!")));

  return t;
};

//预埋单
PyObject * new_CThostFtdcParkedOrderField(CThostFtdcParkedOrderField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcParkedOrderField", (char*)"ccyyicciyciydiiicyyyiyydyycyc",
p->OrderPriceType, p->Direction, p->BrokerID, p->InvestorID, p->MinVolume, p->Status, p->ForceCloseReason, p->VolumeTotalOriginal, p->InstrumentID, p->ContingentCondition, p->UserForceClose, p->ErrorMsg, p->StopPrice, p->RequestID, p->IsAutoSuspend, p->IsSwapOrder, p->UserType, p->ExchangeID, p->UserID, p->GTDDate, p->ErrorID, p->BusinessUnit, p->ParkedOrderID, p->LimitPrice, p->OrderRef, p->CombHedgeFlag, p->VolumeCondition, p->CombOffsetFlag, p->TimeCondition);
}
CThostFtdcParkedOrderField * from_CThostFtdcParkedOrderField(PyObject * p){
  CThostFtdcParkedOrderField *t = (CThostFtdcParkedOrderField *)calloc(1, sizeof(CThostFtdcParkedOrderField));
  memset(t,0,sizeof(CThostFtdcParkedOrderField));
  //报单价格条件
  //enum类型
  //THOST_FTDC_OPT_LastPricePlusOneTicks -> '5', 最新价浮动上浮1个ticks
  //THOST_FTDC_OPT_LastPricePlusTwoTicks -> '6', 最新价浮动上浮2个ticks
  //THOST_FTDC_OPT_BidPrice1PlusTwoTicks -> 'E', 买一价浮动上浮2个ticks
  //THOST_FTDC_OPT_AnyPrice -> '1', 任意价
  //THOST_FTDC_OPT_AskPrice1PlusTwoTicks -> 'A', 卖一价浮动上浮2个ticks
  //THOST_FTDC_OPT_AskPrice1PlusThreeTicks -> 'B', 卖一价浮动上浮3个ticks
  //THOST_FTDC_OPT_BidPrice1PlusThreeTicks -> 'F', 买一价浮动上浮3个ticks
  //THOST_FTDC_OPT_BestPrice -> '3', 最优价
  //THOST_FTDC_OPT_LimitPrice -> '2', 限价
  //THOST_FTDC_OPT_BidPrice1 -> 'C', 买一价
  //THOST_FTDC_OPT_AskPrice1PlusOneTicks -> '9', 卖一价浮动上浮1个ticks
  //THOST_FTDC_OPT_LastPricePlusThreeTicks -> '7', 最新价浮动上浮3个ticks
  //THOST_FTDC_OPT_LastPrice -> '4', 最新价
  //THOST_FTDC_OPT_AskPrice1 -> '8', 卖一价
  //THOST_FTDC_OPT_BidPrice1PlusOneTicks -> 'D', 买一价浮动上浮1个ticks
  t->OrderPriceType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderPriceType"),"gbk","Error!"))[0];
  //买卖方向
  //enum类型
  //THOST_FTDC_D_Buy -> '0', 买
  //THOST_FTDC_D_Sell -> '1', 卖
  t->Direction =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Direction"),"gbk","Error!"))[0];
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //最小成交量
  t->MinVolume =   PyLong_AsLong(PyObject_GetAttrString(p, "MinVolume"));
  //预埋单状态
  //enum类型
  //THOST_FTDC_PAOS_Deleted -> '3', 已删除
  //THOST_FTDC_PAOS_NotSend -> '1', 未发送
  //THOST_FTDC_PAOS_Send -> '2', 已发送
  t->Status =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Status"),"gbk","Error!"))[0];
  //强平原因
  //enum类型
  //THOST_FTDC_FCC_Other -> '6', 其它
  //THOST_FTDC_FCC_ClientOverPositionLimit -> '2', 客户超仓
  //THOST_FTDC_FCC_NotMultiple -> '4', 持仓非整数倍
  //THOST_FTDC_FCC_PersonDeliv -> '7', 自然人临近交割
  //THOST_FTDC_FCC_NotForceClose -> '0', 非强平
  //THOST_FTDC_FCC_Violation -> '5', 违规
  //THOST_FTDC_FCC_MemberOverPositionLimit -> '3', 会员超仓
  //THOST_FTDC_FCC_LackDeposit -> '1', 资金不足
  t->ForceCloseReason =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ForceCloseReason"),"gbk","Error!"))[0];
  //数量
  t->VolumeTotalOriginal =   PyLong_AsLong(PyObject_GetAttrString(p, "VolumeTotalOriginal"));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //触发条件
  //enum类型
  //THOST_FTDC_CC_AskPriceLesserThanStopPrice -> 'B', 卖一价小于条件价
  //THOST_FTDC_CC_Touch -> '2', 止损
  //THOST_FTDC_CC_BidPriceGreaterThanStopPrice -> 'D', 买一价大于条件价
  //THOST_FTDC_CC_LastPriceGreaterEqualStopPrice -> '6', 最新价大于等于条件价
  //THOST_FTDC_CC_AskPriceLesserEqualStopPrice -> 'C', 卖一价小于等于条件价
  //THOST_FTDC_CC_LastPriceGreaterThanStopPrice -> '5', 最新价大于条件价
  //THOST_FTDC_CC_AskPriceGreaterEqualStopPrice -> 'A', 卖一价大于等于条件价
  //THOST_FTDC_CC_LastPriceLesserThanStopPrice -> '7', 最新价小于条件价
  //THOST_FTDC_CC_BidPriceGreaterEqualStopPrice -> 'E', 买一价大于等于条件价
  //THOST_FTDC_CC_Immediately -> '1', 立即
  //THOST_FTDC_CC_LastPriceLesserEqualStopPrice -> '8', 最新价小于等于条件价
  //THOST_FTDC_CC_AskPriceGreaterThanStopPrice -> '9', 卖一价大于条件价
  //THOST_FTDC_CC_BidPriceLesserEqualStopPrice -> 'H', 买一价小于等于条件价
  //THOST_FTDC_CC_ParkedOrder -> '4', 预埋单
  //THOST_FTDC_CC_TouchProfit -> '3', 止赢
  //THOST_FTDC_CC_BidPriceLesserThanStopPrice -> 'F', 买一价小于条件价
  t->ContingentCondition =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ContingentCondition"),"gbk","Error!"))[0];
  //用户强评标志
  t->UserForceClose =   PyLong_AsLong(PyObject_GetAttrString(p, "UserForceClose"));
  //错误信息
  strcpy(t->ErrorMsg, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ErrorMsg"),"gbk","Error!")));
  //止损价
  t->StopPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "StopPrice"));
  //请求编号
  t->RequestID =   PyLong_AsLong(PyObject_GetAttrString(p, "RequestID"));
  //自动挂起标志
  t->IsAutoSuspend =   PyLong_AsLong(PyObject_GetAttrString(p, "IsAutoSuspend"));
  //互换单标志
  t->IsSwapOrder =   PyLong_AsLong(PyObject_GetAttrString(p, "IsSwapOrder"));
  //用户类型
  //enum类型
  //THOST_FTDC_UT_SuperUser -> '2', 管理员
  //THOST_FTDC_UT_Operator -> '1', 操作员
  //THOST_FTDC_UT_Investor -> '0', 投资者
  t->UserType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserType"),"gbk","Error!"))[0];
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //GTD日期
  strcpy(t->GTDDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "GTDDate"),"gbk","Error!")));
  //错误代码
  t->ErrorID =   PyLong_AsLong(PyObject_GetAttrString(p, "ErrorID"));
  //业务单元
  strcpy(t->BusinessUnit, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BusinessUnit"),"gbk","Error!")));
  //预埋报单编号
  strcpy(t->ParkedOrderID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ParkedOrderID"),"gbk","Error!")));
  //价格
  t->LimitPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LimitPrice"));
  //报单引用
  strcpy(t->OrderRef, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderRef"),"gbk","Error!")));
  //组合投机套保标志
  strcpy(t->CombHedgeFlag, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CombHedgeFlag"),"gbk","Error!")));
  //成交量类型
  //enum类型
  //THOST_FTDC_VC_CV -> '3', 全部数量
  //THOST_FTDC_VC_MV -> '2', 最小数量
  //THOST_FTDC_VC_AV -> '1', 任何数量
  t->VolumeCondition =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "VolumeCondition"),"gbk","Error!"))[0];
  //组合开平标志
  strcpy(t->CombOffsetFlag, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CombOffsetFlag"),"gbk","Error!")));
  //有效期类型
  //enum类型
  //THOST_FTDC_TC_IOC -> '1', 立即完成，否则撤销
  //THOST_FTDC_TC_GFS -> '2', 本节有效
  //THOST_FTDC_TC_GTD -> '4', 指定日期前有效
  //THOST_FTDC_TC_GFA -> '6', 集合竞价有效
  //THOST_FTDC_TC_GTC -> '5', 撤销前有效
  //THOST_FTDC_TC_GFD -> '3', 当日有效
  t->TimeCondition =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TimeCondition"),"gbk","Error!"))[0];

  return t;
};

//联系人
PyObject * new_CThostFtdcLinkManField(CThostFtdcLinkManField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcLinkManField", (char*)"yyyiyycycy",
p->PersonName, p->InvestorID, p->Address, p->Priority, p->Telephone, p->BrokerID, p->PersonType, p->ZipCode, p->IdentifiedCardType, p->IdentifiedCardNo);
}
CThostFtdcLinkManField * from_CThostFtdcLinkManField(PyObject * p){
  CThostFtdcLinkManField *t = (CThostFtdcLinkManField *)calloc(1, sizeof(CThostFtdcLinkManField));
  memset(t,0,sizeof(CThostFtdcLinkManField));
  //名称
  strcpy(t->PersonName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "PersonName"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //通讯地址
  strcpy(t->Address, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Address"),"gbk","Error!")));
  //优先级
  t->Priority =   PyLong_AsLong(PyObject_GetAttrString(p, "Priority"));
  //联系电话
  strcpy(t->Telephone, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Telephone"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //联系人类型
  //enum类型
  //THOST_FTDC_PST_TrusteeContact -> 'C', 托（保）管机构联系人
  //THOST_FTDC_PST_Settlement -> '4', 结算单确认人
  //THOST_FTDC_PST_Company -> '5', 法人
  //THOST_FTDC_PST_Trustee -> '9', 托（保）管人
  //THOST_FTDC_PST_Open -> '2', 开户授权人
  //THOST_FTDC_PST_Order -> '1', 指定下单人
  //THOST_FTDC_PST_TrusteeOpen -> 'B', 托（保）管机构开户授权人
  //THOST_FTDC_PST_Fund -> '3', 资金调拨人
  //THOST_FTDC_PST_Corporation -> '6', 法人代表
  //THOST_FTDC_PST_Ledger -> '8', 分户管理资产负责人
  //THOST_FTDC_PST_TrusteeCorporation -> 'A', 托（保）管机构法人代表
  //THOST_FTDC_PST_LinkMan -> '7', 投资者联系人
  t->PersonType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "PersonType"),"gbk","Error!"))[0];
  //邮政编码
  strcpy(t->ZipCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ZipCode"),"gbk","Error!")));
  //证件类型
  //enum类型
  //THOST_FTDC_ICT_TaiwanCompatriotIDCard -> '7', 台胞证
  //THOST_FTDC_ICT_Passport -> '6', 护照
  //THOST_FTDC_ICT_LicenseNo -> '9', 营业执照号
  //THOST_FTDC_ICT_OtherCard -> 'x', 其他证件
  //THOST_FTDC_ICT_IDCard -> '1', 身份证
  //THOST_FTDC_ICT_EID -> '0', 组织机构代码
  //THOST_FTDC_ICT_TaxNo -> 'A', 税务登记号
  //THOST_FTDC_ICT_HomeComingCard -> '8', 回乡证
  //THOST_FTDC_ICT_OfficerIDCard -> '2', 军官证
  //THOST_FTDC_ICT_HouseholdRegister -> '5', 户口簿
  //THOST_FTDC_ICT_SoldierIDCard -> '4', 士兵证
  //THOST_FTDC_ICT_PoliceIDCard -> '3', 警官证
  t->IdentifiedCardType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdentifiedCardType"),"gbk","Error!"))[0];
  //证件号码
  strcpy(t->IdentifiedCardNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdentifiedCardNo"),"gbk","Error!")));

  return t;
};

//删除预埋撤单
PyObject * new_CThostFtdcRemoveParkedOrderActionField(CThostFtdcRemoveParkedOrderActionField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcRemoveParkedOrderActionField", (char*)"yyy",
p->ParkedOrderActionID, p->BrokerID, p->InvestorID);
}
CThostFtdcRemoveParkedOrderActionField * from_CThostFtdcRemoveParkedOrderActionField(PyObject * p){
  CThostFtdcRemoveParkedOrderActionField *t = (CThostFtdcRemoveParkedOrderActionField *)calloc(1, sizeof(CThostFtdcRemoveParkedOrderActionField));
  memset(t,0,sizeof(CThostFtdcRemoveParkedOrderActionField));
  //预埋撤单编号
  strcpy(t->ParkedOrderActionID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ParkedOrderActionID"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));

  return t;
};

//成交
PyObject * new_CThostFtdcTradeField(CThostFtdcTradeField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcTradeField", (char*)"cyycyyyyccycdyyyiiiyyyyyicyycy",
p->TradeSource, p->InvestorID, p->TradeID, p->PriceSource, p->TradeTime, p->ClientID, p->ClearingPartID, p->BrokerID, p->OffsetFlag, p->TradeType, p->TraderID, p->TradingRole, p->Price, p->OrderLocalID, p->ExchangeInstID, p->OrderSysID, p->BrokerOrderSeq, p->SequenceNo, p->Volume, p->TradeDate, p->UserID, p->TradingDay, p->InstrumentID, p->ParticipantID, p->SettlementID, p->Direction, p->BusinessUnit, p->OrderRef, p->HedgeFlag, p->ExchangeID);
}
CThostFtdcTradeField * from_CThostFtdcTradeField(PyObject * p){
  CThostFtdcTradeField *t = (CThostFtdcTradeField *)calloc(1, sizeof(CThostFtdcTradeField));
  memset(t,0,sizeof(CThostFtdcTradeField));
  //成交来源
  //enum类型
  //THOST_FTDC_TSRC_NORMAL -> '0', 来自交易所普通回报
  //THOST_FTDC_TSRC_QUERY -> '1', 来自查询
  t->TradeSource =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeSource"),"gbk","Error!"))[0];
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //成交编号
  strcpy(t->TradeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeID"),"gbk","Error!")));
  //成交价来源
  //enum类型
  //THOST_FTDC_PSRC_LastPrice -> '0', 前成交价
  //THOST_FTDC_PSRC_Buy -> '1', 买委托价
  //THOST_FTDC_PSRC_Sell -> '2', 卖委托价
  t->PriceSource =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "PriceSource"),"gbk","Error!"))[0];
  //成交时间
  strcpy(t->TradeTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeTime"),"gbk","Error!")));
  //客户代码
  strcpy(t->ClientID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ClientID"),"gbk","Error!")));
  //结算会员编号
  strcpy(t->ClearingPartID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ClearingPartID"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //开平标志
  //enum类型
  //THOST_FTDC_OF_Close -> '1', 平仓
  //THOST_FTDC_OF_CloseYesterday -> '4', 平昨
  //THOST_FTDC_OF_CloseToday -> '3', 平今
  //THOST_FTDC_OF_Open -> '0', 开仓
  //THOST_FTDC_OF_LocalForceClose -> '6', 本地强平
  //THOST_FTDC_OF_ForceClose -> '2', 强平
  //THOST_FTDC_OF_ForceOff -> '5', 强减
  t->OffsetFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OffsetFlag"),"gbk","Error!"))[0];
  //成交类型
  //enum类型
  //THOST_FTDC_TRDT_OptionsExecution -> '1', 期权执行
  //THOST_FTDC_TRDT_Common -> '0', 普通成交
  //THOST_FTDC_TRDT_CombinationDerived -> '4', 组合衍生成交
  //THOST_FTDC_TRDT_OTC -> '2', OTC成交
  //THOST_FTDC_TRDT_EFPDerived -> '3', 期转现衍生成交
  t->TradeType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeType"),"gbk","Error!"))[0];
  //交易所交易员代码
  strcpy(t->TraderID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TraderID"),"gbk","Error!")));
  //交易角色
  //enum类型
  //THOST_FTDC_ER_Broker -> '1', 代理
  //THOST_FTDC_ER_Maker -> '3', 做市商
  //THOST_FTDC_ER_Host -> '2', 自营
  t->TradingRole =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingRole"),"gbk","Error!"))[0];
  //价格
  t->Price =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Price"));
  //本地报单编号
  strcpy(t->OrderLocalID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderLocalID"),"gbk","Error!")));
  //合约在交易所的代码
  strcpy(t->ExchangeInstID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeInstID"),"gbk","Error!")));
  //报单编号
  strcpy(t->OrderSysID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderSysID"),"gbk","Error!")));
  //经纪公司报单编号
  t->BrokerOrderSeq =   PyLong_AsLong(PyObject_GetAttrString(p, "BrokerOrderSeq"));
  //序号
  t->SequenceNo =   PyLong_AsLong(PyObject_GetAttrString(p, "SequenceNo"));
  //数量
  t->Volume =   PyLong_AsLong(PyObject_GetAttrString(p, "Volume"));
  //成交时期
  strcpy(t->TradeDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeDate"),"gbk","Error!")));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //交易日
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //会员代码
  strcpy(t->ParticipantID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ParticipantID"),"gbk","Error!")));
  //结算编号
  t->SettlementID =   PyLong_AsLong(PyObject_GetAttrString(p, "SettlementID"));
  //买卖方向
  //enum类型
  //THOST_FTDC_D_Buy -> '0', 买
  //THOST_FTDC_D_Sell -> '1', 卖
  t->Direction =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Direction"),"gbk","Error!"))[0];
  //业务单元
  strcpy(t->BusinessUnit, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BusinessUnit"),"gbk","Error!")));
  //报单引用
  strcpy(t->OrderRef, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderRef"),"gbk","Error!")));
  //投机套保标志
  //enum类型
  //THOST_FTDC_HF_Hedge -> '3', 套保
  //THOST_FTDC_HF_Arbitrage -> '2', 套利
  //THOST_FTDC_HF_Speculation -> '1', 投机
  t->HedgeFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "HedgeFlag"),"gbk","Error!"))[0];
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));

  return t;
};

//期商签退请求
PyObject * new_CThostFtdcReqFutureSignOutField(CThostFtdcReqFutureSignOutField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcReqFutureSignOutField", (char*)"ciyyyyyyiyyyyiiyyyyiy",
p->LastFragment, p->RequestID, p->UserID, p->TradeTime, p->DeviceID, p->TradeDate, p->BrokerID, p->TradingDay, p->SessionID, p->BankSerial, p->OperNo, p->BrokerIDByBank, p->TradeCode, p->InstallID, p->TID, p->BankID, p->CurrencyID, p->BankBranchID, p->BrokerBranchID, p->PlateSerial, p->Digest);
}
CThostFtdcReqFutureSignOutField * from_CThostFtdcReqFutureSignOutField(PyObject * p){
  CThostFtdcReqFutureSignOutField *t = (CThostFtdcReqFutureSignOutField *)calloc(1, sizeof(CThostFtdcReqFutureSignOutField));
  memset(t,0,sizeof(CThostFtdcReqFutureSignOutField));
  //最后分片标志
  //enum类型
  //THOST_FTDC_LF_No -> '1', 不是最后分片
  //THOST_FTDC_LF_Yes -> '0', 是最后分片
  t->LastFragment =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LastFragment"),"gbk","Error!"))[0];
  //请求编号
  t->RequestID =   PyLong_AsLong(PyObject_GetAttrString(p, "RequestID"));
  //用户标识
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //交易时间
  strcpy(t->TradeTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeTime"),"gbk","Error!")));
  //渠道标志
  strcpy(t->DeviceID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "DeviceID"),"gbk","Error!")));
  //交易日期
  strcpy(t->TradeDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeDate"),"gbk","Error!")));
  //期商代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //交易系统日期
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //会话号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //银行流水号
  strcpy(t->BankSerial, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSerial"),"gbk","Error!")));
  //交易柜员
  strcpy(t->OperNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OperNo"),"gbk","Error!")));
  //期货公司银行编码
  strcpy(t->BrokerIDByBank, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerIDByBank"),"gbk","Error!")));
  //业务功能码
  strcpy(t->TradeCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeCode"),"gbk","Error!")));
  //安装编号
  t->InstallID =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallID"));
  //交易ID
  t->TID =   PyLong_AsLong(PyObject_GetAttrString(p, "TID"));
  //银行代码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //币种代码
  strcpy(t->CurrencyID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrencyID"),"gbk","Error!")));
  //银行分支机构代码
  strcpy(t->BankBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBranchID"),"gbk","Error!")));
  //期商分支机构代码
  strcpy(t->BrokerBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerBranchID"),"gbk","Error!")));
  //银期平台消息流水号
  t->PlateSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "PlateSerial"));
  //摘要
  strcpy(t->Digest, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Digest"),"gbk","Error!")));

  return t;
};

//禁止登录用户
PyObject * new_CThostFtdcLoginForbiddenUserField(CThostFtdcLoginForbiddenUserField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcLoginForbiddenUserField", (char*)"yy",
p->BrokerID, p->UserID);
}
CThostFtdcLoginForbiddenUserField * from_CThostFtdcLoginForbiddenUserField(PyObject * p){
  CThostFtdcLoginForbiddenUserField *t = (CThostFtdcLoginForbiddenUserField *)calloc(1, sizeof(CThostFtdcLoginForbiddenUserField));
  memset(t,0,sizeof(CThostFtdcLoginForbiddenUserField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));

  return t;
};

//银行资金转期货请求响应
PyObject * new_CThostFtdcTransferBankToFutureRspField(CThostFtdcTransferBankToFutureRspField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcTransferBankToFutureRspField", (char*)"yyyddy",
p->FutureAccount, p->RetCode, p->RetInfo, p->TradeAmt, p->CustFee, p->CurrencyCode);
}
CThostFtdcTransferBankToFutureRspField * from_CThostFtdcTransferBankToFutureRspField(PyObject * p){
  CThostFtdcTransferBankToFutureRspField *t = (CThostFtdcTransferBankToFutureRspField *)calloc(1, sizeof(CThostFtdcTransferBankToFutureRspField));
  memset(t,0,sizeof(CThostFtdcTransferBankToFutureRspField));
  //资金账户
  strcpy(t->FutureAccount, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "FutureAccount"),"gbk","Error!")));
  //响应代码
  strcpy(t->RetCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "RetCode"),"gbk","Error!")));
  //响应信息
  strcpy(t->RetInfo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "RetInfo"),"gbk","Error!")));
  //转帐金额
  t->TradeAmt =   PyFloat_AsDouble(PyObject_GetAttrString(p, "TradeAmt"));
  //应收客户手续费
  t->CustFee =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CustFee"));
  //币种
  strcpy(t->CurrencyCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrencyCode"),"gbk","Error!")));

  return t;
};

//用户登录请求
PyObject * new_CThostFtdcReqUserLoginField(CThostFtdcReqUserLoginField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcReqUserLoginField", (char*)"yyyyyyyyyy",
p->Password, p->UserProductInfo, p->InterfaceProductInfo, p->ClientIPAddress, p->MacAddress, p->BrokerID, p->TradingDay, p->UserID, p->ProtocolInfo, p->OneTimePassword);
}
CThostFtdcReqUserLoginField * from_CThostFtdcReqUserLoginField(PyObject * p){
  CThostFtdcReqUserLoginField *t = (CThostFtdcReqUserLoginField *)calloc(1, sizeof(CThostFtdcReqUserLoginField));
  memset(t,0,sizeof(CThostFtdcReqUserLoginField));
  //密码
  strcpy(t->Password, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Password"),"gbk","Error!")));
  //用户端产品信息
  strcpy(t->UserProductInfo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserProductInfo"),"gbk","Error!")));
  //接口端产品信息
  strcpy(t->InterfaceProductInfo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InterfaceProductInfo"),"gbk","Error!")));
  //终端IP地址
  strcpy(t->ClientIPAddress, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ClientIPAddress"),"gbk","Error!")));
  //Mac地址
  strcpy(t->MacAddress, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "MacAddress"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //交易日
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //协议信息
  strcpy(t->ProtocolInfo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ProtocolInfo"),"gbk","Error!")));
  //动态密码
  strcpy(t->OneTimePassword, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OneTimePassword"),"gbk","Error!")));

  return t;
};

//返回结果
PyObject * new_CThostFtdcReturnResultField(CThostFtdcReturnResultField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcReturnResultField", (char*)"yy",
p->DescrInfoForReturnCode, p->ReturnCode);
}
CThostFtdcReturnResultField * from_CThostFtdcReturnResultField(PyObject * p){
  CThostFtdcReturnResultField *t = (CThostFtdcReturnResultField *)calloc(1, sizeof(CThostFtdcReturnResultField));
  memset(t,0,sizeof(CThostFtdcReturnResultField));
  //返回码描述
  strcpy(t->DescrInfoForReturnCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "DescrInfoForReturnCode"),"gbk","Error!")));
  //返回代码
  strcpy(t->ReturnCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ReturnCode"),"gbk","Error!")));

  return t;
};

//经纪公司交易参数
PyObject * new_CThostFtdcBrokerTradingParamsField(CThostFtdcBrokerTradingParamsField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcBrokerTradingParamsField", (char*)"ccyyc",
p->MarginPriceType, p->Algorithm, p->BrokerID, p->InvestorID, p->AvailIncludeCloseProfit);
}
CThostFtdcBrokerTradingParamsField * from_CThostFtdcBrokerTradingParamsField(PyObject * p){
  CThostFtdcBrokerTradingParamsField *t = (CThostFtdcBrokerTradingParamsField *)calloc(1, sizeof(CThostFtdcBrokerTradingParamsField));
  memset(t,0,sizeof(CThostFtdcBrokerTradingParamsField));
  //保证金价格类型
  //enum类型
  //THOST_FTDC_MPT_OpenPrice -> '4', 开仓价
  //THOST_FTDC_MPT_PreSettlementPrice -> '1', 昨结算价
  //THOST_FTDC_MPT_AveragePrice -> '3', 成交均价
  //THOST_FTDC_MPT_SettlementPrice -> '2', 最新价
  t->MarginPriceType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "MarginPriceType"),"gbk","Error!"))[0];
  //盈亏算法
  //enum类型
  //THOST_FTDC_AG_None -> '4', 浮盈浮亏都不计算
  //THOST_FTDC_AG_OnlyLost -> '2', 浮盈不计，浮亏计
  //THOST_FTDC_AG_All -> '1', 浮盈浮亏都计算
  //THOST_FTDC_AG_OnlyGain -> '3', 浮盈计，浮亏不计
  t->Algorithm =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Algorithm"),"gbk","Error!"))[0];
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //可用是否包含平仓盈利
  //enum类型
  //THOST_FTDC_ICP_NotInclude -> '2', 不包含平仓盈利
  //THOST_FTDC_ICP_Include -> '0', 包含平仓盈利
  t->AvailIncludeCloseProfit =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AvailIncludeCloseProfit"),"gbk","Error!"))[0];

  return t;
};

//产品
PyObject * new_CThostFtdcProductField(CThostFtdcProductField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcProductField", (char*)"iicciyidccyyi",
p->MaxMarketOrderVolume, p->MinLimitOrderVolume, p->CloseDealType, p->PositionType, p->MinMarketOrderVolume, p->ProductName, p->VolumeMultiple, p->PriceTick, p->PositionDateType, p->ProductClass, p->ProductID, p->ExchangeID, p->MaxLimitOrderVolume);
}
CThostFtdcProductField * from_CThostFtdcProductField(PyObject * p){
  CThostFtdcProductField *t = (CThostFtdcProductField *)calloc(1, sizeof(CThostFtdcProductField));
  memset(t,0,sizeof(CThostFtdcProductField));
  //市价单最大下单量
  t->MaxMarketOrderVolume =   PyLong_AsLong(PyObject_GetAttrString(p, "MaxMarketOrderVolume"));
  //限价单最小下单量
  t->MinLimitOrderVolume =   PyLong_AsLong(PyObject_GetAttrString(p, "MinLimitOrderVolume"));
  //平仓处理类型
  //enum类型
  //THOST_FTDC_CDT_Normal -> '0', 正常
  //THOST_FTDC_CDT_SpecFirst -> '1', 投机平仓优先
  t->CloseDealType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CloseDealType"),"gbk","Error!"))[0];
  //持仓类型
  //enum类型
  //THOST_FTDC_PT_Net -> '1', 净持仓
  //THOST_FTDC_PT_Gross -> '2', 综合持仓
  t->PositionType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "PositionType"),"gbk","Error!"))[0];
  //市价单最小下单量
  t->MinMarketOrderVolume =   PyLong_AsLong(PyObject_GetAttrString(p, "MinMarketOrderVolume"));
  //产品名称
  strcpy(t->ProductName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ProductName"),"gbk","Error!")));
  //合约数量乘数
  t->VolumeMultiple =   PyLong_AsLong(PyObject_GetAttrString(p, "VolumeMultiple"));
  //最小变动价位
  t->PriceTick =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PriceTick"));
  //持仓日期类型
  //enum类型
  //THOST_FTDC_PDT_NoUseHistory -> '2', 不使用历史持仓
  //THOST_FTDC_PDT_UseHistory -> '1', 使用历史持仓
  t->PositionDateType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "PositionDateType"),"gbk","Error!"))[0];
  //产品类型
  //enum类型
  //THOST_FTDC_PC_Options -> '2', 期权
  //THOST_FTDC_PC_Futures -> '1', 期货
  //THOST_FTDC_PC_Spot -> '4', 即期
  //THOST_FTDC_PC_EFP -> '5', 期转现
  //THOST_FTDC_PC_Combination -> '3', 组合
  t->ProductClass =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ProductClass"),"gbk","Error!"))[0];
  //产品代码
  strcpy(t->ProductID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ProductID"),"gbk","Error!")));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //限价单最大下单量
  t->MaxLimitOrderVolume =   PyLong_AsLong(PyObject_GetAttrString(p, "MaxLimitOrderVolume"));

  return t;
};

//用户IP
PyObject * new_CThostFtdcUserIPField(CThostFtdcUserIPField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcUserIPField", (char*)"yyyyy",
p->BrokerID, p->MacAddress, p->UserID, p->IPAddress, p->IPMask);
}
CThostFtdcUserIPField * from_CThostFtdcUserIPField(PyObject * p){
  CThostFtdcUserIPField *t = (CThostFtdcUserIPField *)calloc(1, sizeof(CThostFtdcUserIPField));
  memset(t,0,sizeof(CThostFtdcUserIPField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //Mac地址
  strcpy(t->MacAddress, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "MacAddress"),"gbk","Error!")));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //IP地址
  strcpy(t->IPAddress, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IPAddress"),"gbk","Error!")));
  //IP地址掩码
  strcpy(t->IPMask, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IPMask"),"gbk","Error!")));

  return t;
};

//查询前置状态
PyObject * new_CThostFtdcQryFrontStatusField(CThostFtdcQryFrontStatusField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryFrontStatusField", (char*)"i",
p->FrontID);
}
CThostFtdcQryFrontStatusField * from_CThostFtdcQryFrontStatusField(PyObject * p){
  CThostFtdcQryFrontStatusField *t = (CThostFtdcQryFrontStatusField *)calloc(1, sizeof(CThostFtdcQryFrontStatusField));
  memset(t,0,sizeof(CThostFtdcQryFrontStatusField));
  //前置编号
  t->FrontID =   PyLong_AsLong(PyObject_GetAttrString(p, "FrontID"));

  return t;
};

//交易所行情报盘机
PyObject * new_CThostFtdcMDTraderOfferField(CThostFtdcMDTraderOfferField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcMDTraderOfferField", (char*)"yyycyiyyyyyyyyyyyyy",
p->Password, p->ConnectDate, p->ConnectTime, p->TraderConnectStatus, p->ConnectRequestTime, p->InstallID, p->BrokerID, p->ExchangeID, p->TraderID, p->ParticipantID, p->ConnectRequestDate, p->LastReportDate, p->MaxTradeID, p->StartTime, p->TradingDay, p->MaxOrderMessageReference, p->StartDate, p->OrderLocalID, p->LastReportTime);
}
CThostFtdcMDTraderOfferField * from_CThostFtdcMDTraderOfferField(PyObject * p){
  CThostFtdcMDTraderOfferField *t = (CThostFtdcMDTraderOfferField *)calloc(1, sizeof(CThostFtdcMDTraderOfferField));
  memset(t,0,sizeof(CThostFtdcMDTraderOfferField));
  //密码
  strcpy(t->Password, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Password"),"gbk","Error!")));
  //完成连接日期
  strcpy(t->ConnectDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ConnectDate"),"gbk","Error!")));
  //完成连接时间
  strcpy(t->ConnectTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ConnectTime"),"gbk","Error!")));
  //交易所交易员连接状态
  //enum类型
  //THOST_FTDC_TCS_Connected -> '2', 已经连接
  //THOST_FTDC_TCS_SubPrivateFlow -> '4', 订阅私有流
  //THOST_FTDC_TCS_NotConnected -> '1', 没有任何连接
  //THOST_FTDC_TCS_QryInstrumentSent -> '3', 已经发出合约查询请求
  t->TraderConnectStatus =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TraderConnectStatus"),"gbk","Error!"))[0];
  //发出连接请求的时间
  strcpy(t->ConnectRequestTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ConnectRequestTime"),"gbk","Error!")));
  //安装编号
  t->InstallID =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallID"));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //交易所交易员代码
  strcpy(t->TraderID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TraderID"),"gbk","Error!")));
  //会员代码
  strcpy(t->ParticipantID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ParticipantID"),"gbk","Error!")));
  //发出连接请求的日期
  strcpy(t->ConnectRequestDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ConnectRequestDate"),"gbk","Error!")));
  //上次报告日期
  strcpy(t->LastReportDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LastReportDate"),"gbk","Error!")));
  //本席位最大成交编号
  strcpy(t->MaxTradeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "MaxTradeID"),"gbk","Error!")));
  //启动时间
  strcpy(t->StartTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "StartTime"),"gbk","Error!")));
  //交易日
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //本席位最大报单备拷
  strcpy(t->MaxOrderMessageReference, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "MaxOrderMessageReference"),"gbk","Error!")));
  //启动日期
  strcpy(t->StartDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "StartDate"),"gbk","Error!")));
  //本地报单编号
  strcpy(t->OrderLocalID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderLocalID"),"gbk","Error!")));
  //上次报告时间
  strcpy(t->LastReportTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LastReportTime"),"gbk","Error!")));

  return t;
};

//查询行情报盘机
PyObject * new_CThostFtdcQryMDTraderOfferField(CThostFtdcQryMDTraderOfferField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryMDTraderOfferField", (char*)"yyy",
p->ExchangeID, p->TraderID, p->ParticipantID);
}
CThostFtdcQryMDTraderOfferField * from_CThostFtdcQryMDTraderOfferField(PyObject * p){
  CThostFtdcQryMDTraderOfferField *t = (CThostFtdcQryMDTraderOfferField *)calloc(1, sizeof(CThostFtdcQryMDTraderOfferField));
  memset(t,0,sizeof(CThostFtdcQryMDTraderOfferField));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //交易所交易员代码
  strcpy(t->TraderID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TraderID"),"gbk","Error!")));
  //会员代码
  strcpy(t->ParticipantID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ParticipantID"),"gbk","Error!")));

  return t;
};

//变更银行账户请求
PyObject * new_CThostFtdcReqChangeAccountField(CThostFtdcReqChangeAccountField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcReqChangeAccountField", (char*)"cccyiyyiyycycyyyyyyyyccyyyyyycycyyyyiyyi",
p->MoneyAccountStatus, p->BankPwdFlag, p->CustType, p->TradeTime, p->InstallID, p->BrokerID, p->ZipCode, p->SessionID, p->IdentifiedCardNo, p->NewBankAccount, p->SecuPwdFlag, p->EMail, p->VerifyCertNoFlag, p->MobilePhone, p->BankID, p->CurrencyID, p->AccountID, p->BankAccount, p->Digest, p->Fax, p->Password, p->LastFragment, p->Gender, p->Address, p->NewBankPassWord, p->BrokerIDByBank, p->CountryCode, p->TradeDate, p->TradingDay, p->IdCardType, p->BankSerial, p->BankAccType, p->TradeCode, p->CustomerName, p->BankBranchID, p->BankPassWord, p->TID, p->Telephone, p->BrokerBranchID, p->PlateSerial);
}
CThostFtdcReqChangeAccountField * from_CThostFtdcReqChangeAccountField(PyObject * p){
  CThostFtdcReqChangeAccountField *t = (CThostFtdcReqChangeAccountField *)calloc(1, sizeof(CThostFtdcReqChangeAccountField));
  memset(t,0,sizeof(CThostFtdcReqChangeAccountField));
  //资金账户状态
  //enum类型
  //THOST_FTDC_MAS_Normal -> '0', 正常
  //THOST_FTDC_MAS_Cancel -> '1', 销户
  t->MoneyAccountStatus =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "MoneyAccountStatus"),"gbk","Error!"))[0];
  //银行密码标志
  //enum类型
  //THOST_FTDC_BPWDF_NoCheck -> '0', 不核对
  //THOST_FTDC_BPWDF_BlankCheck -> '1', 明文核对
  //THOST_FTDC_BPWDF_EncryptCheck -> '2', 密文核对
  t->BankPwdFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankPwdFlag"),"gbk","Error!"))[0];
  //客户类型
  //enum类型
  //THOST_FTDC_CUSTT_Person -> '0', 自然人
  //THOST_FTDC_CUSTT_Institution -> '1', 机构户
  t->CustType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustType"),"gbk","Error!"))[0];
  //交易时间
  strcpy(t->TradeTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeTime"),"gbk","Error!")));
  //安装编号
  t->InstallID =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallID"));
  //期商代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //邮编
  strcpy(t->ZipCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ZipCode"),"gbk","Error!")));
  //会话号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //证件号码
  strcpy(t->IdentifiedCardNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdentifiedCardNo"),"gbk","Error!")));
  //新银行帐号
  strcpy(t->NewBankAccount, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "NewBankAccount"),"gbk","Error!")));
  //期货资金密码核对标志
  //enum类型
  //THOST_FTDC_BPWDF_NoCheck -> '0', 不核对
  //THOST_FTDC_BPWDF_BlankCheck -> '1', 明文核对
  //THOST_FTDC_BPWDF_EncryptCheck -> '2', 密文核对
  t->SecuPwdFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "SecuPwdFlag"),"gbk","Error!"))[0];
  //电子邮件
  strcpy(t->EMail, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "EMail"),"gbk","Error!")));
  //验证客户证件号码标志
  //enum类型
  //THOST_FTDC_YNI_No -> '1', 否
  //THOST_FTDC_YNI_Yes -> '0', 是
  t->VerifyCertNoFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "VerifyCertNoFlag"),"gbk","Error!"))[0];
  //手机
  strcpy(t->MobilePhone, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "MobilePhone"),"gbk","Error!")));
  //银行代码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //币种代码
  strcpy(t->CurrencyID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrencyID"),"gbk","Error!")));
  //投资者帐号
  strcpy(t->AccountID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AccountID"),"gbk","Error!")));
  //银行帐号
  strcpy(t->BankAccount, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccount"),"gbk","Error!")));
  //摘要
  strcpy(t->Digest, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Digest"),"gbk","Error!")));
  //传真
  strcpy(t->Fax, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Fax"),"gbk","Error!")));
  //期货密码
  strcpy(t->Password, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Password"),"gbk","Error!")));
  //最后分片标志
  //enum类型
  //THOST_FTDC_LF_No -> '1', 不是最后分片
  //THOST_FTDC_LF_Yes -> '0', 是最后分片
  t->LastFragment =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LastFragment"),"gbk","Error!"))[0];
  //性别
  //enum类型
  //THOST_FTDC_GD_Male -> '1', 男
  //THOST_FTDC_GD_Unknown -> '0', 未知状态
  //THOST_FTDC_GD_Female -> '2', 女
  t->Gender =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Gender"),"gbk","Error!"))[0];
  //地址
  strcpy(t->Address, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Address"),"gbk","Error!")));
  //新银行密码
  strcpy(t->NewBankPassWord, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "NewBankPassWord"),"gbk","Error!")));
  //期货公司银行编码
  strcpy(t->BrokerIDByBank, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerIDByBank"),"gbk","Error!")));
  //国家代码
  strcpy(t->CountryCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CountryCode"),"gbk","Error!")));
  //交易日期
  strcpy(t->TradeDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeDate"),"gbk","Error!")));
  //交易系统日期
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //证件类型
  //enum类型
  //THOST_FTDC_ICT_TaiwanCompatriotIDCard -> '7', 台胞证
  //THOST_FTDC_ICT_Passport -> '6', 护照
  //THOST_FTDC_ICT_LicenseNo -> '9', 营业执照号
  //THOST_FTDC_ICT_OtherCard -> 'x', 其他证件
  //THOST_FTDC_ICT_IDCard -> '1', 身份证
  //THOST_FTDC_ICT_EID -> '0', 组织机构代码
  //THOST_FTDC_ICT_TaxNo -> 'A', 税务登记号
  //THOST_FTDC_ICT_HomeComingCard -> '8', 回乡证
  //THOST_FTDC_ICT_OfficerIDCard -> '2', 军官证
  //THOST_FTDC_ICT_HouseholdRegister -> '5', 户口簿
  //THOST_FTDC_ICT_SoldierIDCard -> '4', 士兵证
  //THOST_FTDC_ICT_PoliceIDCard -> '3', 警官证
  t->IdCardType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdCardType"),"gbk","Error!"))[0];
  //银行流水号
  strcpy(t->BankSerial, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSerial"),"gbk","Error!")));
  //银行帐号类型
  //enum类型
  //THOST_FTDC_BAT_SavingCard -> '2', 储蓄卡
  //THOST_FTDC_BAT_CreditCard -> '3', 信用卡
  //THOST_FTDC_BAT_BankBook -> '1', 银行存折
  t->BankAccType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccType"),"gbk","Error!"))[0];
  //业务功能码
  strcpy(t->TradeCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeCode"),"gbk","Error!")));
  //客户姓名
  strcpy(t->CustomerName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustomerName"),"gbk","Error!")));
  //银行分支机构代码
  strcpy(t->BankBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBranchID"),"gbk","Error!")));
  //银行密码
  strcpy(t->BankPassWord, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankPassWord"),"gbk","Error!")));
  //交易ID
  t->TID =   PyLong_AsLong(PyObject_GetAttrString(p, "TID"));
  //电话号码
  strcpy(t->Telephone, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Telephone"),"gbk","Error!")));
  //期商分支机构代码
  strcpy(t->BrokerBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerBranchID"),"gbk","Error!")));
  //银期平台消息流水号
  t->PlateSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "PlateSerial"));

  return t;
};

//查询禁止登录用户
PyObject * new_CThostFtdcQryLoginForbiddenUserField(CThostFtdcQryLoginForbiddenUserField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryLoginForbiddenUserField", (char*)"yy",
p->BrokerID, p->UserID);
}
CThostFtdcQryLoginForbiddenUserField * from_CThostFtdcQryLoginForbiddenUserField(PyObject * p){
  CThostFtdcQryLoginForbiddenUserField *t = (CThostFtdcQryLoginForbiddenUserField *)calloc(1, sizeof(CThostFtdcQryLoginForbiddenUserField));
  memset(t,0,sizeof(CThostFtdcQryLoginForbiddenUserField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));

  return t;
};

//经纪公司用户口令
PyObject * new_CThostFtdcBrokerUserPasswordField(CThostFtdcBrokerUserPasswordField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcBrokerUserPasswordField", (char*)"yyy",
p->Password, p->BrokerID, p->UserID);
}
CThostFtdcBrokerUserPasswordField * from_CThostFtdcBrokerUserPasswordField(PyObject * p){
  CThostFtdcBrokerUserPasswordField *t = (CThostFtdcBrokerUserPasswordField *)calloc(1, sizeof(CThostFtdcBrokerUserPasswordField));
  memset(t,0,sizeof(CThostFtdcBrokerUserPasswordField));
  //密码
  strcpy(t->Password, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Password"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));

  return t;
};

//银行资金转期货请求，TradeCode=202001
PyObject * new_CThostFtdcTransferBankToFutureReqField(CThostFtdcTransferBankToFutureReqField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcTransferBankToFutureReqField", (char*)"yyyddc",
p->FutureAccount, p->FutureAccPwd, p->CurrencyCode, p->TradeAmt, p->CustFee, p->FuturePwdFlag);
}
CThostFtdcTransferBankToFutureReqField * from_CThostFtdcTransferBankToFutureReqField(PyObject * p){
  CThostFtdcTransferBankToFutureReqField *t = (CThostFtdcTransferBankToFutureReqField *)calloc(1, sizeof(CThostFtdcTransferBankToFutureReqField));
  memset(t,0,sizeof(CThostFtdcTransferBankToFutureReqField));
  //期货资金账户
  strcpy(t->FutureAccount, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "FutureAccount"),"gbk","Error!")));
  //密码
  strcpy(t->FutureAccPwd, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "FutureAccPwd"),"gbk","Error!")));
  //币种：RMB-人民币 USD-美圆 HKD-港元
  strcpy(t->CurrencyCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrencyCode"),"gbk","Error!")));
  //转账金额
  t->TradeAmt =   PyFloat_AsDouble(PyObject_GetAttrString(p, "TradeAmt"));
  //客户手续费
  t->CustFee =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CustFee"));
  //密码标志
  //enum类型
  //THOST_FTDC_FPWD_Check -> '1', 核对
  //THOST_FTDC_FPWD_UnCheck -> '0', 不核对
  t->FuturePwdFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "FuturePwdFlag"),"gbk","Error!"))[0];

  return t;
};

//查询经纪公司用户
PyObject * new_CThostFtdcQryBrokerUserField(CThostFtdcQryBrokerUserField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryBrokerUserField", (char*)"yy",
p->BrokerID, p->UserID);
}
CThostFtdcQryBrokerUserField * from_CThostFtdcQryBrokerUserField(PyObject * p){
  CThostFtdcQryBrokerUserField *t = (CThostFtdcQryBrokerUserField *)calloc(1, sizeof(CThostFtdcQryBrokerUserField));
  memset(t,0,sizeof(CThostFtdcQryBrokerUserField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));

  return t;
};

//用户权限
PyObject * new_CThostFtdcUserRightField(CThostFtdcUserRightField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcUserRightField", (char*)"yiyc",
p->BrokerID, p->IsForbidden, p->UserID, p->UserRightType);
}
CThostFtdcUserRightField * from_CThostFtdcUserRightField(PyObject * p){
  CThostFtdcUserRightField *t = (CThostFtdcUserRightField *)calloc(1, sizeof(CThostFtdcUserRightField));
  memset(t,0,sizeof(CThostFtdcUserRightField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //是否禁止
  t->IsForbidden =   PyLong_AsLong(PyObject_GetAttrString(p, "IsForbidden"));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //客户权限类型
  //enum类型
  //THOST_FTDC_URT_Transfer -> '2', 银期转帐
  //THOST_FTDC_URT_ConditionOrder -> '5', 条件单
  //THOST_FTDC_URT_Logon -> '1', 登录
  //THOST_FTDC_URT_EMail -> '3', 邮寄结算单
  //THOST_FTDC_URT_Fax -> '4', 传真结算单
  t->UserRightType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserRightType"),"gbk","Error!"))[0];

  return t;
};

//查询报单
PyObject * new_CThostFtdcQryHisOrderField(CThostFtdcQryHisOrderField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryHisOrderField", (char*)"yiyyyyyyy",
p->OrderSysID, p->SettlementID, p->InstrumentID, p->TradingDay, p->InsertTimeEnd, p->BrokerID, p->InvestorID, p->ExchangeID, p->InsertTimeStart);
}
CThostFtdcQryHisOrderField * from_CThostFtdcQryHisOrderField(PyObject * p){
  CThostFtdcQryHisOrderField *t = (CThostFtdcQryHisOrderField *)calloc(1, sizeof(CThostFtdcQryHisOrderField));
  memset(t,0,sizeof(CThostFtdcQryHisOrderField));
  //报单编号
  strcpy(t->OrderSysID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderSysID"),"gbk","Error!")));
  //结算编号
  t->SettlementID =   PyLong_AsLong(PyObject_GetAttrString(p, "SettlementID"));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //交易日
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //结束时间
  strcpy(t->InsertTimeEnd, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InsertTimeEnd"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //开始时间
  strcpy(t->InsertTimeStart, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InsertTimeStart"),"gbk","Error!")));

  return t;
};

//行情申卖四、五属性
PyObject * new_CThostFtdcMarketDataAsk45Field(CThostFtdcMarketDataAsk45Field * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcMarketDataAsk45Field", (char*)"ddii",
p->AskPrice5, p->AskPrice4, p->AskVolume5, p->AskVolume4);
}
CThostFtdcMarketDataAsk45Field * from_CThostFtdcMarketDataAsk45Field(PyObject * p){
  CThostFtdcMarketDataAsk45Field *t = (CThostFtdcMarketDataAsk45Field *)calloc(1, sizeof(CThostFtdcMarketDataAsk45Field));
  memset(t,0,sizeof(CThostFtdcMarketDataAsk45Field));
  //申卖价五
  t->AskPrice5 =   PyFloat_AsDouble(PyObject_GetAttrString(p, "AskPrice5"));
  //申卖价四
  t->AskPrice4 =   PyFloat_AsDouble(PyObject_GetAttrString(p, "AskPrice4"));
  //申卖量五
  t->AskVolume5 =   PyLong_AsLong(PyObject_GetAttrString(p, "AskVolume5"));
  //申卖量四
  t->AskVolume4 =   PyLong_AsLong(PyObject_GetAttrString(p, "AskVolume4"));

  return t;
};

//查询交易所
PyObject * new_CThostFtdcQryExchangeField(CThostFtdcQryExchangeField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryExchangeField", (char*)"y",
p->ExchangeID);
}
CThostFtdcQryExchangeField * from_CThostFtdcQryExchangeField(PyObject * p){
  CThostFtdcQryExchangeField *t = (CThostFtdcQryExchangeField *)calloc(1, sizeof(CThostFtdcQryExchangeField));
  memset(t,0,sizeof(CThostFtdcQryExchangeField));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));

  return t;
};

//冲正响应
PyObject * new_CThostFtdcRspRepealField(CThostFtdcRspRepealField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcRspRepealField", (char*)"yyiyiycidyccyyciydyyydyyyyyiicdyiiccyciyycyicyycyyci",
p->TradingDay, p->DeviceID, p->ErrorID, p->BrokerID, p->SessionID, p->IdentifiedCardNo, p->IdCardType, p->FutureRepealSerial, p->FutureFetchAmount, p->BankID, p->BankPwdFlag, p->BankRepealFlag, p->BankAccount, p->BankSecuAcc, p->LastFragment, p->PlateRepealSerial, p->TradeDate, p->CustFee, p->AccountID, p->BankSerial, p->OperNo, p->BrokerFee, p->CustomerName, p->BankPassWord, p->Message, p->BankBranchID, p->Digest, p->PlateSerial, p->RepealedTimes, p->TransferStatus, p->TradeAmount, p->TradeTime, p->FutureSerial, p->InstallID, p->SecuPwdFlag, p->BrokerRepealFlag, p->BankRepealSerial, p->VerifyCertNoFlag, p->RepealTimeInterval, p->CurrencyID, p->ErrorMsg, p->BankSecuAccType, p->Password, p->RequestID, p->BankAccType, p->BrokerBranchID, p->UserID, p->CustType, p->BrokerIDByBank, p->TradeCode, p->FeePayFlag, p->TID);
}
CThostFtdcRspRepealField * from_CThostFtdcRspRepealField(PyObject * p){
  CThostFtdcRspRepealField *t = (CThostFtdcRspRepealField *)calloc(1, sizeof(CThostFtdcRspRepealField));
  memset(t,0,sizeof(CThostFtdcRspRepealField));
  //交易系统日期
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //渠道标志
  strcpy(t->DeviceID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "DeviceID"),"gbk","Error!")));
  //错误代码
  t->ErrorID =   PyLong_AsLong(PyObject_GetAttrString(p, "ErrorID"));
  //期商代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //会话号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //证件号码
  strcpy(t->IdentifiedCardNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdentifiedCardNo"),"gbk","Error!")));
  //证件类型
  //enum类型
  //THOST_FTDC_ICT_TaiwanCompatriotIDCard -> '7', 台胞证
  //THOST_FTDC_ICT_Passport -> '6', 护照
  //THOST_FTDC_ICT_LicenseNo -> '9', 营业执照号
  //THOST_FTDC_ICT_OtherCard -> 'x', 其他证件
  //THOST_FTDC_ICT_IDCard -> '1', 身份证
  //THOST_FTDC_ICT_EID -> '0', 组织机构代码
  //THOST_FTDC_ICT_TaxNo -> 'A', 税务登记号
  //THOST_FTDC_ICT_HomeComingCard -> '8', 回乡证
  //THOST_FTDC_ICT_OfficerIDCard -> '2', 军官证
  //THOST_FTDC_ICT_HouseholdRegister -> '5', 户口簿
  //THOST_FTDC_ICT_SoldierIDCard -> '4', 士兵证
  //THOST_FTDC_ICT_PoliceIDCard -> '3', 警官证
  t->IdCardType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdCardType"),"gbk","Error!"))[0];
  //被冲正期货流水号
  t->FutureRepealSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "FutureRepealSerial"));
  //期货可取金额
  t->FutureFetchAmount =   PyFloat_AsDouble(PyObject_GetAttrString(p, "FutureFetchAmount"));
  //银行代码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //银行密码标志
  //enum类型
  //THOST_FTDC_BPWDF_NoCheck -> '0', 不核对
  //THOST_FTDC_BPWDF_BlankCheck -> '1', 明文核对
  //THOST_FTDC_BPWDF_EncryptCheck -> '2', 密文核对
  t->BankPwdFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankPwdFlag"),"gbk","Error!"))[0];
  //银行冲正标志
  //enum类型
  //THOST_FTDC_BRF_BankNotNeedRepeal -> '0', 银行无需自动冲正
  //THOST_FTDC_BRF_BankBeenRepealed -> '2', 银行已自动冲正
  //THOST_FTDC_BRF_BankWaitingRepeal -> '1', 银行待自动冲正
  t->BankRepealFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankRepealFlag"),"gbk","Error!"))[0];
  //银行帐号
  strcpy(t->BankAccount, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccount"),"gbk","Error!")));
  //期货单位帐号
  strcpy(t->BankSecuAcc, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSecuAcc"),"gbk","Error!")));
  //最后分片标志
  //enum类型
  //THOST_FTDC_LF_No -> '1', 不是最后分片
  //THOST_FTDC_LF_Yes -> '0', 是最后分片
  t->LastFragment =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LastFragment"),"gbk","Error!"))[0];
  //被冲正平台流水号
  t->PlateRepealSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "PlateRepealSerial"));
  //交易日期
  strcpy(t->TradeDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeDate"),"gbk","Error!")));
  //应收客户费用
  t->CustFee =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CustFee"));
  //投资者帐号
  strcpy(t->AccountID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AccountID"),"gbk","Error!")));
  //银行流水号
  strcpy(t->BankSerial, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSerial"),"gbk","Error!")));
  //交易柜员
  strcpy(t->OperNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OperNo"),"gbk","Error!")));
  //应收期货公司费用
  t->BrokerFee =   PyFloat_AsDouble(PyObject_GetAttrString(p, "BrokerFee"));
  //客户姓名
  strcpy(t->CustomerName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustomerName"),"gbk","Error!")));
  //银行密码
  strcpy(t->BankPassWord, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankPassWord"),"gbk","Error!")));
  //发送方给接收方的消息
  strcpy(t->Message, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Message"),"gbk","Error!")));
  //银行分支机构代码
  strcpy(t->BankBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBranchID"),"gbk","Error!")));
  //摘要
  strcpy(t->Digest, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Digest"),"gbk","Error!")));
  //银期平台消息流水号
  t->PlateSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "PlateSerial"));
  //已经冲正次数
  t->RepealedTimes =   PyLong_AsLong(PyObject_GetAttrString(p, "RepealedTimes"));
  //转账交易状态
  //enum类型
  //THOST_FTDC_TRFS_Normal -> '0', 正常
  //THOST_FTDC_TRFS_Repealed -> '1', 被冲正
  t->TransferStatus =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TransferStatus"),"gbk","Error!"))[0];
  //转帐金额
  t->TradeAmount =   PyFloat_AsDouble(PyObject_GetAttrString(p, "TradeAmount"));
  //交易时间
  strcpy(t->TradeTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeTime"),"gbk","Error!")));
  //期货公司流水号
  t->FutureSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "FutureSerial"));
  //安装编号
  t->InstallID =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallID"));
  //期货资金密码核对标志
  //enum类型
  //THOST_FTDC_BPWDF_NoCheck -> '0', 不核对
  //THOST_FTDC_BPWDF_BlankCheck -> '1', 明文核对
  //THOST_FTDC_BPWDF_EncryptCheck -> '2', 密文核对
  t->SecuPwdFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "SecuPwdFlag"),"gbk","Error!"))[0];
  //期商冲正标志
  //enum类型
  //THOST_FTDC_BRORF_BrokerBeenRepealed -> '2', 期商已自动冲正
  //THOST_FTDC_BRORF_BrokerWaitingRepeal -> '1', 期商待自动冲正
  //THOST_FTDC_BRORF_BrokerNotNeedRepeal -> '0', 期商无需自动冲正
  t->BrokerRepealFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerRepealFlag"),"gbk","Error!"))[0];
  //被冲正银行流水号
  strcpy(t->BankRepealSerial, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankRepealSerial"),"gbk","Error!")));
  //验证客户证件号码标志
  //enum类型
  //THOST_FTDC_YNI_No -> '1', 否
  //THOST_FTDC_YNI_Yes -> '0', 是
  t->VerifyCertNoFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "VerifyCertNoFlag"),"gbk","Error!"))[0];
  //冲正时间间隔
  t->RepealTimeInterval =   PyLong_AsLong(PyObject_GetAttrString(p, "RepealTimeInterval"));
  //币种代码
  strcpy(t->CurrencyID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrencyID"),"gbk","Error!")));
  //错误信息
  strcpy(t->ErrorMsg, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ErrorMsg"),"gbk","Error!")));
  //期货单位帐号类型
  //enum类型
  //THOST_FTDC_BAT_SavingCard -> '2', 储蓄卡
  //THOST_FTDC_BAT_CreditCard -> '3', 信用卡
  //THOST_FTDC_BAT_BankBook -> '1', 银行存折
  t->BankSecuAccType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSecuAccType"),"gbk","Error!"))[0];
  //期货密码
  strcpy(t->Password, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Password"),"gbk","Error!")));
  //请求编号
  t->RequestID =   PyLong_AsLong(PyObject_GetAttrString(p, "RequestID"));
  //银行帐号类型
  //enum类型
  //THOST_FTDC_BAT_SavingCard -> '2', 储蓄卡
  //THOST_FTDC_BAT_CreditCard -> '3', 信用卡
  //THOST_FTDC_BAT_BankBook -> '1', 银行存折
  t->BankAccType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccType"),"gbk","Error!"))[0];
  //期商分支机构代码
  strcpy(t->BrokerBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerBranchID"),"gbk","Error!")));
  //用户标识
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //客户类型
  //enum类型
  //THOST_FTDC_CUSTT_Person -> '0', 自然人
  //THOST_FTDC_CUSTT_Institution -> '1', 机构户
  t->CustType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustType"),"gbk","Error!"))[0];
  //期货公司银行编码
  strcpy(t->BrokerIDByBank, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerIDByBank"),"gbk","Error!")));
  //业务功能码
  strcpy(t->TradeCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeCode"),"gbk","Error!")));
  //费用支付标志
  //enum类型
  //THOST_FTDC_FPF_SHA -> '2', 由发送方支付发起的费用，受益方支付接受的费用
  //THOST_FTDC_FPF_BEN -> '0', 由受益方支付费用
  //THOST_FTDC_FPF_OUR -> '1', 由发送方支付费用
  t->FeePayFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "FeePayFlag"),"gbk","Error!"))[0];
  //交易ID
  t->TID =   PyLong_AsLong(PyObject_GetAttrString(p, "TID"));

  return t;
};

//查询合约状态
PyObject * new_CThostFtdcQryInstrumentStatusField(CThostFtdcQryInstrumentStatusField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryInstrumentStatusField", (char*)"yy",
p->ExchangeInstID, p->ExchangeID);
}
CThostFtdcQryInstrumentStatusField * from_CThostFtdcQryInstrumentStatusField(PyObject * p){
  CThostFtdcQryInstrumentStatusField *t = (CThostFtdcQryInstrumentStatusField *)calloc(1, sizeof(CThostFtdcQryInstrumentStatusField));
  memset(t,0,sizeof(CThostFtdcQryInstrumentStatusField));
  //合约在交易所的代码
  strcpy(t->ExchangeInstID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeInstID"),"gbk","Error!")));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));

  return t;
};

//查询预埋单
PyObject * new_CThostFtdcQryParkedOrderField(CThostFtdcQryParkedOrderField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryParkedOrderField", (char*)"yyyy",
p->BrokerID, p->InvestorID, p->ExchangeID, p->InstrumentID);
}
CThostFtdcQryParkedOrderField * from_CThostFtdcQryParkedOrderField(PyObject * p){
  CThostFtdcQryParkedOrderField *t = (CThostFtdcQryParkedOrderField *)calloc(1, sizeof(CThostFtdcQryParkedOrderField));
  memset(t,0,sizeof(CThostFtdcQryParkedOrderField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));

  return t;
};

//交易所交易员
PyObject * new_CThostFtdcTraderField(CThostFtdcTraderField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcTraderField", (char*)"yiyyyy",
p->Password, p->InstallCount, p->BrokerID, p->ExchangeID, p->TraderID, p->ParticipantID);
}
CThostFtdcTraderField * from_CThostFtdcTraderField(PyObject * p){
  CThostFtdcTraderField *t = (CThostFtdcTraderField *)calloc(1, sizeof(CThostFtdcTraderField));
  memset(t,0,sizeof(CThostFtdcTraderField));
  //密码
  strcpy(t->Password, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Password"),"gbk","Error!")));
  //安装数量
  t->InstallCount =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallCount"));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //交易所交易员代码
  strcpy(t->TraderID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TraderID"),"gbk","Error!")));
  //会员代码
  strcpy(t->ParticipantID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ParticipantID"),"gbk","Error!")));

  return t;
};

//投资者结算结果
PyObject * new_CThostFtdcSettlementInfoField(CThostFtdcSettlementInfoField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcSettlementInfoField", (char*)"iyyiyy",
p->SettlementID, p->Content, p->InvestorID, p->SequenceNo, p->BrokerID, p->TradingDay);
}
CThostFtdcSettlementInfoField * from_CThostFtdcSettlementInfoField(PyObject * p){
  CThostFtdcSettlementInfoField *t = (CThostFtdcSettlementInfoField *)calloc(1, sizeof(CThostFtdcSettlementInfoField));
  memset(t,0,sizeof(CThostFtdcSettlementInfoField));
  //结算编号
  t->SettlementID =   PyLong_AsLong(PyObject_GetAttrString(p, "SettlementID"));
  //消息正文
  strcpy(t->Content, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Content"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //序号
  t->SequenceNo =   PyLong_AsLong(PyObject_GetAttrString(p, "SequenceNo"));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //交易日
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));

  return t;
};

//查询银行资金请求响应
PyObject * new_CThostFtdcTransferQryBankRspField(CThostFtdcTransferQryBankRspField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcTransferQryBankRspField", (char*)"yyydddy",
p->FutureAccount, p->RetCode, p->RetInfo, p->TradeAmt, p->UseAmt, p->FetchAmt, p->CurrencyCode);
}
CThostFtdcTransferQryBankRspField * from_CThostFtdcTransferQryBankRspField(PyObject * p){
  CThostFtdcTransferQryBankRspField *t = (CThostFtdcTransferQryBankRspField *)calloc(1, sizeof(CThostFtdcTransferQryBankRspField));
  memset(t,0,sizeof(CThostFtdcTransferQryBankRspField));
  //资金账户
  strcpy(t->FutureAccount, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "FutureAccount"),"gbk","Error!")));
  //响应代码
  strcpy(t->RetCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "RetCode"),"gbk","Error!")));
  //响应信息
  strcpy(t->RetInfo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "RetInfo"),"gbk","Error!")));
  //银行余额
  t->TradeAmt =   PyFloat_AsDouble(PyObject_GetAttrString(p, "TradeAmt"));
  //银行可用余额
  t->UseAmt =   PyFloat_AsDouble(PyObject_GetAttrString(p, "UseAmt"));
  //银行可取余额
  t->FetchAmt =   PyFloat_AsDouble(PyObject_GetAttrString(p, "FetchAmt"));
  //币种
  strcpy(t->CurrencyCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrencyCode"),"gbk","Error!")));

  return t;
};

//查询出入金流水
PyObject * new_CThostFtdcQrySyncDepositField(CThostFtdcQrySyncDepositField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQrySyncDepositField", (char*)"yy",
p->DepositSeqNo, p->BrokerID);
}
CThostFtdcQrySyncDepositField * from_CThostFtdcQrySyncDepositField(PyObject * p){
  CThostFtdcQrySyncDepositField *t = (CThostFtdcQrySyncDepositField *)calloc(1, sizeof(CThostFtdcQrySyncDepositField));
  memset(t,0,sizeof(CThostFtdcQrySyncDepositField));
  //出入金流水号
  strcpy(t->DepositSeqNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "DepositSeqNo"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));

  return t;
};

//银期开户信息
PyObject * new_CThostFtdcOpenAccountField(CThostFtdcOpenAccountField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcOpenAccountField", (char*)"yyiyyiycyycyyyccyycyyyycyiyyyiccyycyyyyycyyciy",
p->TradingDay, p->DeviceID, p->ErrorID, p->BrokerID, p->ZipCode, p->SessionID, p->IdentifiedCardNo, p->IdCardType, p->MobilePhone, p->BankID, p->BankPwdFlag, p->OperNo, p->BankAccount, p->BankSecuAcc, p->LastFragment, p->Gender, p->Address, p->TradeDate, p->MoneyAccountStatus, p->AccountID, p->BankSerial, p->CustomerName, p->BankPassWord, p->CashExchangeCode, p->Digest, p->PlateSerial, p->Fax, p->EMail, p->TradeTime, p->InstallID, p->SecuPwdFlag, p->VerifyCertNoFlag, p->CurrencyID, p->ErrorMsg, p->BankSecuAccType, p->Password, p->BankBranchID, p->CountryCode, p->BrokerBranchID, p->UserID, p->CustType, p->BrokerIDByBank, p->TradeCode, p->BankAccType, p->TID, p->Telephone);
}
CThostFtdcOpenAccountField * from_CThostFtdcOpenAccountField(PyObject * p){
  CThostFtdcOpenAccountField *t = (CThostFtdcOpenAccountField *)calloc(1, sizeof(CThostFtdcOpenAccountField));
  memset(t,0,sizeof(CThostFtdcOpenAccountField));
  //交易系统日期
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //渠道标志
  strcpy(t->DeviceID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "DeviceID"),"gbk","Error!")));
  //错误代码
  t->ErrorID =   PyLong_AsLong(PyObject_GetAttrString(p, "ErrorID"));
  //期商代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //邮编
  strcpy(t->ZipCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ZipCode"),"gbk","Error!")));
  //会话号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //证件号码
  strcpy(t->IdentifiedCardNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdentifiedCardNo"),"gbk","Error!")));
  //证件类型
  //enum类型
  //THOST_FTDC_ICT_TaiwanCompatriotIDCard -> '7', 台胞证
  //THOST_FTDC_ICT_Passport -> '6', 护照
  //THOST_FTDC_ICT_LicenseNo -> '9', 营业执照号
  //THOST_FTDC_ICT_OtherCard -> 'x', 其他证件
  //THOST_FTDC_ICT_IDCard -> '1', 身份证
  //THOST_FTDC_ICT_EID -> '0', 组织机构代码
  //THOST_FTDC_ICT_TaxNo -> 'A', 税务登记号
  //THOST_FTDC_ICT_HomeComingCard -> '8', 回乡证
  //THOST_FTDC_ICT_OfficerIDCard -> '2', 军官证
  //THOST_FTDC_ICT_HouseholdRegister -> '5', 户口簿
  //THOST_FTDC_ICT_SoldierIDCard -> '4', 士兵证
  //THOST_FTDC_ICT_PoliceIDCard -> '3', 警官证
  t->IdCardType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdCardType"),"gbk","Error!"))[0];
  //手机
  strcpy(t->MobilePhone, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "MobilePhone"),"gbk","Error!")));
  //银行代码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //银行密码标志
  //enum类型
  //THOST_FTDC_BPWDF_NoCheck -> '0', 不核对
  //THOST_FTDC_BPWDF_BlankCheck -> '1', 明文核对
  //THOST_FTDC_BPWDF_EncryptCheck -> '2', 密文核对
  t->BankPwdFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankPwdFlag"),"gbk","Error!"))[0];
  //交易柜员
  strcpy(t->OperNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OperNo"),"gbk","Error!")));
  //银行帐号
  strcpy(t->BankAccount, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccount"),"gbk","Error!")));
  //期货单位帐号
  strcpy(t->BankSecuAcc, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSecuAcc"),"gbk","Error!")));
  //最后分片标志
  //enum类型
  //THOST_FTDC_LF_No -> '1', 不是最后分片
  //THOST_FTDC_LF_Yes -> '0', 是最后分片
  t->LastFragment =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LastFragment"),"gbk","Error!"))[0];
  //性别
  //enum类型
  //THOST_FTDC_GD_Male -> '1', 男
  //THOST_FTDC_GD_Unknown -> '0', 未知状态
  //THOST_FTDC_GD_Female -> '2', 女
  t->Gender =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Gender"),"gbk","Error!"))[0];
  //地址
  strcpy(t->Address, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Address"),"gbk","Error!")));
  //交易日期
  strcpy(t->TradeDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeDate"),"gbk","Error!")));
  //资金账户状态
  //enum类型
  //THOST_FTDC_MAS_Normal -> '0', 正常
  //THOST_FTDC_MAS_Cancel -> '1', 销户
  t->MoneyAccountStatus =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "MoneyAccountStatus"),"gbk","Error!"))[0];
  //投资者帐号
  strcpy(t->AccountID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AccountID"),"gbk","Error!")));
  //银行流水号
  strcpy(t->BankSerial, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSerial"),"gbk","Error!")));
  //客户姓名
  strcpy(t->CustomerName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustomerName"),"gbk","Error!")));
  //银行密码
  strcpy(t->BankPassWord, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankPassWord"),"gbk","Error!")));
  //汇钞标志
  //enum类型
  //THOST_FTDC_CEC_Cash -> '2', 钞
  //THOST_FTDC_CEC_Exchange -> '1', 汇
  t->CashExchangeCode =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CashExchangeCode"),"gbk","Error!"))[0];
  //摘要
  strcpy(t->Digest, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Digest"),"gbk","Error!")));
  //银期平台消息流水号
  t->PlateSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "PlateSerial"));
  //传真
  strcpy(t->Fax, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Fax"),"gbk","Error!")));
  //电子邮件
  strcpy(t->EMail, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "EMail"),"gbk","Error!")));
  //交易时间
  strcpy(t->TradeTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeTime"),"gbk","Error!")));
  //安装编号
  t->InstallID =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallID"));
  //期货资金密码核对标志
  //enum类型
  //THOST_FTDC_BPWDF_NoCheck -> '0', 不核对
  //THOST_FTDC_BPWDF_BlankCheck -> '1', 明文核对
  //THOST_FTDC_BPWDF_EncryptCheck -> '2', 密文核对
  t->SecuPwdFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "SecuPwdFlag"),"gbk","Error!"))[0];
  //验证客户证件号码标志
  //enum类型
  //THOST_FTDC_YNI_No -> '1', 否
  //THOST_FTDC_YNI_Yes -> '0', 是
  t->VerifyCertNoFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "VerifyCertNoFlag"),"gbk","Error!"))[0];
  //币种代码
  strcpy(t->CurrencyID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrencyID"),"gbk","Error!")));
  //错误信息
  strcpy(t->ErrorMsg, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ErrorMsg"),"gbk","Error!")));
  //期货单位帐号类型
  //enum类型
  //THOST_FTDC_BAT_SavingCard -> '2', 储蓄卡
  //THOST_FTDC_BAT_CreditCard -> '3', 信用卡
  //THOST_FTDC_BAT_BankBook -> '1', 银行存折
  t->BankSecuAccType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSecuAccType"),"gbk","Error!"))[0];
  //期货密码
  strcpy(t->Password, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Password"),"gbk","Error!")));
  //银行分支机构代码
  strcpy(t->BankBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBranchID"),"gbk","Error!")));
  //国家代码
  strcpy(t->CountryCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CountryCode"),"gbk","Error!")));
  //期商分支机构代码
  strcpy(t->BrokerBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerBranchID"),"gbk","Error!")));
  //用户标识
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //客户类型
  //enum类型
  //THOST_FTDC_CUSTT_Person -> '0', 自然人
  //THOST_FTDC_CUSTT_Institution -> '1', 机构户
  t->CustType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustType"),"gbk","Error!"))[0];
  //期货公司银行编码
  strcpy(t->BrokerIDByBank, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerIDByBank"),"gbk","Error!")));
  //业务功能码
  strcpy(t->TradeCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeCode"),"gbk","Error!")));
  //银行帐号类型
  //enum类型
  //THOST_FTDC_BAT_SavingCard -> '2', 储蓄卡
  //THOST_FTDC_BAT_CreditCard -> '3', 信用卡
  //THOST_FTDC_BAT_BankBook -> '1', 银行存折
  t->BankAccType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccType"),"gbk","Error!"))[0];
  //交易ID
  t->TID =   PyLong_AsLong(PyObject_GetAttrString(p, "TID"));
  //电话号码
  strcpy(t->Telephone, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Telephone"),"gbk","Error!")));

  return t;
};

//期货资金转银行请求，TradeCode=202002
PyObject * new_CThostFtdcTransferFutureToBankReqField(CThostFtdcTransferFutureToBankReqField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcTransferFutureToBankReqField", (char*)"yyyddc",
p->FutureAccount, p->FutureAccPwd, p->CurrencyCode, p->TradeAmt, p->CustFee, p->FuturePwdFlag);
}
CThostFtdcTransferFutureToBankReqField * from_CThostFtdcTransferFutureToBankReqField(PyObject * p){
  CThostFtdcTransferFutureToBankReqField *t = (CThostFtdcTransferFutureToBankReqField *)calloc(1, sizeof(CThostFtdcTransferFutureToBankReqField));
  memset(t,0,sizeof(CThostFtdcTransferFutureToBankReqField));
  //期货资金账户
  strcpy(t->FutureAccount, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "FutureAccount"),"gbk","Error!")));
  //密码
  strcpy(t->FutureAccPwd, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "FutureAccPwd"),"gbk","Error!")));
  //币种：RMB-人民币 USD-美圆 HKD-港元
  strcpy(t->CurrencyCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrencyCode"),"gbk","Error!")));
  //转账金额
  t->TradeAmt =   PyFloat_AsDouble(PyObject_GetAttrString(p, "TradeAmt"));
  //客户手续费
  t->CustFee =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CustFee"));
  //密码标志
  //enum类型
  //THOST_FTDC_FPWD_Check -> '1', 核对
  //THOST_FTDC_FPWD_UnCheck -> '0', 不核对
  t->FuturePwdFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "FuturePwdFlag"),"gbk","Error!"))[0];

  return t;
};

//查询投资者持仓明细
PyObject * new_CThostFtdcQryInvestorPositionDetailField(CThostFtdcQryInvestorPositionDetailField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryInvestorPositionDetailField", (char*)"yyy",
p->BrokerID, p->InvestorID, p->InstrumentID);
}
CThostFtdcQryInvestorPositionDetailField * from_CThostFtdcQryInvestorPositionDetailField(PyObject * p){
  CThostFtdcQryInvestorPositionDetailField *t = (CThostFtdcQryInvestorPositionDetailField *)calloc(1, sizeof(CThostFtdcQryInvestorPositionDetailField));
  memset(t,0,sizeof(CThostFtdcQryInvestorPositionDetailField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));

  return t;
};

//客户通知
PyObject * new_CThostFtdcNoticeField(CThostFtdcNoticeField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcNoticeField", (char*)"yyy",
p->SequenceLabel, p->BrokerID, p->Content);
}
CThostFtdcNoticeField * from_CThostFtdcNoticeField(PyObject * p){
  CThostFtdcNoticeField *t = (CThostFtdcNoticeField *)calloc(1, sizeof(CThostFtdcNoticeField));
  memset(t,0,sizeof(CThostFtdcNoticeField));
  //经纪公司通知内容序列号
  strcpy(t->SequenceLabel, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "SequenceLabel"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //消息正文
  strcpy(t->Content, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Content"),"gbk","Error!")));

  return t;
};

//查询组合合约分腿
PyObject * new_CThostFtdcQryCombinationLegField(CThostFtdcQryCombinationLegField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryCombinationLegField", (char*)"iyy",
p->LegID, p->CombInstrumentID, p->LegInstrumentID);
}
CThostFtdcQryCombinationLegField * from_CThostFtdcQryCombinationLegField(PyObject * p){
  CThostFtdcQryCombinationLegField *t = (CThostFtdcQryCombinationLegField *)calloc(1, sizeof(CThostFtdcQryCombinationLegField));
  memset(t,0,sizeof(CThostFtdcQryCombinationLegField));
  //单腿编号
  t->LegID =   PyLong_AsLong(PyObject_GetAttrString(p, "LegID"));
  //组合合约代码
  strcpy(t->CombInstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CombInstrumentID"),"gbk","Error!")));
  //单腿合约代码
  strcpy(t->LegInstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LegInstrumentID"),"gbk","Error!")));

  return t;
};

//经纪公司资金
PyObject * new_CThostFtdcBrokerDepositField(CThostFtdcBrokerDepositField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcBrokerDepositField", (char*)"ddyyddydddydd",
p->CloseProfit, p->Balance, p->BrokerID, p->TradingDay, p->Deposit, p->Reserve, p->ExchangeID, p->PreBalance, p->CurrMargin, p->FrozenMargin, p->ParticipantID, p->Withdraw, p->Available);
}
CThostFtdcBrokerDepositField * from_CThostFtdcBrokerDepositField(PyObject * p){
  CThostFtdcBrokerDepositField *t = (CThostFtdcBrokerDepositField *)calloc(1, sizeof(CThostFtdcBrokerDepositField));
  memset(t,0,sizeof(CThostFtdcBrokerDepositField));
  //平仓盈亏
  t->CloseProfit =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CloseProfit"));
  //期货结算准备金
  t->Balance =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Balance"));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //交易日期
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //入金金额
  t->Deposit =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Deposit"));
  //基本准备金
  t->Reserve =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Reserve"));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //上次结算准备金
  t->PreBalance =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PreBalance"));
  //当前保证金总额
  t->CurrMargin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CurrMargin"));
  //冻结的保证金
  t->FrozenMargin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "FrozenMargin"));
  //会员代码
  strcpy(t->ParticipantID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ParticipantID"),"gbk","Error!")));
  //出金金额
  t->Withdraw =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Withdraw"));
  //可提资金
  t->Available =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Available"));

  return t;
};

//请求查询银期签约关系
PyObject * new_CThostFtdcQryAccountregisterField(CThostFtdcQryAccountregisterField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryAccountregisterField", (char*)"yyy",
p->BankID, p->BrokerID, p->AccountID);
}
CThostFtdcQryAccountregisterField * from_CThostFtdcQryAccountregisterField(PyObject * p){
  CThostFtdcQryAccountregisterField *t = (CThostFtdcQryAccountregisterField *)calloc(1, sizeof(CThostFtdcQryAccountregisterField));
  memset(t,0,sizeof(CThostFtdcQryAccountregisterField));
  //银行编码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者帐号
  strcpy(t->AccountID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AccountID"),"gbk","Error!")));

  return t;
};

//查询保证金监管系统经纪公司密钥
PyObject * new_CThostFtdcQryCFMMCBrokerKeyField(CThostFtdcQryCFMMCBrokerKeyField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryCFMMCBrokerKeyField", (char*)"y",
p->BrokerID);
}
CThostFtdcQryCFMMCBrokerKeyField * from_CThostFtdcQryCFMMCBrokerKeyField(PyObject * p){
  CThostFtdcQryCFMMCBrokerKeyField *t = (CThostFtdcQryCFMMCBrokerKeyField *)calloc(1, sizeof(CThostFtdcQryCFMMCBrokerKeyField));
  memset(t,0,sizeof(CThostFtdcQryCFMMCBrokerKeyField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));

  return t;
};

//交易所成交
PyObject * new_CThostFtdcExchangeTradeField(CThostFtdcExchangeTradeField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcExchangeTradeField", (char*)"cycyyyccycdyyyiiyycycy",
p->TradeSource, p->TradeID, p->PriceSource, p->TradeTime, p->ClientID, p->ClearingPartID, p->OffsetFlag, p->TradeType, p->TraderID, p->TradingRole, p->Price, p->ExchangeID, p->OrderSysID, p->ExchangeInstID, p->SequenceNo, p->Volume, p->TradeDate, p->ParticipantID, p->Direction, p->BusinessUnit, p->HedgeFlag, p->OrderLocalID);
}
CThostFtdcExchangeTradeField * from_CThostFtdcExchangeTradeField(PyObject * p){
  CThostFtdcExchangeTradeField *t = (CThostFtdcExchangeTradeField *)calloc(1, sizeof(CThostFtdcExchangeTradeField));
  memset(t,0,sizeof(CThostFtdcExchangeTradeField));
  //成交来源
  //enum类型
  //THOST_FTDC_TSRC_NORMAL -> '0', 来自交易所普通回报
  //THOST_FTDC_TSRC_QUERY -> '1', 来自查询
  t->TradeSource =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeSource"),"gbk","Error!"))[0];
  //成交编号
  strcpy(t->TradeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeID"),"gbk","Error!")));
  //成交价来源
  //enum类型
  //THOST_FTDC_PSRC_LastPrice -> '0', 前成交价
  //THOST_FTDC_PSRC_Buy -> '1', 买委托价
  //THOST_FTDC_PSRC_Sell -> '2', 卖委托价
  t->PriceSource =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "PriceSource"),"gbk","Error!"))[0];
  //成交时间
  strcpy(t->TradeTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeTime"),"gbk","Error!")));
  //客户代码
  strcpy(t->ClientID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ClientID"),"gbk","Error!")));
  //结算会员编号
  strcpy(t->ClearingPartID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ClearingPartID"),"gbk","Error!")));
  //开平标志
  //enum类型
  //THOST_FTDC_OF_Close -> '1', 平仓
  //THOST_FTDC_OF_CloseYesterday -> '4', 平昨
  //THOST_FTDC_OF_CloseToday -> '3', 平今
  //THOST_FTDC_OF_Open -> '0', 开仓
  //THOST_FTDC_OF_LocalForceClose -> '6', 本地强平
  //THOST_FTDC_OF_ForceClose -> '2', 强平
  //THOST_FTDC_OF_ForceOff -> '5', 强减
  t->OffsetFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OffsetFlag"),"gbk","Error!"))[0];
  //成交类型
  //enum类型
  //THOST_FTDC_TRDT_OptionsExecution -> '1', 期权执行
  //THOST_FTDC_TRDT_Common -> '0', 普通成交
  //THOST_FTDC_TRDT_CombinationDerived -> '4', 组合衍生成交
  //THOST_FTDC_TRDT_OTC -> '2', OTC成交
  //THOST_FTDC_TRDT_EFPDerived -> '3', 期转现衍生成交
  t->TradeType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeType"),"gbk","Error!"))[0];
  //交易所交易员代码
  strcpy(t->TraderID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TraderID"),"gbk","Error!")));
  //交易角色
  //enum类型
  //THOST_FTDC_ER_Broker -> '1', 代理
  //THOST_FTDC_ER_Maker -> '3', 做市商
  //THOST_FTDC_ER_Host -> '2', 自营
  t->TradingRole =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingRole"),"gbk","Error!"))[0];
  //价格
  t->Price =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Price"));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //报单编号
  strcpy(t->OrderSysID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderSysID"),"gbk","Error!")));
  //合约在交易所的代码
  strcpy(t->ExchangeInstID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeInstID"),"gbk","Error!")));
  //序号
  t->SequenceNo =   PyLong_AsLong(PyObject_GetAttrString(p, "SequenceNo"));
  //数量
  t->Volume =   PyLong_AsLong(PyObject_GetAttrString(p, "Volume"));
  //成交时期
  strcpy(t->TradeDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeDate"),"gbk","Error!")));
  //会员代码
  strcpy(t->ParticipantID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ParticipantID"),"gbk","Error!")));
  //买卖方向
  //enum类型
  //THOST_FTDC_D_Buy -> '0', 买
  //THOST_FTDC_D_Sell -> '1', 卖
  t->Direction =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Direction"),"gbk","Error!"))[0];
  //业务单元
  strcpy(t->BusinessUnit, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BusinessUnit"),"gbk","Error!")));
  //投机套保标志
  //enum类型
  //THOST_FTDC_HF_Hedge -> '3', 套保
  //THOST_FTDC_HF_Arbitrage -> '2', 套利
  //THOST_FTDC_HF_Speculation -> '1', 投机
  t->HedgeFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "HedgeFlag"),"gbk","Error!"))[0];
  //本地报单编号
  strcpy(t->OrderLocalID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderLocalID"),"gbk","Error!")));

  return t;
};

//合约保证金率调整
PyObject * new_CThostFtdcInstrumentMarginRateAdjustField(CThostFtdcInstrumentMarginRateAdjustField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcInstrumentMarginRateAdjustField", (char*)"yddciyycdd",
p->InstrumentID, p->ShortMarginRatioByVolume, p->LongMarginRatioByMoney, p->HedgeFlag, p->IsRelative, p->BrokerID, p->InvestorID, p->InvestorRange, p->LongMarginRatioByVolume, p->ShortMarginRatioByMoney);
}
CThostFtdcInstrumentMarginRateAdjustField * from_CThostFtdcInstrumentMarginRateAdjustField(PyObject * p){
  CThostFtdcInstrumentMarginRateAdjustField *t = (CThostFtdcInstrumentMarginRateAdjustField *)calloc(1, sizeof(CThostFtdcInstrumentMarginRateAdjustField));
  memset(t,0,sizeof(CThostFtdcInstrumentMarginRateAdjustField));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //空头保证金费
  t->ShortMarginRatioByVolume =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ShortMarginRatioByVolume"));
  //多头保证金率
  t->LongMarginRatioByMoney =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LongMarginRatioByMoney"));
  //投机套保标志
  //enum类型
  //THOST_FTDC_HF_Hedge -> '3', 套保
  //THOST_FTDC_HF_Arbitrage -> '2', 套利
  //THOST_FTDC_HF_Speculation -> '1', 投机
  t->HedgeFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "HedgeFlag"),"gbk","Error!"))[0];
  //是否相对交易所收取
  t->IsRelative =   PyLong_AsLong(PyObject_GetAttrString(p, "IsRelative"));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //投资者范围
  //enum类型
  //THOST_FTDC_IR_Single -> '3', 单一投资者
  //THOST_FTDC_IR_All -> '1', 所有
  //THOST_FTDC_IR_Group -> '2', 投资者组
  t->InvestorRange =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorRange"),"gbk","Error!"))[0];
  //多头保证金费
  t->LongMarginRatioByVolume =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LongMarginRatioByVolume"));
  //空头保证金率
  t->ShortMarginRatioByMoney =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ShortMarginRatioByMoney"));

  return t;
};

//交易所保证金率
PyObject * new_CThostFtdcExchangeMarginRateField(CThostFtdcExchangeMarginRateField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcExchangeMarginRateField", (char*)"ydcdydd",
p->InstrumentID, p->ShortMarginRatioByVolume, p->HedgeFlag, p->LongMarginRatioByMoney, p->BrokerID, p->LongMarginRatioByVolume, p->ShortMarginRatioByMoney);
}
CThostFtdcExchangeMarginRateField * from_CThostFtdcExchangeMarginRateField(PyObject * p){
  CThostFtdcExchangeMarginRateField *t = (CThostFtdcExchangeMarginRateField *)calloc(1, sizeof(CThostFtdcExchangeMarginRateField));
  memset(t,0,sizeof(CThostFtdcExchangeMarginRateField));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //空头保证金费
  t->ShortMarginRatioByVolume =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ShortMarginRatioByVolume"));
  //投机套保标志
  //enum类型
  //THOST_FTDC_HF_Hedge -> '3', 套保
  //THOST_FTDC_HF_Arbitrage -> '2', 套利
  //THOST_FTDC_HF_Speculation -> '1', 投机
  t->HedgeFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "HedgeFlag"),"gbk","Error!"))[0];
  //多头保证金率
  t->LongMarginRatioByMoney =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LongMarginRatioByMoney"));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //多头保证金费
  t->LongMarginRatioByVolume =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LongMarginRatioByVolume"));
  //空头保证金率
  t->ShortMarginRatioByMoney =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ShortMarginRatioByMoney"));

  return t;
};

//用户事件通知信息
PyObject * new_CThostFtdcTradingNoticeInfoField(CThostFtdcTradingNoticeInfoField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcTradingNoticeInfoField", (char*)"hiyyyy",
p->SequenceSeries, p->SequenceNo, p->SendTime, p->BrokerID, p->InvestorID, p->FieldContent);
}
CThostFtdcTradingNoticeInfoField * from_CThostFtdcTradingNoticeInfoField(PyObject * p){
  CThostFtdcTradingNoticeInfoField *t = (CThostFtdcTradingNoticeInfoField *)calloc(1, sizeof(CThostFtdcTradingNoticeInfoField));
  memset(t,0,sizeof(CThostFtdcTradingNoticeInfoField));
  //序列系列号
  t->SequenceSeries =   PyLong_AsLong(PyObject_GetAttrString(p, "SequenceSeries"));
  //序列号
  t->SequenceNo =   PyLong_AsLong(PyObject_GetAttrString(p, "SequenceNo"));
  //发送时间
  strcpy(t->SendTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "SendTime"),"gbk","Error!")));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //消息正文
  strcpy(t->FieldContent, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "FieldContent"),"gbk","Error!")));

  return t;
};

//查询经纪公司交易参数
PyObject * new_CThostFtdcQryBrokerTradingParamsField(CThostFtdcQryBrokerTradingParamsField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryBrokerTradingParamsField", (char*)"yy",
p->BrokerID, p->InvestorID);
}
CThostFtdcQryBrokerTradingParamsField * from_CThostFtdcQryBrokerTradingParamsField(PyObject * p){
  CThostFtdcQryBrokerTradingParamsField *t = (CThostFtdcQryBrokerTradingParamsField *)calloc(1, sizeof(CThostFtdcQryBrokerTradingParamsField));
  memset(t,0,sizeof(CThostFtdcQryBrokerTradingParamsField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));

  return t;
};

//转账请求
PyObject * new_CThostFtdcReqTransferField(CThostFtdcReqTransferField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcReqTransferField", (char*)"yccyyiyiyiyycydcyycyydyycicyyccyyyyycdiyyid",
p->Digest, p->TransferStatus, p->BankPwdFlag, p->TradingDay, p->TradeTime, p->FutureSerial, p->DeviceID, p->InstallID, p->BrokerID, p->SessionID, p->IdentifiedCardNo, p->AccountID, p->SecuPwdFlag, p->Message, p->TradeAmount, p->VerifyCertNoFlag, p->BankID, p->CurrencyID, p->BankSecuAccType, p->OperNo, p->BankAccount, p->CustFee, p->BankSecuAcc, p->Password, p->LastFragment, p->RequestID, p->BankAccType, p->TradeDate, p->UserID, p->CustType, p->IdCardType, p->BankSerial, p->BrokerIDByBank, p->TradeCode, p->CustomerName, p->BankPassWord, p->FeePayFlag, p->FutureFetchAmount, p->TID, p->BankBranchID, p->BrokerBranchID, p->PlateSerial, p->BrokerFee);
}
CThostFtdcReqTransferField * from_CThostFtdcReqTransferField(PyObject * p){
  CThostFtdcReqTransferField *t = (CThostFtdcReqTransferField *)calloc(1, sizeof(CThostFtdcReqTransferField));
  memset(t,0,sizeof(CThostFtdcReqTransferField));
  //摘要
  strcpy(t->Digest, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Digest"),"gbk","Error!")));
  //转账交易状态
  //enum类型
  //THOST_FTDC_TRFS_Normal -> '0', 正常
  //THOST_FTDC_TRFS_Repealed -> '1', 被冲正
  t->TransferStatus =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TransferStatus"),"gbk","Error!"))[0];
  //银行密码标志
  //enum类型
  //THOST_FTDC_BPWDF_NoCheck -> '0', 不核对
  //THOST_FTDC_BPWDF_BlankCheck -> '1', 明文核对
  //THOST_FTDC_BPWDF_EncryptCheck -> '2', 密文核对
  t->BankPwdFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankPwdFlag"),"gbk","Error!"))[0];
  //交易系统日期
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //交易时间
  strcpy(t->TradeTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeTime"),"gbk","Error!")));
  //期货公司流水号
  t->FutureSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "FutureSerial"));
  //渠道标志
  strcpy(t->DeviceID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "DeviceID"),"gbk","Error!")));
  //安装编号
  t->InstallID =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallID"));
  //期商代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //会话号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //证件号码
  strcpy(t->IdentifiedCardNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdentifiedCardNo"),"gbk","Error!")));
  //投资者帐号
  strcpy(t->AccountID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AccountID"),"gbk","Error!")));
  //期货资金密码核对标志
  //enum类型
  //THOST_FTDC_BPWDF_NoCheck -> '0', 不核对
  //THOST_FTDC_BPWDF_BlankCheck -> '1', 明文核对
  //THOST_FTDC_BPWDF_EncryptCheck -> '2', 密文核对
  t->SecuPwdFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "SecuPwdFlag"),"gbk","Error!"))[0];
  //发送方给接收方的消息
  strcpy(t->Message, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Message"),"gbk","Error!")));
  //转帐金额
  t->TradeAmount =   PyFloat_AsDouble(PyObject_GetAttrString(p, "TradeAmount"));
  //验证客户证件号码标志
  //enum类型
  //THOST_FTDC_YNI_No -> '1', 否
  //THOST_FTDC_YNI_Yes -> '0', 是
  t->VerifyCertNoFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "VerifyCertNoFlag"),"gbk","Error!"))[0];
  //银行代码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //币种代码
  strcpy(t->CurrencyID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrencyID"),"gbk","Error!")));
  //期货单位帐号类型
  //enum类型
  //THOST_FTDC_BAT_SavingCard -> '2', 储蓄卡
  //THOST_FTDC_BAT_CreditCard -> '3', 信用卡
  //THOST_FTDC_BAT_BankBook -> '1', 银行存折
  t->BankSecuAccType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSecuAccType"),"gbk","Error!"))[0];
  //交易柜员
  strcpy(t->OperNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OperNo"),"gbk","Error!")));
  //银行帐号
  strcpy(t->BankAccount, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccount"),"gbk","Error!")));
  //应收客户费用
  t->CustFee =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CustFee"));
  //期货单位帐号
  strcpy(t->BankSecuAcc, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSecuAcc"),"gbk","Error!")));
  //期货密码
  strcpy(t->Password, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Password"),"gbk","Error!")));
  //最后分片标志
  //enum类型
  //THOST_FTDC_LF_No -> '1', 不是最后分片
  //THOST_FTDC_LF_Yes -> '0', 是最后分片
  t->LastFragment =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LastFragment"),"gbk","Error!"))[0];
  //请求编号
  t->RequestID =   PyLong_AsLong(PyObject_GetAttrString(p, "RequestID"));
  //银行帐号类型
  //enum类型
  //THOST_FTDC_BAT_SavingCard -> '2', 储蓄卡
  //THOST_FTDC_BAT_CreditCard -> '3', 信用卡
  //THOST_FTDC_BAT_BankBook -> '1', 银行存折
  t->BankAccType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccType"),"gbk","Error!"))[0];
  //交易日期
  strcpy(t->TradeDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeDate"),"gbk","Error!")));
  //用户标识
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //客户类型
  //enum类型
  //THOST_FTDC_CUSTT_Person -> '0', 自然人
  //THOST_FTDC_CUSTT_Institution -> '1', 机构户
  t->CustType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustType"),"gbk","Error!"))[0];
  //证件类型
  //enum类型
  //THOST_FTDC_ICT_TaiwanCompatriotIDCard -> '7', 台胞证
  //THOST_FTDC_ICT_Passport -> '6', 护照
  //THOST_FTDC_ICT_LicenseNo -> '9', 营业执照号
  //THOST_FTDC_ICT_OtherCard -> 'x', 其他证件
  //THOST_FTDC_ICT_IDCard -> '1', 身份证
  //THOST_FTDC_ICT_EID -> '0', 组织机构代码
  //THOST_FTDC_ICT_TaxNo -> 'A', 税务登记号
  //THOST_FTDC_ICT_HomeComingCard -> '8', 回乡证
  //THOST_FTDC_ICT_OfficerIDCard -> '2', 军官证
  //THOST_FTDC_ICT_HouseholdRegister -> '5', 户口簿
  //THOST_FTDC_ICT_SoldierIDCard -> '4', 士兵证
  //THOST_FTDC_ICT_PoliceIDCard -> '3', 警官证
  t->IdCardType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdCardType"),"gbk","Error!"))[0];
  //银行流水号
  strcpy(t->BankSerial, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSerial"),"gbk","Error!")));
  //期货公司银行编码
  strcpy(t->BrokerIDByBank, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerIDByBank"),"gbk","Error!")));
  //业务功能码
  strcpy(t->TradeCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeCode"),"gbk","Error!")));
  //客户姓名
  strcpy(t->CustomerName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustomerName"),"gbk","Error!")));
  //银行密码
  strcpy(t->BankPassWord, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankPassWord"),"gbk","Error!")));
  //费用支付标志
  //enum类型
  //THOST_FTDC_FPF_SHA -> '2', 由发送方支付发起的费用，受益方支付接受的费用
  //THOST_FTDC_FPF_BEN -> '0', 由受益方支付费用
  //THOST_FTDC_FPF_OUR -> '1', 由发送方支付费用
  t->FeePayFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "FeePayFlag"),"gbk","Error!"))[0];
  //期货可取金额
  t->FutureFetchAmount =   PyFloat_AsDouble(PyObject_GetAttrString(p, "FutureFetchAmount"));
  //交易ID
  t->TID =   PyLong_AsLong(PyObject_GetAttrString(p, "TID"));
  //银行分支机构代码
  strcpy(t->BankBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBranchID"),"gbk","Error!")));
  //期商分支机构代码
  strcpy(t->BrokerBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerBranchID"),"gbk","Error!")));
  //银期平台消息流水号
  t->PlateSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "PlateSerial"));
  //应收期货公司费用
  t->BrokerFee =   PyFloat_AsDouble(PyObject_GetAttrString(p, "BrokerFee"));

  return t;
};

//查询指定流水号的交易结果响应
PyObject * new_CThostFtdcRspQueryTradeResultBySerialField(CThostFtdcRspQueryTradeResultBySerialField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcRspQueryTradeResultBySerialField", (char*)"ydyiyicyiyyyyyycyyyyyyyyyi",
p->OriginReturnCode, p->TradeAmount, p->TradeTime, p->ErrorID, p->BrokerID, p->SessionID, p->RefrenceIssureType, p->OriginDescrInfoForReturnCode, p->Reference, p->BankID, p->CurrencyID, p->ErrorMsg, p->BankAccount, p->Digest, p->Password, p->LastFragment, p->TradeDate, p->TradingDay, p->AccountID, p->BankSerial, p->TradeCode, p->RefrenceIssure, p->BankPassWord, p->BankBranchID, p->BrokerBranchID, p->PlateSerial);
}
CThostFtdcRspQueryTradeResultBySerialField * from_CThostFtdcRspQueryTradeResultBySerialField(PyObject * p){
  CThostFtdcRspQueryTradeResultBySerialField *t = (CThostFtdcRspQueryTradeResultBySerialField *)calloc(1, sizeof(CThostFtdcRspQueryTradeResultBySerialField));
  memset(t,0,sizeof(CThostFtdcRspQueryTradeResultBySerialField));
  //原始返回代码
  strcpy(t->OriginReturnCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OriginReturnCode"),"gbk","Error!")));
  //转帐金额
  t->TradeAmount =   PyFloat_AsDouble(PyObject_GetAttrString(p, "TradeAmount"));
  //交易时间
  strcpy(t->TradeTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeTime"),"gbk","Error!")));
  //错误代码
  t->ErrorID =   PyLong_AsLong(PyObject_GetAttrString(p, "ErrorID"));
  //期商代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //会话号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //本流水号发布者的机构类型
  //enum类型
  //THOST_FTDC_TS_Store -> '2', 券商
  //THOST_FTDC_TS_Future -> '1', 期商
  //THOST_FTDC_TS_Bank -> '0', 银行
  t->RefrenceIssureType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "RefrenceIssureType"),"gbk","Error!"))[0];
  //原始返回码描述
  strcpy(t->OriginDescrInfoForReturnCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OriginDescrInfoForReturnCode"),"gbk","Error!")));
  //流水号
  t->Reference =   PyLong_AsLong(PyObject_GetAttrString(p, "Reference"));
  //银行代码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //币种代码
  strcpy(t->CurrencyID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrencyID"),"gbk","Error!")));
  //错误信息
  strcpy(t->ErrorMsg, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ErrorMsg"),"gbk","Error!")));
  //银行帐号
  strcpy(t->BankAccount, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccount"),"gbk","Error!")));
  //摘要
  strcpy(t->Digest, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Digest"),"gbk","Error!")));
  //期货密码
  strcpy(t->Password, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Password"),"gbk","Error!")));
  //最后分片标志
  //enum类型
  //THOST_FTDC_LF_No -> '1', 不是最后分片
  //THOST_FTDC_LF_Yes -> '0', 是最后分片
  t->LastFragment =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LastFragment"),"gbk","Error!"))[0];
  //交易日期
  strcpy(t->TradeDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeDate"),"gbk","Error!")));
  //交易系统日期
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //投资者帐号
  strcpy(t->AccountID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AccountID"),"gbk","Error!")));
  //银行流水号
  strcpy(t->BankSerial, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSerial"),"gbk","Error!")));
  //业务功能码
  strcpy(t->TradeCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeCode"),"gbk","Error!")));
  //本流水号发布者机构编码
  strcpy(t->RefrenceIssure, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "RefrenceIssure"),"gbk","Error!")));
  //银行密码
  strcpy(t->BankPassWord, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankPassWord"),"gbk","Error!")));
  //银行分支机构代码
  strcpy(t->BankBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBranchID"),"gbk","Error!")));
  //期商分支机构代码
  strcpy(t->BrokerBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerBranchID"),"gbk","Error!")));
  //银期平台消息流水号
  t->PlateSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "PlateSerial"));

  return t;
};

//银期变更银行账号信息
PyObject * new_CThostFtdcChangeAccountField(CThostFtdcChangeAccountField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcChangeAccountField", (char*)"cccyiiyyiyycycyyyyyyyyyccyyyyyycycyyyyiyyi",
p->MoneyAccountStatus, p->BankPwdFlag, p->CustType, p->TradeTime, p->ErrorID, p->InstallID, p->BrokerID, p->ZipCode, p->SessionID, p->IdentifiedCardNo, p->NewBankAccount, p->SecuPwdFlag, p->EMail, p->VerifyCertNoFlag, p->MobilePhone, p->BankID, p->CurrencyID, p->ErrorMsg, p->AccountID, p->BankAccount, p->Digest, p->Fax, p->Password, p->LastFragment, p->Gender, p->Address, p->NewBankPassWord, p->BrokerIDByBank, p->CountryCode, p->TradeDate, p->TradingDay, p->IdCardType, p->BankSerial, p->BankAccType, p->TradeCode, p->CustomerName, p->BankBranchID, p->BankPassWord, p->TID, p->Telephone, p->BrokerBranchID, p->PlateSerial);
}
CThostFtdcChangeAccountField * from_CThostFtdcChangeAccountField(PyObject * p){
  CThostFtdcChangeAccountField *t = (CThostFtdcChangeAccountField *)calloc(1, sizeof(CThostFtdcChangeAccountField));
  memset(t,0,sizeof(CThostFtdcChangeAccountField));
  //资金账户状态
  //enum类型
  //THOST_FTDC_MAS_Normal -> '0', 正常
  //THOST_FTDC_MAS_Cancel -> '1', 销户
  t->MoneyAccountStatus =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "MoneyAccountStatus"),"gbk","Error!"))[0];
  //银行密码标志
  //enum类型
  //THOST_FTDC_BPWDF_NoCheck -> '0', 不核对
  //THOST_FTDC_BPWDF_BlankCheck -> '1', 明文核对
  //THOST_FTDC_BPWDF_EncryptCheck -> '2', 密文核对
  t->BankPwdFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankPwdFlag"),"gbk","Error!"))[0];
  //客户类型
  //enum类型
  //THOST_FTDC_CUSTT_Person -> '0', 自然人
  //THOST_FTDC_CUSTT_Institution -> '1', 机构户
  t->CustType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustType"),"gbk","Error!"))[0];
  //交易时间
  strcpy(t->TradeTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeTime"),"gbk","Error!")));
  //错误代码
  t->ErrorID =   PyLong_AsLong(PyObject_GetAttrString(p, "ErrorID"));
  //安装编号
  t->InstallID =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallID"));
  //期商代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //邮编
  strcpy(t->ZipCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ZipCode"),"gbk","Error!")));
  //会话号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //证件号码
  strcpy(t->IdentifiedCardNo, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdentifiedCardNo"),"gbk","Error!")));
  //新银行帐号
  strcpy(t->NewBankAccount, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "NewBankAccount"),"gbk","Error!")));
  //期货资金密码核对标志
  //enum类型
  //THOST_FTDC_BPWDF_NoCheck -> '0', 不核对
  //THOST_FTDC_BPWDF_BlankCheck -> '1', 明文核对
  //THOST_FTDC_BPWDF_EncryptCheck -> '2', 密文核对
  t->SecuPwdFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "SecuPwdFlag"),"gbk","Error!"))[0];
  //电子邮件
  strcpy(t->EMail, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "EMail"),"gbk","Error!")));
  //验证客户证件号码标志
  //enum类型
  //THOST_FTDC_YNI_No -> '1', 否
  //THOST_FTDC_YNI_Yes -> '0', 是
  t->VerifyCertNoFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "VerifyCertNoFlag"),"gbk","Error!"))[0];
  //手机
  strcpy(t->MobilePhone, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "MobilePhone"),"gbk","Error!")));
  //银行代码
  strcpy(t->BankID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankID"),"gbk","Error!")));
  //币种代码
  strcpy(t->CurrencyID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CurrencyID"),"gbk","Error!")));
  //错误信息
  strcpy(t->ErrorMsg, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ErrorMsg"),"gbk","Error!")));
  //投资者帐号
  strcpy(t->AccountID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AccountID"),"gbk","Error!")));
  //银行帐号
  strcpy(t->BankAccount, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccount"),"gbk","Error!")));
  //摘要
  strcpy(t->Digest, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Digest"),"gbk","Error!")));
  //传真
  strcpy(t->Fax, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Fax"),"gbk","Error!")));
  //期货密码
  strcpy(t->Password, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Password"),"gbk","Error!")));
  //最后分片标志
  //enum类型
  //THOST_FTDC_LF_No -> '1', 不是最后分片
  //THOST_FTDC_LF_Yes -> '0', 是最后分片
  t->LastFragment =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LastFragment"),"gbk","Error!"))[0];
  //性别
  //enum类型
  //THOST_FTDC_GD_Male -> '1', 男
  //THOST_FTDC_GD_Unknown -> '0', 未知状态
  //THOST_FTDC_GD_Female -> '2', 女
  t->Gender =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Gender"),"gbk","Error!"))[0];
  //地址
  strcpy(t->Address, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Address"),"gbk","Error!")));
  //新银行密码
  strcpy(t->NewBankPassWord, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "NewBankPassWord"),"gbk","Error!")));
  //期货公司银行编码
  strcpy(t->BrokerIDByBank, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerIDByBank"),"gbk","Error!")));
  //国家代码
  strcpy(t->CountryCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CountryCode"),"gbk","Error!")));
  //交易日期
  strcpy(t->TradeDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeDate"),"gbk","Error!")));
  //交易系统日期
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //证件类型
  //enum类型
  //THOST_FTDC_ICT_TaiwanCompatriotIDCard -> '7', 台胞证
  //THOST_FTDC_ICT_Passport -> '6', 护照
  //THOST_FTDC_ICT_LicenseNo -> '9', 营业执照号
  //THOST_FTDC_ICT_OtherCard -> 'x', 其他证件
  //THOST_FTDC_ICT_IDCard -> '1', 身份证
  //THOST_FTDC_ICT_EID -> '0', 组织机构代码
  //THOST_FTDC_ICT_TaxNo -> 'A', 税务登记号
  //THOST_FTDC_ICT_HomeComingCard -> '8', 回乡证
  //THOST_FTDC_ICT_OfficerIDCard -> '2', 军官证
  //THOST_FTDC_ICT_HouseholdRegister -> '5', 户口簿
  //THOST_FTDC_ICT_SoldierIDCard -> '4', 士兵证
  //THOST_FTDC_ICT_PoliceIDCard -> '3', 警官证
  t->IdCardType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "IdCardType"),"gbk","Error!"))[0];
  //银行流水号
  strcpy(t->BankSerial, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankSerial"),"gbk","Error!")));
  //银行帐号类型
  //enum类型
  //THOST_FTDC_BAT_SavingCard -> '2', 储蓄卡
  //THOST_FTDC_BAT_CreditCard -> '3', 信用卡
  //THOST_FTDC_BAT_BankBook -> '1', 银行存折
  t->BankAccType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankAccType"),"gbk","Error!"))[0];
  //业务功能码
  strcpy(t->TradeCode, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradeCode"),"gbk","Error!")));
  //客户姓名
  strcpy(t->CustomerName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CustomerName"),"gbk","Error!")));
  //银行分支机构代码
  strcpy(t->BankBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankBranchID"),"gbk","Error!")));
  //银行密码
  strcpy(t->BankPassWord, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BankPassWord"),"gbk","Error!")));
  //交易ID
  t->TID =   PyLong_AsLong(PyObject_GetAttrString(p, "TID"));
  //电话号码
  strcpy(t->Telephone, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Telephone"),"gbk","Error!")));
  //期商分支机构代码
  strcpy(t->BrokerBranchID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerBranchID"),"gbk","Error!")));
  //银期平台消息流水号
  t->PlateSerial =   PyLong_AsLong(PyObject_GetAttrString(p, "PlateSerial"));

  return t;
};

//交易所报单插入失败
PyObject * new_CThostFtdcExchangeOrderInsertErrorField(CThostFtdcExchangeOrderInsertErrorField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcExchangeOrderInsertErrorField", (char*)"yiiyyyy",
p->ExchangeID, p->ErrorID, p->InstallID, p->ErrorMsg, p->OrderLocalID, p->TraderID, p->ParticipantID);
}
CThostFtdcExchangeOrderInsertErrorField * from_CThostFtdcExchangeOrderInsertErrorField(PyObject * p){
  CThostFtdcExchangeOrderInsertErrorField *t = (CThostFtdcExchangeOrderInsertErrorField *)calloc(1, sizeof(CThostFtdcExchangeOrderInsertErrorField));
  memset(t,0,sizeof(CThostFtdcExchangeOrderInsertErrorField));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //错误代码
  t->ErrorID =   PyLong_AsLong(PyObject_GetAttrString(p, "ErrorID"));
  //安装编号
  t->InstallID =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallID"));
  //错误信息
  strcpy(t->ErrorMsg, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ErrorMsg"),"gbk","Error!")));
  //本地报单编号
  strcpy(t->OrderLocalID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderLocalID"),"gbk","Error!")));
  //交易所交易员代码
  strcpy(t->TraderID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TraderID"),"gbk","Error!")));
  //会员代码
  strcpy(t->ParticipantID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ParticipantID"),"gbk","Error!")));

  return t;
};

//报单操作
PyObject * new_CThostFtdcOrderActionField(CThostFtdcOrderActionField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcOrderActionField", (char*)"yyiyiiyyyiyyyiyyycycdiyyy",
p->InvestorID, p->ClientID, p->InstallID, p->BrokerID, p->FrontID, p->SessionID, p->TraderID, p->StatusMsg, p->ActionLocalID, p->VolumeChange, p->ActionDate, p->ExchangeID, p->OrderSysID, p->RequestID, p->UserID, p->InstrumentID, p->ParticipantID, p->ActionFlag, p->BusinessUnit, p->OrderActionStatus, p->LimitPrice, p->OrderActionRef, p->OrderRef, p->OrderLocalID, p->ActionTime);
}
CThostFtdcOrderActionField * from_CThostFtdcOrderActionField(PyObject * p){
  CThostFtdcOrderActionField *t = (CThostFtdcOrderActionField *)calloc(1, sizeof(CThostFtdcOrderActionField));
  memset(t,0,sizeof(CThostFtdcOrderActionField));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //客户代码
  strcpy(t->ClientID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ClientID"),"gbk","Error!")));
  //安装编号
  t->InstallID =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallID"));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //前置编号
  t->FrontID =   PyLong_AsLong(PyObject_GetAttrString(p, "FrontID"));
  //会话编号
  t->SessionID =   PyLong_AsLong(PyObject_GetAttrString(p, "SessionID"));
  //交易所交易员代码
  strcpy(t->TraderID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TraderID"),"gbk","Error!")));
  //状态信息
  strcpy(t->StatusMsg, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "StatusMsg"),"gbk","Error!")));
  //操作本地编号
  strcpy(t->ActionLocalID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ActionLocalID"),"gbk","Error!")));
  //数量变化
  t->VolumeChange =   PyLong_AsLong(PyObject_GetAttrString(p, "VolumeChange"));
  //操作日期
  strcpy(t->ActionDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ActionDate"),"gbk","Error!")));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //报单编号
  strcpy(t->OrderSysID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderSysID"),"gbk","Error!")));
  //请求编号
  t->RequestID =   PyLong_AsLong(PyObject_GetAttrString(p, "RequestID"));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //会员代码
  strcpy(t->ParticipantID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ParticipantID"),"gbk","Error!")));
  //操作标志
  //enum类型
  //THOST_FTDC_AF_Delete -> '0', 删除
  //THOST_FTDC_AF_Modify -> '3', 修改
  t->ActionFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ActionFlag"),"gbk","Error!"))[0];
  //业务单元
  strcpy(t->BusinessUnit, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BusinessUnit"),"gbk","Error!")));
  //报单操作状态
  //enum类型
  //THOST_FTDC_OAS_Submitted -> 'a', 已经提交
  //THOST_FTDC_OAS_Accepted -> 'b', 已经接受
  //THOST_FTDC_OAS_Rejected -> 'c', 已经被拒绝
  t->OrderActionStatus =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderActionStatus"),"gbk","Error!"))[0];
  //价格
  t->LimitPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LimitPrice"));
  //报单操作引用
  t->OrderActionRef =   PyLong_AsLong(PyObject_GetAttrString(p, "OrderActionRef"));
  //报单引用
  strcpy(t->OrderRef, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderRef"),"gbk","Error!")));
  //本地报单编号
  strcpy(t->OrderLocalID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderLocalID"),"gbk","Error!")));
  //操作时间
  strcpy(t->ActionTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ActionTime"),"gbk","Error!")));

  return t;
};

//查询错误报单操作
PyObject * new_CThostFtdcQryErrOrderActionField(CThostFtdcQryErrOrderActionField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryErrOrderActionField", (char*)"yy",
p->BrokerID, p->InvestorID);
}
CThostFtdcQryErrOrderActionField * from_CThostFtdcQryErrOrderActionField(PyObject * p){
  CThostFtdcQryErrOrderActionField *t = (CThostFtdcQryErrOrderActionField *)calloc(1, sizeof(CThostFtdcQryErrOrderActionField));
  memset(t,0,sizeof(CThostFtdcQryErrOrderActionField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));

  return t;
};

//正在同步中的投资者分组
PyObject * new_CThostFtdcSyncingInvestorGroupField(CThostFtdcSyncingInvestorGroupField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcSyncingInvestorGroupField", (char*)"yyy",
p->BrokerID, p->InvestorGroupID, p->InvestorGroupName);
}
CThostFtdcSyncingInvestorGroupField * from_CThostFtdcSyncingInvestorGroupField(PyObject * p){
  CThostFtdcSyncingInvestorGroupField *t = (CThostFtdcSyncingInvestorGroupField *)calloc(1, sizeof(CThostFtdcSyncingInvestorGroupField));
  memset(t,0,sizeof(CThostFtdcSyncingInvestorGroupField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者分组代码
  strcpy(t->InvestorGroupID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorGroupID"),"gbk","Error!")));
  //投资者分组名称
  strcpy(t->InvestorGroupName, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorGroupName"),"gbk","Error!")));

  return t;
};

//正在同步中的投资者持仓
PyObject * new_CThostFtdcSyncingInvestorPositionField(CThostFtdcSyncingInvestorPositionField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcSyncingInvestorPositionField", (char*)"icddyydddiyddidddiiiddddddydidddidciidic",
p->LongFrozen, p->PosiDirection, p->CloseProfitByTrade, p->SettlementPrice, p->BrokerID, p->InvestorID, p->OpenCost, p->Commission, p->CashIn, p->TodayPosition, p->InstrumentID, p->CloseProfit, p->ExchangeMargin, p->CombLongFrozen, p->PositionProfit, p->PreSettlementPrice, p->FrozenMargin, p->Position, p->ShortFrozen, p->SettlementID, p->LongFrozenAmount, p->ShortFrozenAmount, p->CloseProfitByDate, p->FrozenCommission, p->MarginRateByVolume, p->MarginRateByMoney, p->TradingDay, p->UseMargin, p->OpenVolume, p->FrozenCash, p->PositionCost, p->CloseAmount, p->YdPosition, p->OpenAmount, p->HedgeFlag, p->CloseVolume, p->CombPosition, p->PreMargin, p->CombShortFrozen, p->PositionDate);
}
CThostFtdcSyncingInvestorPositionField * from_CThostFtdcSyncingInvestorPositionField(PyObject * p){
  CThostFtdcSyncingInvestorPositionField *t = (CThostFtdcSyncingInvestorPositionField *)calloc(1, sizeof(CThostFtdcSyncingInvestorPositionField));
  memset(t,0,sizeof(CThostFtdcSyncingInvestorPositionField));
  //多头冻结
  t->LongFrozen =   PyLong_AsLong(PyObject_GetAttrString(p, "LongFrozen"));
  //持仓多空方向
  //enum类型
  //THOST_FTDC_PD_Net -> '1', 净
  //THOST_FTDC_PD_Long -> '2', 多头
  //THOST_FTDC_PD_Short -> '3', 空头
  t->PosiDirection =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "PosiDirection"),"gbk","Error!"))[0];
  //逐笔对冲平仓盈亏
  t->CloseProfitByTrade =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CloseProfitByTrade"));
  //本次结算价
  t->SettlementPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "SettlementPrice"));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //开仓成本
  t->OpenCost =   PyFloat_AsDouble(PyObject_GetAttrString(p, "OpenCost"));
  //手续费
  t->Commission =   PyFloat_AsDouble(PyObject_GetAttrString(p, "Commission"));
  //资金差额
  t->CashIn =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CashIn"));
  //今日持仓
  t->TodayPosition =   PyLong_AsLong(PyObject_GetAttrString(p, "TodayPosition"));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //平仓盈亏
  t->CloseProfit =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CloseProfit"));
  //交易所保证金
  t->ExchangeMargin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ExchangeMargin"));
  //组合多头冻结
  t->CombLongFrozen =   PyLong_AsLong(PyObject_GetAttrString(p, "CombLongFrozen"));
  //持仓盈亏
  t->PositionProfit =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PositionProfit"));
  //上次结算价
  t->PreSettlementPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PreSettlementPrice"));
  //冻结的保证金
  t->FrozenMargin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "FrozenMargin"));
  //今日持仓
  t->Position =   PyLong_AsLong(PyObject_GetAttrString(p, "Position"));
  //空头冻结
  t->ShortFrozen =   PyLong_AsLong(PyObject_GetAttrString(p, "ShortFrozen"));
  //结算编号
  t->SettlementID =   PyLong_AsLong(PyObject_GetAttrString(p, "SettlementID"));
  //开仓冻结金额
  t->LongFrozenAmount =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LongFrozenAmount"));
  //开仓冻结金额
  t->ShortFrozenAmount =   PyFloat_AsDouble(PyObject_GetAttrString(p, "ShortFrozenAmount"));
  //逐日盯市平仓盈亏
  t->CloseProfitByDate =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CloseProfitByDate"));
  //冻结的手续费
  t->FrozenCommission =   PyFloat_AsDouble(PyObject_GetAttrString(p, "FrozenCommission"));
  //保证金率(按手数)
  t->MarginRateByVolume =   PyFloat_AsDouble(PyObject_GetAttrString(p, "MarginRateByVolume"));
  //保证金率
  t->MarginRateByMoney =   PyFloat_AsDouble(PyObject_GetAttrString(p, "MarginRateByMoney"));
  //交易日
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //占用的保证金
  t->UseMargin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "UseMargin"));
  //开仓量
  t->OpenVolume =   PyLong_AsLong(PyObject_GetAttrString(p, "OpenVolume"));
  //冻结的资金
  t->FrozenCash =   PyFloat_AsDouble(PyObject_GetAttrString(p, "FrozenCash"));
  //持仓成本
  t->PositionCost =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PositionCost"));
  //平仓金额
  t->CloseAmount =   PyFloat_AsDouble(PyObject_GetAttrString(p, "CloseAmount"));
  //上日持仓
  t->YdPosition =   PyLong_AsLong(PyObject_GetAttrString(p, "YdPosition"));
  //开仓金额
  t->OpenAmount =   PyFloat_AsDouble(PyObject_GetAttrString(p, "OpenAmount"));
  //投机套保标志
  //enum类型
  //THOST_FTDC_HF_Hedge -> '3', 套保
  //THOST_FTDC_HF_Arbitrage -> '2', 套利
  //THOST_FTDC_HF_Speculation -> '1', 投机
  t->HedgeFlag =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "HedgeFlag"),"gbk","Error!"))[0];
  //平仓量
  t->CloseVolume =   PyLong_AsLong(PyObject_GetAttrString(p, "CloseVolume"));
  //组合成交形成的持仓
  t->CombPosition =   PyLong_AsLong(PyObject_GetAttrString(p, "CombPosition"));
  //上次占用的保证金
  t->PreMargin =   PyFloat_AsDouble(PyObject_GetAttrString(p, "PreMargin"));
  //组合空头冻结
  t->CombShortFrozen =   PyLong_AsLong(PyObject_GetAttrString(p, "CombShortFrozen"));
  //持仓日期
  //enum类型
  //THOST_FTDC_PSD_Today -> '1', 今日持仓
  //THOST_FTDC_PSD_History -> '2', 历史持仓
  t->PositionDate =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "PositionDate"),"gbk","Error!"))[0];

  return t;
};

//投资者账户
PyObject * new_CThostFtdcInvestorAccountField(CThostFtdcInvestorAccountField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcInvestorAccountField", (char*)"yyy",
p->BrokerID, p->InvestorID, p->AccountID);
}
CThostFtdcInvestorAccountField * from_CThostFtdcInvestorAccountField(PyObject * p){
  CThostFtdcInvestorAccountField *t = (CThostFtdcInvestorAccountField *)calloc(1, sizeof(CThostFtdcInvestorAccountField));
  memset(t,0,sizeof(CThostFtdcInvestorAccountField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //投资者帐号
  strcpy(t->AccountID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "AccountID"),"gbk","Error!")));

  return t;
};

//灾备交易转换报文
PyObject * new_CThostFtdcDRTransferField(CThostFtdcDRTransferField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcDRTransferField", (char*)"iiyy",
p->DestDRIdentityID, p->OrigDRIdentityID, p->OrigBrokerID, p->DestBrokerID);
}
CThostFtdcDRTransferField * from_CThostFtdcDRTransferField(PyObject * p){
  CThostFtdcDRTransferField *t = (CThostFtdcDRTransferField *)calloc(1, sizeof(CThostFtdcDRTransferField));
  memset(t,0,sizeof(CThostFtdcDRTransferField));
  //目标交易中心代码
  t->DestDRIdentityID =   PyLong_AsLong(PyObject_GetAttrString(p, "DestDRIdentityID"));
  //原交易中心代码
  t->OrigDRIdentityID =   PyLong_AsLong(PyObject_GetAttrString(p, "OrigDRIdentityID"));
  //原应用单元代码
  strcpy(t->OrigBrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrigBrokerID"),"gbk","Error!")));
  //目标易用单元代码
  strcpy(t->DestBrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "DestBrokerID"),"gbk","Error!")));

  return t;
};

//查询投资者品种/跨品种保证金
PyObject * new_CThostFtdcQryInvestorProductGroupMarginField(CThostFtdcQryInvestorProductGroupMarginField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcQryInvestorProductGroupMarginField", (char*)"yyy",
p->BrokerID, p->InvestorID, p->ProductGroupID);
}
CThostFtdcQryInvestorProductGroupMarginField * from_CThostFtdcQryInvestorProductGroupMarginField(PyObject * p){
  CThostFtdcQryInvestorProductGroupMarginField *t = (CThostFtdcQryInvestorProductGroupMarginField *)calloc(1, sizeof(CThostFtdcQryInvestorProductGroupMarginField));
  memset(t,0,sizeof(CThostFtdcQryInvestorProductGroupMarginField));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //品种/跨品种标示
  strcpy(t->ProductGroupID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ProductGroupID"),"gbk","Error!")));

  return t;
};

//交易所交易员报盘机
PyObject * new_CThostFtdcTraderOfferField(CThostFtdcTraderOfferField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcTraderOfferField", (char*)"yyycyiyyyyyyyyyyyyy",
p->Password, p->ConnectDate, p->ConnectTime, p->TraderConnectStatus, p->ConnectRequestTime, p->InstallID, p->BrokerID, p->ExchangeID, p->TraderID, p->ParticipantID, p->ConnectRequestDate, p->LastReportDate, p->MaxTradeID, p->StartTime, p->TradingDay, p->MaxOrderMessageReference, p->StartDate, p->OrderLocalID, p->LastReportTime);
}
CThostFtdcTraderOfferField * from_CThostFtdcTraderOfferField(PyObject * p){
  CThostFtdcTraderOfferField *t = (CThostFtdcTraderOfferField *)calloc(1, sizeof(CThostFtdcTraderOfferField));
  memset(t,0,sizeof(CThostFtdcTraderOfferField));
  //密码
  strcpy(t->Password, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Password"),"gbk","Error!")));
  //完成连接日期
  strcpy(t->ConnectDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ConnectDate"),"gbk","Error!")));
  //完成连接时间
  strcpy(t->ConnectTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ConnectTime"),"gbk","Error!")));
  //交易所交易员连接状态
  //enum类型
  //THOST_FTDC_TCS_Connected -> '2', 已经连接
  //THOST_FTDC_TCS_SubPrivateFlow -> '4', 订阅私有流
  //THOST_FTDC_TCS_NotConnected -> '1', 没有任何连接
  //THOST_FTDC_TCS_QryInstrumentSent -> '3', 已经发出合约查询请求
  t->TraderConnectStatus =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TraderConnectStatus"),"gbk","Error!"))[0];
  //发出连接请求的时间
  strcpy(t->ConnectRequestTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ConnectRequestTime"),"gbk","Error!")));
  //安装编号
  t->InstallID =   PyLong_AsLong(PyObject_GetAttrString(p, "InstallID"));
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //交易所代码
  strcpy(t->ExchangeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ExchangeID"),"gbk","Error!")));
  //交易所交易员代码
  strcpy(t->TraderID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TraderID"),"gbk","Error!")));
  //会员代码
  strcpy(t->ParticipantID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ParticipantID"),"gbk","Error!")));
  //发出连接请求的日期
  strcpy(t->ConnectRequestDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ConnectRequestDate"),"gbk","Error!")));
  //上次报告日期
  strcpy(t->LastReportDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LastReportDate"),"gbk","Error!")));
  //本席位最大成交编号
  strcpy(t->MaxTradeID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "MaxTradeID"),"gbk","Error!")));
  //启动时间
  strcpy(t->StartTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "StartTime"),"gbk","Error!")));
  //交易日
  strcpy(t->TradingDay, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TradingDay"),"gbk","Error!")));
  //本席位最大报单备拷
  strcpy(t->MaxOrderMessageReference, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "MaxOrderMessageReference"),"gbk","Error!")));
  //启动日期
  strcpy(t->StartDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "StartDate"),"gbk","Error!")));
  //本地报单编号
  strcpy(t->OrderLocalID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderLocalID"),"gbk","Error!")));
  //上次报告时间
  strcpy(t->LastReportTime, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "LastReportTime"),"gbk","Error!")));

  return t;
};

//错误报单
PyObject * new_CThostFtdcErrOrderField(CThostFtdcErrOrderField * p){
  if(p==NULL)
      return Py_None;
  return PyObject_CallMethod(mod, (char*)"CThostFtdcErrOrderField", (char*)"ccyyiciyciydiiiyyiydyycyc",
p->OrderPriceType, p->Direction, p->BrokerID, p->InvestorID, p->MinVolume, p->ForceCloseReason, p->VolumeTotalOriginal, p->InstrumentID, p->ContingentCondition, p->UserForceClose, p->ErrorMsg, p->StopPrice, p->RequestID, p->IsAutoSuspend, p->IsSwapOrder, p->UserID, p->GTDDate, p->ErrorID, p->BusinessUnit, p->LimitPrice, p->OrderRef, p->CombHedgeFlag, p->VolumeCondition, p->CombOffsetFlag, p->TimeCondition);
}
CThostFtdcErrOrderField * from_CThostFtdcErrOrderField(PyObject * p){
  CThostFtdcErrOrderField *t = (CThostFtdcErrOrderField *)calloc(1, sizeof(CThostFtdcErrOrderField));
  memset(t,0,sizeof(CThostFtdcErrOrderField));
  //报单价格条件
  //enum类型
  //THOST_FTDC_OPT_LastPricePlusOneTicks -> '5', 最新价浮动上浮1个ticks
  //THOST_FTDC_OPT_LastPricePlusTwoTicks -> '6', 最新价浮动上浮2个ticks
  //THOST_FTDC_OPT_BidPrice1PlusTwoTicks -> 'E', 买一价浮动上浮2个ticks
  //THOST_FTDC_OPT_AnyPrice -> '1', 任意价
  //THOST_FTDC_OPT_AskPrice1PlusTwoTicks -> 'A', 卖一价浮动上浮2个ticks
  //THOST_FTDC_OPT_AskPrice1PlusThreeTicks -> 'B', 卖一价浮动上浮3个ticks
  //THOST_FTDC_OPT_BidPrice1PlusThreeTicks -> 'F', 买一价浮动上浮3个ticks
  //THOST_FTDC_OPT_BestPrice -> '3', 最优价
  //THOST_FTDC_OPT_LimitPrice -> '2', 限价
  //THOST_FTDC_OPT_BidPrice1 -> 'C', 买一价
  //THOST_FTDC_OPT_AskPrice1PlusOneTicks -> '9', 卖一价浮动上浮1个ticks
  //THOST_FTDC_OPT_LastPricePlusThreeTicks -> '7', 最新价浮动上浮3个ticks
  //THOST_FTDC_OPT_LastPrice -> '4', 最新价
  //THOST_FTDC_OPT_AskPrice1 -> '8', 卖一价
  //THOST_FTDC_OPT_BidPrice1PlusOneTicks -> 'D', 买一价浮动上浮1个ticks
  t->OrderPriceType =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderPriceType"),"gbk","Error!"))[0];
  //买卖方向
  //enum类型
  //THOST_FTDC_D_Buy -> '0', 买
  //THOST_FTDC_D_Sell -> '1', 卖
  t->Direction =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "Direction"),"gbk","Error!"))[0];
  //经纪公司代码
  strcpy(t->BrokerID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BrokerID"),"gbk","Error!")));
  //投资者代码
  strcpy(t->InvestorID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InvestorID"),"gbk","Error!")));
  //最小成交量
  t->MinVolume =   PyLong_AsLong(PyObject_GetAttrString(p, "MinVolume"));
  //强平原因
  //enum类型
  //THOST_FTDC_FCC_Other -> '6', 其它
  //THOST_FTDC_FCC_ClientOverPositionLimit -> '2', 客户超仓
  //THOST_FTDC_FCC_NotMultiple -> '4', 持仓非整数倍
  //THOST_FTDC_FCC_PersonDeliv -> '7', 自然人临近交割
  //THOST_FTDC_FCC_NotForceClose -> '0', 非强平
  //THOST_FTDC_FCC_Violation -> '5', 违规
  //THOST_FTDC_FCC_MemberOverPositionLimit -> '3', 会员超仓
  //THOST_FTDC_FCC_LackDeposit -> '1', 资金不足
  t->ForceCloseReason =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ForceCloseReason"),"gbk","Error!"))[0];
  //数量
  t->VolumeTotalOriginal =   PyLong_AsLong(PyObject_GetAttrString(p, "VolumeTotalOriginal"));
  //合约代码
  strcpy(t->InstrumentID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "InstrumentID"),"gbk","Error!")));
  //触发条件
  //enum类型
  //THOST_FTDC_CC_AskPriceLesserThanStopPrice -> 'B', 卖一价小于条件价
  //THOST_FTDC_CC_Touch -> '2', 止损
  //THOST_FTDC_CC_BidPriceGreaterThanStopPrice -> 'D', 买一价大于条件价
  //THOST_FTDC_CC_LastPriceGreaterEqualStopPrice -> '6', 最新价大于等于条件价
  //THOST_FTDC_CC_AskPriceLesserEqualStopPrice -> 'C', 卖一价小于等于条件价
  //THOST_FTDC_CC_LastPriceGreaterThanStopPrice -> '5', 最新价大于条件价
  //THOST_FTDC_CC_AskPriceGreaterEqualStopPrice -> 'A', 卖一价大于等于条件价
  //THOST_FTDC_CC_LastPriceLesserThanStopPrice -> '7', 最新价小于条件价
  //THOST_FTDC_CC_BidPriceGreaterEqualStopPrice -> 'E', 买一价大于等于条件价
  //THOST_FTDC_CC_Immediately -> '1', 立即
  //THOST_FTDC_CC_LastPriceLesserEqualStopPrice -> '8', 最新价小于等于条件价
  //THOST_FTDC_CC_AskPriceGreaterThanStopPrice -> '9', 卖一价大于条件价
  //THOST_FTDC_CC_BidPriceLesserEqualStopPrice -> 'H', 买一价小于等于条件价
  //THOST_FTDC_CC_ParkedOrder -> '4', 预埋单
  //THOST_FTDC_CC_TouchProfit -> '3', 止赢
  //THOST_FTDC_CC_BidPriceLesserThanStopPrice -> 'F', 买一价小于条件价
  t->ContingentCondition =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ContingentCondition"),"gbk","Error!"))[0];
  //用户强评标志
  t->UserForceClose =   PyLong_AsLong(PyObject_GetAttrString(p, "UserForceClose"));
  //错误信息
  strcpy(t->ErrorMsg, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "ErrorMsg"),"gbk","Error!")));
  //止损价
  t->StopPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "StopPrice"));
  //请求编号
  t->RequestID =   PyLong_AsLong(PyObject_GetAttrString(p, "RequestID"));
  //自动挂起标志
  t->IsAutoSuspend =   PyLong_AsLong(PyObject_GetAttrString(p, "IsAutoSuspend"));
  //互换单标志
  t->IsSwapOrder =   PyLong_AsLong(PyObject_GetAttrString(p, "IsSwapOrder"));
  //用户代码
  strcpy(t->UserID, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "UserID"),"gbk","Error!")));
  //GTD日期
  strcpy(t->GTDDate, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "GTDDate"),"gbk","Error!")));
  //错误代码
  t->ErrorID =   PyLong_AsLong(PyObject_GetAttrString(p, "ErrorID"));
  //业务单元
  strcpy(t->BusinessUnit, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "BusinessUnit"),"gbk","Error!")));
  //价格
  t->LimitPrice =   PyFloat_AsDouble(PyObject_GetAttrString(p, "LimitPrice"));
  //报单引用
  strcpy(t->OrderRef, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "OrderRef"),"gbk","Error!")));
  //组合投机套保标志
  strcpy(t->CombHedgeFlag, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CombHedgeFlag"),"gbk","Error!")));
  //成交量类型
  //enum类型
  //THOST_FTDC_VC_CV -> '3', 全部数量
  //THOST_FTDC_VC_MV -> '2', 最小数量
  //THOST_FTDC_VC_AV -> '1', 任何数量
  t->VolumeCondition =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "VolumeCondition"),"gbk","Error!"))[0];
  //组合开平标志
  strcpy(t->CombOffsetFlag, PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "CombOffsetFlag"),"gbk","Error!")));
  //有效期类型
  //enum类型
  //THOST_FTDC_TC_IOC -> '1', 立即完成，否则撤销
  //THOST_FTDC_TC_GFS -> '2', 本节有效
  //THOST_FTDC_TC_GTD -> '4', 指定日期前有效
  //THOST_FTDC_TC_GFA -> '6', 集合竞价有效
  //THOST_FTDC_TC_GTC -> '5', 撤销前有效
  //THOST_FTDC_TC_GFD -> '3', 当日有效
  t->TimeCondition =   PyBytes_AsString(PyUnicode_AsEncodedString(PyObject_GetAttrString(p, "TimeCondition"),"gbk","Error!"))[0];

  return t;
};
