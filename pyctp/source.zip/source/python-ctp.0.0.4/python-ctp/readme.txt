

使用:
python generate_struct.py   ###创建数据结构
python generate_wrapper.py  ###创建接口层
分别创建数据结构和wrapper层

注意:
必须保证用于创建wrapper的C源代码 和 python接口代码 的一致性
即 两个pyd文件 和使用到两个pyd文件的 自动生成的.py文件必须是同一时刻生成的
否则会出现各种莫名其妙的问题.(由dict不保序引起)

