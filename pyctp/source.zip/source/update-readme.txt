
更新版本时的注意事项:
##注意,
即便只是对生成.py文件的代码部分进行了修改,也需要把重新生成的C++文件分别复制到相应项目并重新编译
初步估计是parse_struct或generate_struct中dict中项目的输出有随机性,所以不是一起生成的文件相互是不匹配的


A. python-ctp.0.0.4下的更新
   inc目录下的4个.h文件
   执行 
   python generate_struct.py   ###创建数据结构
   python generate_wrapper.py  ###创建接口层
   分别创建数据结构和wrapper层

   将生成的generated子目录下的文件分别更新到vcproject

B. vcproject下的更新位置
1. depends\python33_dep\ctp-include
2. depends\python33_dep\lib及下面的orignal

3. _ctp_python33\_ctp_Md 下的5个文件:
   _ctp_Md.cpp
   wrapper_Md.cpp
   wrapper_Md.h
   struct.cpp
   struct.h

4. _ctp_python33\_ctp_Trader 下的5个文件:
   _ctp_Trader.cpp
   wrapper_Trader.cpp
   wrapper_Trader.h
   struct.cpp
   struct.h

5. 用vc2010打开_ctp_python33下的_ctp_python33.sln
   双击即可自动打开
   重新生成(在Debug目录下)
   _ctp_Md.pyd
   _ctp_Trader.pyd

6. 将pyd文件和dll文件复制到
   vcproject/bin下
   

C. 将最新生成的文件复制到上级目录(ctp_api)下:
   MdApi.py
   TraderApi.py
   UserApiStruct.py
   UserApiType.py
   _ctp_Md.py
   _ctp_Trader.py
   thostmduserapi.dll
   thosttraderapi.dll
