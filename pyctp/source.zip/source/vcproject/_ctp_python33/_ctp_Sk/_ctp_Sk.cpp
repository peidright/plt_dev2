/*

A wrapper for CTP's Api library
author: Lvsoft@gmail.com
date: 2010-07-20

This file is part of python-ctp library

python-ctp is free software; you can redistribute it and/or modify it
under the terms of the GUL Lesser General Public License as published
by the Free Software Foundation; either version 2.1 of the License, or
(at your option) any later version.

python-ctp is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY of FITNESS FOR A PARTICULAR PURPOSE. See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along the python-ctp; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
02110-1301 USA
*/

#pragma warning(disable : 4996)

//#include <Python.h>
#ifdef _DEBUG
#undef _DEBUG   //links to pythonxx.lib
#include <Python.h>
#define _DEBUG
#else
#include <Python.h>
#endif

PyMODINIT_FUNC PyInit__ctp_Sk()
{
   static PyMethodDef mbMethods[] = {
     /*{"create_MdApi", create_MdApi, METH_VARARGS},
     {"register_struct", register_struct, METH_VARARGS},

     {"RegisterFensUserInfo", Md_RegisterFensUserInfo, METH_VARARGS} ,
     {"RegisterNameServer", Md_RegisterNameServer, METH_VARARGS} ,
     {"RegisterFront", Md_RegisterFront, METH_VARARGS} ,
     {"RegisterSpi", Md_RegisterSpi, METH_VARARGS} ,
     {"Join", Md_Join, METH_VARARGS} ,
     {"Release", Md_Release, METH_VARARGS} ,
     {"SubscribeMarketData", Md_SubscribeMarketData, METH_VARARGS} ,
     {"GetTradingDay", Md_GetTradingDay, METH_VARARGS} ,
     {"ReqUserLogin", Md_ReqUserLogin, METH_VARARGS} ,
     {"Init", Md_Init, METH_VARARGS} ,
     {"UnSubscribeMarketData", Md_UnSubscribeMarketData, METH_VARARGS} ,
     {"ReqUserLogout", Md_ReqUserLogout, METH_VARARGS} ,
	 */
     {NULL, NULL, NULL} /*sentinel，哨兵，用来标识结束*/
   };

    static struct PyModuleDef moduledef = { //0.04 update
        PyModuleDef_HEAD_INIT,
        "_ctp_Sk",     /* m_name */
        "ctp sk module",  /* m_doc */
        -1,                  /* m_size */
        mbMethods,    /* m_methods */
        NULL,                /* m_reload */
        NULL,                /* m_traverse */
        NULL,                /* m_clear */
        NULL,                /* m_free */
    };
    PyObject *m = PyModule_Create(&moduledef);
   

    PyEval_InitThreads();
	return m;
}

