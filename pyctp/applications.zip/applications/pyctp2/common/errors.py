# -*- coding: utf-8 -*-

class TradeError:
    UNKNOWN = -1
    TIME_ERROR = 1001   #下单时间错, 合约不在交易时间

