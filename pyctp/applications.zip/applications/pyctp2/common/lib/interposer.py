# -*- coding:utf-8 -*-

"""
    动态配置器
"""

class Interposer(object):
    pass
